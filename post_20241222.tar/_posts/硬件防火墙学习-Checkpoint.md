---
title: 硬件防火墙学习-Checkpoint
date: 2018-12-14 23:43:58
tags: 硬件
---

# 前言

最近接触到硬件防火墙设备，想初步学习一下。前辈推荐去 checkpoint 官网上面下载试用的 iso 镜像 ， 自己搭建一个虚拟机系统地学习。

开始做准备工作：

* Checkpoint 官网 ： https://www.checkpoint.com
* 账户注册 ： https://usercenter.checkpoint.com/usercenter/portal/user/anon/page/createProfile.psml  （这里有一个坑，需要页面显示一个验证窗口，需要勾选“我不是机器人选项”才能通过注册）
* 创建 UC Accounts ， 在下载试用品的时候需要注册该账号。

# 安装 R80.10 

装载 ISO 镜像 ， 进入虚拟机。

安装过程跟 Linux Server 安装过程差不多。

Partition Configuration 分区配置，默认如下：

| Name | Size |
|:----:|:----:|
|swap|2GB|
|root|10GB|
|Logs|2GB|
|Backup and upgrade| 35GB|

Account Configuration 账号配置 ， 默认的账户名为 "admin" 。

Management Interface 管理端口设置，我的如下：

| Type | Value |
|:-----:|:-----:|
|IP address|10.1.1.x|
|Netmask|255.255.255.0|
|Default gateway|10.1.1.x|
