---
title: Windows查找账户被禁用的脚本
tags:
  - Powershell
  - 脚本
categories:
  - Windows Server
date: 2021-11-30 02:28:40
---

# 需求

收集一个目录下所有文件夹名，收集这些以AD命名的文件夹名，确认这些用户是否被禁用了。

# 脚本

收集账户名

```ps1
Get-ChildItem D:\ | select name >> Account.list
```

处理账户

```ps1
Get-Content D:\Account.list | ForEach-Object {

  echo $_ > accountInfo.temp
  net user $_ /domain | findstr "Account" | findstr "No" >> acountInfo.temp

  if( $(Get-Content accountInfo.temp).Length -eq 2)
  {
    # Work Here!
  }
}
```

> 注：如果powershell的出来的是乱码，则需要将页面编码改成UTF-8，临时生效的指令为 chcp 65001 。
