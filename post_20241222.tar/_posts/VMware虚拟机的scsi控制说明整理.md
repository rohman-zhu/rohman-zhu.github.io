---
title: VMware虚拟机的scsi控制说明整理
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2021-11-07 23:23:22
---
# 背景

业务场景A中，对存储性能有较高的要求，IOPS最高可以达到5w左右。然而在整套架构review过程中，发现未到达存储瓶颈，从vRealize与OS中观测到IOPS一致，并未达到存储的瓶颈，并且虚拟机的CPU负载正常，并未出现争用情况。

因此，猜测瓶颈可能在虚拟化中。

# 说明

## SCSI上限

每个虚拟机最多可有四个 SCSI 控制器和四个 SATA 控制器。默认 SCSI 或 SATA 控制器为 0。创建虚拟机时，会将默认硬盘分配给总线节点 (0:0) 上的默认控制器 0。

## 序号

如果添加了 SCSI 控制器，可将现有或新硬盘或者设备重新分配给该控制器。例如，可将设备分配给 (1:z)，其中 1 是指 SCSI 控制器 1，z 是指从 0 到 15 这一范围的虚拟设备节点。对于 SCSI 控制器，z 不能为 7。默认情况下，虚拟 SCSI 控制器分配给虚拟设备节点 (z:7)，因此该设备节点不可用于硬盘或其他设备。

如果添加了 SATA 控制器，可将现有或新硬盘或者设备重新分配给该控制器。例如，可将设备分配给 (1:z )，其中 1 是指 SATA 控制器 1，z 是指从 0 到 29 这一范围的虚拟设备节点。对于 SATA 控制器，可以使用设备节点 0 到 29，包括 0:7。

或者，每个虚拟机最多可有四个 NVMe 控制器。可将现有或新的硬盘或设备重新分配给该控制器。例如，可将硬盘分配给 (x:z )，其中 x 是 NVMe 控制器，z 是虚拟设备节点。x 的值为 0 至 3，z 的值为 0 至 14。

## VMware 准虚拟化SCSI控制器

VMware 准虚拟 SCSI 控制器是高性能存储控制器，可提高吞吐量并减少 CPU 使用量。这些控制器最适合于高性能存储环境。

### 更改为准虚拟化控制后

若是有较高IO需求的场景，可以这么设置。

#### ESXi

```sh
## 通过在服务控制台上运行相应命令，验证当前加载的 HBA 模块：
## 对于 QLogic：

esxcli system module list | grep qla

## 对于 Emulex：

esxcli system module list | grep lpfc

## 通过运行以下命令之一将队列深度设置为 128：
## 对于 QLogic：

esxcli system module parameters set -p ql2xmaxqdepth=128 -m qla2xxx

## 对于 Emulex：
## 如果主机上的所有 Emulex 卡都需要更新，则应用全局参数 lpfc_lun_queue_depth。

esxcli system module parameters set -p lpfc0_lun_queue_depth=128 -m lpfc820

# 在以上命令中，ql2xmaxqdepth 和 lpfc0 都使用小写字母 L，而不是数字 1。

# 重启ESXi
reboot

# 验证
esxcli system module parameters list -m driver
```

#### 虚拟机OS内设置

在 Windows 虚拟机或 Linux 虚拟机中增加 PVSCSI 队列深度，如以下各节所述。此修改不但会将 PVSCSI 适配器用于请求环的页数增加到 32，而且会将附加到 PVSCSI 适配器的设备的队列深度增加到 254。

Windows 虚拟机

添加注册表后重启

```reg
REG ADD HKLM\SYSTEM\CurrentControlSet\services\pvscsi\Parameters\Device /v DriverParameter /t REG_SZ /d "RequestRingPages=32,MaxQueueDepth=254"
```

验证

```sh
# 通过在命令行中运行 REGEDIT 命令来打开注册表编辑器。
# 浏览到 HKLM\SYSTEM\CurrentControlSet\services\pvscsi\Parameters\Device。
# 验证 DriverParameter 项是否存在，并验证此项的值是否为 RequestRingPages=32、MaxQueueDepth=254。
```
Linux虚拟机

```sh
# 在 /etc/modprobe.d/ 目录中创建包含以下行的任意名称文件：

options vmw_pvscsi cmd_per_lun=254 ring_pages=32

#注意：对于 RHEL5，请使用相同的行来编辑 /etc/modprobe.conf。创建新的 initrd，以使设置生效。您可以通过使用 mkinitrd 或重新运行 vmware-config-tools.pl 来执行此操作。自版本 6 起，RHEL 使用 modprobe.d。

#或者，您也可以将以下行附加到内核引导参数（例如，在 Red Hat Enterprise Linux 上编辑 /etc/grub.conf，或在 Ubuntu 上编辑 /boot/grub/grub.cfg）。

vmw_pvscsi.cmd_per_lun=254
vmw_pvscsi.ring_pages=32

#重新引导虚拟机。
reboot

#通过对以下文件使用 cat 命令来验证更改后的队列深度：

cat /sys/module/vmw_pvscsi/parameters/cmd_per_lun
cat /sys/module/vmw_pvscsi/parameters/ring_pages
```


### 注意

如果在安装客户机操作系统后更改控制器类型，将导致磁盘和连接到适配器的任何其他设备无法访问。在更改控制器类型或添加新控制器之前，请确保客户机操作系统安装介质包含所需的驱动程序。在 Windows 客户机操作系统上，驱动程序必须作为引导驱动程序进行安装和配置。

# 参考资料

https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.vm_admin.doc/GUID-5872D173-A076-42FE-8D0B-9DB0EB0E7362.html

https://blog.51cto.com/weili163/1681408

关于磁盘：
https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.monitoring.doc/GUID-F31D1FA6-C90D-438D-B6E5-DC4B41199131.html

磁盘性能问题解决方案：
https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.monitoring.doc/GUID-E813116C-9D72-4464-BF3E-1B19F70F45BE.html

https://blog.csdn.net/vic_qxz/article/details/120554882
https://kb.vmware.com/s/article/2053145?lang=zh_cn