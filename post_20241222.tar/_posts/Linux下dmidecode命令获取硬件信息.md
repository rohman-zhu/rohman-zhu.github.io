---
title: Linux下dmidecode命令获取硬件信息
tags:
  - 工具
categories:
  - Linux
date: 2020-05-30 21:44:32
---
# dmidecode

dmidecode在 Linux 系统下获取有关硬件方面的信息。dmidecode 遵循 SMBIOS/DMI 标准，以一种可读的方式dump出机器的DMI(Desktop Management Interface)信息, 其输出的信息包括 BIOS、系统、主板、处理器、内存、缓存等等, 既可以得到当前的配置，也可以得到系统支持的最大配置，比如说支持的最大内存数等。

# 安装

```sh
# Debian/Ubuntu
aptitude install dmidecode
# Fedora
yum installl dmidecode
# Arch Linux
pacman -S dmidecode
# Gentoo
emerge -av dmidecode
```

# 使用

```sh
# 1、查看内存槽数、那个槽位插了内存，大小是多少
dmidecode|grep -P -A5 "Memory\s+Device"|grep Size|grep -v Range

# 2、查看最大支持内存数

dmidecode|grep -P 'Maximum\s+Capacity'

# 3、查看槽位上内存的速率，没插就是unknown。

dmidecode|grep -A16 "Memory Device"|grep 'Speed'
```

输出格式：

```sh
Handle 0×0002
DMI type 2, 8 bytes
Base Board Information
Manufacturer:Intel
Product Name: C440GX+
Version: 727281-0001
Serial Number: INCY92700942
```

1. recode id(handle): DMI表中的记录标识符，这是唯一的,比如上例中的Handle 0×0002。
2. dmi type id: 记录的类型，譬如说:BIOS，Memory，上例是type 2，即”Base Board Information”
3. recode size: DMI表中对应记录的大小，上例为8 bytes.（不包括文本信息，所有实际输出的内容比这个size要更大。）
记录头之后就是记录的值：
4. decoded values: 记录值可以是多行的，比如上例显示了主板的制造商(manufacturer)、model、version以及serial Number。

```sh
# 最简单的的显示全部dmi信息：
#这样将输出所有的dmi信息，你可能会被一大堆的信息吓坏，通常可以使用下面的方法。
dmidecode


# 2.更精简的信息显示：
# -q(–quite) 只显示必要的信息，这个很管用哦。

dmidecode -q

# 3.显示指定类型的信息：
# 通常我只想查看某类型，比如CPU，内存或者磁盘的信息而不是全部的。这可以使用-t(–type TYPE)来指定信息类型：
# (显示bios和processor)
dmidecode -t 0,4 

# 4. 通过关键字查询信息
dmidecode -s system-serial-number
#-s (–string keyword)支持的keyword包括：bios-vendor,bios-version, bios-release-date,system-manufacturer, system-product-name, system-version, system-serial-number,baseboard-manu-facturer,baseboard-product-name, baseboard-version, baseboard-serial-number, baseboard-asset-tag,chassis-manufacturer, chas-sis-version, chassis-serial-number, chassis-asset-tag,processor-manufacturer, processor-version.
```

Type Information

```conf
0 BIOS
1 System
2 Base Board
3 Chassis
4 Processor
5 Memory Controller
6 Memory Module
7 Cache
8 Port Connector
9 System Slots
10 On Board Devices
11 OEM Strings
12 System Configuration Options
13 BIOS Language
14 Group Associations
15 System Event Log
16 Physical Memory Array
17 Memory Device
18 32-bit Memory Error
19 Memory Array Mapped Address
20 Memory Device Mapped Address
21 Built-in Pointing Device
22 Portable Battery
23 System Reset
24 Hardware Security
25 System Power Controls
26 Voltage Probe
27 Cooling Device
28 Temperature Probe
29 Electrical Current Probe
30 Out-of-band Remote Access
31 Boot Integrity Services
32 System Boot
33 64-bit Memory Error
34 Management Device
35 Management Device Component
36 Management Device Threshold Data
37 Memory Channel
38 IPMI Device
39 Power Supply
```

# 实例： 查看当前服务器支持可扩容的内存

```sh
# 查看当前内存大小
free 
cat /proc/meminfo

# 使用dmidecode
dmidecode -t 16 | grep Maximum

# 查看内存插槽
dmidecode -t 17
dmidecode -t 17 | grep Size
# 如果Size为No Module Installed 表示该插槽当前未有插入内存。
```

# 参考资料

http://www.ttlsa.com/linux/the-linux-dmidecode-command-to-get-the-hardware-information/