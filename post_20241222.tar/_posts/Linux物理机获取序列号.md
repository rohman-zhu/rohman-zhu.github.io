---
title: Linux物理机获取序列号
tags:
  - 物理机获取序列号
categories:
  - Linux
date: 2021-06-20 23:09:29
---

# 常见操作

## 获取系统序列号

```sh
dmidecode -t system | grep 'Serial Number'
```

## 获取硬盘序列号

```sh
lsblk --nodeps -no serial /dev/sd[x]
```
