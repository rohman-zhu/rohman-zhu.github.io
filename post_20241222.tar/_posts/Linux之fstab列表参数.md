---
title: Linux之fstab列表参数
tags:
  - default
categories:
  - Linux
date: 2020-12-24 09:27:05
---
# /etc/fstab

```config
一般配置6个参数  ：<file system>，<mount point>，<type>，<options>，<dump>，<pass>

file system
文件系统，参考默认的fstab来看，这里只需要把硬盘的UUID正确配置即可；可以通过指令blkid，查看硬盘的UUID；

mount point
挂载路径，最终硬盘会被挂载到配置的这个路径下，但是这个路径必须先存在，提前创建好这个路径即可；

type
硬盘的文件系统类型，相应的有ntfs，ext4，fat，vfat等等，这里要根据实际情况设置，同样的也可以通过指令blkid，查看硬盘的TYPE；

options

dump
这个参数用来检查文件系统以多快频率进行备份，系统将认为其值为0，则不需要进行备份；

pass
这个参数用来决定在启动时需要被fsck扫描的文件系统的顺序，根文件系统"/"对应该字段的值应该为1，其他的应该逐渐递增，如果设置为0则表示不扫描。
```