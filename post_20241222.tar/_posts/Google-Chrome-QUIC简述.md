---
title: Google Chrome-QUIC简述
tags:
  - default
categories:
  - default
date: 2021-06-20 23:32:29
---
# 说明

用户需要通过AC来控制上网行为，一部分用户默认不允许访问外网。如果有访问外网行为，则会被禁止。

而谷歌浏览器使用QUIC协议，AC会将此访问行为判定为非法行为，因此会封禁。

## QUIC 说明

这批网址使用的是QUIC协议：https://baike.baidu.com/item/QUIC/17341272?fr=aladdin  
因此导致断网组用户在不登录上网验证时可以正常访问外网的部分页面（QUIC协议）  