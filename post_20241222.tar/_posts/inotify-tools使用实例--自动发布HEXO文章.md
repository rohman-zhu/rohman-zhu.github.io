---
title: inotify-tools使用实例--自动发布HEXO文章
date: 2019-04-05 15:54:37
tags: Linux
---

# inotify-tools使用实例--自动发布HEXO文章

## 前言

由于使用的是HEXO来编写博客，每次内容修改都希望能够自动发版，而不需要人为干预。因此想到用inotify-tools这个开源工具来做最合适不过了。

环境：

* OS ： Ubuntu-16.04
* Kernel ： 4.4.0-131

## 操作记录

文章目录 : /home/hexo/_post/

流程：

1. 监控文章目录
2. 只要有文章变更
3. 执行 hexo g && hexo s 指令
4. 最终确定没有问题，手动发布到Github ，hexo s

### 在Ubuntu中安装 inotify-tools

```sh
# 采用apt安装方式
apt-get install inotify-tools -y
# 安装完后会有两个命令
inotifywait
inotifywatch
```

### 编写文件监控脚本

```sh
#!/bin/bash
# Author : Rohman
# Date : 2019-4-5
# Version : v1

log_file=/home/hexo/log/generator.log
watch_path=/home/hexo/source
update()
{
    if [[ -a $log_file ]]
    then
        echo "----------------------------" >> $log_file
        echo `date +"%Y-%m-%d %H:%M:%S"` >> $log_file
        echo "----------------------------" >> $log_file
    else
        touch $log_file
    fi


    hexo_pid=$(ps -a | grep -w hexo | awk -F " " '{print $1}')
    echo "DEBUG : Hexo Server PID is $hexo_pid" >> $log_file

    hexo g >> $log_file
    if [[ $hexo_pid -gt 0 ]]
    then
        kill -9 $hexo_pid
    fi
    hexo g >> $log_file
    hexo s  >> $log_file &
}

inotifywait -mrq --timefmt '%Y/%m/%d %H:%M' --format '%T %w%f %e' --event create,modify,delete $watch_path | while read date time file event
do
    case $event in
        MODIFY | CREATE | DELETE | CREATE,ISDIR | DELETE,ISDIR | MODIFY,ISDIR)
            update
            ;;
    esac
done

```

### 添加到开机自启程序中

由于使用的是Ubuntu ，没有`chkconfig servername on` 的方法（CentOS），但是可以在 /etc/rc.local 文件中添加运行脚本。

```sh
# rc.local

sh - hexo -c "nuhup /home/hexo/update_notify.sh"
```

> 在 rc.local 文件中运行的脚本默认都是root账户启动的， 如果不指定hexo用户，这会导致初始化的`hexo s`进程无法被hexo检测到。

## 参考资料：

* 《通过inotify-tools实现监控文件变化》：https://weizhimiao.github.io/2016/10/29/Linux%E4%B8%AD%E9%80%9A%E8%BF%87inotify-tools%E5%AE%9E%E7%8E%B0%E7%9B%91%E6%8E%A7%E6%96%87%E4%BB%B6%E5%8F%98%E5%8C%96/