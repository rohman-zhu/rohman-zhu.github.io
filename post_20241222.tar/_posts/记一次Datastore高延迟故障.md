---
title: 记一次Datastore高延迟故障
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2020-11-29 23:28:57
---
# 故障现象

虚拟机上面看到iowait与磁盘利用率达到100%以上，延迟非常高。

# 原因分析

底层datastore负载过高。

进入看到虚拟机的虚拟磁盘的读取延迟非常高。大于20ms

一般情况下，10ms以内的延迟是能接受的。而DB的延迟大于20ms，则会出现告警。


# 解决方法

将虚拟机迁移至空闲的datastore或者ssd 存储。