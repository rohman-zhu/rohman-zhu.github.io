---
title: Windows更新服务
tags:
  - wsus
catergories:
  - WindowsServer
date: 2020-01-25 19:40:37
---

# 前置条件

## 端口

- 在 WSUS 3.2 及更早版本中，端口 80 用于 HTTP，443 用于 HTTPS
- 在 WSUS 6.2 及更高版本（至少为 Windows Server 2012）中，端口 8530 用于 HTTP，8531 用于 HTTPS

## wsus服务器中正确的分组

## ad服务器中合适的ou

# 客户端操作

```cmd
wuauclt.exe /detectnow
```

# 参考资料

https://docs.microsoft.com/zh-cn/windows-server/administration/windows-server-update-services/deploy/2-configure-wsus
