---
title: Linux的Swap、Cache、Buffer
tags:
  - default
categories:
  - Linux
date: 2020-12-17 23:33:16
---
# 通过 free 查看Linux的内存

```sh
# total 总内存大小
# used 已使用的内存大小（这里包含 cached 、 buffers 、 shared 部分）
# free ： 空闲的内存大小。
# shared： 进程间共享的存储（一般不会使用，可以忽略）
# buffers： 内存中写完的东西缓存起来，这样快速响应请求，后面数据再定期刷到磁盘上。
# cached：内存中读完缓存起来内容占的大小。（这部分是为了下次查询时能快速返回）

# -/+ buffers/cache 看做两部分：

# -buffers/cache：正在使用的内存大小（注意不是used部分，因为buffers和cached并不是正在使用的，组织和人民需要是它们是可以释放的），其值=used-buffers-cached。

#+buffers/cache：可用的内存大小（同理也不是free表示的部分），其值=free+buffers+cached。

#Swap：硬盘上交换分区的使用大小。

#设计的目的就是当上面提到的+buffers/cache表示的可用内存都已使用完，新的读写请求过来后，会把内存中的部分数据写入磁盘，从而把磁盘的部分空间当做虚拟内存来使用。
```

# 关于Buffer和Cache

数据处理流程

|序号|详情|
|:----:|:-----:|
|1|CPU|
|2|Cache 高速缓存|
|3|内存|
|4|Buffer I/O缓存|
|5|硬盘|

- Cache（缓存），为了调高CPU和内存之间数据交换而设计.
- Buffer（缓冲）为了提高内存和硬盘（或其他I/O设备的数据交换而设计）

```cache
Cache主要是针对读操作设计的，不过Cache概念可能容易混淆，我理解为CPU本身就有Cache，包括一级缓存、二级缓存、三级缓存，我们知道CPU所有的指令操作对接的都是内存，而CPU的处理能力远高于内存速度，所以为了不让CPU资源闲置，Intel等公司在CPU内部集成了一些Cache，但毕竟不能放太多电路在里面，所以这部分Cache并不是很大，主要是用来存放一些常用的指令和常用数据，真正大部分Cache的数据应该是占用内存的空间来缓存请求过的数据，即上面的Cached部分（这部分纯属个人理解，正确与否有待考证）。
```

```buffer
Buffer主要是针对写操作设计的，更细的说是针对内存和硬盘之间的写操作来设计的，目的是将写的操作集中起来进行，减少磁盘碎片和硬盘反复寻址过程，提高性能。
```

# 常见问题

## 在Linux中频繁存取文件，物理内存很快用光，而cached一直在增长。

Linux会对每次请求过的数据缓存在cache里，好处就是CPU的处理速度远远高于内存，所以在CPU和内存通讯的时候可以快速从cache中命中结果返回。

##  Swap被占用。

内存可能不够了，才会占Swap，所以Swap可以作为服务器监控的一项指标，引起注意。

# 手动清理Swap和buffers/cache

## 清理swap

```sh
swapoff -a && swapon -a

#如果已经使用了Swap，且当前清空下+buffers/cache还有空间，在执行  swapoff -a操作时，会触发把Swap中的内容交换到内存中，数据不会丢失。
```

> 此操作相当于 swap空间 “重启”。

## 清理buffers 、 cache

```sh
# sync 目的是将缓存的内容写回到硬盘中
sync

# 修改drop_caches的值为3，默认为0，改为3系统会清理缓存的内容。
echo 3 > /proc/sys/vm/drop_caches

#sleep 2让上述指令执行完毕
sleep 2

# 改为默认值
echo 0 > /proc/sys/vm/drop_caches
```


