---
title: ESXi安装补丁
tags:
  - ESXi
  - 补丁
categories:
  - VMware
  - vSphere
date: 2021-11-07 22:09:04
---
# 背景

VMware 的产品定期都会发布补丁，需要手动安装补丁。

# 步骤

1. 迁移虚拟机，将此ESXi上的虚拟机迁移至其他ESXi中。
2. 将目标ESXi进入维护模式，设置好告警维护窗口。
3. 安装补丁。

## 补丁下载

需注册账户

https://customerconnect.vmware.com/patch

## 安装补丁

将补丁上传至目标ESXi的Datastore

执行指令

```sh
# 查看当前ESXi版本号
vmware -v

# 安装补丁
esxcli software vib install -d="/vmfs/volumes/磁盘路径/ESXi550-201406001.zip" 
```


