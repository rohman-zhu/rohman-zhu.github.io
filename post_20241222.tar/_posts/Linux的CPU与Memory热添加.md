---
title: Linux的CPU与Memory热添加
date: 2020-01-05 17:06:35
tags:
- 虚拟化
categories:
- Linux
---

# 前言

在 vSphere 底层为虚拟机热添加CPU和内存后，一般操作系统都需要重启后才能识别。但是目前常用的Linux操作系统其实已经支持热添加的方式，需要到Linux中修改一下即可。

## 发现CPU

将cpu文件夹中的online文件状态由0改为1即可。

```sh
#如已添加cpu4
echo 1 > /sys/devices/system/cpu/cpu4/online
```

## 发现Memory

Discover Memory script:

```sh
for RAM in $(grep line /sys/devices/system/memory/*/state)
do
 echo "Found ram: ${RAM}.. ."
 if [[ "${RAM}" == *":offline" ]]; then
    echo "Bringing online"
    echo $RAM | sed "s/:offline$//" | sed "s/^/echo online>/" | source /dev/stdin
 else
    echo "Already online"
 fi
 done
```

## 参考资料

CPU  hotplug in the kernel : https://www.kernel.org/doc/html/v4.11/core-api/cpu_hotplug.html
修改脚本 ： https://juejin.im/entry/5ab374adf265da2380598d3c
