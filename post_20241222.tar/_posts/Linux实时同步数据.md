---
title: Linux实时同步数据
date: 2017-10-15 17:31:32
tags: Linux
---
# 实时同步数据 #

有两款软件较为常用:

* inotify
* sersync

## 1.inotify ##

Inotify是一种强大的,异步的文件系统事件监听机制,linux内核从2.6.13起,加入了Inotify支持.

### 1.1检查当前版本是否支持inotify工具 ###

* 检查内核版本 : uname -r

内核版本大于2.6.13即可以

* ls -l /proc/sysy/fs/inotify/

出现下面三条信息即可

```{normal}
$ ls -l /proc/sys/fs/inotify/
total 0
-rw-r--r-- 1 root root 0 Oct 15 08:29 max_queued_events
-rw-r--r-- 1 root root 0 Oct 15 08:29 max_user_instances
-rw-r--r-- 1 root root 0 Oct 15 08:29 max_user_watches
```

### 1.2安装源码包软件步骤(三步) ###

#### 1.2.1解压 ####

tar zxf 软件包.tar

#### 1.2.2切换到该目录 ####

cd 软件包

#### 1.2.3make && make install ####

> ./configure --prefix=/usr/local/软件包名字
> make && make install

### 1.3 inotify 的两个命令 ###

* inotifywait : 在被监控的文件或目录上等特定文件系统事件(open\close\delete等)发生,执行后处于阻塞状态,适合在shell脚本中使用.
* inotifywatch : 收集被监视的文件系统使用统计数据,指文件系统事件发生的次数统计.

#### 1.3.1inotifywait 参数 ####

> [inotify-tools-3.14]# ./bin/inotifywait --help
</br>
./bin/inotifywait

| 参数 | 意义 |
|:----:|:----:|
|-m|永远监控事件|
|-r|递归查询整个目录|
|-q|打印少量的信息,之显示日志|
|-e|监听事件类型|

```{.event}
access   file or directory contents were read
modify   file or directory contents were written
attrib   file or directory attributes changed
close_write  file or directory closed, after being opened in writeable mode
close_nowrite   file or directory closed, after being opened in read-only mode
close    file or directory closed, regardless of read/write mode
open     file or directory opened
moved_to    file or directory moved to watched directory
moved_from  file or directory moved from watched directory
move    file or directory moved to or from watched directory
create      file or directory created within watched directory
delete   file or directory deleted within watched directory
delete_self  file or directory was deleted
unmount     file system containing file or directory unmounted
```

### inotify.sh 脚本 ###

```{.script}
# 把脚本固定在/server/scripts目录里面
# mkdir -p /server/scripts
# vim inotify.sh

#!/bin/bash
inotify=/usr/local/inotify-tools/bin/inotifywait
$inotify -mrq --format '%w%f' -e create,close_write,delete /oldboy  \
|while read file
do
    cd /oldboy &&
    rsync -ac ./ --delete rsync_backup@10.0.0.7::oldboy \ --password-file=/etc/rsync.password
done
:wq

# 检查
# sh -x /server/scripts/inotify.sh
```

## 应用案例 ##

* 客户端 10.0.0.x
* 服务端 10.0.0.7

### 客户端 ###

需要以下几个条件:

* 需要监控的目录
* rsync的密码文件
* inotify脚本
* 启动脚本

这里我们用的例子中:

* 被监控的目录在 /data 中
* 密码文件 /etc/rsync.password
* 脚本 /server/scripts/inotify.sh

```{.normal}
# 创建需要监控的目录
# mkdir /data
# mkdir -p /server/scripts

# 编写脚本
# vim /server/scripts/inotify.sh

# 创建rsync用的密码文件
# echo oldboy > /etc/rsync.password
# chmod 600 /etc/rsync.password

#!bin/bash
inotify=/usr/local/inotify-tools/bin/inotifywait
$inotify -mrq --format '%w%f' -e create,close_write,delete /oldboy  \
|while read file
do
    cd /oldboy &&
    rsync -ac ./ --delete rsync_backup@10.0.0.7::oldboy \ --password-file=/etc/rsync.password
done
:wq

# 编译脚本
# sh -x /server/scripts/inotify.sh

# 运行脚本
# bin/sh /server/scripts/inotify.sh

# 添加到开机自启动项目
# echo bin/sh /server/scripts/inotify.sh

```

### 服务端 ###

需要以下几个条件:

* 存放备份文件的目录 /backup
* rsync用的配置文件 rsyncd.conf
* rsync认证用的用户与密码文件 rsyncd.password
* 开启daemon模式的rsync 服务

```{.normal}

# 创建配置文件
# vim /etc/rsyncd.conf
#Rsync server
#Created by Roman 2017-10-15 14:50
##rsyncd.conf start##
uid = rsync
gid = rsync
use chroot = no
max connection = 200
timout =600
pid file =/var/run/rsyncd.pid
lock file = /var/run/rsync.lock
log file = /var/log/rsyncd.log
ignore errors
read only = false
list = false
hosts allow = 10.0.0.0/24
auth users = rsync_backup
secrets file = /etc/rsync.password
############################
[backup]
comment = backup by roman 14:50 2017-10-15
path = /backup/
:wq

# echo "rsync_backup:oldboy" > /etc/rsync.password

# mkdir /backup

# rsync --daemon
```

## inotify 优点 ##

实时数据同步

## inotify 缺点 ##

1. 并发如果大于200个文件(10-100K),不同会有延迟.
1. 每一次都是全部推送一次,确实是增量的.
1. 监控到事件后,调用 rsync 同步是单进程的(加并发),sersync多进程同步.

既然有了inotify-tools,为什么还要开发sersync?
</br>
sersync功能多:

1. 配置文件
1. 真正的守护进程socket
1. 可以对失败文件定时重传
1. 第三方的HTTP接口
1. 默认多线程同步