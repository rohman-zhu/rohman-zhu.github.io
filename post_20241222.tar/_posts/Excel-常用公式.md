---
title: Excel-常用公示
tags:
  - default
categories:
  - default
date: 2024-03-17 17:48:49
---

# 比较两个日期间隔多少小时

```
cell 1 = 2024-03-17 17:50
cell 2 = 2024-03-28 20:00

间隔天 = (cell2 - cell1) 
间隔小时 = (cell2 - cell1) * 24

```

# 比较两个日期间隔天、月、年

```
cell 1 = 2024-03-17 17:50
cell 2 = 2024-03-28 20:00
天=datedif(cell1,cell2,"d")
月=datedif(cell1,cell2,"m")
天=datedif(cell1,cell2,"d")
```

# 保留小数位

```
round(number,num_digits)
```