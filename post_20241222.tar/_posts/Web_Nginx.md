---
title: Web服务之Nginx
date: 2017-10-20 19:06:50
tags: Linux
---
# Web #

这是一个web服务架,Linux + Apache + MySQL + PHP

> 实现WWW服务的常用Web软件 : nginx 和 apache(静态Web软件)

流行的Web组合:

* LAMP = Linux + Apache + MySQL + PHP
* LNMP = Linux + Nginx + MySQL +PHP

## Nginx(读:Engine x) ##

www服务软件,由俄罗斯人开发,开源,性能很高,C语言开发的(780K)

Nginx本身是一款静态(html,js,css等)的www软件,不能解析动态的PHP,JSP,DO.

最大特点:

1. 配置简单,灵活,轻量
1. 静态小文件(1M) , 支持高并发,同时占用的资源很少.3W并发,10个进程,内存150M.
1. 支持的平台 : Unix,Linux,windows
1. 支持epoll模型,使得Nginx可以支持高并发(Apache使用的是select模型)
1. 支持rewrite模块
1. 支持HTTP限速
1. 支持虚拟主机
1. ...等等

并发参考值:

* Nginx 1-3W访问量
* php 300-800访问量
* DB 300-800访问量

Nginx服务从大方向的功能:

1. www web服务,邮件服务,邮件代理
1. 负载均衡(反向代理proxy)
1. web cache(web缓存),相当于squid

### 应用场合 ###

1. 提供静态服务(图片.视频服务),另一个lighttpd.
1. 提供动态服务 , nginx + fastcgi的方式运行PHP,jsp.
1. 提供反向代理(proxy)服务,或者称负载均衡.
1. 缓存业务,类似Squid,Varnish,ats.

### 支持虚拟主机 ###

一个Server标签就是一个虚拟主机.

1. 基于域名和虚拟主机.通过域名来区分虚拟主机
1. 基于端口的虚拟主机.
1. 基于IP的虚拟主机.(几乎不用)

### 安装Nignx ###

#### 安装PCRE ####

Perl Compatiable Regular Expressions

安装方式:

```{.LinuxCommand}
# wget http://sourceforge.net/projects/pcre/files/pcre.tar
# tar vxf pcre.tar
# cd pcre/
# ./configure
# make && make install

# ----------------

# yum install pcre pcre-devel -y

# -----------安装open sll

# yum install opensll-devel -y
```

#### 安装Nignx服务 ####

```{.linuxCommand}
# rpm -qa nginx
# wget [nignx url]
# ./configure
# make && make install

# --------------------
# 创建用户
# useradd nginx /sbin/nologin
# ----检查---
# id nginx
```

##### 如果出现 Another app is currently holding the yum lock #####

可以进行强制关闭进程

> rm -f /var/run/yum.pid

#### Ngnix 配置站点 ####

##### 添加站点信息到/ngnix/conf/nginx.conf #####

```{.LinuxCommand}

html{
    server{
        listen 80;
        server_name xx.xxx.xxx;
        location \ {
            root html/xxx;
            index xxx.html;
        }
    }
}
```

#### 在ngnix/html中创建站点 ####

mkdir /ngnix/html/xxxx/

#### 添加域名到hosts文件 ####

echo "xx.xx.xx.xx(ip) xxx.xxx.xxx(域名)" > /etc/hosts

### 关于Ngnix的相关操作 ###

#### 1.规范配置文件 ####

```{.linuxCommand}
# vim conf/nginx.conf

# --------------------

# 在http节点里面用include
http
{
    include extra/htmt.conf
    include extra/blog.conf
}

# --------------------
# 创建目录
# mkdir /nginx/extra/
# touch /nginx/extra/html.conf
# 把原来的server节点复制进去
# sed -n '26,33p' nginx.conf.base-name > extra/html.conf
# 检查语法
# /ngnix/sbin/ngnix -t
# 重启
# /ngix/sbin/ngnix -s reload
```

#### 2.别名的配置 ####

虚拟主机的别名配置,主要在server_name里面添加,同时要在DNS里面添加域名

#### 3.Ngnix的状态 ####

--with-http-stub\_status_mode;

```{.linuxCommand}
# 增加一个虚拟主机
# vim extra/status.conf

#---------------

server{
    listen 80;
    server_name status.etiantian.org;
    location / {
        stub_status on;
        access_log off;
    }
}

# 需要包含进配置文件
# 检查语法
# 添加进DNS服务器
```

#### 4.错误日志配置 ####

放在Main区块中全局配置 , 格式如下:

> error_log file level

* level : debug | info | notice | warm | error | crit | alert | emerg

少用debug与info这两个都会打印出所有日志,会增加磁盘的负担.

### Ngnix的访问日志 ###

* log_format 用于定义记录日志的格式
* access\_log 访问log 格式: access_log logs/access.log combined

| Ngnix日志变量 | 说明 |
|:------------:|:-----------:|
|$remote_addr|记录访问网站的客户端地址|
|$http\_x\_forwarded\_for|当前有代理服务器时,设置web节点记录客户端地址的配置,此参数生效的前提是代理服务器上也要进行相关的x\_forwarded_for设置.|
|$remote_user|远程客户端用户名称|
|$time_local|记录访问时间与时区|
|$request|用户的http请求起始行信息|
|$status |http状态码,记录请求返回的状态|
|$body\_bytes_sents|服务器发送给客户端的响应body字节数|
|$http_referer|记录此次请求是从哪一个链接访问过来的,可以根据referer进行防盗链设置.|
|$http\_user_agent|记录客户端访问信息,例如:浏览器or手机客户端等|
