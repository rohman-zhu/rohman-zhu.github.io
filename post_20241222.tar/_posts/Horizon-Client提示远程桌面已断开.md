---
title: Horizon Client提示远程桌面已断开
tags:
  - 故障
categories:
  - VMware
  - Horizon View
date: 2022-01-04 22:27:26
---

# 故障现象

用户端使用VMware Horizon Client登录后，打开其中发布的VDI或者RDSH应用，提示“远程桌面已断开”。

# 原因分析

## 原因一--服务端防火墙拦截

服务端的防火墙拦截，例如连接服务器与Horizon View Agent之间防火墙拦截、安全服务器或UAG与Horizon View Agent之间的防火墙拦截。

使用Blast网关或者PCoIP网关的情况下，防火墙如下：

SRC:UAG\Connection Server\Security Server
DST:Horizon View Agent
TCP:22443(Blast)\4172(PCoIP)
UDP:2443(Blast)\4172(PCoIP)

检测方法，可以使用WEB端访问，如果可以访问，则说明Blast协议所需的防火墙已开通。

## 原因二--客户端异常

本地客户端VMware Horizon View Client有异常，需要卸载重装。

# 解决方法

## 原因一 -- 申请防火墙即可。

## 原因二 -- 卸载客户端重装。

需要将原来Horizon View里面的文件均删除，如AppData中的文件夹。