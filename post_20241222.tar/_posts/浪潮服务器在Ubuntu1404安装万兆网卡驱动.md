---
title: '浪潮服务器在Ubuntu1404安装万兆网卡驱动'
date: 2018-10-30 22:28:27
tags: 服务器
---

# 环境准备

* 服务器 ： Inspur SM5224M4
* 网卡 ： 板载X552网卡（10 GbE）
* OS ： Ubuntu-14.04-3.13.0-24-generic

# 操作记录

```shell
# 查看所有网卡信息
ifconfig -a

# 只有两个千兆网卡的信息
# 查看所有网卡的pci信息
lspci | grep net

# 发现系统只识别到两个网卡的信息，另外两个万兆网卡的信息都不显示。
# 因此可以断定网卡驱动没有安装。

```

去浪潮的官网查询驱动，发现没有支持Ubuntu系统的驱动。浪潮官方技术支持提出，该服务器没有经过Ubuntu1404的兼容性测试，因此也无法提供该技术支持服务，但能提供安装包，他们也是去英特尔官网下载。

根据网卡型号，去英特尔官方下载驱动，也没有看到支持Ubuntu1404的驱动，最低支持Ubuntu1604的驱动。 但是看到有兼容内核的列表，看到匹配度极高的驱动下载完后，都会报编译错误。

最终无奈只能将系统升级至Ubuntu-1604-4.4.0-138-generic ， 发现完美兼容该驱动。

# 后记

从服务器上架服役，到发现问题已经过去半个月，之前由于没有使用万兆网卡，所以没有发现驱动问题，如今所有业务必须停掉，用于服务器升级系统。

因此，以后服务器上架前，需要做以下检查：

* 确认配件是否齐全，配置是否跟需求单一致。（如是否有冗余电源、是否有万兆网卡等）
* 确认操作系统的兼容性。

# 参考：

* 浪潮官网驱动支持：http://www.inspur.com/eportal/ui?struts.portlet.action=/portlet/download-front!toView.action&pageId=2367231&index=0&product_id=3768&type=0&productName=SA5224M4
* Intel 驱动支持：https://downloadcenter.intel.com/zh-cn/download/27159/Ethernet--PCIe-Linux-
* 系统升级教程：https://r0manj.github.io/2018/11/01/Ubuntu1404-%E5%9C%A8%E7%BA%BF%E5%8D%87%E7%BA%A7%E5%88%B0Ubuntu1604/