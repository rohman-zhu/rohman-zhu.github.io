---
title: Exchange CU23升级日志
tags:
  - Exchange Server
catergories:
  - Windows Server
date: 2020-03-08 15:28:40
---

# 前言

最新的Exchange Server需要安装补丁KB4536988，而这个补丁需要升级至CU23才可安装，然而我们的服务器版本为CU21。因此，服务器需要做一遍升级操作才可安装补丁。

主要流程：

1. 安装 dot net 4.7.2
2. 安装 CU23 
3. 安装补丁 KB-4536988

# 前端服务器升级

升级步骤：

| 步骤 | 任务 | 详情 | 备注 |
|:---:|:----:|:----|:----:|
| 1 |  备份OWA自定义文件 | Exchange Server\V15\Frontend\HttpProxy\版本号\themes | CAS 前端服务器 |
| 2 | 备份OWA自定义文件 | Exchange Server\V15\Frontend\HttpProxy\OWA\Auth\logon.aspx | CAS 前端服务器 |
| 3 | 安装 dot Net 4.7.2 | 以管理员身份运行安装包，安装完后重启服务器 | |
| 4 | 安装CU23 | 以管理员身份运行安装包，安装完后重启服务器 | |
| 5 | 安装KB-4536988 | 以管理员身份运行安装包，安装完后重启服务器 | |
| 6 | 验证测试 | 见前端测试流程 | |

> 为了避免出错，可以管理员身份运行安装包，可以使用 CMD（以管理员身份运行）。

测试流程：

1. 修改hosts文件，将邮件服务器域名解析指向目标前端服务器；
2. 测试 OWA 的邮件收发情况（内网、外网均测试一下）
3. 新建用户邮件 profile 文件 ，使用新profile文件进行邮件收发测试

# 后端服务器升级

| 步骤 | 任务 | 详情 | 备注 |
|:---:|:----:|:----|:----:|
| 1 | 备份Web.config文件 | Exchange Server\Bin\EdgeTransport.exe.config | 后端服务器 |
| 2 | 将DAG中的邮箱服务器切换到维护模式 | 见下列操作步骤 | |
| 3 | 安装 dot Net 4.7.2 | 以管理员身份运行安装包，安装完后重启服务器 | |
| 4 | 安装CU23 | 以管理员身份运行安装包，安装完后重启服务器 | |
| 5 | 安装KB-4536988 | 以管理员身份运行安装包，安装完后重启服务器 | |
| 6 | 将邮箱服务器退出维护模式 | 见下列操作步骤 | |
| 7 | 检查服务 | 见下列操作步骤 | 

进入维护模式：

```ps1
# 1. 定义本机主机名变量
$Computer = $ENV:ComputerName

# 2. 排空邮箱服务器上的所有传送队列的活动邮件，同时传输这些邮件到另外一台服务器上。
Redirect-Message -Server $Computer -Target [DAG的伙伴服务器FQDN名]

# 3. 传输组件设置维护模式
Set-ServerComponentState $Computer -Component HubTransport -State Draining -Requester Maintenance

# 4. 重启Exchange传输服务
Restart-Service MSExchangeTransport

# 5. 暂停此群集节点
Suspend-ClusterNode $Computer

# 6. 设置迁移活动数据库不能回到当前数据库
Set-MailboxServer $Computer -DatabaseCopyActivationDisabledAndMoveNow $True

# 7. 设置自动切换数据库策略为阻止
Set-MailboxServer $Computer -DatabaseCopyAutoActivationPolicy Blocked

# 8. 将服务器设置到维护模式
Set-ServerComponentState $Computer -Component ServerWideOffline -State Inactive -Requester Maintenance

# 9. 查询所有服务器状态，所有组件必须为 “inactive” 状态 。（除了Monitoring 和 RecoveryActionsEnabled）
Get-ServerComponentState $Computer | ft Component,State -Autosize
```

退出维护模式：

```ps1
# 1. 定义本机主机名变量
$Computer = $ENV:ComputerName

# 2. 恢复传输组件状态
Set-ServerComponentState $Computer -Component ServerWideOffline -State Active -Requester Maintenance

# 3. 恢复此群集节点
Resume-ClusterNode $Computer

# 4. 手动切换数据库状态
Set-MailboxServer $Computer -DatabaseCopyActivationDisabledAndMoveNow $False

# 5. 设置自动切换数据库策略为不受限制
Set-MailboxServer $Computer -DatabaseCopyAutoActivationPolicy Unrestricted

# 6. 传输服务器设置维护状态
Set-ServerComponentState $Computer -Component HubTransport -State Active -Requester Maintenance

# 7. 重启Exchange传输服务
Restart-Service MSExchangeTransport

# 8. 查询所有服务器状态，所有组件必须为 “inactive” 状态 。（除了Monitoring 和 RecoveryActionsEnabled）
Get-ServerComponentState $Computer | ft Component,State -Autosize
```

## 问题记录

一、 IIS导致的故障

解决方法：

1. verify you have several gigs free disk space on C drive of the server being upgraded
2. Stop the IISADMIN service and World Wide Web Services
3. Make sure the account your using to run the installer is member of schema admins, domain admins and exchange organization management
4. Run the upgrade again, but this time, right click the install file and click ‘run as administrator’

参考：https://enterpriseit.co/microsoft-exchange/2013/error-cu-upgrade-system-management-automation-remoteexception/

二、 安装CU23出现错误 “ Setup can't continue with the upgrade because the monad(7688) ...mscorsvw (14664) has open files. Close the process, and then restart Setup. For more information, visit: http://technet.microsoft.com/library(EXCHG.150)/ms.exch.setupreadiness.ProcessNeedsToBeClosedOnUpgrade.aspx ”

- 关于 mscorsvw（14664） 是一个 .net 相关的进程，可能net4.7.2没有安装成功。
- 参考：https://www.concurrency.com/blog/w/exchange-2013-cu-installation-setup-can-t-continue

- 关于monad（7688）是一个powershell的进程，但这是跟NetBackup备份服务相关的进程冲突导致的，需要关闭相关服务。
