---
title: 记一次Linux中CPU主频与温度异常问题
tags:
  - 故障
  - CPU
categories:
  - Linux
date: 2022-10-30 15:18:17
---

# 问题描述

服务器CPU的型号为 Intel Xeon Gold 6254 (基础频率为 3.1 GHz ， 睿频可达 4.0 GHz);

产品信息 https://ark.intel.com/content/www/cn/zh/ark/products/192451/intel-xeon-gold-6254-processor-24-75m-cache-3-10-ghz.html

OS为 Ubuntu 18.04，OS内用指令 lscpu、 cpupower frequency-info 查看到CPU的最大主频为3.2GHz ，而没有达到 4.0 GHz；

# 原因分析

1. BIOS没有开启CPU的睿频模式，也就是Turbo Mode；
2. OS内禁用CPU的PState ，进而禁用睿频；

# 解决方法

## BIOS设置

进入BIOS ， Processor Configuration / Advanced Power Management Configuration

```
CPU P State Control
- SpeedStep(Pstates) 选择 Enable
# 传统的 Intel SpeedStep 技术根据处理器负荷状况，在高和低两个级别之间依次切换电压和频率。
- ConfigTDP 选择Normal
# 可选择的有Level 1 \ Level 2 \ Normal
# 最高的等级为 Level 2 ，能耗更高；
# 参考https://www.hardwaretimes.com/intel-10th-gen-cpu-power-consumption-explained-pl1-pl2-and-tau/
https://www.anandtech.com/show/13544/why-intel-processors-draw-more-power-than-expected-tdp-turbo


- EIST PSD Function 选择 HW-ALL
# 在 HW_ALL 模式下，处理器硬件负责在关联的逻辑处理器之间协调 P- 状态。操作系统负责保持 P- 状态请求最新（在所有逻辑处理器上）。
# 在 SW_ALL 模式下，操作系统电源管理器负责在关联的逻辑处理器之间协调 P- 状态，并且必须在所有逻辑处理器上启动切换。
# 在 SW_ANY 模式下，操作系统电源管理器负责在关联的逻辑处理器之间协调 P- 状态，并且可以在任何逻辑处理器上启动切换。

- Turbo Mode 选择 Enable
# 此项目启用时，处理器将自动地逐渐提升其 1-2 个处理内核的时钟速度，以提高性能。
# 若禁用此项目，处理器的所有内核均不超频。
```

## OS内的设置

Grub启动参数不能将 pstat 状态禁用；

```
# Grub菜单参数编辑
vim /etc/default/grub
GRUB_CMDLINE_LINUX_DEFAULT="intel_pstate=enable"
# 保存退出

# 生成新的grub菜单
update-grub
```

# 问题描述

服务器没有运行任务（空载）的情况下，CPU温度达到70℃，甚至会达到82℃。（OS中断的温度104℃，此CPU最大允许的运行温度是82℃；）

```sh
# 查看CPU相关参数，如活动核数、频率、温度，中断温度等信息
turbostat
# 看到 MSR_IA32_PACKAGE_THERM_INTERRUPT 相关
...MSR_IA32_PACKAGE_THERM_INTERRUPT...(104 C , 104 C)
# 104℃ 为中断温度；
```

看到系统在空载的情况下，CPU当前主频会达到3.9GHz 。并持续在3.9GHz；

```sh
cpupower frequency-info
# 显示信息如下
driver: intel_pstate
  CPUs which run at the same hardware frequency: 0
  CPUs which need to have their frequency coordinated by software: 0
  maximum transition latency:  Cannot determine or is not supported.
  hardware limits: 1.20 GHz - 4.00 GHz
  available cpufreq governors: performance powersave
  current policy: frequency should be within 1000 MHz and 2.30 GHz.
                  The governor "performance" may decide which speed to use
                  within this range.
  current CPU frequency: Unable to call hardware
  current CPU frequency: 3.9 GHz (asserted by call to kernel)
  boost state support:
    Supported: no
    Active: no
```

BMC将十个散热风扇调整到最大转速，依旧无法有效降温，CPU温度轻松突破82℃。

```sh
# 查看CPU温度
ipmitool sensor list;

```

# 原因分析

相当于CPU在满性能运行，要找出让CPU满性能运行的原因。

1. BIOS将CPU的C State调整成最高性能模式，并持续为高性能模式；
2. OS内手动将性能调整至最高性能模式；

# 解决方法

## BIOS设置

将CPU的C State模式调整为Auto

```BIOS
# 进入BIOS ， Processor Configuration / Advanced Power Management Configuration


CPU C Sate
- Autonomous Core C-state 选择 Disable
# 默认是Enable

- CPU  C6 report 选择 Auto
# 让您决定在系统闲置状态下是否让 CPU 进入 C3/C6 模式。启用时，CPU 内核频率和电压在系统闲置状态下会降低，以降低功耗。C3/C6 状态是比 C1 更加省电的状态。
# 默认C3是 Disable ， C6默认是Enabled；

- Enhanced Halt Sate(CIE) 选择 Enable

Package C State Control
- Package C State 选择 No limit
# 默认设置是 C6(non Retention) state（C6 非保持状态）。

```

## OS 检测

一般为Grub菜单初始化

```sh
# Grub菜单参数编辑
vim /etc/default/grub
# 取消此参数描述
GRUB_CMDLINE_LINUX_DEFAULT="intel_idle.max_cstate=0 processor.max_cstate=0 idle=poll"
# 保存退出

# 生成新的grub菜单
update-grub

# 重启服务器
init 6
```



# 参考资料
《主板手册》
https://download.gigabyte.com/FileList/Manual/server_manual_md70-hbx_sc_1202.pdf
https://product-help.schneider-electric.com/Machine%20Expert/V1.1/zh/SPanePC1/SPanePC1/iPC_-_Configuration_of_the_BIOS/iPC_-_Configuration_of_the_BIOS-4.htm

《CPU模式》
https://gist.github.com/Brainiarc7/8dfd6bb189b8e6769bb5817421aec6d1

《被误解的CPU利用率、超线程、动态调频 —— CPU 性能之迷 Part 1》
https://blog.mygraphql.com/zh/notes/hw/hyper-threading/

《谁动了我的 CPU 频率 —— CPU 性能之迷 Part 2》
https://segmentfault.com/a/1190000042050535