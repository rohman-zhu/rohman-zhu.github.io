---
title: firewall-cmd使用
date: 2019-01-01 20:02:09
tags: Linux
---
# 前言

* OS: CentOS Linux release 7.5.1804 (Core)
* Firewall-Version : 0.4.4.4

# 通用

* 不指定( --zone=... ) zone ，则都是默认的 zone。
  
# 添加端口

（临时生效，重启后则恢复）在默认的 zone 中，添加常用的 80 （http）端口 和 443（https） 端口。

```shell
# 方法一
firewall-cmd --add-port=80/tcp
firewall-cmd --add-port=443/tcp

# 方法二
firewall-cmd --add-service=http
```

# 查询

```
firewall-cmd --list-all
```

# 参考资料

* firewall-cmd ： https://wangchujiang.com/linux-command/c/firewall-cmd.html
* https://blog.csdn.net/weixin_37998647/article/details/78895754
