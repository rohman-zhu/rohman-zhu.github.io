---
title: 初识LDAP
date: 2018-07-15 23:58:26
tags: Linux
---

# 前言

这周末看了LDAP的相关文档，只是尝试根据官方说明文档搭建了一下这个应用。但对于该应用是否能够投入使用，以及搭建过程中是否出错，目前不得而知。因此，此篇文章只做简单的记录，后续还需要再验证。而之所以会想去了解 _LDAP_ ，是因为在工作环境中会听到这个词汇，但我对于其具体作用却不得而知，所以才会利用空余时间去了解一下这一个应用。

# 理论部分

## LDAP

这里采用官方文档的介绍：

LDAP stands for Lightweight Directory Access Protocol. As the name suggests, it is a lightweight protocol for accessing directory services, specifically X.500-based directory services. LDAP runs over TCP/IP or other connection oriented transfer services. LDAP is an IETF Standard Track protocol and is specified in "Lightweight Directory Access Protocol (LDAP) Technical Specification Road Map" RFC4510.

 The LDAP information model is based on entries. An entry is a collection of attributes that has a globally-unique Distinguished Name (DN). The DN is used to refer to the entry unambiguously（ _不含糊地 adv_ ）. Each of the entry's attributes has a type and one or more values. The types are typically mnemonic( _有助于记忆的 adj_ ) strings, like "cn" for common name, or "mail" for email address. The syntax of values depend on the attribute type. For example, a cn attribute might contain the value Babs Jensen. A mail attribute might contain the value "babs@example.com". A jpegPhoto attribute would contain a photograph in the JPEG (binary) format.

The LDAP search operation allows some portion of the directory to be searched for entries that match some criteria specified by a search filter. Information can be requested from each entry that matches the criteria（n. 标准）.

 In general, you should use a Directory server when you _require data to be centrally managed, stored and accessible via standards based methods_.

从上述内容中，可以知道：

1. LDAP是一个轻量级的目录访问协议，适用于目录服务的。（这里的目录，并不仅仅指我们说的文件夹）
2. LDAP是可以运行在TCP/IP 协议上。
3. 记录信息的单位是 Entry ，类似于数据库中的记录。
4. 信息存储是以树状形式存储的。（类似于DNS的多级域名解析）
5. 需要通过一些简单的方式集中管理、存储的数据，我们用LDAP。

| 缩写 | 全称 |
|:---:|:----:|
| dc |domain Component|
| uid | user ID |
| ou | organization unit |
| cn | comman name |
| sn | surname |
| dn | distinguished name |
| rdn | relative distinguished name |
| c | country |
| o | organization |

目前从文档中看到的四个特点是：

1. 采用标准协议
2. 树状结构表示数据
3. 静态数据查询快，但更新慢
4. 可采用 SASL 、 SSL 、 TLS 安全认证

## DIT（ Directory Information Tree）

## LDIF （ LDAP Data Interchange Format）

* 必须存在objectclass
* 以空行分割不同的记录 ，类似于｛｝的作用。

## Linux上安装LDAP

* Centos_6.9_minimal
* LDAP_2.4.46
* Berkeley_5.1

由于我的Linux是最小化安装，因此还缺少一些必要的工具，类似于NTP服务、GCC编译等。所以在安装前，先执行以下指令：

```shell
$yum grouplist
# 查看当前系统是否有安装以下包
# Base
# Compatibility libraries
# Debugging Tools
# Development Tools
# Dial-up Networking Support
# Hardware monitoring utilities
# Performance Tools

$ yum groupinstall "需要安装的包" -y
```

在安装前，需做好以下工作，避免产生不必要的错误：

```shell
# SELINUX
$ sed -i "s#SELINUX=enforcing#SELINUX=disabled#g"

# iptables
$ /etc/init.d/iptables stop

# NTP
$ /usr/sbin/ntpdate time.windows.com
# 添加到定时任务
$ crontab -e

*/5 * * * * /usr/sbin/ntpdate time.windows.com

```

采用编译安装，如果过程中出现“BerkeleyDB”未找到，需要指定相关目录。

```shell
#Berkeley 安装
$tar xf db-5.1.tar
$cd db-5.1/build_unix/
$../dist/configure 
$ make && make install

# OpenLdap安装
$tar openldap
$cd openldap
$ ./configure CPPFLAGS="-I/usr/local/BerkeleyDB.6.2/include" LDFLAGS="-L/usr/local/BerkeleyDB.6.2/lib"
```

> 第一次安装openldap的时候，在已经安装了Berkeley的情况下依然出现 BerkeleyDB version incompatible withBDB/HDB backends ， 查询了一下 _README_ 文件后才知道，Openldap对DB版本有要求地。

参考 : https://www.linuxidc.com/Linux/2016-05/130997.htm

## 启动服务

根据官方文档，编译安装启动方式如下：

```shell
$/usr/local/libexec/slapd [option]
# port:389
$lsof -i:389
```

默认配置文件 ：  /usr/local/etc/openldap/slapd.ldif
# 未完结