---
title: Simple performance testing on hard disk with different RAID level record
tags:
  - default
categories:
  - default
date: 2024-08-28 00:20:26
---



| Index | TEST ENV | Type | Read Speed (MBps) | Write Speed (MBps)| Read IOPS | Write IOPS | Read latency(us) | Write latency(us) |
| 1 | 10 * 18TB SATA HDD , RAID 6 | SEQ 1M,Q8T1 | 1294 | 1421 | 1234 | 1355 | 6471 | 5864 |
| 2 | 10 * 18TB SATA HDD , RAID 6 | RND 1M,Q1T1 | 355 | 1385 | 339 | 1321 | 2907 | 756 |
| 3 | 10 * 18TB SATA HDD , RAID 6 | RND 4K,Q32T1 | 10 | 64 | 2480 | 15829 | 12842 | 1863|
| 4 | 10 * 18TB SATA HDD , RAID 6 | RND 4K,Q1T1 | 1 | 18 | 352 | 4551 |2827 | 195 |
| 5 | 2 * 960GB SATA SSD , RAID 1 | SEQ 1M,Q8T1 | 1294 | 1421 | 1234 | 1355 | 6471 | 5864 |
| 6 | 2 * 960GB SATA SSD , RAID 1 | RND 1M,Q1T1 | 355 | 1385 | 339 | 1321 | 2907 | 756 |
| 7 | 2 * 960GB SATA SSD , RAID 1 | RND 4K,Q32T1 | 10 | 64 | 2480 | 15829 | 12842 | 1863|
| 8 | 2 * 960GB SATA SSD , RAID 1 | RND 4K,Q1T1 | 1 | 18 | 352 | 4551 |2827 | 195 |
