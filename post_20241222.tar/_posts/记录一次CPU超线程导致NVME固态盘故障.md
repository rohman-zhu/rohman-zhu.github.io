---
title: 记录一次CPU超线程导致NVME固态盘故障【待补充】
tags:
  - 故障
categories:
  - 服务器与存储
  - 服务器
date: 2022-12-20 23:22:25
---
# 故障描述

有一批相同配置的服务器，大部分服务器上面的磁盘读写始终不及预期。原本以为这就是服务器所能达到的实际速度，然而，这一批次中却有一台服务器速率却能达标。因此记录此次故障记录，避免后续再遇到。

服务器大致配置，关键配件为CPU与NVME SSD；

# 原因分析

服务器使用两个AMD的CPU，单颗CPU为64Core，总共是128Core；而NVME SSD的队列为128，如果开了超线程，则会导致CPU有256Core去与NVME交互，会导致SSD的一个队列在等待2个Core的调度（争用），从而导致整体效率下降。【猜想】

```sh
# 查看Nvme盘的队列长度
nvme get-feature /dev/nvme0n1 --feature-id=7 -H
```

# 解决方法

关闭超线程

# 参考资料

浪潮NF5488A5
： https://www.inspur.com/lcjtww/2526894/2526897/2526898/2527436/index.html

AMD 7002：https://www.amd.com/zh-hans/processors/epyc-7002-series

AMD 7003：https://www.amd.com/zh-hans/processors/epyc-7003-series

固态硬盘：NVME 命令队列 SQ/CQ ： https://cloud.tencent.com/developer/article/2168043

你所不知道的NVME：https://developer.aliyun.com/article/767312