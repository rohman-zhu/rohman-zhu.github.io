---
title: Linux-忘记root密码
date: 2018-11-18 19:05:22
tags: Linux
---

# 前言

有时候一台 Linux 虚拟机放太久了，又没有做注释，初始密码就容易忘记。

前提条件：

* MBR + Grub 的方式引导系统启动。

# CentOS密码忘记

* 进入 grub 菜单后，对想要编辑的菜单项按 [E] 键编辑；
* 再将光标移到 Kernel 上方再点 [E] 键编辑；
* 在末尾添加 single ：

```
grub edit > kernel /vmlinuz-2.6.18-92.e15 ro root=LABEL=/ rhgb quiet single
```

* 按 [回车] 键后， 按 [B] 键即可进入单用户维护模式了。

# Ubuntu 进入恢复模式

* 开机长按 [Shift] 键进入 grub 菜单；
* 进入高级菜单 [Advanced options for Ubuntu] ；
* 选择任意一个恢复模式；
* 选择 "root Drop to root shell prompt";
* 重新挂载 / 目录 ， mount -o remount,rw /
* 再去修改密码。

# Ubuntu 修改内核启动参数

* 开机长按 [Shift] 键进入 grub 菜单；
* 进入高级菜单 [Advanced options for Ubuntu] ；
* 选择任意一个恢复模式,按 [E] 键编辑；

```shell
# 将 linux 那一行的末尾 ro single 改成 rw single init=/bin/bash
rw single init=/bin/bash
```

* 按 [Ctrl] + [X] 进入单用户模式，修改密码。