---
title: Micosoft-ATA学习与部署计划
tags:
  - 学习笔记
categories:
  - Windows Server
  - ATA(Advanced Threat Analytics)
date: 2021-01-31 15:39:19
---
# 背景

Deadline：2021-03-31
参考资料：https://docs.microsoft.com/zh-cn/advanced-threat-analytics/what-is-ata