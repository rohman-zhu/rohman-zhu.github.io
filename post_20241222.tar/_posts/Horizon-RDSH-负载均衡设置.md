---
title: Horizon-RDSH-负载均衡设置
tags:
  - default
categories:
  - VMware
  - Horizon View
date: 2022-10-23 15:38:27
---
# 需求

Horizon RDSH有负载均衡，可以根据下列负载均衡设置；

|类型|设置阈值|备注|
|:---:|:---:|:---:|
|CPU|90||
|Memory|90||
|Session|20||


# 参考资料

https://docs.vmware.com/cn/VMware-Horizon/2203/published-desktops-applications/GUID-461B7E5E-183B-4AA0-AB87-A76D07F6BDDD.html
