---
title: Linux循环创建账户脚本
tags:
  - Shell
categories:
  - Linux
date: 2021-11-30 02:15:21
---

# 需求

需要一次性创建10个测试账户，并且设置初始账户密码。

# 脚本

创建账户

```sh

for (( i=1;i<11;i++ ))
do
    sudo useradd -m -s /bin/bash [username]-$i
done

```

批量修改密码

```temp.file
[username]:[init password]
```

```sh
sudo chpasswd < temp.file
```