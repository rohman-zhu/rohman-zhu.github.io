---
title: 记一次多路径存储的Linux扩容过程
tags:
  - default
categories:
  - default
date: 2021-02-09 23:21:31
---
# 需求背景

1. 服务器直连SAN存储，需要从SAN存储划分1个1T的硬盘给服务器使用。
2. SAN已经在底层划分1个1T的硬盘。

# 操作过程

```sh
# 确定当前的磁盘与映射关系
df -Th
pvs
ls /dev/mapper/*

# 发起磁盘扫描
echo "- - -" > /sys/class/scsi_host/host0/scan
echo "- - -" > /sys/class/scsi_host/host1/scan
echo "- - -" > /sys/class/scsi_host/host2/scan

# 将目标磁盘做成LVM卷
fdisk /dev/mapper/ma...

pvcreate
vgcreate vg-data
lvcreate -n lv-data

mkfs.xfs /dev/vg-data/lv-data

```
