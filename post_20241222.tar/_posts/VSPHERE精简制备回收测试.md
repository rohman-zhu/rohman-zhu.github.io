---
title: VSPHERE精简制备回收测试
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2023-02-05 23:07:48
---

# 背景1

精简置备模式下的虚拟机，OS内的空间删除后，底层空间并没有随之释放。需要测试并输出可行的方法。

# 测试步骤

1. 部署虚拟机，配置为 2C4G ，100G数据盘（D:\ 或 /data）;【记录精简置备下，OS内的使用空间，底层使用空间】
2. 向数据盘写入非零数据，写入量大于等于80G的数据，并删除；【记录OS内的空间占用情况，记录底层存储空间占用情况】
3. 对目标虚拟机执行Storage vMotion，先转厚置备快速置零（Thick），再转精简置备（Thin）。【记录底层空间占用情况】
4. 向数据盘写入零数据，写入量大于等于80G的数据，并删除；【记录OS内的空间占用情况，记录底层存储空间占用情况】
5. 对目标虚拟机执行Storage vMotion，先转厚置备快速置零（Thick），再转精简置备（Thin）。【记录底层空间占用情况】
6. 目标虚拟机关机，进入ESXi Shell 对目标vmdk置零回收空间。【记录vmdk使用量与回收时间】

# 初步结论

|测试环境|空间自动回收|分区置零+Storage vMotion 是否会自动回收空间|分区置零+底层回收空间|
|:---:|:---:|:---:|:---:|
|CentOS 7 + XFS| × | × | √ |
| Ubuntu 20.04 + EXT4 | × | × | √ |
| Windows Server 2019 + NTFS | √ | 无条件测试 | 无条件测试 |
| Windows Server 2012R2 + NTFS | √ | 无条件测试 | 无条件测试 |

> Windows Server 2019 虚拟机底层空间会自动回收；无法做其他测试复核；

# 涉及脚本

Linux中用dd置零

```sh
#!/bin/bash
echo "Create ZERODATA to /data."
df -Th
dd if=/dev/zero of=/data/test bs=1G count=90;
echo "Create ZERODATA completed."
df -Th
echo "Delete ZERODATA."
rm -f /data/test
df -Th
```

Linux重复写入常规数据

```sh
#!/bin/bash
# data.tar = 1G 
echo "Create DATA to /data/normaltest."
df -Th
for((i=0;i<80;i++0))
do
  echo $i
  cp data.tar /data/normaltest/data.tar.$i
done

echo "Create DATA to /data/normaltest/ completed."
df -Th

echo "Delete DATA to /data/normaltest ."
rm -rf /data/normaltst/*
df -Th
```

ESXi Shell

```sh
# 目标vmdk 路径假设为 /vmfs/volume/xxxx/xxxx.vmdk
du -sh ./*
vmkfstools -K /vmfs/volume/xxxx/xxxx.vmdk
du -sh ./*
```

# 背景2

在底层做vmdk置零块移除的时候，为了避免数据丢失，需要做一下快照；因此需要测试，在有快照的情况下，是否可以做置零块移除？

# 测试步骤

## 测试1

1. 部署虚拟机，配置为 2C4G ，100G数据盘（D:\ 或 /data）;【记录精简置备下，OS内的使用空间，底层使用空间】
2. 虚拟机拍摄内存快照；
3. 向数据盘写入非零数据，写入量大于等于80G的数据，并删除；【记录OS内的空间占用情况，记录底层存储空间占用情况】
4. 向数据盘写入零数据，写入量大于等于80G的数据，并删除；【记录OS内的空间占用情况，记录底层存储空间占用情况】
5. 目标虚拟机关机，进入ESXi Shell 对目标vmdk置零回收空间。【记录vmdk使用量与回收时间】
6. 删除虚拟机快照；【记录vmdk占用情况】

## 测试2

1. 部署虚拟机，配置为 2C4G ，100G数据盘（D:\ 或 /data）;【记录精简置备下，OS内的使用空间，底层使用空间】
2. 虚拟机拍摄硬盘快照；
3. 向数据盘写入非零数据，写入量大于等于80G的数据，并删除；【记录OS内的空间占用情况，记录底层存储空间占用情况】
4. 向数据盘写入零数据，写入量大于等于80G的数据，并删除；【记录OS内的空间占用情况，记录底层存储空间占用情况】
5. 目标虚拟机关机，进入ESXi Shell 对目标vmdk置零回收空间。【记录vmdk使用量与回收时间】
6. 删除虚拟机快照；【记录vmdk占用情况】

# 结论

有快照的情况下，均不能实现空间自动回收；而且Windows Server服务器要手动触发 SDelete 指令回收置零空间。