---
title: Synology磁盘盘位
date: 2019-12-28 23:29:17
tags:
- Synology
categories: 
- 服务器与存储
- 存储
- NAS存储
---
# 识别硬盘位置

https://www.synology.com/zh-cn/knowledgebase/DSM/tutorial/Storage/How_do_I_identify_the_drives_on_my_Synology_NAS

# 硬盘兼容性列表

https://www.synology.cn/zh-cn/compatibility?search_by=category&category=hdds_no_ssd_trim&p=1
