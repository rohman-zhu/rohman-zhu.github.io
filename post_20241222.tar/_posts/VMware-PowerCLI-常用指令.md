---
title: VMware PowerCLI 常用指令
tags:
  - 脚本
  - 常用指令
categories:
  - VMware
  - vSphere
date: 2022-12-29 23:32:27
---

# 获取虚拟机配置信息

CPU、Memory、制备空间、使用空间

```ps1
$VM=Get-VM -Name "虚拟机名"
# CPU核数，单位Core
$cpu=$VM.NumCPU;
# 内存数，单位GB
$ramGB=$VM.MemoryGB;
# 制备空间，单位GB
$provisionedSpaceGB=$VM.ProvisionedSpaceGB;
# 使用空间，单位GB
$usedSpaceGB=$VM.UsedSpaceGB;
```

# 设置虚拟机备注信息

```ps1
# 保留之前的备注信息
$VM=Get-VM -Name "虚拟机名";
$preNotes=$VM.notes;
Set-VM -VM $VM -Notes "$preNotes+[新的备注信息]" -confirm:$FALSE;
```

# 热关闭虚拟机

> VMware Tools要是可用情况下

```ps1
Get-VM -Name "虚拟机名" | Stop-GuestVM -Confirm:$FALSE;
```

# 修改虚拟机名

```ps1
Set-VM -VM $VM -Name "新虚拟机名"
```

# 迁移虚拟机

```ps1
# 仅迁移计算资源
Get-VM -Name $VMName | Move-VM -Destination $targetESXi -RunAsync:$fal
# 迁移计算资源与存储资源
Get-VM -Name $VMName | Move-VM -Destination $targetESXi -Datastore $targetDatastore -RunAsync:$fal
```
# 设置目标虚拟机端口组

```ps1
$targetVDPort=[目标端口组名称]
Get-VM -Name $VMName | Get-NetworkAdapter | Set-NetworkAdapter -NetworkName $targetVDPort -Confirm:$false
```

# 创建分布式端口组

```ps1
# 创建分布式端口组
New-VDPortgroup -Name $targetVDPort -VDSwitch $targetVD -VlanID $targetVLanID

# 将目标分布式端口指定上行链路
$activeUplinkPortList="Need-Used"
$unusedUplikPortList="上行链路1","上行链路2"
Get-VDPortgroup -Name $targetVDPort -VDSwitch $targetVD | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort $activeUplinkPortList  -UnusedUplinkPort $unusedUplinkPortList;
```

# 移除虚拟机快照

```ps1
# 输入项
Get-VM -Name $servername | Get-Snapshot | Remove-Snapshot -Confirm:$FALSE;
```

# 设置自定义规范

## Linux

```ps1
$OSCUSTOMIZATIONSPEC="目标自定义规范的名称";
$DEFAULTGATEWAY="默认网关";
$TARGETIPADDRESS="IP";
$TARGETSUBNETMASK="子网掩码";
$TARGETDNS="目标DNS";
# 多个地址是$TARGETDNS="8.8.8.8","8.8.4.4";

$TARGETOSCUSTOMIZATION=Get-OSCustomizationSpec -Name $OSCUSTOMIZATIONSPEC;
Get-OSCustomizationNicMapping -OSCustomizationSpec $TARGETOSCUSTOMIZATION | Set-OSCustomizationNicMapping -DefaultGateway $DEFAULTGATEWAY -IPAddress $TARGETIPADDRESS-SubnetMask $TARGETSUBNETMASK -IpMode "UseStaticIP";
# 设置DNS
Set-OSCustomizationSpec -OSCustomizationSpec $TARGETOSCUSTOMIZATION -DnsServer $TARGETDNS;
```

## Windows

```ps1
$OSCUSTOMIZATIONSPEC="目标自定义规范的名称";
$DEFAULTGATEWAY="默认网关";
$TARGETIPADDRESS="IP";
$TARGETSUBNETMASK="子网掩码";
$TARGETDNS="目标DNS";
# 多个地址是$TARGETDNS="8.8.8.8","8.8.4.4";

$TARGETOSCUSTOMIZATION=Get-OSCustomizationSpec -Name $OSCUSTOMIZATIONSPEC;
Get-OSCustomizationNicMapping -OSCustomizationSpec $TARGETOSCUSTOMIZATION | Set-OSCustomizationNicMapping -DefaultGateway $DEFAULTGATEWAY -IPAddress $TARGETIPADDRESS-SubnetMask $TARGETSUBNETMASK -IpMode "UseStaticIP" -Dns $TARGETDNS;
```

# 克隆虚拟机【待补充】

1. 获取虚拟机对象；
2. 使用指令New-VM -Name 虚拟机名 -VM 被克隆的虚拟机对象 -VMHost ESXi主机 -Datastore 存储卷 -OSCustomizationSpec 自定义规范
3. 设置目标虚拟机的端口组
4. 启动虚拟机

# 设置标签

指令： Get-Annotation , Set-Annotation


# 参考资料

https://developer.vmware.com
