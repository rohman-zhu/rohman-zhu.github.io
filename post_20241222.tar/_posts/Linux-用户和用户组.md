---
title: Linux_用户和用户组
date: 2017-10-05 14:46:31
tags: Linux
---
# Linux用户和用户组 #

用户分为三种类型：

* 普通用户（多个）
* 超级用户（一个）
* 虚拟用户

## 配置文件 ##

* /etc/passwd
* /etc/shadow
* /etc/group
* /etc/gshadow

### passwd ###

|第一列|第二列|第三列|第四列|第五列|第六列|第七列|
|-------|--------|------|------|------|-------|--------|
|账号名称|账号密码|账号UID|账号组GID|用户说明|用户家目录|shell解释器|

## /etc/skel 目录 ##

作用：存放新用户配置文件的目录

## useradd 参数 ##

|   指令    |  意义   |
|:--------:|:-------:|
|   -c     |新账号password档的说明栏|
|   -d     |新账号每次登陆时所使用的家目录|
|   -e      |账号终止日期(MM/dd/yyyy)|
|   -f      |账号过期几天后永久停权    |
|   -g      |group名称或以数字作为用户登入起始用户组|
|   -G      |定义此用户为多个不同groups的成员|
|   -m      |用户目录如不存在则自动建立|
|   -M      |不建立用户家目录，优先于/etc/login.defs文件的设定|
|   -n      |默认情况用户的用户组与用户的名称会相同|
|   -f      |此参数是用来建立系统账户|
|   -s      ||

### 实例 ： 用 useradd -c -u -G -s -d多个参数组合例子 ###

* 自定义用户的家目录、shell类型、所归属的用户组 ；
* 添加用户oldboy6，并设置其用户注释信息为HandsomeBoy，UUID指定为806；
* 归属为用户组root ， oldboy ，sa 成员， 其shell类型为/bin/sh,设置家目录为/oldboy6 ;

```｛.normal}
查看是否有oldboy组
# id -g oldboy
# id -gn oldboy
# grep oldboy /etc/group
# grep -o "\bsa\b" /etc/group

增加组
# useradd -c "HandsomeBoy" -u 806 -G root,oldboy,sa -s /bin/sh -d /oldboy6 oldboy6

检查
#id oldboy6
```

## 关于密码 ##

超级用户可以更改普通用户的密码。

```｛.normal}
# echo 123456 | passwd --stdin username
```

### 实例 ： 要求用户 oldboy 七天内不能改密码，60天以后必须改密码，过期前10天通知oldboy，过期30天后禁止用户登陆 。 ###

```{.normal}
# pass -n 7 -x 60 -w 10 -i 30 oldboy
        min max inactive warning

查看更改
# chage -l oldboy

```

### 实例 ： 批量创建10个用户 stu01 - stu10，并且设置随机8位密码，要求不能使用shell循环（如 for ，while 等 ），只能用命令以及管道实现。 ###

```{.normal}
echo stu(01..10)|{tr " " "\n"|sed -r 's#(.*)#useradd \1;pass=$((RANDOM+10000000));echo "pass"|passwd --stdin \1;echo -e "\1\t'echo"$pass"'">>/tmp/oldboy.log#g'|bash
```

## chage 命令 ##

查看与更改用户信息。

|   参数  |   说明  |
|:-------:|:--------:|
|   -d  | 最近一次密码设置时间|
|   -E  |账户过期时间 |
|   -l  |显示账户年龄信息|
|   -m  |将两次改变密码之间时间间隔设置为‘最小天数’|
|   -M  |将两次改变密码之间时间间隔设置为‘最大天数’|
|   -W  |将过期警告天数 设置为xx天|

## 删除用户 ##

主要涉及到这几个文件：

* /etc/passwd - 用户账号资料文件
* /etc/shadow - 用户账号资讯加密文件
* /etc/group - 用户资讯文件

### userdel 命令 ###

```{.normal}
连同家目录一起删除
# userdel -r username
```

> 工作中少用这条指令，直接用vi /etc/passwd 给相应的用户添加注释即可。
> 也可以让一个账户过期。

### groupdel 命令 ###

```{.nromal}
# groupdel [groupName]
```

### usermod 命令 ###

用于修改用户
|   参数  |   说明  |
|:-------:|:--------:|
|   -c  |添加注释|
|   -d  |设置家目录|

> 跟 useradd 类似。

## 查询用户信息 ##

* id username 命令
* finger 命令 （centos5）
* whoami (show who is logged on currently)
* w 命令 （show who is logged on and what they are doing )
* who 命令 （show who is logged on）
* users (show who is logged on)
* last (show listing of who is logged on)
* lastlog(reports the most recent login of all users or of a given user)

## 为用户添加sudo操作权限 ##

```｛.normal}
# visudo

按住 ‘A’ 进入最后一行插入
格式如下：
用户名     主机名称=(可切换的身份)   可用指令
root    ALL=（ALL）       ALL

如果是想添加整个组，格式如下：
%组名     主机名称=(可切换的身份)   可用指令

```