---
title: Linux下的阵列卡工具
tags:
  - 工具
categories:
  - Linux
date: 2020-05-30 21:19:42
---
# 需求分析

对已经做了磁盘阵列的服务器，需要在OS层查看阵列状态信息，如硬件的健康状态、阵列等级......

对于Linux，可以使用MegaCli这个工具。

# MegaCli 介绍

MegaCli是一款管理维护硬件RAID软件，可以通过它来了解当前raid卡的所有信息，包括 raid卡的型号，raid的阵列类型，raid 上各磁盘状态。

这个工具有Linux和Windows两个版本。本文先看Linux下的使用方式。

## 常用命令

如果是通过Linux自身查看：

```sh
#查看软件RAID
cat  /proc/mdstat
# 查看硬件RAID：查看RAID的厂家、型号、级别
dmesg | grep -i raid
cat /proc/scsi/scsi
```

通过 MegaCli：

```sh
# 【查raid级别】
/opt/MegaRAID/MegaCli/MegaCli64 -LDInfo -Lall -aALL 
# 【查raid卡信息】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpAllInfo -aALL
# 查看【硬盘信息】
/opt/MegaRAID/MegaCli/MegaCli64 -PDList -aALL 
#  【查看电池信息】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpBbuCmd -aAll
# 【查看raid卡日志】
/opt/MegaRAID/MegaCli/MegaCli64 -FwTermLog -Dsply -aALL 
# 【显示适配器个数】
/opt/MegaRAID/MegaCli/MegaCli64 -adpCount 
# 【显示适配器时间】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpGetTime –aALL
#  【显示所有适配器信息】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpAllInfo -aAll 
#  【显示所有逻辑磁盘组信息】
/opt/MegaRAID/MegaCli/MegaCli64 -LDInfo -LALL -aAll
# 【显示所有的物理信息】
/opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll 
# 【查看充电状态】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpBbuCmd -GetBbuStatus -aALL |grep ‘Charger Status’ 
#【显示BBU状态信息】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpBbuCmd -GetBbuStatus -aALL
# 【显示BBU容量信息】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpBbuCmd -GetBbuCapacityInfo -aALL
# 【显示BBU设计参数】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpBbuCmd -GetBbuDesignInfo -aALL 
# 【显示当前BBU属性】
/opt/MegaRAID/MegaCli/MegaCli64 -AdpBbuCmd -GetBbuProperties -aALL 
# 【显示Raid卡型号，Raid设置，Disk相关信息】
/opt/MegaRAID/MegaCli/MegaCli64 -cfgdsply -aALL 
```

这个软件貌似支持从系统层做RAID，但我们一般都在服务器的BIOS设置，这里的命令仅做记录，并没有验证：

```sh
#6.创建一个 raid5 阵列，由物理盘 2,3,4 构成，该阵列的热备盘是物理盘 5
/opt/MegaCli -CfgLdAdd -r5 [1:2,1:3,1:4] WB Direct -Hsp[1:5] -a0

#7.创建阵列，不指定热备
/opt/MegaCli -CfgLdAdd -r5 [1:2,1:3,1:4] WB Direct -a0

#8.删除阵列
/opt/MegaCli -CfgLdDel -L1 -a0

#9.在线添加磁盘
/opt/MegaCli -LDRecon -Start -r5 -Add -PhysDrv[1:4] -L1 -a0

#10.阵列创建完后，会有一个初始化同步块的过程，可以看看其进度。
/opt/MegaCli -LDInit -ShowProg -LALL -aALL

#或者以动态可视化文字界面显示
/opt/MegaCli -LDInit -ProgDsply -LALL -aALL

#11.查看阵列后台初始化进度
/opt/MegaCli -LDBI -ShowProg -LALL -aALL

#或者以动态可视化文字界面显示
/opt/MegaCli -LDBI -ProgDsply -LALL -aALL

#12.指定第 5 块盘作为全局热备
/opt/MegaCli -PDHSP -Set [-EnclAffinity] [-nonRevertible] -PhysDrv[1:5] -a0

#13.指定为某个阵列的专用热备
/opt/MegaCli -PDHSP -Set [-Dedicated [-Array1]] [-EnclAffinity] [-nonRevertible] -PhysDrv[1:5] -a0

#14.删除全局热备
/opt/MegaCli -PDHSP -Rmv -PhysDrv[1:5] -a0

#15.将某块物理盘下线/上线
/opt/MegaCli -PDOffline -PhysDrv [1:4] -a0
/opt/MegaCli -PDOnline -PhysDrv [1:4] -a0

# 16.查看物理磁盘重建进度
/opt/MegaCli -PDRbld -ShowProg -PhysDrv [1:5] -a0

#或者以动态可视化文字界面显示
/opt/MegaCli -PDRbld -ProgDsply -PhysDrv [1:5] -a0
```

# 参考资料

https://blog.51cto.com/hmtk520/2140657
http://www.ttlsa.com/tools/megacli-tool-query-raid-status/
下载地址：https://www.broadcom.com/site-search?q=megacli