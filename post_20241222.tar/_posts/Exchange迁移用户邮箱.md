---
title: Exchange迁移用户邮箱
tags:
  - Exchange日常运维任务
categories:
  - Windows Server
  - Exchange
date: 2020-12-07 23:20:46
---

# 需求分析

一个用户的邮箱需要迁移到其他的后端服务器上。

# 操作指令

```ps1
Get-Mailbox -id zhurongjian@126.com | New-MoveRequest -targetDataBase wangyiMail-DAG
```

如果不能迁移，提示有迁移任务存在。可以检查一下：

```ps1
# 检测当前的移动队列
Get-MoveRequest | Get-MoveRequestStatistics

# 取消队列
Remove-MoveRequest -identity zhurongjian@126.com
```
