---
title: Linux虚拟机如何定位硬盘
tags:
  - vSphere
  - Linux
  - Virtual Machine
categories:
  - Linux
date: 2021-10-11 23:40:00
---


# 背景

实际生活中，有用户查询操作系统中的/dev/sdb 是否在SSD卷上。

# 解决方法

## 方法一

```sh
# 查询scsi控制器信息
# Host: scsi2 Channel: 00 Id: 00 Lun: 00    
#（控制器号:scsi2  scsi通道号:channel:00  scsi ID号，对应硬盘插槽号:00  对应硬盘LUN号）
cat /proc/scsi/scsi
```

## 方法二

```sh
dmesg | grep sda
#...
#[    2.202671] sd 2:0:0:0: [sda] Attached SCSI disk
#...
```

## 方法三

```sh
# 进入目录
cd /dev/disk/by-path
# 查看
ls -l
```

# 参考资料

https://blog.csdn.net/find_zh/article/details/106156928
https://support.huawei.com/enterprise/zh/doc/EDOC1000041337/75f2d44b
https://blog.csdn.net/weixin_43778969/article/details/84389865