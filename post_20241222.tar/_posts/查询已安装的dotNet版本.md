---
title: 查询已安装的dotNet版本
tags:
  - default
catergories:
  - default
date: 2020-03-07 22:55:26
---
