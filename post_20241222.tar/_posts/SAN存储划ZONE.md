---
title: SAN存储划ZONE
tags:
  - default
categories:
  - SAN 存储
date: 2021-10-13 01:14:42
---

# 背景

# 处理思路

1. 创建别名，alicreate
2. 创建zone，zonecreate

## 创建别名

指令：alicreate "别名","WWN"

## 创建zone

指令：zonecreate "zone名" , "别名1;别名2"

# 参考资料


