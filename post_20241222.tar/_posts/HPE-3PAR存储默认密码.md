---
title: HPE-3PAR存储默认密码
tags:
  - 密码
categories: 
  - 服务器与存储
  - 存储
date: 2020-12-03 23:43:36
---

|Username|Password|Remark|
|:----:|:-----:|:-----:|
|3paradm|3pardata|	Management port (MGMT) for admin control|
|Setupusr/root|(blank)|	SP initial default credentials (before config)|
|Spvar|3V#rpar|SP default credentials (after config)|
|3parcust|3parInServ|SP default credentials, meant for customers to use|
