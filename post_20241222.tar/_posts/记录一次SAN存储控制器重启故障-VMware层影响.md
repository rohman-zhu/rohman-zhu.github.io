---
title: 记录一次SAN存储控制器重启故障-VMware层影响
tags:
  - 故障
categories:
  - default
date: 2024-03-19 22:17:33
---

# 故障现象

SAN存储触发的告警为：控制 Offline 告警邮件，显示 Node 1 失败（Node unexpectedly offline ）;
虚拟化层触发的告警为：StorageConnectivityAlarm;

# 原因

SAN存储固件异常，导致控制器自行重启。

# 解决方法

升级SAN存储控制器固件至指定版本。

## 关于ESXi多路径排查过程

```sh
# 进入ESXi Shell
# 查看VMware kernel日志 ，路径为 /var/log/vmkernel.log

# 查找关键字 3470， CmdSN  xxx from world xxx to dev "xxxx" failed 
# 参考 ：https://blog.csdn.net/Pespi_Co1a/article/details/111191902
# 参考 ： https://kb.vmware.com/s/article/1029039?lang=zh_cn
# H:0x0 , D0x2 ,P:0x0
# Host ID
# 0x0 当主机端不存在任何错误时，返回此状态。
# 0x01 如果与LUN的连接丢失，将返回此状态。【发生在LUN不再从阵列端对主机可见，或者如果与阵列的物理连接已被移除，则会发生这种情况】【https://kb.vmware.com/s/article/1003433?lang=zh_cn】
# 0x02 当HBA驱动程序无法项设备发出命令时，将返回此状态。【发生在环境中丢弃了FCP帧】
# 0x03 当正在对阵列执行的命令超时时，将返回此状态。
# 0x04 驱动程序对发生故障的目标中止命令后，将返回此状态。【通常发生在硬件错误时；如果向发生故障的目标ID发送命令也会出现】
# 0x05 如果驱动程序必须对目标中止的命令，将返回此状态。【命令超时或帧中出现奇偶校验错误】
# 0x06 将为一般错误反馈此状态。【针对其他错误（如数据超限或不足）未涵盖的事件而发生】
# 0x07 当由于存储器错误已重置设备时，将返回此状态。【通常过时的HBA固件，或者可能是发生故障的HBA】
# 0x08 遗留错误，不会返回。
# 0x0a 遗留错误，不会返回。
# 0x0b HBA驱动程序返回 DID_REQUEUE 命令，将返回此状态。【在接受到这个状态时，将重新发出I/O命令】
# 0x0c 由于暂时性错误，将返回此状态。【I/O命令将重新加入阵列并重新发出】
# 0x0d 当HBA驱动程序尝试中止命令（随后会对iocb ring中的所有命令设置IOSTAT_LOCAL_REJECT状态）时，将返回此状态。

# Vital Product Data(VPD)
# https://kb.vmware.com/s/article/1010244?lang=zh_cn
# https://kb.vmware.com/s/article/289902?lang=zh_cn
# https://www.t10.org/lists/2asc.htm
# 0x80 ,设备序列号
# 0x83 ,设备标志号
# 0x85 ,管理网络地址
# 存储设备重新枚举期间，VMware ESX/ESXi VMkernel 向目标发送 SCSI 报告 LUN 命令 (0xa0) 以检索 LUN 列表，向每个 LUN 发送 SCSI 查询命令 (0x12) 以确定设备类型（磁盘、CD-ROM、USB 等）、设备品牌和型号以及设备支持的功能。
# 如果 SCSI 设备不支持某个 VPD 页面 VPD，它在响应此类请求时可能会出现错误。尤其是，它可能会返回 SCSI 状态 2（检查状况），其中，感知密匙为 5（非法请求），附加感知代码 (ASC) 和附加感知代码标识符 (ASCQ) 设置为 0x20/0x0 或 0x24/0x0。
# 1. 本地存储设备通常不支持 VPD 页面 0x83，从而无法用于裸设备映射 (RDM)。页面 0x83 的内容用作设备的唯一标识符。
# 2. CD 或 DVD-ROM 设备通常不支持 VPD 页面 0x80、0x83 或 0x85。
# 3. 一些设备控制器不支持报告 LUN。如果不存在 LUN 0 或报告的 SCSI 版本为 2 或更低版本，ESX/ESXi 主机会对此控制器上的 LUN 进行迭代扫描。


# 查找关键字 lpfc_els_rcv_rscn 
# https://kb.vmware.com/s/article/2151839?lang=zh_CN
# lpfc为驱动程序


# [恢复] 查找关键之 Device .... performance has improved . I/O latency reduced from xxxx microseconds to xxx microseconds.

# [恢复] lpfc : lpfc_reportStats: xxxxx Compression log for fcp target 8 , path is ok ,IO errors: busy 9 , retry xxxxx,no_connect xx,fcperr xxxx ,tmo x;
# https://kb.vmware.com/s/article/76350
```


