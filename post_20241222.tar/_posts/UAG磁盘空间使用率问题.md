---
title: UAG磁盘空间使用率问题
tags:
  - 故障
categories:
  - VMware
  - Horizon View
date: 2021-11-30 00:37:56
---

# 背景

UAG近期被主流Horizon View架构中，用于替换安全服务器。这个是基于Photon Linux封装的操作系统，官方直接提供OVF包让我们导入虚拟化环境中。然而，这套东西貌似还没有开发完善，连基本的扩容操作都没有，ovf中可怜的20G空间很快就会被审计日志占满。当空间被占满后，就容易影响原有的业务，然而面对这种窘境，官方竟然没有任何一篇KB能够解决！

除了空间问题，还有其他槽点：
1. UAG还无法通过 WEB 控制台设置时区，甚至你都不知道你设置了哪一个时区!
2. Web控制台每次刷新一下，就得重新输入账户密码！
3. SNMP可监控的项实属过少。
4. 无法讲明的会话机制，也无法讲明的释放机制。（我曾经因为会话数达到最大值而被中断业务。 T T）
5. 最为致命的是ovf没有使用LVM来分区，无法做到在线扩容。

# 解决思路

既然底层是基于Linux封装的，那也就意味着可以自定义定期运行的脚本。由此，我们可以基于shell脚本+crontab任务来解决，定期将已归档的审计日志（/var/log/audit/audit.log.gz)、系统日志(/var/log/message.x)、认证日志(/var/log/auth.log.gz)转移至其他地方。

## 底层添加磁盘

略

## 初始化分区

略

## 脚本

```sh
#!/bin/bash
# @Rohman
# 2021-11-30
# 将目标日志挪到/archive目录下

# 设置目录变量，如果要执行的指令，需要用$()
Directory="/archive/$(date '+%Y-%m-%d')"

# 创建目录
mkdir $Directory

# 移动对应的文件
mv /var/log/audit/audit.*.gz $Directory
mv /var/log/message.* $Directory
mv /var/log/auth.*.gz $Directory
```

## 创建定期任务

```sh
# 编辑任务
crontab -e

# 进入任务配置
# 格式为 分、时、日、月、周
# 每个月的月初执行即可，例如 每一个月的1日00:00执行
0 0 1 * * [脚本的绝对路径]

# 保存退出

# 检查是否有配置任务
crontab -l

# 检查日志
less /var/log/cron
```