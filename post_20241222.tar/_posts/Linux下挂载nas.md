---
title: Linux下挂载nas
date: 2018-10-16 00:23:14
tags: Linux
---

# 需求 #

* NAS服务器 ： 10.10.1.1
* NAS文件路径： volume/ftp
* Linux主机 ： 10.10.2.1
* Linux版本 ： Ubuntu 14.04 LTS
* Linux内核 ： 3.13.0-24-generic
* 登录用户 user:user
  
需要创建一个Linux服务器用于备份，因此挂载一个3T空间的NAS服务器文件目录,并开启 ftp 服务。

# 实现记录 #

```shell
# apt-get install nfs-common -y
# sudo mkdir /mnt/nas
# sudo chown user:root /mnt/nas
# mount -t nfs 10.10.1.1:/volume/ftp /mnt/nas
# df -h
# vim /etc/fstab

# /etc/fstab:static file system information.
10.10.1.1:/volume/ftp /mnt/nas nfs defaults 0 0
:wq

# apt-get install openssh-server openssh-client -y
# ps -e | grep ssh
# netstat -ano | grep 22
# vim /etc/ssh/sshd_config

Subsystem sftp internal-sftp
Match Group sftp
    ChrootDirectory /mnt/nas/
    ForceCommand internal-sftp
    AllowTcpForwarding no
:wq

# service ssh restart
# /etc/init.d/ssd restart
# ps -e | grep ssd
# netstat -ano | grep ssh

# groupadd sftp
# useradd -g sftp -s /bin/false mysftp
# chown root:sftp /mnt/nas
# chmod 755 /mnt/nas

```

# 命令笔记 #


* df -h：查看磁盘占用情况
* df -T：查看所有磁盘的文件系统类型(type)
* fdisk -l：查看所有被系统识别的磁盘
* mount -t type device dir：挂载device到dir
* ChrootDirectory设置的目录/sftp/sftpuser1的所有者必须是root,并且该目录的上级目录/sftp的所有者也必须是root. 

# 问题 #

* /bin/false 和 /sbin/nologin 的区别在哪里？
  


