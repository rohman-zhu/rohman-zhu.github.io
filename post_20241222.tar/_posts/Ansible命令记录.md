---
title: Ansible命令记录
tags:
  - Ansible
categories:
  - Linux
  - Ansible
date: 2021-02-22 00:50:38
---
# 常用命令

```sh
# 上传文件到目标群组
ansible group1 -m copy -a "src=[本地文件所在的路径] dest=[目标服务器的目标路径]"

# 执行指令
ansible group1 -m shell -a "指令"
```