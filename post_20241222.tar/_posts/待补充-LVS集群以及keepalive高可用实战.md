---
title: LVS集群以及keepalive高可用实战
date: 2018-01-21 19:31:08
tags: Linux
---
# 负载均衡LVS,Keepalive#

## APR (Address Resolution Protocol) 地址解析协议 ##

> 通过IP地址,获取主机的MAC地址

查看ARP:

```cmd
# Windows && Linux
arp -a
```

1. 有arp缓存表可以加速ARP的解析速度.
2. 给恶意黑客带来攻击服务器主机的风险(ARP欺骗)

> ARP属于三层协议

### ARP欺骗原理 ###

ARP攻击就是通过伪造IP地址和MAC地址对(IP-MAC),实现ARP欺骗.

解决方法 : 

* 记录正确网关地址

### 高可用服务器对 切换时ARP缓存问题 ###

```sh
/sbin/arping -I eth0 -c 3 -s 10.0.-.162 10.0.0.253
/sbin/arping -U -I eth0 10.0.0.162
```

### 路由器等设备迁移时,要考虑ARP缓存的问题 ###

同上一个问题.

## LVS (Linux Virtual Server) ##

负载均衡主要功能
 
1. 减少用户等待相应时间,系统处理能力得到大幅度提高.
2. 单个负载的运算分担到多台节点设备上做并行处理.
3. 7*24的服务保证

LVS:

1. 实现调度的工具IPVS
2. 管理工具 IPVSADM
3. keepalived 实现管理及高可用 

术语:

| 名称 | 缩写 | 说明 |
|:----:|:-----:|:-----:|
|虚拟IP地址|VIP|VIP为Director用于向客户端计算机提供服务的IP地址|
|真实IP地址|RIP||
|客户端主机IP|CIP||
|Director的IP地址|DIP|用于连接内外网络的IP 地址,物理网卡上的IP 地址.|

### 四种工作模式 ###

#### DR模式(Director Router) ####

通过改写请求报文的目标MAC地址,通过LVS发送给服务器,服务器将结果返回给客户端.

> 请求过程: CIP -> VIP -> 更改 VIP:MAC -> VIP:RMAC(真实服务器的MAC) -> CIP -> VIP -> L0绑定VIP,并且抑制ARP

 ## 小结 ##