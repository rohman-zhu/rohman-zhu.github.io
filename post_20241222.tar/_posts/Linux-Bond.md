---
title: Linux_Bond
tags:
  - default
categories:
  - Linux
date: 2024-09-08 22:58:47
---

# Linux bond 模式

Bonding驱动一共提供了7种负载均衡模式，它们分别是：balance-rr、active-backup、balance-xor、broadcast、802.3ad、balance-tlb、balance-alb，其中最常用的是balance-xor和balance-alb。

0. balance-rr or 0：轮询模式，提供负载平衡和容错。该模式下两个网口都工作。
1. active-backup or 1：主备倒换模式，提供冗余功能，该模式下只有一个网口工作，另一个做备份。本模式可以和任何二层（Layer-II）交换机一起工作。
2. balance-xor or 2：基于HASH算法的负载均衡模式，网卡的分流按照xmit_hash_policy的TCP协议层设置来进行HASH计算分流，使各种不同处理来源的访问都尽量在同一个网卡上进行处理。
3. broadcast or 3：广播模式，所有被绑定的网卡都将得到相同的数据，一般用于十分特殊的网络需求。
4. 802.3ad or 4：802.3ad模式，要求交换机也支持802.3ad模式，理论上服务器及交换机都支持此模式时，网卡带宽最高可以翻倍（如从1Gbps翻到2Gbps）。在本模式中，bonding可以和支持IEEE 802.3ad动态连接聚合（Dynamic Link Aggregation）的系统一起工作，大多数可管理交换机和很多不可管理交换机都支持802.3ad。
5. balance-tlb or 5：适配器输出负载均衡模式，输出的数据会通过所有被绑定的网卡输出，接收数据时则只选定其中一块网卡。如果正在用于接收数据的网卡发生故障，则由其他网卡接管，要求所用的网卡及网卡驱动可通过ethtool命令得到speed信息。
6. balance-alb or 6：适配器输入/输出负载均衡模式，在"模式5"的基础上，在接收数据的同时实现负载均衡，除要求ethtool命令可得到speed信息外，还要求支持对网卡MAC地址的动态修改功能。

## 需要交换机配置的策略

### mode=0,balance-rr

轮询的方式将数据包流转，第一个包走eth0，第二个包走eth1，知道数据包发送完毕。

优点：流量提高一倍；
缺点：需要接入交换机做端口聚合，否则可能无法使用；

### mode=2,balance-xor

表示 XOR Hash负载分担，和交换机的聚合强制不协商方式配合。（序号xmit_hash_policy,需要交换机配置port channel）

特点：基于指定的传输HASH策略传输数据包。缺省的策略是：（源MAC地址 XOR 目标MAX地址）% Slave数量 。 其他的传输策略可通过xmit_hash_policy选项指定，此模式提供负载均衡和容错能力

### mode=3,broadcast

表示所有包从所有网络口发出，不均衡，只有冗余。

特点：每一个slave接口都在传输每一个数据包。

### mode=4,802.3ad

表示使用802.3ad协议，需要和交换机聚合LACP方式配合，标准要求所有设备在聚合操作时，要在同样的速率和双工模式，每一个连接只能用一个网络接口。

前置条件：
1. ethtool 支持获取每一个slave的速率和双工设定；
2. 交换机支持 IEEE802.3ad Dynamic link aggregation;

## 不需要交换机配置的策略

### mode=1,active-backup

为主备模式

优点：冗余性高；
缺点：链路利用率低，只有一块网卡在使用；


### mode=5,balance-tlb

根据slave负载情况选择slave进行发送，接收时使用当前轮到的slave。该模式要求slave接口的网络设备驱动有某种ethtool支持，而且ARP监控不可用。

特点：不需要任何特定的交换机支持，在每一个slave上根据当前的负载分配外出流量。如果正在接受数据的slave出现故障，另一个slave接管失败的slave的MAC地址。

前置条件：
1. ethtool支持获取每一个slave的速率

### mode=6,balance-alb

在mode=5基础上加上了 “接收负载均衡（receiveload balance）”,不需要交换机支持，接收负载均衡是通过ARP协商实现的。

# 参考资料

netplan yaml：https://netplan.readthedocs.io/en/latest/netplan-yaml/
fail_over_mac: https://www.ibm.com/docs/en/linux-on-systems?topic=mode-option-fail-over-mac
