---
title: Linux-EXT4文件系统LVM缩容实例
tags:
  - 故障
categories:
  - Linux
  - Ubuntu
date: 2023-03-13 23:54:47
---
# 需求

将已有的一个文件系统，缩容10G；目标文件系统也是由LVM组成的；

# 操作记录

1. 确保文件系统内可用空间的部分比要减少的空间大。（例如实际可用空间为20G，我们要缩容10G；）
2. 目标文件系统要解除挂载状态，即umount状态，如果是系统根目录，则需要使用安装iso进入救援模式去操作；
3. 检查文件系统块是否正常，即用e2fsck检测目标文件系统；
4. 文件系统层做缩容，即用resize2fs或resize4fs操作；
5. LVM层做缩容；

```sh
# 目标文件系统为/,缩容10g
# 路径为 /dev/vg-root/lv-root

# 步骤1，确认可用空间情况。（略）

# 步骤2，挂载安装盘，进入救援模式。（略）
# 步骤2，目标文件系统不需要挂载。

# 步骤3，检查文件系统情况
e2fsck -f /dev/vg-root/lv-root

# 步骤4，将目标文件系统缩容至指定大小 ，即总大小 - 需缩容的大小
resize2fs /dev/vg-root/lv-root [最终大小]

# 步骤5，LVM层缩容
lvs
lvreduce -L [最终大小] /dev/vg-root/lv-root
lvs

## 目标磁盘=缩容大小
vgs
vgreduce vg-root [目标磁盘]
vgs
```

# 参考资料

https://anjia0532.github.io/2021/04/27/ubuntu-lvm/