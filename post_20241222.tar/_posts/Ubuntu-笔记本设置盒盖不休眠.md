---
title: Ubuntu-笔记本设置盒盖不休眠
tags:
  - default
categories:
  - Linux
  - Ubuntu
date: 2023-01-27 23:09:36
---
# 需求

有一台笔记本电脑需要当服务器使用，安装的是Ubuntu Desktop 22.04版本，平时需要合上笔记本盖。

# 设置方式

```sh
#编辑下列文件：/etc/systemd/logind.conf
vim /etc/systemd/logind.conf

#HandlePowerKey按下电源键后的行为，默认power off
#HandleSleepKey 按下挂起键后的行为，默认suspend
#HandleHibernateKey按下休眠键后的行为，默认hibernate
#HandleLidSwitch合上笔记本盖后的行为，默认suspend（改为ignore；即合盖不休眠）在原文件中，还要去掉前面的#

# 然后将其中的： #HandleLidSwitch=suspend
# 改成下面，记得去掉“#”号：
HandleLidSwitch=ignore

# 最后重启服务
service systemd-logind restart
```

# 参考资料

https://blog.csdn.net/xiaoxiao133/article/details/82847936