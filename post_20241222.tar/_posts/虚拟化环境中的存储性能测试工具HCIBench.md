---
title: 虚拟化环境中的存储性能测试工具HCIBench
tags:
  - 磁盘性能测试
categories:
  - VMware
  - vSphere
date: 2024-09-22 18:07:05
---

# 背景说明

一般部署完虚拟化环境后，需要使用一些工具用于测试磁盘性能。
传统使用FIO，VDBench来测试性能，但在虚拟化环境中，官方有一个免费且方便的测试工具，可以一键部署，并下发测试任务；
对比传统的FIO、VDBench来测试，HCIBench不再需要我们申请虚拟机，部署测试节点、服务节点，且写好测试文件，HCIBench会纳管vCenter，从而实现自动部署测试节点。

# FHCIBench 介绍
 
本章节引用博客  https://www.ethanzhang.xyz/

官方推荐HCIBench作为vSAN的性能测试工具，其本质是对开源的性能测试工具Vdbench 和Fio以Photon guest VM为基础镜像进行重新打包。

> PhotonOS是VMware专为ESXi定制的容器操作系统

然后虚拟机模版部署在vSphere平台上，利用RVC/GOVC控制vCenter通过自动化脚本向vSphere平台部署用于基准性能测试的虚拟机，用于产生测试工作负载

在各工作负载的虚拟机内，利用FIO/VDBench开源工具进行基线测试，HCIBench控制虚拟机(Control VM)会不断收集相关信息，同时新添加的Grafana工具，以容器化部署的方式在Control VM中对外以可视化的形式提供服务。

## FIO

FIO（Flexible I/O Tester）是一个用于测试磁盘、文件系统、块设备和网络设备性能的工具。它可以模拟不同类型的I/O负载，包括随机或顺序读写、混合读写、随机或顺序访问等

FIO提供了丰富的选项和参数，可以对测试进行高度定制化配置，以满足各种应用场景和需求。FIO是开源软件，可在Linux、Unix、Windows等多种平台上运行

## VDBench

VDBench是一款基于Java编写的性能基准测试工具。它可以测试不同类型的存储设备，如磁盘，网络文件系统（NFS），网络附加存储（NAS）和存储区域网络（SAN）等

VDBench的设计目标是测试存储系统的性能特征，如带宽和IOPS（每秒输入/输出操作数）

## HCIBench架构

下载地址：

原地址：https://flings.vmware.com/hcibench
新地址：https://github.com/vmware-labs/hci-benchmark-appliance


HCIBench专为针对vSphere中的共享或本地数据存储运行性能测试而设计，它使用Vdbench或Fio生成测试工作负载

> 实际上HCIBench并没有包括Vdbench的二进制程序，如果需要以Vdbench的方式提供测试，在测试阶段会从Oracle网站进行在线下载

HCIBench以开放虚拟化设备（OVA格式）的形式提供，用于安装在vSphere上，具体架构如下图所示

![HCIBench Applicance](https://typorabyethancheung911.oss-cn-shanghai.aliyuncs.com/typoralimage-20230831181326290.png)

### 包含以下组件

#### 1、Ruby vSphere Console (RVC)

RVC是基于Ruby的一个vSphere命令行工具，他可以管理ESXi或者vCenter

#### 2、GOVC

GOVC是基于 VMware 官方govmomi库的一个 vSphere 命令行工具，使用它可以通过命令或脚本，实现对 VMware vSphere 系统的管理

注意：

从HCIBench2.6开始GOVC开始添加到Control VM中，HCIBench的核心引擎最终将从RVC转移到GOVC

#### 3、Docker

​ 3.1 Graphite Container: 1.1.5-10

​ 3.2 Grafana Container: 8.3.11

​ 3.3 InfluxDB Container: 1.8.1-alpine

#### 4、vSAN Observer

#### 5、Automation bundle

#### 6、Configuration files

#### 7、Fio binary: 3.30

#### 8、Photon guest VM template: 3.0

其中Photon guest VM template用于部署Guest VM产生工作负载

# 防火墙策略

| SRC | DST | TCP Port | UDP Port | Description |
|:---:|:---:|:---:|:---:|:---:|
| HCIBench | vCenter | 443 | - | 纳管vCenter，使HCIBench可以读取到VCSA信息并且做下发部署指令 |
| HCIBench | ESXi Host | 443 | - | HCIBench 获取到ESXI Host用于检测目标ESXiHost信息 | 
| HCIBench | ESXi Host | 22 | - | 若每次测试完毕后要清除数据，则需要开通此端口 |
| Operator Machine | HCIBench | 80,443,8443 | - | 用于访问HCIBenc的WEB界面，完成配置 | 

# 查看最终测试结果

https://HCIBenchIP:8443/results

# IO模型建议

除了覆盖到以下测试项，如果未达到集群瓶颈，可以再增加资源进行压力测试，比如增加测试的虚拟机、测试的虚拟机配置提高，并增加每台虚拟机测试的进程；

## 必测项目--集群整体性能

1. 块大小从4K到1024K均需要覆盖；
2. 顺序、随机均需要覆盖；
3. 100%读、100%写、70%读；

## 必测项目--单个虚拟机在此集群中能跑到的性能

1. 块大小从4K到1024K均需要覆盖；
2. 顺序、随机均需要覆盖；
3. 100%读、100%写、70%读；


# 参考资料

1. https://core.vmware.com/resource/vsan-proof-concept-vsan-performance-testing
2. https://www.ethanzhang.xyz/2023/09/01/%E4%BD%BF%E7%94%A8HCIBench%E5%B7%A5%E5%85%B7%E5%AF%B9vSAN%E8%B6%85%E8%9E%8D%E5%90%88%E8%BF%9B%E8%A1%8C%E6%80%A7%E8%83%BD%E6%B5%8B%E8%AF%95/