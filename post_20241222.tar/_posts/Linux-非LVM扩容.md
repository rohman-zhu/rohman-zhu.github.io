---
title: Linux-非LVM扩容
tags:
  - 扩容
  - SOP
categories:
  - Linux
date: 2022-09-13 23:47:07
---

# 背景

Linux Server的磁盘没有做LVM，导致无法很直接地在线扩容。但是如果一个磁盘中的所需要扩容的分区在这个磁盘的末尾分区，我们还是有办法扩容的；例如，sda磁盘中，一共只有sda1\sda2\sda3，这3个分区，如果我们要扩容sda3分区，则有办法扩容；但是若我们想扩容sda1或sda2分区，则没有办法操作。

# 扩容目标分区--末尾分区sda3

## 虚拟化层对目标磁盘扩容

在虚拟化层找到目标虚拟机的磁盘，将目标磁盘扩容50GB。

> 如果是VMware vSphere 中磁盘无法直接修改容量，则需要检查一下当前虚拟机是否有快照；若有快照，则是无法修改磁盘大小的。

> 如果目标虚拟机有多个磁盘的话，需要确定对应关系，则可以使用以下指令确认位置：

```sh
# 查询scsi控制器信息
# Host: scsi2 Channel: 00 Id: 00 Lun: 00    
#（控制器号:scsi2  scsi通道号:channel:00  scsi ID号，对应硬盘插槽号:00  对应硬盘LUN号）
cat /proc/scsi/scsi

# 进入目录
cd /dev/disk/by-path
# 查看
ls -l
```

## OS内识别磁盘扩容部分

如果当前虚拟机是在开机状态下进行的扩容，则有两种方式让系统识别到扩容的部分，第一个是重启虚拟机；第二个是使用指令扩容。

以下为指令识别：

```sh
# 方法1 ， 触发目标磁盘的扫描
echo 1 > /sys/block/sda/device/rescan

# 方法2
ll /sys/block/
ll /sys/class/scsi_disk/
# 使用两个指令进行对比，确定目标磁盘所在的总线编号
echo 1 > /sys/class/scsi_disk/[目标总线编号]/device/rescan

# 识别完毕后，使用fdisk指令查看
fdisk -l

```

番外--新增硬盘识别：

```sh
ls /sys/class/scsi_host/ | while read host ; do echo '- - -' > /sys/class/scsi_host/$host/scan ; done
```

## 分区扩容--方法一

```sh
# 末尾分区扩容
growpart  [目标磁盘]  [分区号]]
```

## 分区扩容--方法二【此方法有风险】

若出现ERROR: GPT PMBR SIZE MISMATCH，则需要修复一下；

```sh
parted -l
fix
```

本质上就是修改分区的结束位置
因此整个动作分为，删除目标分区、新建目标分区、保持起始位置不变、修改结束位置。

操作前可以给虚拟机打快照！！

```sh
# 修改目标磁盘
fdisk /dev/sda

# 查看当前分区情况，记录目标分区的起始位置、末尾位置
p

# 删除目标分区
d
# 选择目标 sda3
3

# 千万不能保存退出！
# 新建分区
n

# 选择目标分区sda3
3

# 输入起始位置
略

# 输入末尾位置
# 最大

# 查看当前的分区情况 ，确认目标分区的起始位置是否与之前相同
# 确认目标分区已扩容
p

# 确认无误后，保存退出
w
```

> 注意：以上操作若有异常，可以按Ctrl + C退出。

## 让OS识别增长的分区

```sh
# ext4、ext3、ext2文件系统
resize2f /dev/sda3

# xfs文件系统
xfs_growfs /dev/sda3

```


# 参考资料

非LVM在线识别：  https://blog.whsir.com/post-6379.html
磁盘修复： https://arstech.net/gpt-pmbr-size-mismatch/

