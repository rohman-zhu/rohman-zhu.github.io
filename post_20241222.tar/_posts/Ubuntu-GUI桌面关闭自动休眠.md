---
title: Ubuntu-GUI桌面关闭自动休眠
tags:
  - 故障
categories:
  - Linux
  - Ubuntu
date: 2023-04-30 16:03:03
---

# 故障描述

服务器过几分钟的时候就卡死了，无法唤醒；

# 原因分析

进入系统日志 /var/log/syslong ,里面看到有 suspend 字样；

# 解决方法

```sh
systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
```