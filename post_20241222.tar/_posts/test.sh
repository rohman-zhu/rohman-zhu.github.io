#!/bin/bash
# kernal base optimization

# Create directory to save yum repo
mkdir /mnt/yum.repo

# Install nfs-utils

# Mount web_server yum cache
mount -t nfs 172.16.177.145:/var/cache/yum/x86_64/6/ /mnt/yum.repo/

# Add yum-media.conf
sed -i "s#media/CentOS#mnt/yum.repo#g" /etc/yum.repo.d/CentOS-Media.repo
yum makecacahe

# -----------
# Turn off the iptable and selinux
chkconfig --level 35 iptables off
sed -i "s#SELINUX=enforcing#SELINUX=disabled#g" /etc/selinux/config


#Change yum repo
#wget -O /etc/yum.repos.d/CentOS-Base.repo httpL//mirrors.aliyun.com/repo/Centos-6.repo
#yum makecache
