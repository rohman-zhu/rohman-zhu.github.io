---
title: Vmware Horizon View的API操作
tags:
  - VMware
catergories:
  - 虚拟化
date: 2020-01-26 23:32:24
---
# 前言

需要获取当前会话数量。

# 从API文档查找

## Data Object - LocalSessionStatistics

rdsSessionStatistics ：

The session state Statistics for RDS sessions.
This property cannot be updated.

> 是 SessionsStateStatistics 类型

### SessionsStateStatistics 类

| NAME | TYPE |	DESCRIPTION |
|:----:|:-----:|:----:|
| numActiveSessions	| xsd:int | The number of active sessions.This property cannot be updated.
| numIdleSessions	| xsd:int |  The number of idle sessions.This property cannot be updated.
| numDisconnectedSessions	| xsd:int | The number of disconnected sessions. This property cannot be updated.
| numPendingSessions	| xsd:int | 	The number of pending sessions. This property cannot be updated

## 样例 ##

```bat
$hvServer = Connect-HVServer -Server <Server> -User <UserName> -Password <Password> -Domain <Domain>
$services = $hvServer.ExtensionData
$<serviceHelper> = New-Object VMware.Hv.<YourServiceName>

```

# 参考资料

https://www.simonlong.co.uk/blog/horizon-view-api/
https://blogs.vmware.com/euc/2017/01/vmware-horizon-7-powercli-6-5.html
http://www.virtu-al.net/2016/12/08/getting-started-powercli-6-5-horizon-view/
https://code.vmware.com/apis/902/view