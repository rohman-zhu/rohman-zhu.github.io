---
title: GNS3安装ASA
date: 2019-01-06 16:13:37
tags: 网络知识
---

# 前言

在MacOS上面安装GNS3 。

* GNS-2.1.11 ： https://gns3.com/software/download
* GNS3-VM-2.1.11 : https://gns3.com/software/download-vm
* ASA-9.gns3a : https://gns3.com/marketplace/appliance/cisco-asav
* asav992.qcow2 : http://down.51cto.com/data/2444351

MAC 上面安装GNS3 比较简单，直接拖入 Application 即可。
开启GNS3时，也需要开启 GNS3 的虚拟机 ， 并且将GNS3的服务器地址跟 GNS3 VM的IP地址设置在同一个网段即可。

# GNS3 导入ASA

在左上角的【文件】选项卡中，有一个【Import Applicance】，选择刚下载的cisco-asav.gns3a 。

接下来需要找到对应的镜像 ， 选中 ASAv 9.9.2 点【import】（一般系统会自动检测，如果电脑存在该镜像，则会显示 Found）

后面的选项都默认即可。

# 通过VNC打开ASA

如果在GNS3中右键 ASA ，点击【Console】 ，则会自动调用系统的屏幕共享应用。我这边没有成功过，还是用第三方的 “VNC Viewer” ， 连接提示的IP地址，密码默认为空即可。

这个是MACOS默认调用的屏幕共享程序，不知道是怎么回事。。。

```shell
osascript -e 'set posix_path to do shell script "echo \"$PATH\""' -e 'tell application "Terminal"' -e 'activate' -e 'do script "echo -n -e \"\\033]0;%d\\007\"; clear; PATH=" & quoted form of posix_path & " telnet %h %p ; exit"' -e 'end tell'
```

* VNC-IP:192.168.1.56::5900
* 密码为空

# 将连接方式改为telnet方式

先通过VNC的方式连接ASA

```shell
ciscoasa#conf t
ciscoasa(config)# cd coredumpinfo
ciscoasa(config)# copy coredump.cfg disk0:/use_ttyS0
```
# 修改ASA的设备名称与登录密码

```shell
#进入特权模式
enable
#进入配置文件
configure terminal
#修改设备名
hostname asa-01
#修改登录密码
passwd test123
#修改特权用户的密码
enable passwd test123
#保存配置
write
```
# 参考资料

* 让ASA的连接方式从VNC改为Telnet ： https://gns3.com/qa/how-to-configure-any-asav-qcow2-