---
title: >-
  ESXi_Large-Scale workloads with intensive IO patterns might require queue
  depths significantly greater than paravirtual SCSI default values
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2024-09-04 00:26:21
---
# 场景描述

部分虚拟机业务对存储的IO有着极高的需求，在硬件条件有限的情况下，可以优化一下虚拟化层的配置。

# 操作过程

## 虚拟化层的修改

核心就是修改 HBA 设备的队列深度

```sh
# 先确认当前使用的哪种类型的HBA
## Qlogic HBA卡 类查询
esxcli system module list | grep qla
##  Emulex HBA卡 类查询
esxcli system module list | grep lpfc

# > 看上述指令哪一个指令有结果显示
# 修改 Qlogic 类HBA卡
esxcli system module parameters set -p ql2xmaxqdepth=128 -m [根据上述指令查询的设备]
# 修改 Emulex 类HBA卡
esxcli system module parameters set -p lpfc0_lun_queue_depth=128 -m [根据上述指令查询的设备]

# 调整完毕后，需要重启 ESXi
reboot

# 重启后使用指令查询
esxcli system module parameters list -m [根据上述指令查询的设备]
```

## 虚拟机设置修改

将磁盘改为 PVSCSI 类型。

## 虚拟机OS修改

### Linux 类修改

```sh
# 内核加载
vim /etc/modprobe.d/pvscsi
# 添加以下内容，并保存
options vmw_pvscsi cmd_per_lun=254 ring_pages=32

# 修改启动文件 /etc/grub.conf 或 /boot/grub/grub.cfg
# 添加
vmw_pvscsi.cmd_per_lun=254
vmw_pvscsi.ring_pages=32

# 重启服务器
reboot

# 重启后确认信息
cat /sys/module/vmw_pvscsi/parameters/cmd_per_lun
cat /sys/module/vmw_pvscsi/parameters/ring_pages
```

### Windows 类修改

```cmd
# 添加注册表项
REG ADD HKLM\SYSTEM\CurrentControlSet\services\pvscsi\Parameters\Device /v DriverParameter /t REG_SZ /d "RequestRingPages=32,MaxQueueDepth=254"

# 修改完毕后，重启服务器
shutdown /r /t 1

# 确认是否生成注册表
# HKLM\ SYSTEM\CurrentControlSet\services\pvscsi\Parameters\Device.
# 确认两个值是否为RequestRingPages=32, MaxQueueDepth=254.
```

# 参考资料

https://knowledge.broadcom.com/external/article/343323/largescale-workloads-with-intensive-io-p.html