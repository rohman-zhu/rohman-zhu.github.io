---
title: '设置NTP服务器'
date: 2018-11-10 22:05:53
tags: Linux
---

# 前言

前些日子遇到google-authenticator验证失败，排查过程中发现 静态token能生效，然而动态的token却无法生效，经过一番的排查，锁定为时间问题，服务器上面的时间跟当前的时间偏差竟然达到10分钟的偏移，所以这个是导致动态token验证的主要原因。 因此，今天就记录ntp时间同步的相关操作，因为集群中没有设置ntp服务器（非常有必要建立NTP服务器），所以连接的NTP服务器，我这里选用 阿里云 的时间服务器。

* NTP = 网络时间协议(Network Time Protocol)，它是用来同步网络中各个计算机的时间的协议

# 准备工作

* OS：CentOS 6.9

# 操作实例

```shell
# 安装ntp服务
yum install ntp -y

# 设置 ntp 的主节点
vim /etc/ntp.conf
#---ntp.conf---#
server ntp1.aliyun.com
server ntp2.aliyun.com

# ntp 用到的端口是UDP 123 ， 因此防火墙拦截会导致ntp无法使用
# 开启服务后，可以用netstat看该端口是否有运行
netstat -lntup | grep 123

# 查看ntp运行状态
watch ntpq -p
# 一般需要等待20分钟左右，我这里6分钟就生效了。
# 当服务器地址前面有 “*” 时 ， 表示正在使用该服务器做时间同步
ntpstat
```

# 知识梳理

## 标准时间 ##

1、美国中部时间：Central Standard Time (USA) UT-6:00
2、澳大利亚中部时间：Central Standard Time (Australia) UT+9:30
3、中国标准时间：China Standard Time UT+8:00
4、古巴标准时间：Cuba Standard Time UT-4:00

# 参考资料

* 设置实例 ：https://www.cnblogs.com/quchunhui/p/7658853.html
* 设置实例 ：https://blog.csdn.net/caodongfang126/article/details/79670636
* NTP服务器官网 ：http://www.pool.ntp.org/
