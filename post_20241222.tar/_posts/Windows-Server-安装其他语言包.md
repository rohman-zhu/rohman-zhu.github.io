---
title: Windows Server  安装其他语言包
tags:
  - default
categories:
  - Windows Server
date: 2024-04-22 16:44:54
---
# 步骤

1. 下载语言包；
2. 将所需的语言cab包传入目标服务器；
3. 运行lpksetup.exe,安装对应的补丁包；

# 参考

https://www.dell.com/support/kbdoc/zh-cn/000220901/windows-server-2022%E7%A6%BB%E7%BA%BF%E5%AE%89%E8%A3%85%E8%AF%AD%E8%A8%80%E5%8C%85
https://netshopisp.medium.com/how-to-install-language-pack-on-windows-server-2019-8d477d8c3c2e
