---
title: 扩容坑-32bit-EXT4最大限制16TB
tags:
  - 故障
categories:
  - Linux
date: 2023-02-19 23:33:56
---
# 背景

一个EXT4分区需要做扩容动作，由16TB扩容至32TB，目标lv是条带卷，条带宽度为8；

底层添加完磁盘后，系统层需要做LV扩容与分区resize，在执行resize2fs指令，提示 “ New size too large to be expressed in 32 bits”

# 原因分析

默认情况下EXT4为64位，可支持的空间大于16TiB，而目标EXT4文件系统最大支持空间为16TB ，即 4K * 2^32 = 16TB ,查询方式：

```sh
tune2fs -l [目标卷] | grep 'Filesystem features'
```


# 其他相关指令

## 如何创建32bit的ext4文件系统

```sh
# 编辑mke2fs.conf里面的ext4选项
# 把 auto_64-bit_support = 1 改为 0
mkfs.ext4 /dev/vg-data/lv-data
```
## 如何检查目标分区是否有64bit功能

```sh
tune2fs -l [目标卷] | grep 'Filesystem features'
# 如果为64bit，会有64bit标识符；如果未显示，则是32bit；
```

## 条带lv缩容是否对数据有影响测试

```sh
# 在目标卷放置一个test文件，空间大小为15.5TiB，记录md5值
dd if=/dev/zero of=/data/test-15.8 bs=1G count=15872
md5sum /data/test

# 开始缩容
# 由16.1TB缩容至15.9TiB
lvreduce -L -0.02T /dev/vg-data/lv-data

# 检查是否影响数据
md5sum /data/test

# 比对MD5值
```

# 参考资料

https://blog.csdn.net/bing154690097/article/details/122351797