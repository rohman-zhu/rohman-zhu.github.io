---
title: Windows-文件服务器
tags:
  - default
categories:
  - Windows Server
date: 2021-01-29 00:00:11
---

# 文件服务器

DFS（Distributed File System）分布式文件系统

- 相当于对共享服务器建立索引

## Failover Clust

主要用于后端存储服务器（SQL Server，Exchange Mailbox ，FS）

前提条件：
1. 必须要域架构
2. 标准的Cluster需要的共享存储（SQL Server的 Always on）
3. 仲裁服务器（服务器总数为偶数，则需要仲裁服务器。因为偶数个服务器无法裁决集群中的服务器健康状态，需要有投票节点。）

群集的两种模式：
1. Active/Passive:主备模式
2. Active/Active:双主模式


## 部署流程

1. 安装DFS命名空间。
