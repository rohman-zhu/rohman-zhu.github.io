---
title: Citrix_XenDesktop_7.6_Windows_Server_2019实测记录
tags:
  - VDI
categories:
  - default
date: 2024-10-10 02:23:06
---

# 前言

最近找到一个 Citrix老版本安装包，版本号应该是 7.6 ；这么一个上古版本的Citrix，想尝试部署试试，结果发现在Windows Server 2019中无法顺利安装。

## 出现的问题

### StoreFront

1. 访问URL没有自动跳转到 Citrix 正确的应用目录，这个应该是通病，要自行设置IIS；
2. 没有配置证书；
3. 传输用HTTPS就无法显示应用，用HTTP就可以显示应用，这个要变更；

### Delivery Controller

1. 没有办法安装Director；

## Virtual Desktop Agent

1. 没有办法正常安装，会提示 “远程桌面会话主机无法”无法安装，但实际已经安装了；
2. 打开日志会看到有个“Desktop Experience”，是一个Windows图形化界面的功能，一般在安装操作系统时才会出现；现有系统已经是 GUI界面，仍然提示需要安装；

> 可以用指令安装跳过检查，.\XenDesktopVDASetup.exe /quit /controller "xxxx" /exclude "Desktop Experience"

跳过检查的方法毕竟还是高风险操作，不知道后续会不会有其他问题。
