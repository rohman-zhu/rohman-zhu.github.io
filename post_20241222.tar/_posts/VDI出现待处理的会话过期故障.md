---
title: VDI出现待处理的会话过期故障
tags:
  - 故障
  - VDI
categories:
  - VMware
  - Horizon View
date: 2022-10-23 11:47:49
---

# 故障描述

1. 用户反馈无法连接VDI，会出现“资源xxxx，请联系管理员xxx”,需要手动发起重置VDI才能解决；
2. Horizon 管理后台发现目标用户有待处理的会话以过期：(The pending session on machine for user has expired)
3. 用户已断开VDI，此虚拟机在后台还是显示为“可用”；

# 原因分析

- Single Sign-On(SSO)未正常运行；
- 注册表项userinit 字符串被修改；
- 组策略更新了 userinit;
- 安装一些软件 导致 userinit 被修改；

VDI 虚拟机userinit的值应该为 

```
C:\Windows\System32\userinit.exe,"C:\Program Files\VMware\VMware View\Agent\bin\wssm.exe",
```

# 解决方法

找到注册表HKEY_LOCAL_MACHINE>Software>Microsoft>Windows NT>Current Version>Winlogon；

输入值：

```
C:\Windows\System32\userinit.exe,"C:\Program Files\VMware\VMware View\Agent\bin\wssm.exe",
```

重启虚拟机生效，注意注册表值需要带上 “,” ；

Powershell脚本：

```ps1

Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name userinit -value 'C:\Windows\System32\userinit.exe,"C:\Program Files\VMware\VMware View\Agent\bin\wssm.exe",' ;

Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name userinit;

# 一分钟后重启

shutdown /r /t 60;
```


# 参考资料

https://kb.vmware.com/s/article/1028975?lang=zh_cn


