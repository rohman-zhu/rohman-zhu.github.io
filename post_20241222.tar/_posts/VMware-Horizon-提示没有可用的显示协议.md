---
title: VMware Horizon 提示没有可用的显示协议
tags:
  - VMware
  - Horizon View
categories:
  - 故障
date: 2023-11-05 16:38:08
---
# 故障描述

关键节点：UAG、连接服务器、RDSH服务器；

显示协议：Blast；

客户端节点提示，无可用显示协议或者 Internal Server Error；
UAG与RDSH服务器网络链路正常，TCP-22443端口是联通的；

# 原因分析

RDSH服务器上面的22443端口不是VMware View Agent进程监听的，而是其他应用程序在监听，导致客户端无法使用 Blast 协议安装；

# 解决方法

检测端口监听的进程：

```ps1
# -a:--all，显示所有链接和监听端口
# -b:显示包含于创建每个连接或监听端口的可执行组件。在某些情况下已知可执行组件拥有多个独立组件，并且在这些情况下包含于创建连接或监听端口的组件序列被显示。这种情况下，可执行组件名在底部的 [] 中，顶部是其调用的组件，等等，直到 TCP/IP 部分。注意此选项可能需要很长时间，如果没有足够权限可能失败。
netstat -ab | findstr 22443;
```

检测 WINRM 监听端口并修改：

观察到 WINRM 的端口被改为 22443 ，导致BLAST协议的进程无法使用此端口；

```ps1
# 检查端口
winrm enumerate winrm/config/listener

# 修改端口
set-item wsman:\localhost\listener\listener*\port -value 8080
```