---
title: 服务器安装Windows Server异常提示无法安装到这个磁盘
tags:
  - 故障
categories:
  - 服务器与存储
  - 服务器
date: 2024-02-05 00:28:51
---

# 故障现象

安装操作系统提示:

```
Windows 无法安装到这个磁盘。这台计算机的硬件可能不支持启动到此次盘。请确保在计算机的 BIOS 菜单中启用了磁盘的控制器。

Windows cannot be installed to this disk. This computer&＃39;s hardware may not support booting to this disk. Ensure that the disk&＃39;s controller is enabled in the computer&＃39;s BIOS menu.
```

# 原因

阵列组并未作为启动卷。

# 解决方法

到阵列卡中设置卷为启动卷。

# 参考

https://zhiliao.h3c.com/Theme/details/20319