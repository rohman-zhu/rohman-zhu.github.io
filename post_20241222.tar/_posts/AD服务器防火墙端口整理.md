---
title: AD服务器防火墙端口整理
tags:
  - Active Directory
  - Firewall ACL
categories:
 - Windows Server
date: 2020-03-15 20:46:00
---
# 前言

If you are working on Active Directory environment and have domain joined systems that needs access to Active Directory that are on different or isolated networks separated by Firewall then you need to allow multiple Active Directory ports to pass through the Firewall. Below are the ports that I have validated and needs to be allowed for smooth member server / workstation and AD Communication, as well as for replication -

# 端口列表

| Port Description | Port Details |
|:------:|:-----:|
|Kerberos|TCP-88,UDP-88|
|DNS|TCP-53,UDP-53|
|Global Catalog| TCP-3268|
|Global Catalog（Secure）|TCP-3269|
|LDAP|TCP-389，UDP-389|
|LDAP（Secure）|TCP-636|
|RPC/Replication|TCP -135|
|Time Service|UDP-123|
|Replication, User / Computer Authentication, Trusts and Group PolicyNetLogon, NetBIOS name ResolutionDFS , NetLogon|TCP-49152 to 65535,UDP-49152 to 65535|
| Kerberos Password Change | TCP-464,UDP-464|
|SMB(File Sharing)|TCP-139,445|
|DFSR|TCP-5722|

## Replication

Replication uses the remote procedure call (RPC) transport. Replication connections can be created between any two domain controllers located in the same site. Connections can be made with multiple domain controllers to reduce replication latency.

# 参考资料

https://gallery.technet.microsoft.com/Active-Directory-Firewall-bd21b246