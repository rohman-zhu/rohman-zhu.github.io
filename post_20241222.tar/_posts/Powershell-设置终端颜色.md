---
title: Powershell-设置终端颜色
tags:
  - default
categories:
  - Windows Server
  - Powershell
date: 2024-07-28 16:27:25
---


# 需求

Powershell默认背景是黑色的，需要调整


# 设置过程

```ps1

# 查看当前配色方案
Get-PSReadLineOption

# 设置具体
Set-PSReadLineOption -Colors @{"String"="yellow"};

```

# 参考

https://learn.microsoft.com/zh-cn/powershell/module/PSReadline/Set-PSReadlineOption?view=powershell-7.4