---
title: Linux之Saltstack自动化运维
date: 2017-10-31 21:54:19
tags: Linux
---
# Saltstacks #

是一个新的基础平台管理工具.

## 0.运维重复性工作有哪些 ##

1. 系统安装
1. 环境部署
1. 添加监控
1. 代码发布
1. 项目迁移
1. 计划任务

Saltstack主要用于解决环境部署的工作.

## 1.Salt可以做什么 ##

1. 配置管理
1. 远程命令
1. 包管理

## 2.安装部署 ##

### 2.1 客户端 ###

```{.normal}
# 安装
# yum install -y salt-monitor

# 修改配置文件
# vim /etc/salt/minion
# ------
master : 服务端的ip
cachedir : /etc/salt/modules
log_file:
log_level:
# --------

# salt的hostname
# vim /etc/salt/minion_id
```

### 2.2 服务端 ###

yum install -y salt-master

## 3.KEY管理(master) ##

```{.normal}

# 查看key
# salt-key -L

# 接收所有key
# salt-key -A

```

## 4.测试(master) ##

### 4.1分组管理 ###

```{.normal}

nodegroups:
  php:'主机名字'

# salt -N '组名' 模块.执行命令 '命令'
# salt -N 'php' cmd.run 'uptime'

```

### 4.2即时管理 ###

* salt -N '组名' test.ping 匹配分组主机,即时ping
* salt -N '组名' cmd.run 'uptime' 即时执行命令
* salt -E 'ops-dev{01|03}' test.ping
* salt '*' cmd.run "ab-n 10 -c 2 "`http://www.google.com/`" 匹配所有机器做压力测试.
* salt -N 'dev' sys.doc.cmd 查看模块文档

### 4.3环境配置 ###

```{.normal}
# vim /etc/master
#--------
file_roots:
    base:
      - /srv/salt
```

两个空格为一个单位.
