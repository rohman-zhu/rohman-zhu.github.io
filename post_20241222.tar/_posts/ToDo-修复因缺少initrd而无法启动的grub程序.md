---
title: ToDo-修复因缺少initrd而无法启动的grub程序
date: 2018-11-18 18:20:44
tags:
---
