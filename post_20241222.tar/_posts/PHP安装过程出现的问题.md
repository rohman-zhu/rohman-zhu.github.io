---
title: PHP相关过程的问题
date: 2017-10-23 22:54:31
tags: PHP
---
# 错误或者问题集锦 #

## 1.用curl命令出现"file not found" ##

这里可能是php解析出了问题,或者是配置php节点.

```{.conf}
location ~* \.(ph|php5)?$
{
    fastcgi_pass 127.0.0.1:9000;
    fastcgi_index index.php;
    include fastcgi.conf;
}
```