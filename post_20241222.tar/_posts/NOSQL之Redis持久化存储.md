---
title: NOSQL之Redis持久化存储
date: 2017-11-24 19:20:07
tags: Linux
---
# Redis #

先说NOSQL,全称时指No only structure query language.

Redis (Remote Dictionary Server)是一个基于key-value键值对的持久化数据存储系统.

* redis支持的数据存储类型更丰富,包括string,list,set,zset(有序集合).
* redis还支持master-slave(主从同步).
* 性能很高,支持超过100K+每秒的读写频率(数据常规的是几百的读写).
* Redis所有的操作都有原子性的,同时Redis还支持对几个操作全并后的原子性执行.
* Redis还支持public/subscribe,通知,key过期等特性

## 应用场景 ##

### 传统的MySQL+Memcached网站架构的局限 ##

当业务数据量的不断增加,memcache也需要不断扩容,扩容和维护工作占据大量的运维时间.

1. 增加运维时间.
1. Memcache与MySQL的数据存在一致性问题.
1. Memcache数据命中率低或者宕机,会导致大量访问直接穿透数据库,导致MySQL无法支撑访问.
1. 跨机房与cache同步一致性问题.

Redis的最佳应用场景:

1. 全部数据是in-memory.
1. 作为Memcached的替代品来使用.
1. 当需要除了key-value之外的更多数据类型支持时,使用Redis更合适.
1. 当存储的数据不能被剔除时,使用Redis更合适.

参考文章:`http://blog.nosqlfan.com/html/2235.html`

## 安装 ##

### 服务端安装 ###

`https://redis.io`

常规编译安装即可.

添加环境变量,/redis/bin/*

### 修改配置文件 ###

原本的配置文件在源安装文件的根目录下,把该文件复制到软件安装的根目录下

### 客户端安装 ###

类似memcache客户端安装

```sh
# cd phpredis-master
# /application/php/bin/phpize
# ./configure -with-php-config=/application/php/bin/php-config
# make
# make install
# echo "extension = redis.so" >> /application/php/lib/php.ini
```