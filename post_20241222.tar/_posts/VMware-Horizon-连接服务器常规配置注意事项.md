---
title: VMware Horizon-连接服务器常规配置注意事项
tags:
  - default
categories:
  - VMware
  - Horizon View
date: 2023-07-30 15:33:11
---
# 配置文件 locked.properties -- 检查源 checkOrigin

问题：连接服务器管理后台会提示“Failed to connect to the Connection Server”

```locked.properties 
checkOrigin = false
```

https://kb.vmware.com/s/article/2144768?lang=zh_cn

# 配置文件 locked.properties -- CORS（Cross-Origin Resource Sharing） ，enableCORS

问题：Horizon 8 后，CORS（Cross-Origin Resource Sharing）默认是开启的；

```locked.properties 
enableCORS = false
```

https://kb.vmware.com/s/article/2144768
https://kb.vmware.com/s/article/85801

# 添加UAG服务器步骤简写

1. 虚拟机化层，部署UAG镜像；
2. 应用层，配置UAG，即进入UAG管理界面 https://UAG-IP:9443 ；
- 配置连接服务器地址
- 导入证书
3. 应用层，配置Connection Server，即进入Connection Server管理界面 https://ConnectionServer-IP/admin ；
- 连接服务器不使用安全网关
- 添加UAG服务器

# 安全服务器/连接服务器配置证书步骤

1. 生成pkg证书文件；
2. 导入安全服务器服务器；
3. 修改目标证书别名为vdm；

# UAG服务器证书配置步骤

1. 生成pkg证书文件；
2. 导入UAG服务器；