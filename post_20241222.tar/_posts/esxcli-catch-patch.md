---
title: esxcli catch patch
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2024-09-08 23:26:51
---
# 抓包过程

1. 登录ESXi Shell
2. 使用 pktcap-uw 抓包
3. 使用 tcpdump-uw 解包


## 基于vmk抓包

```sh
# 抓取 vmk0 的数据包，并保存在 test.zip
pktcap-uw --vmk vmk0 -o test.zip

# 解包
tcpdump-uw -enr test.zip
```

## 基于虚拟机端口抓包

```sh
# 找到虚拟机端口 ，虚拟机名为 testdemo,输出的包为 test.zip
net-stats -l | grep testdemo

# 抓虚拟机所需的端口
pktcap-uw --switchport [testdemo nic port] --ip [需要过滤的IP] -o test.zip

# 解包
tcpdump-uw -enr test.zip
```