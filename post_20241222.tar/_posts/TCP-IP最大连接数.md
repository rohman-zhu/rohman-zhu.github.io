---
title: TCP/IP最大连接数
tags:
  - default
catergories:
  - WindowsServer
date: 2020-02-03 22:13:21
---

# TCP/IP 最大连接数

一般服务器TCP连接数已达到 TCP MaxUserPort，微软默认TCP连接端口数是 5000 。

## 查看方式

```cmd
netstat -n | find /C /I "established"
```

```ps1
Get-Counter -Counter \TCPv4\*查看
```

## 修改MaxUserPort的最大值

打开regedit

HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters中添加名为MaxUserPort，类型为DWORD(32-bit)，值为65543（10进制）的项目并重启计算机。

## 参考资料

https://blog.csdn.net/weixin_33725126/article/details/85809638
