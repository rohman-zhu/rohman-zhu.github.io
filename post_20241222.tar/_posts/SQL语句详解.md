---
title: SQL语句详解
date: 2017-11-09 17:20:39
tags: Linux
---
# Structure Query Language #

一般分为三类:

1. DDL(Data Definition Language) -- 数据定义语言(CREAT,EALTER,DROP),管理基础数据,例如:库,表;
1. DCL(Data Control Language) -- 数据控制语言(GRANT,REVOKE,COMMIT,ROLLBACK),用户授权,权限回收,数据提交回滚
1. DML(Data Manipulation Language) -- 数据操作语言 (SELECT,INSERT,DELETE,UPDATE),针对数据库里的表与记录

## 常见应用 ##

### 1. 创建数据库 ###

```Linux
create database <DatabaseName>;

* 创建指定字符集的数据库:

create database <DatabaseName> CHARACTER SET [Charset] [Description] [Default collattion];

* 查看字符集

show character set;
```

默认使用utf-8

### 2.删除数据库 ###

```Linux

drop database <databaseName>

```

### 3.连接数据库 ###

```Linux
use <databaseName>

不切换数据库,用 database.table

例如:

select user,host from mysql.user
```

### 4.授权 ###

```Linux
命令 : 授权命令 对应权限 目标 用户名和客户机 密码

mysql> grant all on *.* to ''@'localhost' identified by '12345';
```

### 5.为表创建索引 ###

加快语句查询速度.

#### 5.1 主键索引 ####

一个表只能有一个主键索引列,可以有多个普通列索引.

```Linux
在建表的时候添加

# 主键索引
primary key(列名)

# 普通索引
Key index_name(列名)

mysql > alter table [table_name] [add|drop] index_name(ColumName);

# 指定某一个列中的前几个字符,例如 student 表的name varchar(20)
mysql > create index index_name to student(name(8))
```

* PRI为主键索引的标识
* MUL为普通索引的标识

#### 5.2 联合索引 ####

具有前缀特性,举个例子

```Linux
# 有三个字段 A B C

# 创建联合索引 index(A,B,C)

那么在查询的时候,索引的位置只能是以下三种情况:

A

A B

A B C

===============以下情况则不允许出现================

A C

B C

C
```

因此,我们创建的时候,要考虑到以下因素:

> 经常用于条件查询的字段,放在前面,例如经常查 学号(A),再查年龄(B),那么创建联合索引就可以是index(A,B)

#### 5.3唯一索引 ####

#### 5.4 关于索引的相关问题 ####

##### 1.既然索引可以加快查询速度,那么就给所有列都添加索引,可以吗 #####

因为索引占系统空间,而且更新数据库也需要更新索引数据,因此索引并不是越多越好.例如,几百行的小表上无需建立索引,更新频繁,读取比较少的表要少建立索引.

##### 2.需要在哪些列上创建索引 #####

* 索引一定要创建在where后的条件列上,而不是select后的选择数据列上.
* 索引建立在_唯一值_多的大表上的列建立索引.(只有男/女的列上不适合建立索引)

### 6.用explain优化SQL语句查询 ###

1. 抓慢查询: a. show full prcesslist;(现场抓) b.分析慢查询日志.(配置文件中添加long\_query\_time =1 log-slow-queries = /../../xx.log log\_queries\_not\_using_indexes)
1. explain语句检查索引执行情况
1. 对需要建索引的列建立索引.

### 7.profile功能对SQL语句进行优化 ###

### 8.增删表的字段 ###

alter table table_name add 字段 类型 其他;

### 9.中文数据乱码问题 ###

设置好以下字符集(UTF-8):

* Linux 客户端字符集
* Linux 服务端字符集
* 数据库 客户端字符集
* 数据库 服务端字符集
* 具体数据库的字符集
* 表的字符集
* PHP/Java程序字符集

#### 9.1 解决方法 ####

##### 临时生效:set names 字符集 #####

相当于

SET character\_set_client = 字符集
SET character\_set_results = 字符集
SET character\_setconnection = 字符集

查看字符集更改

show variable like "character%"

##### 永久生效 :mysql --default-character-set = utf8 ######

登录数据库的时候指定字符集

##### 配置文件:my.cnf更改mysqld标签下面 #####

在 [mysqld] 下边添加: init_connect = 'SET NAMES 字符集'

> 客户端字符集更改,默认配置文件在/etc/my.cnf

##### 小结 #####

在配置文件中修改[mysqld]标签下的参数,相当于在登录mysql后,修改了以下两个参数:

* character\_set_database | gbk
* character\_set_server | gbk

客户端[mysql]修改后,相当于登录mysql后,修改了以下两个参数:

* character\_set_database
* character\_set_results
* character\_set_client

另外,数据有中文与英文,建议用"utf-8"字符集.

### 10.MySQL日志 ###

#### 10.1错误日志 ####

1. 在配置文件中的 [mysqld_safe] 的 log-error 设置
1. 启动命令添加 --log-error

#### 10.2查询日志 ####

在数据库中,用命令查看相关命令show variables like 'general_log%'

更改(临时生效),set global general\_log_file="全路径"

在配置文件中添加 general-log-file="全路径"

#### 10.3慢查询日志 ####

这里面记录查询时间超过指定时间的语句

log-slow-queries="全路径"

使用mysqlsla分析慢查询,定时发给相关人员邮箱.

#### 10.4二进制日志 ####

在配置文件中,把 log_bin 打开开关, log-bin = "全路径"

作用:

1. 记录更改的SQL语句
1. 主从复制
1. 做增量备份

三种模式:

##### 1. Row Level #####

优点 : 记录了每一个SQL执行语句的细节.
缺点 : 性能不足.

##### 2. Statement Level(默认) #####

优点 : 提高效率
缺点 : 简略记录SQL语句,会导致从库无法执行执行.(例如使用了一些特殊功能的语句)

##### 3. Mixed #####

会分析SQL语句,根据情况选择Statement或者Row模式.

> 如果对数据库要求较多,则选择Mixed

### 11.恢复数据库source命令 ###

source 备份文件的全路径

### 12.mysqlbinlog命令 ###

主要用于增量恢复,原本是二进制的内容解析成SQL语句.

* 参数 :-d 指定对应的库

1. 条件: 全备份与全备后的binlog
1. 关键点 : G点 ,确定全备份之后时刻binlog文件及位置
1. 恢复时尽量对外停止服务

> 如果不能停止对外服务,要怎么做?