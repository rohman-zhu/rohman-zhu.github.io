---
title: 关于HEXO问题的解决方案
date: 2017-10-01 20:19:40
tags: HEXO
---

# 使用 hexo -s 预览页面出现 "extends partical..."问题

更新使用新的主题，打开主界面显示以下代码：
```
extends partial/layout

block container
    include mixins/post
    +posts()

block pagination
    include mixins/paginator
    +home()

block copyright
    include partial/copyright

```

网络给出的解决方案是这样的，只需要添加依赖即可，亲测有效。

```
$npm install --save hexo-renderer-jade hexo-generator-feed hexo-generator-sitemap hexo-browsersync hexo-generator-archive
```

<a href="https://www.v2ex.com/amp/t/362017">原文地址</a>

PS : 至于是什么原因目前我还不知道，因为不是这个领域的人员，所以也不太清楚这到底是干什么的，见谅见谅。

