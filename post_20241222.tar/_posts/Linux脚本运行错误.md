---
title: Linux脚本运行错误
tags:
  - Shell
categories:
  - Linux
date: 2020-05-21 00:00:50
---
# 故障描述

运行脚本出现：

```sh
syntax error: unexpected end of file或syntax error near unexpected token `fi'
```

# 原因分析

1. 脚本格式为dos，而Linux只能执行格式为unix的脚本。
2. 因为在dos/window下按一次回车键实际上输入的是“回车（CR)”和“换行（LF）”，而Linux/unix下按一次回车键只输入“换行（LF）”，所以修改的sh文件在每行都会多了一个CR，所以Linux下运行时就会报错找不到命令。

查看方式：

在vim中打开脚本，输入： set ff ，回车可以看到脚本为dos格式。

# 解决方法

在vim中打开脚本，输入： set ff=unix 或者 set fileformat=unix ,即可。

# 参考资料

https://blog.csdn.net/u012453843/article/details/69803244
