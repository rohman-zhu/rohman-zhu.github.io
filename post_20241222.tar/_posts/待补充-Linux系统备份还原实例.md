---
title: '[待补充]Linux系统备份还原实例'
date: 2018-11-07 23:17:12
tags: Linux
---
# 前言

今天从书上看到Linux的系统备份相关知识，做一次记录。备份的重要性，在此就不讲了，只记录实战中所需要的命令知识与系统知识点。

# To-Do list

* 指定备份策略 ： 周备份策略 ， 日备份策略 ，并写出相应的脚本
* 执行一遍Centos的备份操作
* 执行一遍Ubuntu的备份操作
* 执行一遍Centos的还原操作
* 执行一遍Ubuntu的还原操作

# 知识梳理

* 操作系统中需要备份的目录
* 这里有用到 dd ， tar ， dump ，cpio 四种指令
* 两种备份方式： 完整备份（包含差异备份） 、 关键数据备份
* 针对备份频率的备份策略脚本

## cpio

```shell
-o 将数据Copy 输出到文件或设备上
-B 让默认的 Blocks 可以增加至 5120 bytes ， 默认的是 512 bytes
-i 将数据自文件或设备复制到系统中
-d 自动新建目录。使用cpio所备份的数据内容不见得会在同一层目录中，因此我们必须要让cpio再还原时可以新建新目录，此时就要 -d 参数的帮助
-u 自动将较新的文件覆盖较旧的文件
-t 需要配合 -i 参数，~~可用在查看以~~ cpio 新建的文件或设备的内容
-v 让存储过程中，文件名可以在屏幕上显示
-c 一种较新的 portable format 方式存储
```

## 需要备份的目录

| 目录 | 讲解 |
|:----:|:---:|
|/etc/passwd 、 /etc/shadow 、 /etc/group 、 /etc/gshadow 、 /etc | 这些目录跟账户有关，而Linux中所有重要参数、配置参数都在/etc/下面保存。|
|/home | 用户的主要文件夹 | 
|/var/spool/mail| 邮件|
|/boot | 启动引导 |
|/root | 不解释 |
|/usr/local| |
|/opt | |
|/src| |

对于软件应用来说 ， 如果是默认安装 一般配置文件都在 /etc下面 ，但是若为用户自行安装，则有可能在 /usr/local 下面。

而可以不需要备份的目录有：

| 目录 | 讲解 |
|:-----:|:----:|
|/dev|设备信息|
|/proc||
|/mnt,/media|如果没有挂载系统的东西，可以不用备份|
|/tmp| 就一个临时文件存放地|

## 备份命令

```shell
# 用 dd 备份
# 假设 sda 是系统盘 ， sdb是移动硬盘，用于存放备份资料的
# 因为 dd 是读取扇区 ， 所以 sdb 这块磁盘可以不必格式化。
# 缺点是非常慢
dd if=/dev/sda of=/dev/sdb

#用dd恢复
dd if=/dev/sdb of=/dev/sda

# 用 cpio 备份
# 假设存储设备为sata磁带机
find / -print | cpio /backupdata/home.dump /home
cpio -iduv < /dev/st0

# 用dump备份
# 完整备份
dump -0u -f /backupdata/home.dump /home
# 增量备份
dump -1u -f /backupdata/home.dump.1 /home

#用tar备份
#tar --exclude /proc --exclude /mnt --exclude /tmp --exclude /backupdata -jcvp -f /backupdata/system.tar.bz2

tar cvpzf system_backup.tar.gz / --exclude=/proc --exclude=/lost+found --exclude=/system_backup.tar.gz --exclude=/mnt --exclude=/sys

#用tar恢复系统
tar xvpfz system_backup.tar.gz -C /
#创建备份时排除的目录
mkdir proc
mkdir lost+found
mkdir mnt
mkdir sys

#/proc 权限：文件所有者：root群组：root 所有者：读取 执行 群组：读取 执行 其它：读取 执行
#/lost+found 权限：文件所有者：root群组：root 所有者：读取 写入 执行 群组：读取 执行 其它：读取 执行
#/mnt 权限：文件所有者：root群组：root 所有者：读取 写入 执行 群组：读取 执行 其它：读取 执行
#/sys 权限：文件所有者：root群组：root 所有者：读取 写入 执行 群组：读取 执行 其它：读取 执行


#使用rsync备份
#注意目标分区的格式最好是NTFS、FAT、EXT之类的格式，避免遇到大于4G的文件无法备份的问题。
rsync -Pa / /media/usb/backup_20170410 --exclude=/media/* --exclude=/sys/* --exclude=/proc/* --exclude=/mnt/* --exclude=/tmp/*
#使用rsync恢复
rsync -Pa /media/usb/backup_20170410 /

```

# 实例

这里参照《鸟哥的Linux私房菜》写到的策略：

1. 主机硬件：使用一个独立的文件系统来存储备份数据，此文件系统挂载到/backup
2. 每日进行： 仅仅备份 MySql 的数据库
3. 每周进行： 包括 /home、/var 、/etc 、 /boot 、 /usr/local 等目录与特殊服务的目录

## 每周备份脚本

## 每日备份脚本