---
title: Docker-学习记录
tags:
  - default
categories:
  - Docker
date: 2024-03-17 14:45:03
---

# 前言

这段时间看到一位大佬的学习记录，因此这里有大部分内容是转载的。推荐看原文!!!

转载自：
- https://www.zsythink.net/archives/4286


# 什么是Docker 与 安装 Docker

咱们还是以传统意义上的“虚拟机”作为切入点，假设，有一台物理服务器，我们把这台服务器当做宿主机，在宿主机上虚出了虚机A、虚机B等虚拟机，对于这些虚拟机来说，它们各自都独占了一套完整的操作系统，准确的说，应该是一套完整的“操作系统发行版”，注意，这里强调一下“发行版”三个字，以linux系统为例，组成一个“linux系统发行版”，首先需要有“linux内核”，其次还需要有相关软件依赖的运行环境软件包，比如说一些类库包、命令行工具等等，不同的linux发行版基于相同的linux内核开发，但是由于组成运行环境的包的不同，所以产生了不同的发行版，比如ubuntu和centos就是不同的linux发行版，对于虚机A和虚机B来说，它们各自拥有一套完整的操作系统（即使A和B都安装了centos7.9，本质上也是两个相互独立的操作系统），从隔离层面上来说，A和B之间是“linux系统发行版”的完整隔离，A和B都各自使用自己的内核和运行环境依赖包，各自使用自己的虚拟硬件，这是虚拟机在操作系统层面的隔离，理解上述概念，是避免搞混docker和传统虚拟化的关键。

现在再来聊聊docker，我们知道docker是一种容器引擎，docker运行容器的本质目的是去运行某个程序，docker通过应用程序镜像，安装并运行对应的程序，比如，我需要运行nginx，只需要下载对应的nginx镜像，docker就可以把这个nginx镜像运行成一个容器，容器把内部的nginx服务端口暴露出来，我们就可以访问nginx服务了，其他服务软件同理，在没有使用docker之前，看到“镜像”这个词，我又情不自禁的想到了虚拟机，只不过，虚拟机是通过“操作系统镜像”安装运行系统，docker是通过“应用程序镜像”安装运行对应的软件，当我搜索docker和虚拟机有什么不同的时候，我看到了下面这张图

![Docker与虚拟机区别](https://www.zsythink.net/wp-content/uploads/2022/01/16421268329864.jpg)

从上图来看，每个虚拟机都有自己的完整的操作系统（上图的GUEST OS就是虚拟机的操作系统，但是此处，我们应该把它拆成两部分理解，GUEST OS是由其内核和运行环境包组成的），VM1虚拟机上的所有APP使用的是同一套运行库和内核，其他虚拟机同理，Hypervisor层对硬件资源进行划分，各个虚拟机在整个操作系统发行版层面进行了隔离，而容器则不同，容器是将APP和其需要依赖的运行库打包成一个镜像，在APP进程和运行库层面进行了隔离（上图中CONTAINER中的APP就是应用程序镜像，这个镜像中包含应用本身和其需要的运行时依赖包），不同的APP各自使用自己的运行时环境，容器所运行的镜像中不需要内核，所有容器共用所在主机HostOS的内核，统一通过HostOS的内核与硬件进行交互，docker就是运行在HostOS中的容器引擎，理解了上图以后，我们就能明显感觉到它们的区别了，上图中最凸显的区别就是隔离层面的不同，虚拟机是针对整个系统发行版层面的隔离，而容器则是对程序进程和其依赖的运行环境的隔离，虚拟机的隔离性更强，隔离范围大，容器的隔离性没有虚拟机强，但是隔离范围更小，容器并不涉及Hypervisor层，它是一种进程隔离技术，从这个方面讲，它不应该算做“传统虚拟化”的范围，人们愿意把它称之为容器“虚拟化”技术，我觉得是因为容器更偏向于“java虚拟机”或者“python虚拟环境”这种软件意义上的“虚拟”，所以说，容器并不会取代虚拟机，它们之间也并不冲突，它们应该是相辅相成的。

把应用程序和其运行时依赖库打包隔离的好处有哪些呢？首先，由于隔离的范围更小了，所以当出现问题时，影响的范围也会更小，只会影响这个应用程序容器的进程本身，而不是其他程序的容器和HOST操作系统，其次，由于应用程序和其依赖的运行时环境是打包在一起的（打包成一个docker镜像），这就表示，如果一个程序的镜像在我的centos7上能够运行，那么在你的centos7上用也能够正常运行，不会出现某个程序在开发人员的笔记本中可以运行，但是放在服务器上就不能正常运行的情况（因为服务器上可能没有安装程序所依赖的包），这就是把程序和依赖打包在一起的好处。


```sh
# 
# Ubuntu 安装Docker
# 参考 https://docs.docker.com/desktop/install/ubuntu/

# 更新 Docker 源
sudo apt-get update
sudo apt-get install ca-certificates curl -y
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add the repository to Apt sources:
echo 
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | 
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update

# 安装Docker GUI 版本
apt-get install ./docker-desktop-<vsersion>-<arch>.deb
apt-get install ./docker-desktop-4.28.0-amd64.deb

# https://docs.docker.com/engine/install/ubuntu/#install-using-the-repository
 sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

```

# 初始化 仓库、镜像、容器

参考 https://www.zsythink.net/archives/4302

从docker hub默认仓库获取镜像

```sh
# 表示从docker hub的nginx官方仓库中拉取tag为latest的镜像（即从nginx官方仓库中拉取最新版本的nginx镜像
docker pull docker.io/library/nginx:latest
# 等效于 
docker pull nginx
```

关于 URL ： docker.io/library/nginx:latest
![Docker URL](https://www.zsythink.net/wp-content/uploads/2022/02/16443754787791.jpg)

第1部分 docker.io ：代表从哪个仓库服务中心下载镜像，docker.io就是官方的仓库服务中心（其实就是docker hub，官方的仓库服务器），这个仓库服务器中有很多组织，也有很多个人，每个组织或者个人都可以在这个仓库服务器创建仓库，然后把镜像存放在仓库中，前文说过，docker hub的官网地址是registry.hub.docker.com，这个地址是方便我们从web页面查找镜像使用的，使用命令行从docker hub拉取镜像时，默认使用的是docker.io这个地址。除了docker官方的docker hub，还有一些其他仓库服务器，我们也可以自建仓库服务器，当使用其他仓库服务器或者自建仓库服务器时，要把第1部分改为对应的域名或IP，如果我们就是想要从官方的docker hub下载镜像，上图中的第1部分可以不写，当省略第1部分时，默认就是使用docker.io这个仓库服务器的，仓库服务或者仓库服务中心的英文原文是registry，简单来说，第1部分就是registry的地址。

第2部分 library：代表组织或者个人的“命名空间”，命名空间是什么意思呢？举个例子，我们每个人都可以docker hub上注册自己的账号，然后使用自己的账号在docker hub上创建仓库，比如，我在docker hub上的账号id是zsythink，那么我就可以在docker hub的zsythink命名空间下创建仓库，如果我创建了一个名为nginx的仓库，那么我就可以通过如下url，获取到这个nginx仓库中的镜像

```
docker.io/zsythink/nginx
```

> library，这个命名空间比较特殊，library是专门给上游软件提供商官方使用的命名空间，比如，nginx官方（或者说nginx组织）的nginx的仓库，并不会使用docker.io/nginx/nginx，而是会使用docker.io/library/nginx，同理，redis官方的redis仓库，也不会使用docker.io/redis/redis，而是会使用docker.io/library/redis，官方仓库中的镜像被称之为官方镜像，docker有一个专门的团队，负责审核和发布官方镜像，这个团队会与软件提供商、社区以及安全专家合作，共同维护这些官方仓库中的镜像，官方镜像的更多内容，可以参考如下链接https://docs.docker.com/docker-hub/official_images，当我们想要从官方仓库下载镜像时，是可以省略library的，比如，我想要直接从docker hub的nginx官方仓库中下载镜像，可以直接使用docker pull nginx命令，此命令等效于docker pull docker.io/library/nginx，需要注意，只有官方仓库可以省略（即只有library可以省略），其他组织或者个人的命名空间不能省略。

第3部分 nginx：代表仓库名，在介绍第2部分时，我们已经描述的比较清楚了，我们可以在自己的命名空间下创建很多仓库，比如nginx仓库、redis仓库等，nginx仓库专门用来存放nginx镜像，redis仓库专门用来存放redis镜像，创建仓库时，我们可以选择是否公开仓库，如果不公开，只有通过认证后，才能够获取仓库中的镜像，仓库的英文原文为repository，简单来说，第3部分就是repository的名字。

第4部分 latest：代表镜像对应的标签（tag），通常情况下，我们会通过标签对镜像的版本进行区分，比如，nginx仓库中有十个nginx镜像，第一个nginx镜像对应的版本为nginxV1.1，第二个nginx镜像对应的版本为nginxV1.2，那么第一个镜像的tag就是1.1，第二个镜像的tag就是1.2，以此类推，当我们在拉取镜像时，如果没有指定tag，默认会使用”latest”作为tag，也就是图例中第4部分的标签，”latest”表示最新版，当省略标签或者标签为latest时，会从仓库中下载最新版本的镜像，但是今天的最新版可能就是明天的旧版本，所以，在生产环境中，不要使用latest这个tag，或者说，不要省略tag，最好是指定一个明确的版本tag，这样做是为了防止”latest”这个特殊的tag对应的镜像发生了更新。tag和仓库名之间需要用冒号隔开，比如，nginx:1.21表示nginx库中的tag为1.21的镜像。

启动镜像，基于nginx:latest这个镜像，创建一个名为nginx-demo的容器，并启动这个容器，-d表示后台运行这个容器，-p 80:80表示将docker主机的80端口和容器内nginx服务的80端口进行映射，映射后，访问docker主机的80端口，即相当于访问容器内的nginx服务的80端口

```sh
docker run --name nginx-demo -d -p 80:80 nginx:latest
```

# 与Docker交互

已有一个名为 nginx-demo 的容器，需要进入容器

```sh
docker exec -it nginx-demo /bin/bash

# -i参数表示interactive，即交互模式。
# -t参数表示分配一个伪终端。

# 执行上述命令后，命令提示符会从host主机的提示符变成了容器的提示符（host主机就是容器所在的主机
[root@kvm32docker2 ~]# docker exec -it nginx-demo /bin/bash
root@55e0b2020fc0:/# 
root@55e0b2020fc0:/# 
```

> 55e0b2020fc0为容器的ID

修改Docker内的文件

```sh
# 方法1，将文件拷贝出来做修改操作
docker cp nginx-demo:/etc/nginx/nginx.conf ./
# 修改完毕后，拷贝回去
docker cp ./nginx.conf nginx-demo:/etc/nginx/nginx.conf

# 方法2，进入docker，执行修改指令
docker exec -it nginx-demo /bin/bash
vi [target.file]
```

## 关于进程隔离

参考：https://www.zsythink.net/archives/4321

在host主机中通过docker top命令查询出的pid，和在容器中通过ps命令查询出的pid不同，前文说过，docker的本质是一种进程隔离技术，docker是通过Linux内核的namespace功能实现PID的隔离的，pid namespace将host上的PID映射为容器内的PID，这样可以让不同的PID namespace中存在相同的进程号，并控制进程间的关系。

这样说可能不太容易理解，咱们换个方式解释一下，假设，现在有两个容器，一个nginx容器，一个redis容器，在nginx容器中，nginx的master进程的pid为1，在redis容器中，redis-server进程的pid为1，对于nginx-master进程或者redis-server进程来说，它们都以为自己是这个世界上的王者，因为它们只能看到自己的世界，而且在自己看到的世界中，自己是主进程（PID为1）。

其实，它们都只不过是host主机中的一个普通进程罢了，nginx容器的master进程在host主机中的PID可能是1234，redis容器中的server进程在host主机中的PID可能是5678，即使在各自的容器中，它们的PID都是1，也许这就是pid namespace进程隔离最直观的感受吧。所以，docker top命令查看的是容器进程在host中的pid，在容器内执行ps命令查看的是容器进程在容器内的pid。

# 镜像

镜像来源：
1. 官方镜像库；
2. 自定义镜像；

自定义镜像流程：

1. 初始化一个容器
2. 进入容器做自定义修改
3. 打包镜像

```sh
# 1
docker run -td --name alpine-test alpine

# 2
docker exec -it alpine-test sh
apk add nginx


# 3
docker commit -p -c 'CMD ["nginx","-g","daemon off;"]' alpine-test zsythink/nginx:test1
# docker commit 提交容器为镜像
# 基于 alpine-test 创建名为 zsythink/nginx:test1 的镜像
# 上例标签中的zsythink是作者在docker hub上注册的账号ID，zsythink/nginx表示zsythink账号下名为nginx的仓库，完整的写法应该是docker.io/zsythink/nginx:test1，表示docker hub上zsythink账户下nginx仓库中的tag为test1的镜像，但是由于是docker hub上的仓库，所以可以省略registry地址，于是就写成了zsythink/nginx:test1
# -c选项用于设定镜像的各种参数，上例-c选项的值为'CMD ["nginx","-g","daemon off;"]'，表示将镜像的默认运行的程序设置为nginx
```


## Docker 构建新镜像

基于现有的镜像，重新封装一个新的镜像；需要有原始镜像，并且需要有dockerfile文件

以下为基于node最新镜像，封装安装一个hexo博客引擎镜像；

```dockerfile
# 基础镜像
FROM node:latest

# 维护者信息
MAINTAINER your_name <your_mail>

# 工作目录
WORKDIR /hexo

# 安装Hexo
RUN npm install hexo-cli -g
RUN hexo init .
RUN npm install

# 设置git
RUN git config --global user.name "your_name"
RUN git config --global user.email "your_mail"

# 映射端口
EXPOSE 4000

# 运行命令
CMD ["/bin/bash"]
```

文件写完后，执行指令

```sh
docker build -t "hexo:latest"
```

> 编译完成后，会出现镜像 hexo:latest

## Docker Compose 应用

将一些列动作打包至一个配置文件中，并将最终的docker以服务的方式运行。

> 先决条件：涉及镜像封装，需要有dockerfile ；

```yml
# 配置一个hexo的compose文件
version: '3'
services:
  blog:
    # 如果镜像有异常就直接执行重启
    restart: always
    build:
        # 涉及构建，dockerfile所在的文件夹为context属性，即为上下文
        context: hexo_docker
        # 对应的dockerfile
        dockerfile: dockerfile
    # 构建完的镜像名
    image: nextblog:24
    # 新起的docker服务名
    container_name: temp_simple_test
    # 映射端口
    ports:
      - "4000:4000"
    # 映射的目录
    volumes:
     - $PWD:/hexo
```

检查compose过程中的报错日志

```sh
docker-compose logs -f --tail=50 
```