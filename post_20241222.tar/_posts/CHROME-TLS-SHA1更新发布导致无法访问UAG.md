---
title: CHROME-TLS-SHA1更新发布导致无法访问UAG
tags:
  - 故障
categories:
  - VMware
  - Horizon View
date: 2023-10-08 00:16:04
---

# 故障描述

Chrome浏览器在117版本中，访问UAG地址（https://xxxxxx.com） 浏览器提示"ERR_SSL_PROTOCOL_ERROR";但使用其他浏览器，如Safari、Edge、Firefox就可以正常访问；

Chrome版本信息：117.0.5938.150

# 原因分析

服务器端的TLS使用了SHA1加密，导致浏览器判定为异常；

# 解决方案

## 短期方案

调整Chrome的配置

```sh
# 在浏览器地址栏中输入
chrome://flags/#use-sha1-server-handshakes
# 将 Allow SHA-1 server signatures in TLS 调整为 Allow
```

## 长期方案【待补充】

需要升级openssl

```sh
# 版本查看
openssl version
```

```操作记录
# 2023-10-07
测试过 2306 ，2306-FIPS版本，结果只有普通版的2306版本是正常的，而FIPS版本则无法使用；
可能是FIPS版本，过程有需要SHA-1加密的TLS，导致被Chrome给拦截了，目前还在等待官方信息；

```
# 参考资料

诡异的ERR_SSL_PROTOCOL_ERROR：https://zhuanlan.zhihu.com/p/659738295
Chromium描述：https://bugs.chromium.org/p/chromium/issues/detail?id=1488571
发布信息：https://chromium-review.googlesource.com/c/chromium/src/+/4898836