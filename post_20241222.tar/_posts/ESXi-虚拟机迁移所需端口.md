---
title: ESXi 虚拟机迁移所需端口
tags:
  - KB
categories:
  - VMware
  - vSphere
date: 2022-01-04 22:36:23
---

# 需求

需要vCenter下的ESXi内的虚拟机能相互迁移。

| SRC | DST | TCP | UDP | Description |
|:----:|:----:|:----:|:---:|:---:|
| vCenter| ESXi|443，902| |vCenter能够添加目标ESXI|
| ESXi | ESXi |8000| |vMotion端口|