---
title: lamp-Zabbix服务器监控部署
date: 2018-11-20 23:18:36
tags: Linux
---


# 环境

* Centos 7
* Zabbix-4.0
* PHP-7.2.12
* Apache-2.2.24
* MariaDB-10.3.11 Stable

> 采用编译安装

> Centos 7 的防火墙坑，firewall-cmd --stat 看看防火墙的状态是否为运行状态。

# TODO

完成应用的安装
Deadline ：2018-12-2 0:00 [完成时间：20181202 22:30]

完成监控部署
Deadline ：2018-12-8 0:00

# Linux中的准备工作

* httpd (提供 Apache 主程式)
* mysql (MySQL 客戶端程式)
* mysql-server (MySQL 伺服器程式)
* php (PHP 主程式含給 apache 使用的模組)
* php-devel (PHP 的發展工具，這個與 PHP 外掛的加速軟體有關)
* php-mysql (提供給 PHP 程式讀取 MySQL 資料庫的模組)

* 关闭 Selinux
* 关闭 Iptables
* 添加 mysql 账号
* 添加 zabbix 账号
* 添加 apache 账号

# 安装Apache

先安装apache必备运行库 ， 安装 apr 和 apr-util 

* apr-1.6.5
* apr-util-1.6.1

```shell
# 安装依赖包
yum install pcre-devel -y

# 安装运行库必备
wget -O apr-1.6.5.tar.gz http://mirror.bit.edu.cn/apache//apr/apr-1.6.5.tar.gz

wget -O apr-util-1.6.1.tar.gz http://mirror.bit.edu.cn/apache//apr/apr-util-1.6.1.tar.gz

# 到 apr 目录下
./configure --prefix=/usr/local/apr-1.6.5
# 检查
echo  $?
# 如果没有错误则编译安装
make
make install

# 到 apr-util 目录下
./configure --prefxi=/usr/local/apr-util-1.6.1 --with-apr=/usr/local/apr
# 检查
echo $?
make
make install

# 到httpd-2.2.4的目录下安装
./configure --prefix=/usr/local/httpd-2.2.24/ --sysconfdir=/etc/httpd --enable-so --enable-rewrite --enable-ssl --enable-cgi --enable-cgid --enable-modules=most --enable-mods-shared=most --enable-mpms-shared=all --with-apr=/usr/local/apr --with-apr-util=/usr/local/apr-util

make && make install


# 参数说明
# --enable-so：支持动态共享模块，如果支持php将不能与apache一起工作。必须要有
# --enable-ssl：启用ssl功能，如果不启用将无法使用https
# --enable-mpms-shared=all：prefork、worker、event
# --with-mpm=event：event为默认
# --enable-rewrite：支持URL重写
# --enable-cgi :支持cgi
# --enable-cgid:httpd使用event或者worker得启用被线程方式访问
# --enable-modules=most :启用大多数模块
# --enable-mods-shared=most:启用大多数共享模块

#复制apachectl到/etc/init.d下
cp /usr/local/httpd/bin/apachectl /etc/init.d/httpd
```

## Apache启动报错

1. Could not reliably determine the server's fully qualified domain name, using localhost.localdomain for ServerName


2. configure: error: ...No recognized SSL/TLS toolkit detected
* yum install openssl-devel -y

3. Syntax error on line 118 of /usr/local/httpd-2.2.24/conf/httpd.conf:Invalid command 'Order', perhaps misspelled or defined by a module not included in the server configuration
* 没有加载 mod_authz_host.so 模块
* LoadModule authz_host_module modules/mod_authz_host.so

# 安装PHP-7.2.12

* curl 要求 7.10.5+
* 区别于 --with-mysql , 这个版本的php用的是 --with-pdo-mysql ,而不是用 --with-mysql
  
```shell
./configure --prefix=/usr/local/php-7.2.12 --with-config-file-path=/usr/local/php-7.2.12/etc --with-bz2 --with-curl --enable-ftp --enable-sockets --disable-ipv6 --with-gd --with-jpeg-dir=/usr/local --with-png-dir=/usr/local --with-freetype-dir=/usr/local --with-iconv-dir=/usr/local --enable-mbstring --enable-calendar --with-gettext --with-libxml-dir=/usr/local --with-zlib --with-pdo-mysql=mysqlnd --with-mysqli=mysqlnd --enable-dom --enable-xml --enable-fpm --with-libdir=lib64 --enable-bcmath --enable-mbstring --with-gd  --with-libxml-dir=/usr/local --with-apxs2=/usr/local/httpd/bin/apxs

make && make install
```

> 因为要编译apache的php模块，所以一定要带上 --with-apxs2 参数。

需要对 apache 的配置文件进行设置 ， httpd.conf , 默认在 /usr/local/httpd/conf/httpd.conf 。

```shell
# 添加解析问文件后缀
AddType application/x-httpd-php .php .html .htm

LoadModule php7_module modules/libphp7.so

添加解析节点
<FileMatch \.php$>
    SetHandler application/x-httpd-php
<FileMatch>
```

设置几个必要参数 , 修改配置文件 /etc/php.ini

```shell
# 查看 php 的配置文件 php.ini 的路径
./bin/php --ini
# 编辑 php.ini 文件
vi /etc/php.ini
---
max_execution_time = 300
memory_limit = 128M
post_max_size = 16M
upload_max_filesize = 2M
max_input_time = 300
date.timezone PRC
---

# 修改完后，需要重启 web服务器 才能生效。
/etc/init.d/httpd restart
```

* php-fpm.conf 是 PHP-FPM特有的配置文件。
* php.ini 是 PHP 解析器的配置文件。

## 遇到的问题

1. wrong mysql library version or lib not found.

* 不指定对应的mysqli即可。
   
2. ERROR: No pool defined. at least one pool section must be specified in confi

* 进入PHP安装目录/etc/php-fpm.d ，将www.conf.default改名为www.conf
* 这个是池的定义，默认的为www池。


# 安装 Mysql 

解压源码包，执行编译安装。

```shell
tar xf mariaDB-10.3.11.tar.gz

cd mariaDB-10.3.11

cmake . -DCMAKE_INSTALL_PREFIX=/usr/local/mariaDB-10.3.11 -DMYSQL_DATADIR=/usr/local/mariadb/DB-DATA/ -DSYSCONFDIR=/etc -DWITHOUT_TOKUDB=1 -DWITH_INNOBASE_STORAGE_ENGINE=1  -DMYSQL_UNIX_ADDR=/tmp/mysql.sock -DDEFAULT_CHARSET=utf8 -DDEFAULT_COLLATION=utf8_general_ci

make && make install

# 参数说明：

# -DCMAKE_INSTALL_PREFIX是指定安装的位置
# -DMYSQL_DATADIR是指定MySQL的数据目录
# -DSYSCONFDIR是指定配置文件所在的目录，一般都是/etc ，具体的配置文件是/etc/my.cnf
# -DWITHOUT_TOKUDB=1这个参数一般都要设置上，表示不安装tokudb引擎。

# tokudb是MySQL中一款开源的存储引擎，可以管理大量数据并且有一些新的特性，这些是Innodb所不具备的，这里之所以不安装，是因为一般计算机默认是没有Percona Server的，并且加载tokudb还要依赖jemalloc内存优化，一般开发中也是不用tokudb的，所以暂时屏蔽掉。

#将常用指令添加至环境变量中。

vim /etc/profile

#---profile---
export PATH="/usr/local/mariaDB/bin:$PATH"
#---profile---

source /etc/profile


#关于配置文件，默认安装中，mysql的配置文件放在 /etc/my.cnf 中，里面需要编辑，有关于服务端的配置。

vim /etc/my.cnf
---
[mysqld]
basedir=/usr/local/mariaDB-10.3.11
port=3306
socket=/tmp/mysqld.socket
datadir=/db-data/
log_error=/db-data/mariaDB-error.log

[client]
socket=/tmp/mysqld.socket

# 进入数据库
/usr/local/mysqld/support-files/mysql.service start

```


## 遇到的问题

1. 无法看到报错日志。

* 需要自己手动创建报错日志文件 ，即 touch /var/log/mariadb/mariadb.log
* 没有配置mysqld的错误日志输出 log_error 参数未设置

2. 无法启动 mysql 服务 ，因为 mysql.user 表不存在。“Fatal error: Can't open and lock privilege tables: Table 'mysql.user' doesn't exist“

* 这个是因为列表没有初始化，导致数据库无法识别到相应的用户信息以及数据库信息。
* 检查方法：在 my.cnf 配置文件的 [mysqld] 节点中添加 skip-grant-tables , 就可以跳过检查 user 表进入数据库，可以看到里面并没有mysql这个库。
* 真正的解决方法是在编译安装完后，需要运行脚本 mysql_install_db

下面是mysql进程所调用的路径

```shell
mysql    120667  0.1  3.9 1281688 73040 pts/0   Sl   12:58   0:00 /usr/local/mysql/bin/mysqld --basedir=/usr/local/mysql --datadir=/usr/local/mysql/data --plugin-dir=/usr/local/mysql/lib/plugin --user=mysql --log-error=/usr/local/mysql/data/localhost.localdomain.err --pid-file=/usr/local/mysql/data/localhost.localdomain.pid
```

3. 如果还是无法启动，请检查以下 mysql 目录下的用户权限。“ Cannot open '/data/mysql/ib_buffer_pool' for reading: Permission denied
”

* 因为使用mysql用户去启动这个进程，所有调用都是使用mysql去实现，因此必要的文件必须拥授权给mysql。

4. 启动遇到socket问题，无法连接 mysql.socket.

* 这是因为我已经修改了socket文件的命名，默认的是mysql.socket , 因此只需要在启动的时候指定 socket 即可 ， 加参数 -S 。

# 安装Zabbix-4.0.2

```shell
./configure --prefix=/usr/local/zabbix-4.0.2/ --enable-server \
--enable-agent --with-mysql --with-net-snmp --with-libcurl --with-libxml2

make && make install=

# 创建专门用于zabbix的账户
useradd zabbix -s /sbin/nologin

# 初始化zabbix的数据库
mysql -uroot -p -S /tmp/mysql.socket < 'create database zabbix default charset utf8'
# 初始化数据库的表格
mysql -uroot zabbix < /data/zabbix-2.2.20/database/mysql/schema.sql
#初始化sever
mysql -uroot zabbix< /data/zabbix-2.2.20/database/mysql/images.sql
mysql -uroot zabbix< /data/zabbix-2.2.20/database/mysql/data.sql
# 导入sql语句的时候，可能会提示没有找到数据库
# 自己手动往 schema.sql 、 images.sql 、 data.sql 上添加 use zabbix

# 配置zabbix_server
# TODO ： 前端文件复制到 Apache 目录下
mkdir /etc/zabbix
cp config/zabbix_server.conf /etc/zabbix/
vim /etc/zabbix/zabbix_server.conf
#---zabbix_server.conf---#
DBName=zabbix
DBUser=root
DBPassword=ttlsapwd
DBPort=3306
#---zabbix_server.conf---#
```

Zabbix 初始账号和密码：

* Usr ： Admin
* Pwd ： zabbix

## 遇到的问题
1. configure: error: newly created file is older than distributed files!

* 硬件时钟、系统时间不一致导致的问题。

2. 进入web界面，初始化zabbix遇到以下问题。

```shell
Minimum required size of PHP post is 16M (configuration option "post_max_size").
Minimum required limit on execution time of PHP scripts is 300 (configuration option "max_execution_time").
Time zone for PHP is not set (configuration parameter "date.timezone").
```

* 这个需要修改 php.ini 文件。
* timezone 是在 php-5.1 开始引入的东西，默认是关闭的，显示的时间是格林威治标准时间，和北京时间相差 8 个小时。
  
# 小结

对于安装顺序的要求，是因为安装时会有关联，因此先执行以下的安装顺序较为妥当：

1. 安装 Apache
2. 安装 Mysql
3. 安装 PHP
    1. 加上 axps 参数，指定apache路径
4. 安装 Zabbix

Centos中对防火墙的使用并不是 iptables ， 而是 firewalld 因此在端口拦截方面要注意此应用。

# 参考资料

* 坑爹的网卡配置 ：https://www.linuxidc.com/Linux/2017-04/143002.htm
* 坑爹的网卡操作指令：https://linux.cn/article-3631-1.html
* 阿里源 https://blog.csdn.net/jameshadoop/article/details/54881295
* APR :http://apr.apache.org/download.cgi 
* Apache ： https://archive.apache.org/dist/httpd/
* 开发套件安装 ：https://www.linuxidc.com/Linux/2016-04/130081.htm
* Httpd 配置 ： https://www.linuxidc.com/Linux/2016-04/130079.htm
* Apache-2.2 ：http://httpd.apache.org/docs/2.2/
* Zabbix官方安装指引 ： https://www.zabbix.com/cn/download?zabbix=4.0&os_distribution=centos&os_version=7&db=MySQL
* MariaDB-10.3.11 : https://downloads.mariadb.org/mariadb/10.3.11/
* MariaDB : https://mariadb.com/kb/zh-cn/mariadb/
* MariaDB-10.1.18源码安装：https://www.cnblogs.com/freeweb/p/5991374.html
* php 时区设置：https://www.jb51.net/article/27821.htm
* firewall-cmd : https://www.jianshu.com/p/411274f96492
* PHP的配置文件 ： https://blog.csdn.net/u012129607/article/details/71191489