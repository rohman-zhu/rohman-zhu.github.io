---
title: 油猴JavaScript脚本-B站牧场物语弹幕需求
tags:
  - default
categories:
  - default
date: 2024-05-05 00:21:04
---
# 需求说明

B站有一个弹幕游戏，叫牧场物语，可以通过弹幕来进行喂鸡、收货、寻宝等动作；于是就想做一个自动点击操作的脚本；现有的技术能力有两种：
1. python+selenium；
2. JavaScript+油猴插件；

方案1已经挑战过了，现在来试试方案2；

# 代码记录

```javascript
// ==UserScript==
// @name         牧场物语-喂食-收取-寻宝一条龙
// @namespace    http://tampermonkey.net/
// @version      2024-05-04
// @description  try to take over the world!
// @author       You
// @match        https://live.bilibili.com/21510733?live_from=84001&spm_id_from=333.337.search-card.all.click
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    console.log("【TESTING！！】Start to handle script.")

    var index=0;
    var timer;
    //timer =setInterval(function(){ var lock = getlock(); if(lock == 0){setval();clearInterval(timer)} },500)

    //Global VAR

    function delay(x){
        return new Promise(resolve => {
            setTimeout(() => {
                console.log(111);
                resolve(x);
            },2000);
    });
    }


    function WS(){
        console.log("[Script Work]Ready to WS");
        var DM=document.querySelector("textarea");
        var SENDBUTTON=document.querySelectorAll("button[class='bl-button live-skin-highlight-button-bg live-skin-button-text bl-button--primary bl-button--small']")[0];

        DM.value="喂食";
        DM.dispatchEvent(new Event('input'));
        SENDBUTTON.style.backgroundColor="Aqua";
        SENDBUTTON.click();

        console.log("[Script Work]WS completed.")

    }

    function SQ(){
        console.log("[Script Work]Ready to SQ");
        var DM=document.querySelector("textarea");
        var SENDBUTTON=document.querySelectorAll("button[class='bl-button live-skin-highlight-button-bg live-skin-button-text bl-button--primary bl-button--small']")[0];

        DM.value="收取";
        DM.dispatchEvent(new Event('input'));
        SENDBUTTON.style.backgroundColor="Lime";
        SENDBUTTON.click();

        console.log("[Script Work]SQ completed.");
    }

    function XB(){
        console.log("[Script Work]Ready to XB");
        var DM=document.querySelector("textarea");
        var SENDBUTTON=document.querySelectorAll("button[class='bl-button live-skin-highlight-button-bg live-skin-button-text bl-button--primary bl-button--small']")[0];

        //var DM=document.querySelector("textarea");
        //DM.click();
        DM.value="寻宝";
        DM.dispatchEvent(new Event('input'));

        //var SENDB=document.querySelectorAll("button[class='bl-button live-skin-highlight-button-bg live-skin-button-text bl-button--primary bl-button--small']")[0];
        SENDBUTTON.style.backgroundColor="yellow";
            //DM.value="寻宝";

        SENDBUTTON.click();
        console.log("[Script Work]XB completed.")

    }

        function DY(){
        console.log("[Script Work]Ready to XB");
        var DM=document.querySelector("textarea");
        var SENDBUTTON=document.querySelectorAll("button[class='bl-button live-skin-highlight-button-bg live-skin-button-text bl-button--primary bl-button--small']")[0];

        //var DM=document.querySelector("textarea");
        //DM.click();
        DM.value="d1";
        DM.dispatchEvent(new Event('input'));

        //var SENDB=document.querySelectorAll("button[class='bl-button live-skin-highlight-button-bg live-skin-button-text bl-button--primary bl-button--small']")[0];
        SENDBUTTON.style.backgroundColor="yellow";
            //DM.value="寻宝";

        SENDBUTTON.click();
        console.log("[Script Work]XB completed.")

    }

    setTimeout(WS,2000);
    setTimeout(SQ,8000);
    setTimeout(XB,18000);
    //setTimeout(DY,18000);

    //200s
    setTimeout(()=>{ location.reload();},202000);


})();
```

## 注意点，注意坑！

1. 查找元素的方法为 dom 对象以及其对应的方法，比如 document.querySelector("标签或者元素")；
2. 注意大小写！JavaScript是区分大小写的，这个与powershell脚本不同；
3. DOM的querySelectorAll方法，返回的是数组，所以需要引用该数组对象的第一个；
4. setTimeout延时函数有毒，是异步执行的，所以写延时函数需要注意网页加载时间；
4. 匿名函数表示方法 ()=>{} ;
5. 页面刷新 location.reload();
