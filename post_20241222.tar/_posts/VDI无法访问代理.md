---
title: VDI无法访问代理
tags:
  - View
categories:
  - VMware
  - Horizon View
date: 2021-10-13 01:21:00
---

# 问题

用户无法访问VDI，点开VDI后无法正常访问。

# 原因分析

1. CS与Horizon Agent的防火墙拦截。
2. Horizon Agent没有设置DNS，无法解析到Horizon Connection Server的FQDN。
3. Connection Server异常，需要重置key

# 解决方法

## 防火墙

防火墙拦截，申请防火墙即可。

```
SRC:CS
DST:Horizon Agent
TCP-Port:4172(PCoIP)、22443（Blast）
UDP-Port:5172(PCoIP)、22443(Blast)

SRC:Horizon Agent
DST:CS
TCP-Port:4001、4002、389
```

## DNS问题

给Horizon Agent设置DNS

## 配对问题

进入CS，以管理员身份执行powershell

```
vdmadmin -a [桌面池] -m [VDI虚拟机名] -resetkey
```


