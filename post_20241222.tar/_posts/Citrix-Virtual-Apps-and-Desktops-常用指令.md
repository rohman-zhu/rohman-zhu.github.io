---
title: Citrix Virtual Apps and Desktops 常用指令
tags:
  - 脚本
  - 常用指令
categories:
  - Citrix
date: 2023-07-30 17:19:20
---
# 如何使用

1. 安装SDK，或者直接在DDC中打开powershell
2. 加载SDK，使用指令 asnp citrix*

## 获取用户信息

```powershell
Get-BrokerUser
```


# 参考资料

- https://developer-docs.citrix.com/projects/citrix-virtual-apps-desktops-sdk/en/latest/Broker/Get-BrokerUser/
- https://docs.citrix.com/en-us/xenapp-and-xendesktop
- https://support.citrix.com/article/CTX222326/how-to-configure-powershell-sdk-and-execute-commands-remotely-in-xenappxendesktop-7x#:~:text=Install%20these%20PowerShell%20Snap-ins%20on%20the%20machine%20where,Citrix%20PowerShell%20commands%20by%20using%20the%20%22AdminAddress%22%20parameter.