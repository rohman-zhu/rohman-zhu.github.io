---
title: Windows设置驱动数字签名
tags:
  - default
categories:
  - Windows Server
date: 2020-12-25 08:36:04
---
# 背景需求

用户需要安装驱动，需要禁用驱动数字签名检测。

# 解决方法

方法一：

1. 依次选择开始-设置-更新和安全-恢复-立即重新启动。
2. 在启动设置页面,依次选择疑难解答-高级选项-启动设置-重启。
3. 系统重新启动以后，在启动设置页面按"7"或者"F7"选择禁用驱动程序强制签名。

方法二：

1. 以管理员方式打开 CMD 
2. 输入指令 bcdedit.exe /set nointegritychecks on  回车
3. 重启PC

> 如果需要改回来，则输入指令 bcdedit.exe /set nointegritychecks off ， 重启

进入测试模式

1. 以管理员方式打开 CMD 
2. 输入指令   bcdedit /set testsigning on ， 回车
3. 重启PC

> 系统禁用驱动程序强制签名模式，用于关闭系统驱动签名，安装一些没有经过签名的驱动和程序。