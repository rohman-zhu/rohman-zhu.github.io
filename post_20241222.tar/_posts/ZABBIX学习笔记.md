---
title: ZABBIX学习笔记
date: 2017-12-09 15:40:17
tags: Linux
---
# 监控-ZABBIX #

监控类别:

* 业务监控 (流量分析,开源的Piwik;)
* 网络监控 (开源的Smokeping)
* 应用监控
* 单机监控

## 监控的细节 ##

1. 确定业务类型
1. 熟悉监控指标
1. 确定性能基准线
1. 使用工具-获取工具-设置阀值-触发报警-报警通知-通知升级

### CPU ###

* 用户态
* 内核态

CPU Utilization - 如果一个CPU被充分使用,利用率分类之间均衡的比例:

* 65%-70% User Time
* 30% -35% System Time
* 0% - 5% Idle(闲置的) Time

> 什么是Buffer?什么是Cache?

## 什么是ZABBIX ##

Zabbix是一个企业级的、开源的、分布式的监控套件
Zabbix可以监控网络和服务的监控状况. Zabbix利用灵活的告警机制，允许用户对事件发送基于Email的告警. 这样可以保证快速的对问题作出相应. Zabbix可以利用存储数据提供杰出的报告及图形化方式. 这一特性将帮助用户完成容量规划.

### 进程介绍 ###

* ZABBIX_agentd :客户端守护进程，此进程收集客户端数据，例如cpu负载、内存、硬盘使用情况等
* zabbix\_get : zabbix工具，单独使用的命令，通常在server或者proxy端执行获取远程客户端信息的命令。通常用户排错。例如在server端获取不到客户端的内存数据，我们可以使用zabbix\_get获取客户端的内容的方式来做故障排查。
* zabbix_sender : zabbix工具，用于发送数据给server或者proxy，通常用于耗时比较长的检查。很多检查非常耗时间，导致zabbix超时。于是我们在脚本执行完毕之后，使用sender主动提交数据。
* zabbix服务端守护进程。zabbix\agentd、zabbix\_get、zabbix\_sender、zabbix\_proxy、zabbix\_java_gateway的数据最终都是提交到server
* zabbix_proxy : zabbix代理守护进程。功能类似server，唯一不同的是它只是一个中转站，它需要把收集到的数据提交/被提交到server里。为什么要用代理？代理是做什么的？卖个关子，请继续关注运维生存时间zabbix教程系列。
* zabbix\_java\_gateway : zabbix2.0之后引入的一个功能。顾名思义：Java网关，类似agentd，但是只用于Java方面。需要特别注意的是，它只能主动去获取数据，而不能被动获取数据。它的数据最终会给到server或者proxy。

### 软硬件需求 ###

![硬件需求表](http://www.ttlsa.com/wp-content/uploads/2014/03/zabbix-hard-require.jpg)

支持的操作系统:

* Linux
* IBM AIX
* FreeBSD
* NetBSD
* OpenBSD
* HP-UX
* Mac OS X
* Solaris
* Windows: 2000, Server 2003, XP, Vista, Server 2008, 7, 8, Server 2012 (只能跑Zabbix agent)

>window只能跑客户端

软件需求:

1. 数据库:
    1. MySQL:5.0.3+,推荐使用InnoDB引擎
    1. Oracle:10G+
    1. Postgresql:8.1+
    1. SQLite:3.3.5+
    1. IBM DB2:9.7+
1. Web:
    1. Apache:1.3.12+
    1. PHP:5.3.0+
    1. PHP 拓展:
        1. gd
        1. bcmath
        1. ctype
        1. libXML     2.6.15或以上
        1. xmlreader
        1. xmlwriter
        1. session
        1. sockets
        1. mbstring
        1. gettext
        1. ibm_db2（可选）
        1. mysqli（推荐）
        1. oci8（可选）
        1. pgsql（可选）
        1. sqlite3    （可选）
1. 服务器:
    1. OpenIPMI：IPMI硬件监控
    1. libssh2：版本1.0以上，监控ssh服务
    1. fping：icmp监控项
    1. libcurl：监控web项.
    1. libiksemel：支持jabber报警
    1. net-snmp：增加SNMP支持
1. JAVA网关:
    1. logback-core-0.9.27.jar ：http://logback.qos.ch/ ，0.9.27, 1.0.13, and 1.1.1已测试
    1. logback-classic-0.9.27.jar ：http://logback.qos.ch/ ， 0.9.27, 1.0.13, and 1.1.1.已测试
    1. slf4j-api-1.6.1.jar ：http://logback.qos.ch/ ，1.6.1, 1.6.6, and 1.7.6.已测试
    1. android-json-4.3\_r3.1.jar `https://android.googlesource.com/platform/libcore/+/master/json ，2.3.3\_r1.1 and 4.3\_r3.1已测试`
1. 时间同步:

```script
00 00 * * * /usr/sbin/ntpdate -u 195.13.1.153
```

## 安装过程 ##

安装ZABBIX需要在LNMP或者LAMP环境下.

### 安装MySQL ###

```sh
tar xvf MySQL.tar
# 将目录移到/Application或者/usr/local/下
mv MySQL /usr/local/MySQL
# 执行安装脚本
/usr/local/MySQL/bin/mysql_install_db
# 添加命令到环境中
vim /etc/profile
#-------------------
PATH="usr/local/MySQL/bin:$PATH"
#--------------------
source /etc/profile
# 将服务添加至/init.d/中
cp /usr/local/mysql/support-files/mysql.server /etc/init.d/
# 启动服务
/etc/init.d/mysql.server start
# 检查是否启动了
lsof -i:3306
```

### PHP ###

php具体安装方法参考上面的链接，不过如下模块要特别留意加上

```sh
bcmath        --enable-bcmath
mbstring    --enable-mbstring
sockets        --enable-sockets
gd            --with-gd
libxml        --with-libxml-dir=/usr/local
```

php.ini配置文件需要修改,否则不能安装ZABBIX

```sh
max_execution_time = 300
memory_limit = 128M
post_max_size = 16M
upload_max_filesize = 2M
max_input_time = 300
date.timezone PRC
```

安装 php

```shell
./configure --prefix=/usr/local/php-5.5.38 --with-config-file-path=/usr/local/php-5.5.38/etc --with-bz2 --with-curl --enable-ftp --enable-sockets --disable-ipv6 --with-gd --with-jpeg-dir=/usr/local --with-png-dir=/usr/local --with-freetype-dir=/usr/local --enable-gd-native-ttf --with-iconv-dir=/usr/local --enable-mbstring --enable-calendar --with-gettext --with-libxml-dir=/usr/local --with-zlib --with-pdo-mysql=mysqlnd --with-mysqli=mysqlnd --with-mysql=mysqlnd --enable-dom --enable-xml --enable-fpm --with-libdir=lib64 --enable-bcmath --enable-mbstring --with-gd  --with-libxml-dir=/usr/local
make
make install
```

### 安装ZABBIX ###

zabbix官网下载页:
`https://www.zabbix.com/download`

```shell
yum install net-snmp-devel libxml2-devel libcurl-devel
tar -xzvf zabbix-2.2.2.tar.gz
cd zabbix-2.2.2
./configure --prefix=/usr/local/zabbix-2.2.2/ --enable-server \
--enable-agent --with-mysql --with-net-snmp --with-libcurl --with-libxml2
make
make install
```

>在zabbix server一般充当两个角色：server、angent，所以上面的配置参数也同时加上了--enable-agent。
>请安装好MySQL，snmp，curl开发库

如果出现 not found mysqlclient library,解决方法是安装 mysql-devel

### 创建用户 ###

为了安全考虑,zabbix只使用普通用户使用运行.

```sh
useradd zabbix
```

### 初始化数据库 ###

zabbix server与proxy需要数据库，angent不需要。
尤其要注意的是proxy只需要导入一个sql文件，而server一共要导入3个sql文件。

```sql
create database zabbix default charset utf8;
```

导入相关sql语句,再zabbix源安装包下

```shell
mysql -uroot zabbix < /data/zabbix-2.2.20/database/mysql/schema.sql
#初始化sever
mysql -uroot zabbix< /data/zabbix-2.2.20/database/mysql/images.sql
mysql -uroot zabbix< /data/zabbix-2.2.20/database/mysql/data.sql
```

### 配置zabbix_Server ###

配置文件再zabbix的源文件下,叫做zabbix_server.conf

```sh
mkdir /etc/zabbix
cp config/zabbix_server.conf /etc/zabbix/
vim /etc/zabbix/zabbix_server.conf
#---zabbix_server.conf---#
DBName=zabbix
DBUser=root
DBPassword=ttlsapwd
DBPort=3306
#---zabbix_server.conf---#
```

> TODO:20171225:今天就先学到这里,配置完zabbix_server端,晚安啦.

#### 配置Zabbix_Server的前端界面 ####

```sh
# 创建根目录
mkdir /dat/logs/nginx
mkdir /data/site/monitor.ttlsa.com/zabbix
cp -rp zabbix-2.2.2/frontends/php/* /data/site/monitor.ttlsa.com/zabbix
```

#### 在nginx中配置节点 ####

```nginx.conf
server{
    listen 80;
    server_name monitor.ttlsa.com;
    access_log /data/logs/nginx/monitor.ttlsa.com.access.log;
    index index.html index.php;
    root /data/site/monitor.ttlsa.com;
    location /
    {
        try_files $uri /index.php?$args;
    }
    location ~*.\.(php|php5)$
    {
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi.conf;
    }
}
```

配置完后,重启一下nginx.

#### 在浏览器中输入monitor.ttlsa.com/zabbix ####

![界面一](http://www.ttlsa.com/wp-content/uploads/2014/03/zabbix-setup-1.jpg)
![php环境检查](http://www.ttlsa.com/wp-content/uploads/2014/03/zabbix-setup-2-check.jpg)
![MySQL配置](http://www.ttlsa.com/wp-content/uploads/2014/03/zabbix-setup-3-mysql.jpg)

省略两个图

![最终界面](http://www.ttlsa.com/wp-content/uploads/2014/03/zabbix-setup-6-Finnish.jpg)

总结一下这个步骤踩到的坑:

1. PHP环境检查的时候发现没有gd-jpeg-support和gd-freetype-support的支持,这个是需要在编译安装php的时候做好的.(TODO : 有没有方法是在php-fpm都安装完后,补安装呢? 找到一种解决方法,缺什么安装什么...http://blog.csdn.net/wudixingyunxingxing/article/details/56561620)
1. Mysql配置的时候,有可能连接不上数据库,是因为数据的账号默认是本地连接,因此在数据库中创建的账户需要添加主机地址,例如root@'%'
1. 最后一步,可能提示配置文件无法生成,那是因为php没有写入的权限,可以手动复制过去.(不算错误的错误...)

初始账号:
Admin-zabbix

#### 配置监控主机 ####

Configure - Hosts - Create host

要填写的信息:

* Host name
* Agent interfaces

Template:

select - Template OS Linux - Select - ADD

### 客户端配置 ###

客户端配置就简单很多了

编译安装 zabbix-2.2.2

```sh
./configure --enable-agent
vi /usr/local/zabbix-2.2.2/etc/
/usr/local/zabbix-2.2.2/sbin/zabbix_agentd
```

这个是zabbix\_agentd相关说明:http://www.ttlsa.com/zabbix/zabbix-command-zabbix_agentd/
以及这一篇文章:
http://blog.51cto.com/pynliu/1569596

>今天完成了zabbix的初步配置(服务端与客户端),明天把nec的电脑装成linux做服务器,并配置为LNMP和zabbix服务端.(2018-1-6)

## 参考文章 ##

1. `http://www.ttlsa.com/zabbix/introduction-zabbix-the-first-section-of-chapter/`
1. `http://www.ttlsa.com/zabbix/zabbix-features-section-2-of-chapter/`
1. `http://www.ttlsa.com/zabbix/zabbix-section-3-of-chapter-1/`