---
title: Bash-Shell常用脚本汇总
tags:
  - 常用指令
categories:
  - Linux
  - 脚本
date: 2024-10-04 17:54:27
---

# 脚本

## 迁移文件

### 递归查询与将文件迁移到上级目录

```sh
#!/bin/bash
# Version:v1
# Date:2024-10-04
# Description: 遍历目标目录下的文件；

target_diectoryName=$1;

function check-targetfoler(){
    # local 定义为局部变量，避免在递归过程中值在传递过程中，发生变更
    local target_folder=$1
    local dir_depth=$2
    local is_move=$3 # 1 表示迁移；0 表示不迁移；

    echo "Current parent folder is "$target_folder
    echo "Current depth is "$dir_depth
    echo "Current is_move flag is "$is_move

    for file in `ls $target_folder`
        do
            if [ -d $target_folder"/"$file ]
            then
                # 目标为目录
                echo $target_folder"/"$file" is a directory,continue to check"
                
                check-targetfoler $target_folder"/"$file $(($dir_depth +1 )) 1
            elif [ -f $target_folder"/"$file ]
            then
                # 目标为文件
                echo $target_folder"/"$file" is a file" 
            fi
        done   
}

function move-filetoparentfolder(){
    # local 定义为局部变量，避免在递归过程中值在传递过程中，发生变更
    local target_folder=$1
    local dir_depth=$2
    local is_move=$3 # 1 表示迁移；0 表示不迁移；

    echo "Current parent folder is "$target_folder
    echo "Current depth is "$dir_depth
    echo "Current is_move flag is "$is_move

    for file in `ls $target_folder`
        do
            if [ -d $target_folder"/"$file ]
            then
                # 目标为目录
                echo $target_folder"/"$file" is a directory,continue to check"
                
                check-targetfoler $target_folder"/"$file $(($dir_depth +1 )) 1
            elif [ -f $target_folder"/"$file ]
            then
                # 目标为文件
                echo $target_folder"/"$file" is a file" 
                if [ $is_move == 1 ]
                then
                    echo $target_folder"/"$file" need to move"
                    # 获取上级目录的信息
                    local parent_folder=awk -F/ '{print $1}'
                    mv $target_foler"/"$file $parent_folder"/"
                fi
            fi
        done   
}



# 脚本的第一个参数为0 ， 这个跟Shell脚本有差异，Bash Shell脚本是 $1;Windows Shell 脚本是$args[0];
move-filetoparentfolder $target_diectoryName 0 0
```

注意点：
1. 函数内的参数，要增加local变量，使参数变为局部变量，而不是全局变量；否则递归会失效；
2. 字符串切割，用awk -F指令，F后面要接切割字符，输出的时候是以1开始； awk -F/ '{print $1}';