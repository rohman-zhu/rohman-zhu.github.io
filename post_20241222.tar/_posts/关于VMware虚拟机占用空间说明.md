---
title: 关于VMware虚拟机占用空间说明
tags:
  - 虚拟机
categories:
  - VMware
  - vSphere
date: 2021-08-08 23:29:58
---
# 虚拟机内存分配

虚拟机实际分配内存，开机后会产生一个内存swap文件，并占用Datastore空间。
因此实际计算虚拟机使用Datastore空间，应为 分配空间+运行内存大小。
