---
title: Linux里的文件ACL属性控制
tags:
  - acl
categories:
  - Linux
date: 2022-11-24 00:51:02
---
# 背景

如果Linux提供SAMBA服务，如何才能做到类似Windows的NTFS文件系统ACL，例如多个用户同时对某一个文件或文件夹有读写权限，而不用通过组来控制。

# setfacl指令

setfacl的英文全称是“ set file access control list ”,即“设置文件访问控制列表”。改命令可以更精确的控制权限的分配，比如让某一个用户对某一个文件具有某种权限。

ACL指文件的所有者、所属组、其他人的读/写/执行之外的特殊的权限， 对于需要特殊权限的使用状况有一定帮助。 如，某一个文件，不让单一的某个用户访问。

语法格式：setfacl [参数] [文件]

参数:

```sh
-m	--modify-acl 更改文件的访问控制列表
-M	--modify-file=file 从文件读取访问控制列表条目更改
-x	--remove=acl 根据文件中访问控制列表移除条目
-X	--remove-file=file 从文件读取访问控制列表条目并删除
-b	--remove-all 删除所有扩展访问控制列表条目
-k	--remove-default 移除默认访问控制列表
-d	--default 应用到默认访问控制列表的操作
-P	--physical 依照自然逻辑，不跟随符号链接
-v	--version 显示版本并退出
-R	--recursive 递归操作子目录
```

DEMO:

```sh
[root@linuxcool ~]# getfacl test
 file: test
 owner: root
 group: root
 user::rwx
 user:zwx:rw-
 group::r-x
 mask::rwx
 other::r-x
[root@linuxcool ~]# setfacl -Rm u:zwx:rw- test 
[root@linuxcool ~]# getfacl test
 file: test
 owner: root
 group: root
 user::rwx
 user:zwx:rw-
 group::r-x
 mask::rwx
 other::r-x
```
# 参考资料

https://www.linuxcool.com/setfacl
