---
title: 启动错误-init配置文件错误
date: 2018-11-18 19:05:38
tags: Linux
---
# 前言

进入 single mode 也要读取 /etc/inittab 来开机。如果无法进入单用户模式，改用 bash 。

# 操作

```shell
grub edit > kernel /vmlinuz-2.6.18-92.e15 ro root=LABEL=/ rhgb quiet init=/bin/bash
```

指定内核调用第一个进程（init）变成 /bin/bash  , 因此 /sbin/init 就不会被执行。

进入 bash 界面将根目录变成读写状态：

```shell
mount -o remount,rw /
```
