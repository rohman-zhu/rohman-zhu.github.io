---
title: 'Virtualbox error with linux Kernal upgrade '
tags:
  - Linux
categories:
  - 故障
date: 2024-09-01 00:26:17
---
# 故障现象
VirtualBox 在Linux 内核升级后，虚拟机无法启动，会提示报错；忽略错误，则会导致虚拟机进入 Guru Mediation 状态。在log文件中可以看到 "VCPU0: Guru Meditation -2708(VERR_VMM_SET_JMP_ABORTED_RESUME)"


# 原因分析

# 解决方法
在非 root 账户下 ，执行指令

```sh
VBoxManage setextradata "[虚拟机名]" "VBoxInternal/RamPreAlloc" 1
```

# 参考
https://forums.virtualbox.org/viewtopic.php?t=103333