---
title: 基于Invoke-Command远程更新VMware Horizon View Agent
tags:
  - 脚本
categories:
  - Windows Server
date: 2022-05-08 17:04:29
---
# 需求

需要更新RDSH的Horizon View Agent 至最新版本。

> Target VMware Horizon View Agent： 7.13.1

## 条件准备

- OS ： Windows Server 2012R2；
- 网络：到客户端的TCP-5985防火墙需要开通；
- 客户端：需要开启WinRM功能，指令 Enable-PSRemoting；
- 安装包准备：将Horizon View Agent安装包放置到客户端的C盘目录下，例如C:\1-InstallPackage；

## 脚本实现

1. 将所需的文件拷贝至客户端；
2. 删除旧的Horizon View Agent客户端，客户端安装完成后重启；
3. 安装新的Horizon View Agent客户端，客户端安装完成后重启；


| 文件名 | 说明 | 使用方式 |
|:---:|:---:|:----:|
|hosts.list|客户端的文件列表|逐行记录客户端的Hostname|
|CopyFiles.ps1|用于拷贝文件至远端服务器|.\CopyFiles.ps1 .\hosts.list|
|SendCommand.ps1|下发指令至客户端|.\SendCommand.ps1 .\hosts.list .\[脚本]|
|UninstallHorizonViewAgent.ps1|卸载Horizon View Agent|.\SendCommand.ps1 .\hosts.list .\UninstallHorizonViewAgent.ps1|
|InstallHorizonViewAgent.ps1|安装Horizon View Agent|.\InstallHorizonViewAgent.ps1 .\hosts.list|


### 拷贝文件脚本--CopyFiles.ps1

可以用 Copy-Item 指令

```ps1
# 输入客户端
$targetHostsFile=$args[0];

Get-Content $targetHostsFile | ForEach-Object {
$targetSession=New-PSSession -ComputerName $_ ;
  Copy-Item [源文件路径] -Destination [目标文件路径] -ToSession $targetSession ;
}
```

### 发送指令脚本--SendCommand.ps1

原本指令为 Invoke-Command -ComputerName [Hostname] -Filepath [脚本路径]

```ps1
$targetHostsFile=$args[0];
$scriptFile=$args[1];

Get-Content $targetHostsFile | ForEach-Object {
  Invoke-Command -ComputerName $_ -Filepath $scriptFile;
}
```

### 删除VMware Horizon View Agent脚本--UninstallHorizonViewAgent.ps1

卸载完成后，会自动重启服务器；

```ps1
Get-Package -Name "VMware Horizon Agent" | Uninstall-Package;
Shutdown -r -t 300;
```

### 安装VMwareHorizon View Agent脚本--InstallHorizonViewAgent.ps1

利用的是安装包可以用msi静默安装的指令；
这里的安装包放在客户端的C:\1-InstallPackage\agent.exe;
安装结束后，可以自动触发服务器重启；

> 本次脚本是触发agent.exe去后台安装，如果PS会话被注销，则会导致安装失败；因此需要建立一个会话供Horizon View Agent去安装。

本脚本需要输入客户端列表 hosts.list；

脚本内部需要修改：
- Connect Server IP；
- 密码

```ps1
$targetHostsFile=$args[0];
$i=0;
$sessionArray=@($a,$b,$c,$d,$e);

Get-Content $targetHostsFile | ForEach-Object {
#设置5个并发为一组
$index=$($i%5)
$sessionArray[$index]=New-PSSession -ComputerName $_ ;
Invoke-Command -Session $sessionArray[$index] -ScriptBlock {
  C:\1-InstallPackage\agent.exe /s /v '/qn RDP_CHOICE=0 VDM_VC_MANAGED_AGENT=0 VDM_SERVER_NAME=[Connect Server IP] VDM_SERVER_USERNAME=[domain\administratorUsername] VDM_SERVER_PASSWORD="[密码，需要用双引号]" ADDLOCAL=Core REBOOT=Force' /l C:\1-InstallPackage\installAgent.log;
}

if($index -eq 4){
  Start-Sleep -Seconds 300;
}

$i++;
}
```

# 参考资料

- TCP-5985：https://www.speedguide.net/port.php?port=5985
- VMware Horizon View Agent 静默安装：https://docs.vmware.com/cn/VMware-Horizon-7/7.13/horizon-virtual-desktops/GUID-0B32D33F-152F-45EC-AC2C-F523D9432426.html