---
title: VMware Converter 无法启动服务
tags:
  - 故障
categories:
  - VMware
date: 2023-03-27 23:22:22
---
# 故障描述

Windows Server安装VMware Converter后，无法启动服务；

报错信息：

```
安装 vCenter Converter standalone 6.x 时，安装会完成，但会出现弹出窗口“无法启动服务 (Could not start service)”。
在 Windows Service Manager 中，vCenter Converter Agent、vCenter Converter Server 或 vCenter 

Converter Worker 服务无法转变为“正在运行”。
在 Windows 事件查看器中可以获得事件 ID 7009，并显示内容“等待 VMware vCenter Converter Standalone 

Worker 服务连接时达到超时时间（30000 毫秒） (A timeout was reached (30000 milliseconds) while waiting for the VMware vCenter Converter Standalone Worker service to connect)”。
```
# 原因分析

VMware Converter在启动服务的时候会联网获取信息，如果获取超时，服务就会提示未响应；

# 解决方法

延长服务超时时间：

```cmd
# 注册表路径
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control

# 创建 DWORD 项，名字为ServicesPipeTimeout
# 值大于 30000（十进制）
```


# 参考资料

https://kb.vmware.com/s/article/64993?lang=zh_cn