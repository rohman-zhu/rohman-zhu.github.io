---
title: 因磁盘空间不足导致VCSA异常
tags:
  - 故障
  - VCSA
categories:
  - VMware
  - vSphere
date: 2021-11-07 18:23:12
---

# 故障现象

vCenter突然出现403错误。

# 原因分析

1. 磁盘空间已满。
2. 自签证书到期。（已检查证书，未过期）

```sh
# 通过运行以下命令验证 vCenter Server Appliance 中的 vpxd 服务是否已停止：

service vmware-vpxd status

# 通过运行以下命令验证 vPostgres 服务是否已停止：

service vmware-vpostgres status

# 通过运行以下命令验证 vPostgres 数据库是否已满：

df -h 

# 在 vpxd 日志文件中，检查是否有类似以下内容的消息：
# No Space left on device

# 在 /storage/db/vpostgres/pg_log/postgresql.log 日志文件中，您会看到类似以下内容的条目：
# PANIC: could not write to file ...No space left on device
# ERROR: could not extend file ...No space left on device
```

# 解决方法

ssh到VCSA，无法在根目录下创建文件，使用 df -Th 看到一个目录使用率已经达到100%。

## 删除PG数据库日志

```sh
# 删除 /storage/db/vpostgres/pg_log/ 中所有旧的日志文件。要删除旧的日志文件，请执行如下命令：

find /storage/db/vpostgres/pg_log -name postgresql\*.log -ctime +30 -print -exec rm {} \;
```

## 扩容

找到对应的vmdk，扩容添加需要扩容的容量。

```sh
# 检查现有容量
df -Th

# 扩容指令
vpxd_servicecfg storage lvm autogrow

# 执行完后会输出内容 VC_CFG_RESULT=0

# 检查是否扩容成功
df -Th
```

# 参考资料

https://kb.vmware.com/s/article/2058273?lang=zh_cn
https://kb.vmware.com/s/article/2056448?lang=zh_cn

监控：
https://kb.vmware.com/s/article/2058187?lang=zh_cn

扩容：
https://www.dinghui.org/increasing-the-disk-space-for-the-vcenter-server-appliance.html
https://kb.vmware.com/s/article/2126276?lang=zh_CN