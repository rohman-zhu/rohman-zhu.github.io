---
title: 关闭Ubuntu自动初始化的进程cloud-init
tags:
  - default
categories:
  - Linux
  - Ubuntu
date: 2022-12-30 22:41:40
---
# 故障分析

修改完主机名后，服务器重启后导致修改的内容被重置。

# 原因分析

因为服务器有cloud-init进程，在执行初始化；

# 解决方法

可以进入单用户模式或者常规模式，执行指令

```sh
systemctl disable cloud-init-local cloud-init cloud-config cloud-final
systemctl stop cloud-init-local cloud-init cloud-config cloud-final
```

可以在/etc/cloud中创建文件cloud-init.disabled

```sh
touch /etc/cloud-init.disabled
```