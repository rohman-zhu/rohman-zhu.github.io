---
title: CentOS7无法启动故障
tags:
  - Linux
categories:
  - 故障
date: 2023-08-27 23:08:01
---

# 故障描述

服务器在开机时会出现Log

```
[FAILED] Failed to start Security Auditing Service.
[FAILED] Failed to start Journal Service.
```

使用正确的密码却无法登录服务器，一直提示Login incorrect.

# 原因分析

服务器开启了 selinux

# 解决方法

```
vim /etc/selinux/config

将selinux改为disabled
```
