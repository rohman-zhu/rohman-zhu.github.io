---
title: Linux系统日志提示umount
date: 2020-01-05 17:01:38
tags:
- 系统异常
- 日志
catogeries:
- Linux
---

# 

## 故障现象：

查看 /var/log/message 的日志，一直提示“umounting”

## 原因分析：

/run/systemd/generator/xxx.mount
可能有修改配置文件。

## 解决方法：

执行systemctl daemon-reload