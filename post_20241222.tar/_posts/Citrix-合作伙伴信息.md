---
title: Citrix 合作伙伴信息
tags:
  - 商务
categories:
  - Citrix
date: 2023-07-30 17:23:44
---
# Citrix 代理商资质信息

目前有4中资质,资质从低到高分别是：

1. Silver Solution Advisor
2. Gold Solution Advisor
3. Platinum Solution Advisor
4. Platinum Plus Solution Advisor

> 信息截止至：2023年

# 可以在Citrix官网查询

https://www.citrix.com/buy/partnerlocator/results.html?partnertypes=CSN&levels=PLATINUM

# 参考资料

https://www.citrix.com/buy/partnerlocator/results.html?partnertypes=CSN&levels=PLATINUM
https://www.citrix.com/buy/partnerlocator/results.html?partnertypes=CSN&levels=PLATINUM