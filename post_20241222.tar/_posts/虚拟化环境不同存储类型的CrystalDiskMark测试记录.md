---
title: 虚拟化环境不同存储类型的CrystalDiskMark测试记录
tags:
  - default
categories:
  - 服务器与存储
  - 存储
date: 2024-06-12 14:51:44
---

# 测试环境描述

硬件环境：

- 底层存储类型：
1. SSD SAN
2. SSD DAS,RAID 1
3. NVMe SSD,PM9A1

虚拟化层环境：
vSphere:6.7

测试机环境：
- OS：Windows Server 2019
- 配置：2C4G
- 测试软件：CrystalDiskMark

# 测试记录
8G数据量，测试5次



