---
title: Windows VDI 黑屏无法唤醒
tags:
  - 故障
  - VDI
categories:
  - VMware
  - Horizon View
date: 2022-10-16 23:49:02
---

# 故障描述

```note
The VM may have a black screen and fail to show desktop contents when using multiple monitors. The issue does not occur when the primary host monitor is at the top-left of the host monitor topology. This affects guests running Windows 10 2004 or 20H2, although other versions may also be affected.

Users may see a regression when upgrading from VMTools 11.1.5 or earlier, and be unable to enter FullScreen or Unity view modes in WS/Fusion.
```

# 原因

```note
An incompatibility between Windows 10 20004/20H2 and WDDM graphics driver in VM Tools 11.2.0-11.2.5 causes the resolution change operation to fail.
```

为兼容性问题，Windows 20H2的 VDDM 驱动与VM Tools 11.2.0-11.2.5 会有异常。
在VMware Tools的11.3发版前，只能通过升级VMware显卡驱动解决，现在直接升级VMware Tools即可；

# 解决方法

```note
This issue is resolved in VMware Tools 11.3.0. Please click here for direct download.
```

# 参考资料

https://kb.vmware.com/s/article/82276?lang=en_US&queryTerm=black%20screen
