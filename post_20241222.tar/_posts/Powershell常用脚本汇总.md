---
title: Powershell常用脚本汇总
tags:
  - 脚本
  - 常用指令
categories:
  - Windows Server
date: 2022-05-10 00:15:36
---

# 常用脚本与指令合集

## 导出csv

```ps1
Export-Csv [目标文件名] 
Export-Csv [目标文件名] -Delimiter "分隔符"

```

## 特殊字符转意

需要使用单引号转意 `

## 获取系统启动时间

```ps1
(Get-Process wininit).StartTime
```

## Invoke-Command 传递参数

Invoke-Command指令，需要带上-ArgumentList 传递参数
代码块使用Param()捕获参数

```ps1
Invoke-Command xxxxxxx -ArgumentList 参数1 -ScriptBlock {Param($捕获参数1) ; xxx使用 $捕获参数1 }
```

传递多个参数

```ps1
Invoke-Command -ArgumentList [$参数1],[$参数2],[$参数3] -ScriptBlock {Param($参数1,$参数2,$参数3)};
```

## 获取当前时间

```ps1
Get-Date -Format "[yyyy-MM-dd][hh:mm]"
```

常用于打印Log

```ps1
function GetLog($logLevel,$logInfo){
  "$(Get-Date -Format "[yyyy-MM-dd][hh:mm]")[$logLevel],[$logInfo]"
}
```

## While 语句

```ps1
while (<condition>){<statement list>}

Example:

while($val -ne 3)
{
    $val++
    Write-Host $val
}

```

## Switch 语句

```ps1
Switch (<test-expression>)
{
    <result1-to-be-matched> {<action>};
    <result2-to-be-matched> {<action>};
}

## Examples:
switch (3)
{
    1 {"It is one."}
    2 {"It is two."}
    3 {"It is three."}
    4 {"It is four."}
}
```


## 字符转十进制数字

```ps1
$targetNumber=[convert]::ToInt32($targetString,10)
```

## 切割字符串

```ps1
$stringArray=$targetString -Split "[切割字符]" 
```

一般配合.Trim()方法，来去除空格。

```ps1
$noSpaceKey=$targetString.Trim()
```

## 获取变量的类型

一般用于识别当前参数的类型；

```ps1
$targetArgs.GetType()
```

## 拷贝文件到远端的方法

```ps1
$remoteSession=New-PSSession -ComputerName $targetServerHostName
Copy-Item [Local Target File] -Destination [Remote Target File Path] -ToSession $remoteSession
```

> ToSession参数需要PS 5.1以上版本才可以使用。

## 拷贝文件夹

需要加参数-Recurse

> 最简单的复制一个文件到另一个文件夹内，如果目标文件夹不存在会自动创建。

```ps1
Copy-Item "E:\PowerShell\form\*" -Destination "E:\PowerShell\to\" -Recurse
```

## 查看Powershell版本

```ps1
$PSVersionTable | Findstr PSVersion
```

## 获取当前登录的用户数

```ps1
$userTempInfo1=query user | Measure-Object | Findstr Count;
$userTempInfo2=$userTempInfo1 -Split ":";
$userTempInfo3=$userTempInfo2[1].Trim();
$userTempAmount=[Convert]::ToInt32($userTempInfo3,10);
$userAmount=$userTempAmount-1;
```

> 当服务器未有用户会话时，query user指令会返回“无用户登录”。

## 条件语句比较

数字比较

|字符|说明|备注|
|:---:|:---:|:---:|
| -gt | 大于 | |
| -ge | 大于等于 ||
| -lt | 小于 ||
| -le | 小于等于 ||
| -eq | 等于 ||
| -ne | 不等于 ||

字符串比较

|字符|说明|备注|
|:----:|:----:|:---:|
| -like | 字符串匹配通配符模式 ||
| -match | 字符串匹配正则表达式模式 ||

> 注意，所有字符串都能 match 空值 $null

## 检查目标补丁是否安装

```ps1
#目标补丁KB号
TargetHotFixIDArray="",""

for ( $i=0 ; $i -lt $TargetHotFixIDArray.length ; $i++ ){
  $isInstalled=Get-HotFix | Where-Object {$_.HotFixID=$TargetHotFixIDArray[$i]} ;
  if ($isInstalled -eq $null){
    "$TargetHotFixIDArray[$i] don't installed." 
  }
}

```


## 设置注册表

注意：如果设置本地组策略或者有域策略的覆盖策略情况下，注册表写入的值会被覆盖。可以使用 rsop.msc 查看。

```ps1
#主要使用的指令
Set-ItemProperty -Path 'HKCU:\xxx\' -Name [xxx] -Value [xxx]
New-ItemProperty -Path 'HKLM:\xxx\' -Name [xxx] -Value [xxx]
Get-ItemProperty -Path 'HKCU:\xxx\' -Name [xxxx]
Get-ChildItem -Path 'HKLM:\xxx\'

# 隐藏所有盘符
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name NoDrives -Value 61708863
```

```
# 除了设置常规的注册表项 （admx.help 获取） ，还可以关注WOW6432node注册表项
# 参照
When the 32-bit app performs a registry query on HKEY_LOCAL_MACHINE\SOFTWARE\<company>\<product>, Windows automatically redirects the query to HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\<company>\<product>

There’s no need to take into account Wow6432 during the development of a 32-bit application. The management of Wow6432 is totally transparent for the developer. Kombustor, for example, modifies Afterburner registry entry:
HKEY_LOCAL_MACHINE\SOFTWARE\MSI\Afterburner. During the dev of Kombustor, I never made a reference to Wow6432.

```

> 查看对应的注册表项 https://admx.help

## 设置网卡

静态IP设置

```ps1
# 修改IP
netsh interface ipv4 address [网卡名] static [IP] [NETMASK] [Gateway]
# 修改DNS
# 主DNS
netsh interface ipv4 dns [网卡名] static [DNS] primary
# 副DNS
netsh interface ipv4 add dns [网卡名] [DNS]
```

DHCP设置

```ps1
netsh interface ipv4 set address [网卡名] dhcp
netsh interface ipv4 set dns [网卡名] dhcp
```

### 设置DNS

```ps1
$NICNAMESET=Get-NetAdapter -Physical;

$NICNAMESET=Get-NetAdapter -Physical;
$PRIMARYDNS="8.8.8.8";
$SECONDDNS="8.8.4.4";

if($NICNAMESET.Name.GetType().BaseType.Name -match "Object"){
    # 单网卡设置DNS；
    $NICNAME=$NICNAMESET.Name;

    Set-DnsClientServerAddress -InterfaceAlias $NICNAME -ServerAddresses $PRIMARYDNS,$SECONDDNS;

}elseif ($NICNAMESET.Name.GetType().BaseType.Name -match "Array") {
    # 多网卡设置DNS
    for($i=0;$i -lt $NICNAMESET.Length;$i++){
        $NICNAME=$NICNAMESET.Name[$i];
        Set-DnsClientServerAddress -InterfaceAlias $NICNAME -ServerAddresses $PRIMARYDNS,$SECONDDNS;
    }
}
```

## 切割IP信息

```ps1
#获取IP信息
$IPInfo=$($(ipconfig | findstr "IPv4") -Split "[:]")[1].Trim();
```

### 切割IP信息-基于IP做主机名修改

格式为：主机名[IP第四位的序号]

如：

- 主机名001
- 主机名010
- 主机名111

```ps1
$baseHostname="【设置的主机名基本格式】";
$IPInfo=$($(ipconfig | findstr "IPv4") -Split "[:]")[1].Trim();
$index=$($IPInfo -Split "[.]")[3].Trim();

#将字符型转为整型 
$flag=[convert]::ToInt32($index,10);
if($($flag -ge 1) -and $($flag -le 9) ){
  # 在 001 与 009 区间
  $newHostname=$baseHostname + "00" + $index;
}elseif($($flag -ge 10) -and $($flag -le 99)){
  # 在 100 与 99 区间
  $newHostname=$baseHostname + "0" + $index;
}else{
  # 大于100
  $newHostname=$baseHostname + $index;
}

# 两种改名方式
# 方式1：非加域
Rename-Computer -NewName $newHostname;

# 方式2：加域
Add-Computer -DomainName "【目标域名】" -Credential "加域用的账户" -NewName $newHostname;
```
## 检查端口占用进程

```ps1
netstat -ab
```

## 服务器安装角色

```ps1
# 获取安装的功能
Get-WindowsFeature -ComputerName [主机名]

# 安装功能
Install-WindowsFeature -Name [功能名]
```

### 安装Remote Desktop Host Session

远程桌面会话主机： RDS-RD-Server

```ps1
# 自动重启需要加参数 -Restart
Install-WindowsFeature -Name "RDS-RD-Server" -Restart
```

## 加域

```ps1
$Cred=Get-Credential

Add-Computer -DomainName $Domain -Credential $Cred -NewName $NewComputerName
```

## 在文本后面追加内容

```ps1
Add-Content [FilePath] [Content]
```

## 禁用本地账户

```ps1
Disable-LocalUser -Name [UserName]
```

## 为本地用户组增加用户

```ps1
Add-LocalGroupMember -Name "组名"  -Member "用户";
```

## 参数

```sh
.\脚本.ps1  [参数1文件]
$FILE=$args[0];

# 参数1文件名获取 
$FILE 

```

## 启动服务与设置服务

```ps1
Start-Service "Zabbix Agent"
Set-Service "Zabbix Agent" -StartupType Automatic
```

## 循环语句

```ps1
for($i = 0 ; $i -le 10 ; $i++ )
{
  echo $i;
}
```

## 测试端口是否连通

```ps1
$TCP=New-Object Net.Sockets.TcpClient
$TCP.Connect("192.168.1.1",80)
$TCP.Close();
```

## 删除用户配置文件

```ps1
#requires -RunAsAdministrator

$domain = 'ccie'
$username = 'user01'

# get user SID
$sid = (New-Object Security.Principal.NTAccount($domain, $username)).Translate([Security.Principal.SecurityIdentifier]).Value

Get-WmiObject -ClassName Win32_UserProfile -Filter "SID='$sid'" |
  ForEach-Object {
    $_.Delete()
  }
```

### 删除用户配置文件改进版本

场景：读取本地RDSH内的所有已登录的用户AD，并识别出已经停用的AD，对状态为“已停用”的AD账户配置删除。

```ps1
#requires -RunAsAdministrator

# 初始信息，需要输入AD域名
$domain = 'ccie'

# 用户目录位置
$fpath="C:\Users"
$childPath=Get-ChildItem -Path $fpath

foreach($tempPath in $childPath ){
  $userName=$tempPath.Name.Trim()
  $userInfo=net user $userName /domain

  if($userInfo[7] -match "Yes"){
    #"$userName is ACTIVE."
  }else{
    "$userName is INACTIVE.Deleting..."

    # get user SID
    $sid = (New-Object Security.Principal.NTAccount($domain, $username)).Translate([Security.Principal.SecurityIdentifier]).Value

    Get-WmiObject -ClassName Win32_UserProfile -Filter "SID='$sid'" | ForEach-Object {
      $_.Delete()
    }
  }
}

```

## 查看WINRM监听端口

```ps1
winrm enumerate winrm/config/listener
```

## 更改WINRM监听端口

```ps1
set-item wsman:\localhost\listener\listener*\port 5895
```

## 逐行读取

```ps1
Get-Content [FILEPATH] | ForEach-Object {
  #line = $_
  $_
}
```

## 时间戳

```ps1
New-Timespan [更早的时间]  [更晚的时间]

New-Timespan $(Get-Date) $(Get-Date "target date")
```

## 获取注册表值

```ps1
Get-ItemPropertyValue -Path HKLM:\xxxxx\xxxx -Name [ItemName]
```

> 注意：如果注册表路径带有空格，则需要将整个路径用" "

## 设置注册表值

```ps1
Set-ItemProperty -Path HKLM:\路径 -Name [ItemName] -value [具体的值]
```

## 非Powershell--Chrome忽略证书

```
# 增加参数
–ignore-certificate-errors
```

## 清除剪贴板

```cmd
cmd.exe /c "echo off | clip"
```

## 检查Windows是否需要因为补丁重启

```log
#The RebootPending value at
#HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing
#The RebootRequired value at
#HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update
#The PendingFileRenameOperations value at
#HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager
```

```ps1
isRebootRequired=Get-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"

if($isRebootRequired -eq $null){
  "Current server don't need Reboot."
}
else{
  "Current server need Reboot."
}
```

## 静默安装Chrome

```ps1
# 会话需要保持几分钟，用于Chrome完成安装；
Chrome-xxxxx.msi  /passive /norestart; Start-Sleep -Seconds 200;
```

Chrome 下载地址

x64位下载地址

http://www.google.com/intl/zh-CN/chrome/business/browser/admin/thankyou.html?platform=win64&msi=true&installdataindex=defaultbrowser&standalone=1

x86位下载地址
http://www.google.com/intl/zh-CN/chrome/business/browser/admin/thankyou.html?platform=win&msi=true&installdataindex=defaultbrowser&standalone=1

## 静默安装火狐浏览器

```ps1
Firefox-xxxxx.msi  /passive /norestart; Start-Sleep -Seconds 200;
```

## Chrome浏览器制定用户数据目录

增加参数--user-data-dir="xxxx\%username%\ChromeData"

## 离线安装cab文件

```ps1
dism.exe  /online /add-package /packagepath:"路径"  /Quiet
```

- 会自动重启 /Quiet
- 不用自动重启 /Norestart

# 设置防火墙策略

```ps1
# 启用策略
Get-NetFirewallRule -Name [防火墙策略名] | Set-NetFirewallRule -Enabled;
# 设置目标策略的作用域,{IP1},{IP2},{IP3}
Get-NetfirewallRule -Name [防火墙策略名] | Get-NetFirewallAddressFilter | Set-NetFirewallAddressFilter -RemoteAddress {IP1},{IP2},{IP3}
```
# 关闭本地防火墙

```ps1
# 关闭
netsh advfirewall set allprofiles state off
# 启动
netsh advfirewall set allprofiles state on
```

# 常用防火墙策略名称

| 策略显示名(Display) | 策略名(Name) |
|:----:|:----:|
| Windows 远程管理(HTTP-In) | WINRM-HTTP-IN-TCP |
| Windows 远程管理(HTTP-In) | WINRM-HTTP-IN-TCP-PUBLIC |
| 远程计划任务管理(RPC) | RemoteTask-In-TCP |
| 远程计划任务管理(RPC-EPMAP) | RemoteTask-RPCSS-In-TCP |

# 系统延迟

```ps1
Start-Sleep -Seconds [单位为秒];
```

# 发送邮件通知

```ps1
Send-MailMessage -From [发件人] -To [收件人] -Cc [抄送人] -Subject [邮件主题] -Body [邮件内容] -Credential [邮箱服务器认证账户] -SmtpServer [目标邮箱服务器地址]

$mailbody=@"
......邮件内容
"@
```

> 中文邮件要注意编码，指令末尾需要加上 -Encoding ([System.Text.Encoding]::UTF8)

# 模板--逐行读取文件

```ps1
# Description:
# Version:
# Date:
# Author:

# 输入文件
$file=$args[0];
$index=0;

if($file -match ".\\"){
  # 如果输入的参数是文件，则逐行读取
  Get-Content $file | ForEach-Object {
  $target=$_.Trim();
  "[$index][$target]"

  # TODO HERE：

  $index++;
  }
}else{
  # 如果是单独一行字符串；
  $target=$file.Trim();
  "[$index][$target]"
  # TODO HERE;

}

```

# 设置WSUS下载服务器的地址--注册表项

```ps1
$targetWSUS="";

Set-ItemProperty -Path HKLM:Software\Policies\Microsoft\Windows\WindowsUpdate -Name WUServer -Value $targetWSUS;

Set-ItemProperty -Path HKLM:Software\Policies\Microsoft\Windows\WindowsUpdate -Name WUStatusServer -Value $targetWSUS;

```
# 定义函数与参数

```ps1
function TEST{
  # 参数写法,这里传入的是形参；
  param($参数1,$参数2);

  # 函数内调用的参数与变更，仅在函数内有效；
  $参数1=[New Value];
  $参数2=[New Value];

  return [返回值];
}

# 调用函数
# 参数对应关系 $参数1=$传入参数1,$参数2=$传入参数2;
# 不抓取返回值的写法
TEST $传入参数1 $传入参数2;

# 抓取返回值的写法
$GETRETURN=TEST $传入参数1 $传入参数2;
```

## 删除软件包

```ps1
Get-Package | Where-Object {$_.Name -like "包名"} | Uninstall-Package
```

## 设置受信任主机列表

```ps1
Set-Item WSman:\localhost\Client\TrustedHosts -value [列表]
```

## 输出控制台指令日志记录

```ps1
Start-Transcript -Path [Log file path];
Stop-Transcript;
```
## 遍历文件夹并传输文件

```ps1
# ps1
# Description: 迁移文件至执行脚本所在的目录
# Version:v1
# Date:2024-10-04

# 脚本的第一个参数为0 ， 这个跟Shell脚本有差异，Bash Shell脚本是 $1;Windows Shell 脚本是$args[0];
$target_directoryName=$args[0];

Function Move-FileToParentDir{
    param($target_DirName,$dir_depth,$is_move);

    Write-Host "Current parent folder is $target_DirName";
    Write-Host "Current depth is $dir_depth";
    Write-Host "Current is_move flag is $is_move";


    $target_dirtoryItem=get-Item $target_DirName;

    Get-ChildItem $target_dirtoryItem | Foreach-Object {
        $item_object=$_;

        if($item_object | where-object {$_.mode -match "d"}){
            # Is directory
            # Powershell允许参数自加，LinuxShell没有此规则，需要$(($目标参数+1))
            Move-FileToParentDir "$target_dirtoryItem\$item_object" $($dir_depth+1) 1;

        }else{
            Write-Host "$target_DirName\$($item_object.Name) is a file"

            if($is_move -eq 1){
                # 这个是执行脚本所在的目录，.\等价于脚本所在的目录，而不是递归到所到的文件层级；
                Write-Host "$($item_object.Name) is a file which under a directory , need to move to parent directory."
                Write-Host $target_DirName;
                $parent_path=Split-Path -Parent $target_DirName;
                move-item "$target_DirName\$($item_object.Name)" $parent_path

            }
        }
    }

    $dir_depth=0;
}

Move-FileToParentDir $target_directoryName 0 0;
```

注意点：
1. 父目录，需要用Split-Path获取；

## Write-Host 与 Write-Output 区别

|指令|说明|示例|
|:---:|:---:|:---:|
|Write-Host| Write-Host 是直接将信息输出到控制台，而不管信息是什么类型，都会将其转换成字符串，并且不会将输出发送到管道。| Write-Host "Hello world" |
|Write-Output| Write-Output 则会将输出发送到管道，以便在管道中的其他命令或过程中使用。它可以输出对象或文本，并且它不会将输出直接发送到控制台，除非您将输出发送到控制台。| Get-ChildItem\| Write-Output |

# 参考资料

- 获取系统启动时间：https://www.pstips.net/system-running-time.html
- PS中的比较：https://docs.microsoft.com/zh-cn/powershell/module/microsoft.powershell.core/about/about_comparison_operators?view=powershell-7.2
- 测试端口是否连通： https://blog.csdn.net/weixin_33737134/article/details/85544432
- 删除用户配置文件： https://blog.vichamp.com/2017/12/27/deleting-user-profiles/
- 更改WINRM监听端口： https://blog.51cto.com/281816327/1394801
- Chrome 修改用户数据目录：https://blog.csdn.net/weixin_40364421/article/details/82769021
- 获取已安装的补丁： https://www.winhelponline.com/blog/how-to-check-if-a-windows-update-kb-is-installed/
- 检查Windows是否需要因为安装补丁重启：https://docs.microsoft.com/en-us/answers/questions/675843/from-the-command-line-how-can-i-tell-if-a-reboot-i.html
- Copy-Item 复制文件和文件夹：https://0x400.net/post/powershell-copy-item.html
- 组策略与注册表项查询：https://admx.help/?Category=Windows_8.1_2012R2&Policy=Microsoft.Policies.WindowsUpdate::CorpWuURL
- Start-Transcript: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.host/start-transcript?view=powershell-7.4
- Write-Host与Write-Output区别： https://juejin.cn/s/powershell%20write-host%20write-output


