---
title: RHEL7.5无法启动问题
tags:
  - 故障
categories:
  - Linux
date: 2020-07-30 00:56:07
---
# 问题描述

1. 启动进入紧急模式 dracut
2. 提示找不到 root 所在的lv

# 原因分析

未知

# 解决方法

1. 进入恢复模式
2. 执行以下指令

```sh
dracut -f
grub2-mkconfing
```
