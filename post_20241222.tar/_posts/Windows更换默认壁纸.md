---
title: Windows更换默认壁纸
tags:
  - default
catergories:
  - WindowsServer
date: 2020-02-04 18:55:18
---
# 更换默认壁纸

用户配置 -- 》 管理模板 --》桌面 --》 Active Desktop
