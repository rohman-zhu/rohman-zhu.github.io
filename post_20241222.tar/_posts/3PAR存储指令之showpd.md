---
title: 3PAR存储指令之showpd
tags:
  - 3PAR指令
categories:
- 服务器与存储
- 存储
- SAN存储
date: 2020-12-05 21:15:03
---

```s
showpd

---

SYNTAX

    showpd [options] [<PD_ID> ...]

    showpd -listcols



OPTIONS

    -listcols               List columns available to be shown with -showcols.

    -showcols <column>[,<column>...]

                            Explicitly select columns to show.

    -i                      Show inventory (inquiry) information.

    -e                      Show disk environmental and error information.

    -c                      Show chunklet usage information.

    -state                  Show detailed state information.

    -s                      Show detailed state information.

    -path                   Show current and saved path information for disks.

    -space                  Show disk capacity usage information (in MB).

    -sortcol <col>[,<dir>][:<col>[,<dir>]...]

        Sorts command output based on column number (<col>).

    -failed                 Show only failed physical disks.

    -degraded               Show only degraded disks

    -p <pattern>            Show disks matching <pattern>

    -nodes <node_list>      Specifies the node list.

    -slots <slot_list>      Specifies the slot list.

    -ports <port_list>      Specifies the port list.

    -w <world-wide_name>    Specifies the WWN of the physical disk.

	
```

现实序号0至1行的记录

```sh
showpd -c - 1
```