---
title: 记录一个Windows远程桌面错误--由于安全设置错误，客户端无法连接到远程计算机
tags:
  - 故障
categories:
  - Windows Server
date: 2022-05-22 16:25:19
---

# 故障现象
远程桌面提示“由于安全设置错误，客户端无法连接到远程计算机” 。

# 解决方法

需要将“系统加密：将FIPS兼容算法用于加密、哈希和签名”设置为禁用 。

1. 打开 secpol.msc
2. 依从进入 安全设置--> 本地策略 --> 安全选项

# 参考资料

https://www.cnblogs.com/Braveliu/p/6759810.html