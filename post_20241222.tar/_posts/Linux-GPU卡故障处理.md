---
title: Linux-GPU卡故障处理
tags:
  - 故障
categories:
  - Linux
date: 2022-09-14 00:18:39
---

# 背景

GPU机器学习的服务器经常容易出现显卡故障，需要更换。
本文将记录定位目标GPU卡的过程。

# 故障现象记录

使用 nvidia-smi 会提示 ： Unable to determine the device handle for GPU XXXX:XX:XX.X GPU is lost . Reboot the system to recover this GPU.
使用 gpustat 会提示 :  Error on querying NVIDIA devices.
使用 lspci -vvs [故障GPU卡的总线地址] 会提示  Unknow header type 7f.

# 操作记录

```sh
# 如果nvidia-smi指令还可以用的情况下，但不提示某一张卡失效

# nvidia-smi查看是哪一张卡缺失；例如原来是8张卡，现在只显示7张卡；
nvidia-smi

# lspci  | grep -i nvidia 结合nvidia-smi结果查看是哪一个bus地址丢失；
lspci | grep -i nvidia

# dmidecode -t slot 查看目标bus地址的物理位置，一般会显示CPU【X】 Slot【X】
dmidecode -t slot


```

番外

```sh
查看pci插槽的速率

lspci -vvvs [总线地址]
lspci -vvvs [总线地址] | grep -i lnksta

```

