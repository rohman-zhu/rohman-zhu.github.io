---
title: Supermicro服务器BMC许可获取方法
tags:
  - 许可
  - License
categories:
  - 服务器与存储
date: 2022-01-11 00:01:12
---
# 获取方法

进入任意一台Linux服务器，输入指令：

```sh
echo -n '0c-c4-xx-xx-xx-xx' | xxd -r -p | openssl dgst -sha1 -mac HMAC -macopt hexkey:8544E3B47ECA58F9583043F8 | awk '{print $2}' | cut -c 1-24
```

# 参考资料

https://www.liujason.com/article/1185.html
