---
title: LINUX-DHCP服务搭建
date: 2019-04-17 23:57:58
tags: Linux
---

# 在Linux中安装 DHCP 服务

OS：
1. CentOS7
2. Ubuntu 16.04

在以上两种系统中，分别安装DHCP服务 ， 并设置DHCP-IP池 。

DHCP 服务中两个关键的文件：

1. 用于绑定网卡的配置文件 /etc/default/isc-dhcp-server 。
2. 用于配置DHCP池的配置文件 /etc/dhcp/dhcpd.conf

## 在 CentOS7 中安装 DHCP 服务

```sh
# 安装 DHCP 服务
yum install dhcp 
# 编辑DHCP绑定的网卡
vim /etc/sysconfig/dhcpd

# 固定IP
# 如果不固定IP，则无法启用 DHCP 服务。
# 略

# 编辑配置文件
vim /etc/dhcp/dhcpd.conf
#--- dhcpd.conf ---#
subnet 192.168.1.0 netmask 255.255.255.0 {
    range 192.168.1.10 192.168.1.100;
    option routers 192.168.1.1;
    # PXE 用的配置
    next-server 192.168.1.167;
    filename "pxelinux.0"

    # 固定IP
    # 格式：
    # host hostname {
    #   hardware ethernet MAC-地址;
    #   fixed-address 固定的IP地址;   
    # }
    host PXE-SERVER {
        hardware ethernet 00:00:00:00:00:00;
        fixed-address 192.168.1.167;
    }
}
#--- dhcpd.conf ---#



```

## 在 Ubuntu16.04 中安装 DHCP 服务

```sh
# apt-get 安装 dhcp 服务 ， 服务名为 isc-dhcp-server
apt-get install isc-dhcp-server -y

# 固定IP
# 如果不固定IP，则无法启用 DHCP 服务。
# 略

# 编辑绑定端口
vim /etc/default/isc-dhcp-server

#---isc-dhcp-server---#
INTERFACES="ens38"
#---isc-dhcp-server---#

# 编辑 dhcpd.conf 配置文件
vim /etc/dhcp/dhcpd.conf

#--- dhcpd.conf ---#
subnet 192.168.1.0 netmask 255.255.255.0 {
    range 192.168.1.10 192.168.1.100;
    option routers 192.168.1.1;
    # PXE 用的配置
    next-server 192.168.1.167;
    filename "pxelinux.0"

    # 固定IP
    # 格式：
    # host hostname {
    #   hardware ethernet MAC-地址;
    #   fixed-address 固定的IP地址;   
    # }
    host PXE-SERVER {
        hardware ethernet 00:00:00:00:00:00;
        fixed-address 192.168.1.167;
    }
}
#--- dhcpd.conf ---#

# 启动 DHCP 服务
/etc/init.d/isc-dhcp-server start
# 查看服务的状态
/etc/init.d/isc-dhcp-server status


```
