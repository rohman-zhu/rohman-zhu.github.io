---
title: Windows-Server-RDSH初始化清单
tags:
  - default
categories:
  - VMware
  - Horizon View
date: 2024-04-18 19:54:05
---

# 前言

RDSH(Remote Desktop Session Host)，用于发布APP给到用户，需要做一些初始化的操作，以及安装一些必要的软件。

# 确认需求

比如通过RDSH发布的浏览器或者SSH客户端，用于网页访问、SSH访问；

## 应用清单

|名称|版本|备注|
|:---:|:---:|:---:|
|Chrome|最新版本|可以用msi包，通过WINRM下发指令安装|
|Firefox|最新版本|作为Chrome的备用软件，也可以远程安装|
|杀毒软件||避免用户自行上传恶意包，导致RDSH故障|
|XSHELL|||
|Putty||作为xshell的备用软件|
|Xterm||作为xshell的备用软件，可以打开X Desktop应用|
|VMware Horizon View Agent|有版本关联要求，一般安装稳定版本||
|Remote desktop session hosts||120天限制|


## 权限与组策略调整

### Chrome没有声音

可以参照：https://rohman-zhu.github.io/2022/10/16/RDSH%E4%B8%AD%E7%9A%84Chrome%E6%B2%A1%E6%9C%89%E5%A3%B0%E9%9F%B3/

### Chrome下载目录

1. 导入Chrome 组策略包；
2. 设置下载路径： \\[SAMBA 服务器地址]\路径\${user_name}

> ${user_name}是一个变量，固定写法；

### 设置安全策略

1. 隐藏驱动器；

### 设置C盘根目录权限

一般可以访问RDSH的用户均是 Remote Desktop Users 组，因此对C盘根目录的NTFS权限可以设置 该组 为 _写入拒绝_ 、 _读取内容拒绝_ 权限；

> 只有Windows 、 Program Files 、Program Files(x86) 目录无法设置；

## 运维相关

### 安装 PS Windows Update 模块

为了方便以后Windows 补丁安装；

### 修改 WinRM 监听端口

默认端口为5985，需要修改为一个不常用的端口；
其次要设置防火墙策略，避免被拦截。



