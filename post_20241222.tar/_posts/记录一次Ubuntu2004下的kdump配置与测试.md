---
title: 记录一次Ubuntu2004下的kdump配置与测试
tags:
  - kdump
  - crash
categories:
  - Linux
  - Ubuntu
date: 2022-05-22 16:17:42
---

# 背景

有一台服务器经常死机，配置了kdump后并无生成dump日志，手动触发系统Crash后依旧无法重启记录Dump日志。
重装操作系统后依旧无生成dump日志。

- OS：Ubuntu 20.04
- Kernel ： 5.4.0-42-generic
- CPU：6252 * 4
- Memory：512GB

# 分析原因

经过长期实测，主要原因还是在于需要增加dumpcrash的内存大小，否则kdump进程没有足够多的内存写入日志。

# Ubuntu 20.04配置 Kdump 过程

```sh
# 安装主要工具
# 这里会安装 crash 、 kexec-tools 、 makedumpfile
apt-get install linux-crashdump -y

# 调整crashkernel分配的内存空间
vim /etc/default/grub.d/kexec-tools.cfg
# 末尾字段增加
# 需要根据实际内存大小来预分配
crashkernel=128G-:4096M

# 调整kdump配置文件
vim /etc/default/kdump-tools
#配置项为 
USE_KDUMP=1

# 配置触发条件
vim /etc/sysctl.conf
# 配置项为
# 相应sysrq来触发
kernel.sysrq=1
# 硬件NMI按钮被按下时触发
kernel.unknown_nmi_panic=1
kernel.panic_on_unrecovered_nmi=1
# 触发内存OOM收集kdump
vm.panic_on_oom=1
# 内核在OOPS错误（非法内存访问或非法指令）后触发
kernel.panic_on_oops=1
# 内核在死锁或者死循环（soft-lockup）触发
kernel.panic_on_io_nmi=1
# 内核在进程hung住时触发
kernel.hung_task_panic=1
# 进程hung住多少时间触发
kernel.hung_task_timeout_secs=120

# 配置完成后，需要重启服务器才能生效
init 6

# 查看是否配置成功，可以在重启后执行指令;查看是否有为kdump分配内存
dmesg | grep -i crash

# 重启完成后，通过指令查询
kdump-config show
cat /proc/cmdline

# 日志会默认保存在 /var/crash目录
```

# 触发测试

```sh
echo 1 > /proc/sys/kernel/sysrq
echo c > /proc/sysrq-trigger
```

正常情况下，服务器会卡死，并开始记录crash信息，屏幕会输出 makedumpfile 信息。最终将重启服务器，并在/var/crash目录中生存相关信息。

# 分析日志

## 分析日志的前置工作--安装 dbgsym

分析日志需要用到 dbgsym ，也就是debug info包。需要增加 ddebs 源才能安装，联网安装方式为

```sh
echo "deb http://ddebs.ubuntu.com $(lsb_release -cs) main restricted universe multiverse " | sudo tee -a /etc/apt/sources.list.d/ddebs.list

# /etc/apt/sources.list.d/ddebs.list 应该有以下内容
deb http://ddebs.ubuntu.com [Ubuntu 发行版本] main restricted universe multiverse
deb http://ddebs.ubuntu.com [Ubuntu 发行版本]-updates main restricted universe multiverse
deb http://ddebs.ubuntu.com [Ubuntu 发行版本]-proposed main restricted universe multiverse

# 开始安装
apt-key adv --keyserver keyserver.ubuntu.com --recv-keys ECDCAD72428D7C01
apt-get update
apt-get install systemtap
apt-get install linux-image-$(uname -r)-dbgsym
apt-get source linux-image-$(uname -r)
```

离线安装方式

```sh
# 下载地址 http://ddebs.ubuntu.com/pool/main/l/linux
# 因系统为 5.4.0-42-generic 的内核，因此需要使用这个版本
# 下载64位专用版本 linux-image-unsigned-5.4.0-42-generic-dbgsym_5.4.0-42.46_amd64.ddeb 
# 服务器内安装 
dpkg -i linux-image-unsigned-5.4.0-42-generic-dbgsym_5.4.0-42.46_amd64.ddeb
```

## 开始分析

```sh
# 指令  crash [vmcore] [dumpfile]

crash /usr/lib/debug/boot/vmlinux.......   /var/crash/20xxxxx/dump.xxxxxx 

# 看到因为我们手动触发系统 Crash 的那一部分显示
PANIC：“Kernel panic - not syncing： sysrq triggered crash”
```



# 参考资料

CentOS下的配置 https://blog.51cto.com/kk876435928/2054256
Ubuntu 20.04 下配置 https://www.ebpf.top/post/ubuntu_kdump_crash/ 
Kdump技术了解 https://linux.cn/article-8737-1.html
dbgsym: https://cloud.tencent.com/developer/article/1637887 
ubuntu 中 的hwe ： https://askubuntu.com/questions/248914/what-is-hardware-enablement-hwe 
dbgsym 库 ： http://ddebs.ubuntu.com/pool/main/l/linux-hwe-5.4/ 
x86 “ https://blog.csdn.net/xiao_yi_xiao/article/details/120223255?utm_medium=distribute.pc_relevant.none-task-blog-2~default~baidujs_baidulandingword~default-0-120223255-blog-86352725.pc_relevant_default&spm=1001.2101.3001.4242.1&utm_relevant_index=3 
Ubuntu 中的内存大小 小于 实际内存大小： https://askubuntu.com/questions/923371/why-does-ubuntu-show-slightly-less-ram-than-my-computer-has-built-in 
kdump ： https://wiki.ubuntu.com/Kernel/CrashdumpRecipe 
其他：https://blog.csdn.net/quqi99/article/details/38069657
