---
title: 记一次IO引起的故障
tags:
  - 虚拟化
  - 故障
categories:
  - Windows Server
date: 2020-06-14 14:35:40
---

# 故障现象

- 用户反馈应用访问特别慢。
- Windows Server中查看的磁盘IO状态，看到数据库相关的进程Response Time(ms)达到200以上。
- 在虚拟化监控平台vRealize中查看虚拟磁盘总IO延迟：
  - 总IOPS达到 10000 + ；

# 原因分析

服务器的IO过高，底层没有来得及处理IO请求，新的IO请求已进入，因此导致高延迟。

# 解决方法

找到IO的瓶颈，逐个扩容:

1. 硬件层调整，UCS的刀片IO更改默认值。
2. 虚拟化层调整，改用PV SCSI
3. 操作系统层注册此SCSI控住器：

```bat
reg add HKLM\SYSTEM\CurrentControlSet\services\pvscsi\Parameters\Device / DriverParameter /t REG_SZ /d "RequestRingPages=32,MaxQueueDepth=254"
```

# 补充：

## pvscsi 的 IO是多少？

参考资料 ： 
- https://blogs.vmware.com/vsphere/2014/03/pvscsi-large-ios.html
- https://blog.csdn.net/weixin_34054866/article/details/85184550
- https://kb.vmware.com/s/article/1017652
- https://blogs.vmware.com/performance/2010/02/highperformance-pvsci-storage-adapter-can-reduce-cpio-by-1030.html
