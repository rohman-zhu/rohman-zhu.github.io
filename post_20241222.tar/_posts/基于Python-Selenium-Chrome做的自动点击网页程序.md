---
title: 基于Python+Selenium+Chrome做的自动点击网页程序
tags:
  - 脚本
categories:
  - 基础知识
  - 编程
  - Python
date: 2022-03-20 23:14:36
---
# 背景

工作场景中，存在大量需要在网页中点击的场景。因此想做一个自动点击网页的脚本程序，而点击依据来源于本地的Excel文件。基于这样的思路，选用Python+Selenium+Chrome来实现这个功能。

# 工具说明

1. Python3
2. Selenium
3. Chrome
4. Excel（xls文件）

# 代码部分【TODO】