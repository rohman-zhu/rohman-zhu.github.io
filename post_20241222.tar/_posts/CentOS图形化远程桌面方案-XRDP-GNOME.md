---
title: CentOS图形化远程桌面方案-XRDP-GNOME
tags:
  - default
categories:
  - Linux
  - CentOS
date: 2023-04-30 17:27:10
---

# 需求分析

CentOS 常规远程的方法是 CLI 方式，但是也有GUI界面的需求；

# 操作方式

```sh
# 安装GUI桌面
# groupinstall 是会安装关联目标软件的包；
# install 仅安装目标软件；
yum groupinstall "GNOME Desktop"
# 初始化Desktop
startx

# 安装xrdp
# 需要先配置epel包；
yum install epel* -y
yum install xrdp

```

客户端远程方式：

```sh
mstsc 到目标服务器
```
