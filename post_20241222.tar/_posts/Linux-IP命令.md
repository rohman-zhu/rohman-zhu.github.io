---
title: Linux-IP命令
tags:
  - network
catergories:
  - Linux
date: 2020-02-21 23:15:25
---

# 前言


# ip ad

新的命名方案被称为“可预测的网络接口Predictable Network Interface”。 它已经在基于systemd 的 Linux 系统上使用了一段时间了。 接口名称取决于硬件的物理位置。 en 仅仅就是 “ethernet” 的意思，就像 “eth” 用于对应 eth0，一样。 p 是以太网卡的总线编号，s 是插槽编号。 所以 enp0s25 告诉我们很多我们正在使用的硬件的信息。

## 信息解读

```
BROADCAST   该接口支持广播
MULTICAST   该接口支持多播
UP          网络接口已启用
LOWER_UP    网络电缆已插入，设备已连接至网络

mtu 1500                                    最大传输单位（数据包大小）为1,500字节
qdisc pfifo_fast                            用于数据包排队
state UP                                    网络接口已启用
group default                               接口组
qlen 1000                                   传输队列长度
link/ether 00:1e:4f:c8:43:fc                接口的 MAC（硬件）地址
brd ff:ff:ff:ff:ff:ff                       广播地址
inet 192.168.0.24/24                        IPv4 地址
brd 192.168.0.255                           广播地址
scope global                                全局有效
dynamic enp0s25                             地址是动态分配的
valid_lft 80866sec                          IPv4 地址的有效使用期限
preferred_lft 80866sec                      IPv4 地址的首选生存期
inet6 fe80::2c8e:1de0:a862:14fd/64          IPv6 地址
scope link                                  仅在此设备上有效
valid_lft forever                           IPv6 地址的有效使用期限
preferred_lft forever                       IPv6 地址的首选生存期
```

# 参考资料

https://linux.cn/article-9476-1.html
https://linux.cn/article-9704-1.html
