---
title: Linux操作系统的CIS设置
tags:
  - default
categories:
  - Linux
date: 2020-12-23 23:08:26
---
# 背景

需要设置与信息安全相关的选项，以满足公司的信息安全规范。


# 资料来源

https://downloads.cisecurity.org/#/