---
title: VMware相关业务所需端口查询地址
tags:
  - default
categories:
  - VMware
date: 2022-11-24 00:35:03
---
# 常用VMware相关的业务系统防火墙端口查询

在线地址 ： https://ports.esp.vmware.com/

可以下载端口地址表；

Horizon ：https://ports.esp.vmware.com/home/Horizon