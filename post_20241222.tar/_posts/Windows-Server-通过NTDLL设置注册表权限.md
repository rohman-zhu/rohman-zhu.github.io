---
title: 待补充-Windows Server 通过NTDLL设置注册表权限
tags:
  - 未完善
categories:
  - Windows Server
date: 2024-04-23 00:49:16
---

# 场景说明

一般在重置 RDS 120天许可会用到，需要删除GracePeriod 注册表才可以恢复120天试用期；但是直接使用Powershell的Remove-Item属性是无法完成这个操作的，必须提权。


