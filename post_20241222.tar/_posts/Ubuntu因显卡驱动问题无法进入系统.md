---
title: Ubuntu因显卡驱动问题无法进入系统
tags:
  - 故障
catergories:
  - Linux
date: 2020-02-25 15:42:11
---
# 故障现象

无法进入图形界面，重复输入密码。
进入命令行界面，查看xsession-error日志

```
name of display: :0
X Error of failed request:  BadValue (integer parameter out of range for operation)
Major opcode of failed request:  154 (GLX)
Minor opcode of failed request:  24 (X_GLXCreateNewContext)
Value in failed request:  0x0
Serial number of failed request:  30
Current serial number in output stream:  31

openConnection:connect:No such file or directory
cannot connect to britty at :0
```

# 原因分析

#