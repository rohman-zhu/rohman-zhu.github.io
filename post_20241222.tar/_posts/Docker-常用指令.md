---
title: Docker-常用指令
tags:
  - 常用指令
categories:
  - Docker
date: 2024-03-17 14:41:00
---


# 查看版本

```sh
docker version
```

# 获取镜像

```sh
docker pull [image name]

# 增加代理
docker pull dockerproxy.cn/[image name]:[version]
```

# 运行容器

```sh
docker run --name [docker name] -d -p [host port]:[dokcer port] [image name]


docker run  -td --name [docker name] -d -p [host port]:[dokcer port] [image name]
# -t表示为容器分配伪终端
# -d表示让容器在后台运行
# 如果只是用-t选项，不使用-d选项，为容器分配的伪终端会直接占用host的命令行，所以，-t选项配合-d选项，让容器在后台运行，可以避免容器一直占用host的命令行窗口，并持续运行容器。
# 如果只使用-d选项，不使用-t选项，会无法正常运行容器，原因是pid为1的主进程结束时，容器也会自动停止，具体情况是这样的，这些操作系统类的基础镜像默认运行的程序通常都是shell，比如bash，也就是说，bash是容器中的主进程，pid是1，如果不使用-t选项为bash分配伪终端，单独执行bash命令后，bash进程就直接结束了（没有绑定任何终端，相当于执行bash命令后一闪而过，没有任何输入输出，直接结束进程）
```

# 查看镜像

```sh
docker images
```

# 下载Docker或上传文件至Docker

```sh
# 下载
docker cp [Docker]:/..../target.file  ./

# 上传
docker ./target.file [Docker]:/..../target.file 
```

# 与容器交互

```sh
# 以bash进行交互
docker exec -it [docker name] /bin/bash

# 退出，结束当前终端
exit
# 退出，不结束当前终端
Ctrl + p + q
```

```sh
# docker exec命令指定在nginx-demo中运行ls -l /etc/nginx/命令，并将容器内的运行结果返回到当前的命令行中，从而查看到了容器内部/etc/nginx/目录中的信息。
docker exec nginx-demo ls -l /etc/nginx/
```

# 关闭容器

```sh
docker stop [docker name]
docker kill --signal=HUP [docker name]
```

# 查看docker对象的详细信息

```sh
docker inspect [docker name]
```

# 删除容器

```sh
# 需要先停止运行的容器才能删除目标容器
docker rm [docker name]
docker ps
docker ps -a
```

# 删除镜像

```sh
docker rmi [image name]
```

# 修改镜像的标签

```sh
docker tag [旧镜像名称]:[旧标签] [新镜像标签]:[新标签]

# 这个动作会保留原有的标签，同时克隆一个新的标签；
# 可以将旧的标签删除 docker rmi [旧镜像名称]:[旧标签]
```

# 构建自己的镜像

Dockerfile 是用于定义和构建 docker 镜像的文本文件。
包含一些指令与参数，用于描述镜像的构建过程，包含基础镜像、软件安装包、文件拷贝、环境变量设置；

编写规则：

1. 每一个执行指令，均为大写字母，且需要跟随参数；
2. 文件按照由上至下执行；


```sh
# 参考 https://chunchengwei.github.io/ruan-jian/ji-yu-docker-de-hexo-bo-ke-da-jian/

# 1. 先要有一个基础镜像
docker pull node:10

# 2. 编写docker的构建文件
# 命名为Dockerfile
# 文件内容： 

# *****************************************************************************
# File Name: Dockerfile
# Auther: Chuncheng Wei
# Email: weicc1989@gmail.com
# Created Time: Fri Nov 30 23:08:07 2018
# Description:
#
#     This bases on node:10 image
#
# *****************************************************************************


# 基础镜像
FROM node:10

# 维护者信息
MAINTAINER your_name <your_mail>

# 工作目录
WORKDIR /hexo

# 安装Hexo
RUN npm install hexo-cli -g
RUN hexo init .
RUN npm install

# 设置git
RUN git config --global user.name "your_name"
RUN git config --global user.email "your_mail"

# 映射端口
EXPOSE 4000

# 运行命令
CMD ["/bin/bash"]

# 3. 开始构建
docker build -t "新镜像名:版本号"  -f ./Dockerfile

```