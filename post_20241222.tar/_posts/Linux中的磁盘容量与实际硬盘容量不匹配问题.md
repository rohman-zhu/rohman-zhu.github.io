---
title: Linux中的磁盘容量与实际硬盘容量不匹配问题
tags:
  - default
categories:
  - Linux
date: 2022-10-30 16:32:19
---

# 问题描述

虚拟化层分配的硬盘容量是10GB ， OS内用 fdisk -l 指令查看到目标硬盘总容量为 10.7GB ，即多现实了 0.7 GB。

# 原因分析

虚拟化层使用的是GiB单位，实际为10GiB ,即 10* 1024 * 1024 * 1024 bytes;
而fdisk的GB显示的是以1000进制，即为10.73741824GB，但是显示字节的时候又为 1073741824 ；

# 参考资料

https://blog.csdn.net/zzm628/article/details/49225475
