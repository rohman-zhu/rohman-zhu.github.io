---
title: vSAN写入带宽实测记录
tags:
  - 监控
categories:
  - VMware
  - vSphere
date: 2022-12-27 17:03:16
---
# 测试环境

SAN存储传入vSAN存储。

虚拟机大小25GB
走万兆网络

登录ESXi，使用指令esxtop获取数据；按u\d\x切换视图，vSAN使用x视图。

vSAN的物理瓶颈
SATA总线，6Gbps，大概0.7GB/s
网络瓶颈，10Gbps，大概1.25GB/s

# 数据记录

## 1台虚拟机迁移

源ESXi
读取速率：50-100MB/s
耗时：5min
传输数据量：25GB
速率修正：85MB/s

## 2台虚拟机

源ESxi
读取速率：200MB/s

## 3台虚拟机

目的ESXi
写入速度可达到300MB/s 至 400MB/s

## 6台虚拟机

目的ESXi
写入速度480MB/s

## 7台虚拟机

目的ESXi
写入速度600MB/s 至 1000MB/s

## 8个虚拟机
目的ESXi
写入速度700MB/s 至 1000MB/s
