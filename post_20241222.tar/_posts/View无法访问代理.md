---
title: View无法访问代理
tags:
  - default
catergories:
  - 虚拟化
  - VMware Horizon View
date: 2020-02-05 11:35:57
---

# 故障原因

1. Agent端无法访问Connection Server的必要端口（TCP：389，4001，4002）
  1. Agent 端无法正确解析Connection Server的IP地址；
