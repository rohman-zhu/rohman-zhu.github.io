---
title: Horizon-VDI提示无法访问代理
tags:
  - 故障
  - VDI
categories:
  - VMware
  - Horizon View
date: 2022-08-29 00:10:40
---

# 故障现象

```log
重新安装或升级代理后，View 桌面在 View Administrator 控制台中报告以下消息：
无法访问代理 (Agent Unreachable)
在 Horizon Agent 日志中，您会看到类似以下内容的消息：

<YYYY-MM-DD>T<time> 789-07:00 DEBUG (0EB8-0F74) <theTopicMessageManager> [AgentJmsConfig] Published CHANGEKEY request

</time>约 10 秒后，您会看到以下条目：

<YYYY-MM-DD>T<time></time> 789-07:00 DEBUG (0EB8-0F74) <theTopicMessageManager> [AgentJmsConfig] Timeout waiting for success response
您会在同一日志文件中看到类似以下内容的条目：
update rejected, attempt to reconfigure as paired with missing key information
FATAL (0324-23C) <572> []The JVM has exited with code 6.
INFO (0308-052C) <JavaBridge> wsnm_jms died, restarting in a minute
 
在连接服务器日志中，您会看到类似以下内容的条目：

<DesktopControlJMS> [JMSMessageSecurity] Message could not be validated: Signature invalid for identity agent
<DesktopControlJMS> [DesktopTracker] CHANGEKEY message from agent/<Agent GUID> is discarded as it cannot be validated
```

# 原因

```log
如果在连接服务器配置中更改注册表项失败，进而导致 View Agent 和连接服务器之间的通信中断，则会出现此问题。

重新安装或升级 View Agent 时，它可能会更改用于识别 View Agent 与连接服务器连接的密匙对。
```

# 解决方案

登录Connect Server服务器，打开powershell，输入指令

```ps1
vdmadmin -A -d desktop-pool-name -m name-of-machine-in-pool -resetkey
```

# 参考资料

https://kb.vmware.com/s/article/2038679?lang=zh_cn