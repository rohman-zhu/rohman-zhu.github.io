---
title: Synology监控空间配额方案
date: 2019-12-24 23:42:13
tags:
- Synology
categories:
- 服务器与存储
- 存储
- NAS存储
---

# Synology NAS Command

## 查看共享文件夹配额

```sh
btrfs qgroup show -pcreFf [--sort=qgroupid,rfer,excl,max_rfer,max_excl] <path>

# show [options] <path>
# -p : print parent qgroup id.
# -c : print child qgroup id.
# -r : print limit of referenced size of qgroup.
# -e : print limit of exclusive size of qgroup.
# -F : list all qgroups which impact the given path(include ancestral qgroups)
# -f : list all qgroups which impact the given path(exclude ancestral qgroups)
# --raw : raw numbers in bytes, without the B suffix.
# --human-readable : print human friendly numbers, base 1024, this is the default
# --iec : select the 1024 base for the following options, according to the IEC standard.
# --si : select the 1000 base for the following options, according to the SI standard.
# --kbytes : show sizes in KiB, or kB with --si.
# --mbytes : show sizes in MiB, or MB with --si.
# --gbytes ：show sizes in GiB, or GB with --si.
# --tbytes ： show sizes in TiB, or TB with --si.
# --sort=[+/-]<attr>[,[+/-]<attr>]… ： list qgroups in order of <attr>. <attr> can be one or more of qgroupid,rfer,excl,max_rfer,max_excl.Prefix '+' means ascending order and '-' means descending order of <attr>. If no prefix is given, use ascending order by default.If multiple <attr>s is given, use comma to separate.
# --sync ： To retrieve information after updating the state of qgroups, force sync of the filesystem identified by <path> before getting information.

# For example:
# btfs qgroup show -pcreFf /volume1/Rohman-TEST
```

## 查询共享文件夹用户的配额限制

```sh
btrfs usrquota show <options> <path>

# 默认单位是 byte ， 无法更改。

# <Options>
# -a : print quota for all subvolume
# -n : do not print header
# -u <user id> : print quota for user
# -U <user name> : print quota for user

# For example:
# id rohman
# uid=1000
# btrfs usrquota show -u 1000 /volume1/Rohman-TEST
```

## 查询iSCSI LUN 大小

方法：
1. 获取LUN UUID
2. synoiscsiwebapi lun list all | grep <LUN UUID>

```sh
# 1. 查询 LUN UUID 
# 在 /[ volume ID] /\@iSCSI/LUN/iscsi_lun.conf 目录中
# 根据 name 确定 LUN UUID

# 2. 查询
synoiscsiwebapi lun list all | grep <LUN UUID>
# size 显示的是 LUN 配置的大小；
# allocated_size 显示的是 LUN 已使用的大小；
# 默认单位是 Byte 
```

### synoiscsiwebapi 【待补充】

```sh
# 格式： synoiscsiwebapi [node uuid] <api> <method> [args ...]
```

## 基于SNMP的ZABBIX

获取的MIB没有包含共享文件夹的配额。

## 参考资料

1. btrfs : https://wiki.archlinux.org/index.php/Btrfs_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)#%E5%88%97%E5%87%BA%E5%AD%90%E5%8D%B7%E5%88%97%E8%A1%A8
2. btrfs-qgroup : https://btrfs.wiki.kernel.org/index.php/Manpage/btrfs-qgroup
3. btrfs-quota : https://btrfs.wiki.kernel.org/index.php/Manpage/btrfs-quota
4. btrfs-quota support : https://btrfs.wiki.kernel.org/index.php/Quota_support
5. Synology DiskStation MIB Guide ： https://global.download.synology.com/download/Document/Software/DeveloperGuide/Firmware/DSM/All/enu/Synology_DiskStation_MIB_Guide.pdf
