---
title: 库存属性SKU与SPU
date: 2019-12-15 16:18:19
tags:
- 产品
- 库存
categories:
 - 服务器与存储
---

# SPU & SKU

SPU是标准化产品单元，区分品种；
SKU是库存量单位，区分单品；

## Standard Product Unit（标准化产品单元）

SPU是商品信息聚合的最小单位，是一组可复用、易检索的标准化信息的集合，该集合描述了一个产品的特性。

通俗点讲，属性值、特性相同的商品就可以称为一个SPU。例如，iphone4就是一个SPU，N97也是一个SPU，这个与商家无关，与颜色、款式、套餐也无关。

## Stock Keeping Unit（库存量单位）

SKU即库存进出计量的单位， 可以是以件、盒、托盘等为单位。在服装、鞋类商品中使用最多最普遍。 例如纺织品中一个SKU通常表示：规格、颜色、款式。


## 参考资料

https://www.zhihu.com/question/19841574