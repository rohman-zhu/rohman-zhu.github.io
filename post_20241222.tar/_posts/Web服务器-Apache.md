---
title: Web_Apache
date: 2017-10-27 14:48:28
tags: Linux
---
# Apache 

## 0.下载地址 

httpd-2.4.28.tar.gz:

`http://mirror.bit.edu.cn/apache/httpd/httpd-2.4.28.tar.gz`

apr-util-1.6.1:

`http://mirror.bit.edu.cn/apache/apr/apr-util-1.6.1.tar.gz`

apr-1.6.3:

`http://mirror.bit.edu.cn/apache/apr/apr-1.6.3.tar.gz`

开始安装前,把必要的编译库安装上:

```shell
yum groupinstall Development tools Compatibility libraries Chinese Support [zh] -y
```

需要的依赖文件:

```shell
yum install pcre-devel openssl openssl-devel -y
```

编译安装

```shell
./configure \
--prefix=/usr/local/httpd-2.x.x \
--sysconfdir=/etc/httpd \
--with-apr=/usr/local/apr \
--with-apr-util=/usr/local/apr-util \
#允许压缩,提升效率
--enable-deflate \
#浏览器打开页面后有缓存
--enable-expires \
--enbale-headers \
#激活大部分模块
--enable-modules=most \
--enable-so \
#worker模式
--with-mpm=worker \
--enable-rewrite
```

编辑/conf下的httpd.conf

* 网页首页与目录权限设定（DocumentRoot 与 Directory）

```xml
#添加虚拟主机
Include conf/extra/httpd-vhosts.conf

<Directory "路径">
    Options -Indexes +FollowSymLinks
    Order allow,deny
    Allow from all
</Directory>

#添加两行
AddType application/x-httpd-php .php .phtmls
AddType application/x-httpd-php-source .php5
```
## httpd.conf 配置文件

一般在 /etc/httpd/httpd.conf

### Diretory 节点

Options 可选参数:

* Indexes：如果在此目录下找不到 index.html 时， 就顯示整個目錄下的檔案名稱，至於『首頁檔案檔名』則與 DirectoryIndex 設定值有關。
* FollowSymLinks：這是 Follow Symbolic Links 的縮寫， 字面意義是讓連結檔可以生效的意思。我們知道首頁目錄在 /var/www/html，既然是 WWW 的根目錄，理論上就像被 chroot 一般！ 一般來說被 chroot 的程式將無法離開其目錄，也就是說預設的情況下，你在 /var/www/html 底下的連結檔只要連結到非此目錄的其他地方，則該連結檔預設是失效的。 但使用此設定即可讓連結檔有效的離開本目錄。
* ExecCGI：讓此目錄具有執行 CGI 程式的權限，非常重要！舉例來說，之前熱門的OpenWebMail 使用了很多的 perl 的程式，你要讓 OpenWebMail 可以執行，就得要在該程式所在目錄擁有 ExecCGI 的權限才行喔！但請注意，不要讓所有目錄均可使用 ExecCGI ！
* Includes：讓一些 Server-Side Include 程式可以運作。建議可以加上去！
* MultiViews：這玩意兒有點像是多國語言的支援，與語系資料 (LanguagePriority) 有關。最常見在錯誤訊息的回報內容，在同一部主機中，可以依據用戶端的語系而給予不同的語言顯示呢！ 預設在錯誤回報訊息當中存在，你可以檢查一下/var/www/error/ 目錄下的資料喔！

AllowOverride:

表示是否允許額外設定檔 .htaccess 的某些參數覆寫？我們可以在 httpd.conf 內設定好所有的權限，不過如此一來若使用者自己的個人網頁想要修改權限時將會對管理員造成困擾。因此 Apache 預設可以讓使用者以目錄底下的 .htaccess 檔案內覆寫 <Directory> 內的某些功能參數。

* ALL：全部的權限均可被覆寫；
* AuthConfig：僅有網頁認證 (帳號密碼) 可覆寫；
* Indexes：僅允許 Indexes 方面的覆寫；
* Limits：允許使用者利用 Allow, Deny 與 Order 管理可瀏覽的權限；
* None：不可覆寫，亦即讓 .htaccess 檔案失效！ 

Order:

決定此目錄是否可被 apache 的 PID 所瀏覽的權限設定啦！能否被瀏覽主要有兩種判定的方式：

* deny,allow：以 deny 優先處理，但沒有寫入規則的則預設為 allow 喔。
* allow,deny：以 allow 為優先處理，但沒有寫入規則的則預設為 deny 喔。 所以在預設的環境中，因為是 allow,deny 所以預設為 deny (不可瀏覽)，不過在下一行有個
* Allow from all，allow 優先處理，因此全部 (all) 用戶端皆可瀏覽啦！


## 1.重要目录以及文件 ##

### htdocs 目录下面 ###

这是编译安装默认的站点目录.

### logs 目录下面 ###

* access_log - 这是apache的默认访问日志,使用tail-faccess.og可以实时观看网站用户的访问情况.
* error_log - 这是apache的错误日志文件,如果apache出现启动故障等问题,一定要看这个错误日志.
* httpd.pid - http的pid文件,http进程启动后,会把所有进程的ID号写到此文件.

### modules 目录 ###

apache的模块目录,比如 php等.

### bin 目录下面 

* ab - Apache HTTP服务器性能测试工具,简单/易用.同类软件还有jmeter,loadrunner,webbench等.
* apachectl - 这是apache的启动命令,apachectl是一个脚本.
* apxs - Apache HTTP服务器编译和安装拓展模块的工具,在进行DSO方式编译模块时会用到,--with-apxs2=/application/apache/bin/apxs
* htcaheclean - 这是清理磁盘缓冲区的命令,需要在编译时指定相关参数才可以使用.
* htpasswd - 建立和更新基本认证文件,如:配置nagios等监控服务时会用到.
* httpd - Apache的控制命令程序,apachectl执行时会调用httpd
* rotatelogs - apache自带的日志轮询命令.

### conf 目录下面 

* extra - 这是额外的apache配置文件的陆慕,这个目录里面的文件会经常访问,如:httpd-vhosts.conf默认就在这个目录.
* httpd.conf - apache的主配置文件,这个文件也会经常访问修改,其中每一行的参数作用都应该弄清除明白

#### 进入主配置文件http.conf 

```xml
ServerRoot //根目录
Listen //端口
User
Group
ServerAdmin you@example.com
DocumentRoot //站点根目录
<Directory /> //禁止任何人访问根目录
    Options FollowSymLinks
    AllowOverride None
    Order dely,allow
    Deny from all
</Directory>

//创建了新的站点目录
<Directory "/application/apache/htdocs">
    Options Indexes FollowSymLinks //Indexes这个参数非常危险,会展现目录结构;优化是删除或者添加-Indexes;
    AllowOverride None
    Order allow,deny
    Allow from all
</Directory>
```

检查语法 : /bin/apachectl -graceful
