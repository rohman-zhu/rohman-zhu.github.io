---
title: Ubuntu20.04开机网卡超时等待
tags:
  - 网卡
categories:
  - Linux
  - Ubuntu
date: 2020-12-08 23:21:37
---
# 故障描述

开机卡在“A start job is running for wait for network to be Configured”两分多钟。

# 原因分析

# 解决方法

```sh
cd /etc/systemd/system/network-online.target.wants/

ls ./

# 修改本目录下的文件
#在[Service]下添加TimeoutStartSec=2sec
vi ./xxxxx

[Service]
TimeoutStartSec=2sec

```