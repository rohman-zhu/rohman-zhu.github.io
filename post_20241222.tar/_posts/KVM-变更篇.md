---
title: KVM-变更篇
date: 2018-10-27 22:02:02
tags: Linux
---

# 实验环境信息 

* OS:CentOS-6.9-Server-Minimal
* CPU:2u
* Memory:4GB
* 运行在 Vmware Fusion 专业版 8.0.0
* 开启虚拟化管理程序

# To-Do list

* 为VM的磁盘扩容
    * Windows 扩容
        * 修改XML，添加IDE硬盘。[完成时间：20181103]
        * 修改XML文件，添加virtio硬盘。
        * 使用attach-disk，添加硬盘。[完成时间：20181104]
    * Linux 扩容
        * Ubuntu
        * Centos [完成时间:20181104]
* 为VM的内存扩容[完成时间：20181104]
* 调整VM的CPU资源[完成时间：20181104]
* 任意挂载ISO镜像，重装系统。 [完成时间：20181104]
* 更改网卡连接模式

# 变更操作

## 修改 XML 文件

一般需要修改XML的，无非是重新加载 ISO 镜像 或者 内存变更 、 硬盘变更 等资源的变更。

操作基本都是在VM关机的情况下进行，而基本流程分为以下三步：

1. 修改xml文件，即 virsh edit (VM-Name)
2. 再启动VM

> 网络变更，可以在不关机的情况下更改吗？ 类似于Vsphere更改交换机与连接模式那样？

接下来都是XML内容的变更与讲解

### 修改启动项

```xml
 <os>
    <type arch='x86_64' machine='pc-i440fx-2.8'>hvm</type>
    //type参数指定了虚拟机操作系统的类型，内容：hvm表明该OS被设计为直接运行在裸金属上面，需要全虚拟化，
    //而linux(一个不好的名字)指OS支 持XEN3hypervisor的客户端ABI，
    //type同样有两个可选参数：arch指定虚拟机的CPU构架，machine指定机器的类型。
    <boot dev='hd'/>
    //dev属性的值可以是：fd、hd、cdrom、network，它经常被用来指定下一次启动。boot的元素可以被设置多个用来建立一个启动优先规则。
    <bootmenu enable='yes' timeout='0'/>
    //这里的timeout设置无效。
    <bios useserial='yes'/>

  </os>
```

### 以修改XML文件的方式添加硬盘

使用 virsh attach-disk 去添加硬盘，见后面的命令说明。

由于IDE不支持热插拔，但其他的方式因为 IO 不支持，所以需要我暂时用 IDE 的连接方式创建硬盘，完整过程如下：

```shell
# 创建一个新的磁盘，格式为qcow2 ， 大小为2GB
qemu-img create -f qcow2 /opt/windows.disk2.qcow2 2G

# 添加进WindowsServer的XML文件,虚拟机名为windows ， 命令格式为 virsh edit [domain]
virsh edit windows

# 在Driver标签内，添加以下内容。
<disk type='file' device='disk'>
      <driver name='qemu' type='qcow2' cache='none'/>
      <source file='/opt/windows.qcow2.disk2'/>
      <target dev='hdb' bus='ide'/>
      <address type='drive' controller='0' bus='0' target='0' unit='1'/>
</disk>

# 添加进windows虚拟机的硬盘并不会马上显示，需要重新格式化
# 以下为在windows的CMD界面中操作命令
# 进入windows专用的分区工具
diskpart
# ----- DISKPART SHELL -----
# 查看当前系统有多少块磁盘
list disk

# 可以看到多了一块磁盘 ， disk 1
# 进入 磁盘 1 ，需要对磁盘1 进行分区操作
select disk 2

# 清除磁盘 [To-Do] 这个步骤是否必要？
clean

# 创建分区 ， 创建主分区
create partition primary

# [To-Do]active 的意义是?
active

# 格式化分区
format fs=ntfs label="Disk2" quick

# 挂载至系统
assign

```

### Widows系统 以attach-disk的方式添加硬盘

采用 virsh attach-disk 添加的硬盘，需要安装virtio驱动。

```shell
# virsh attach-disk [domain] [source] [target]
virsh attach-disk windows /opt/source.img vda

# 需要在Windows中安装驱动

```

### Linux系统 以attach-disk的方式添加硬盘

添加的时候要指定好参数，否则会因为格式不对而导致硬盘无法读写。

```shell
virsh attach-disk --domain linux --source /opt/test.img --target vdd --driver qemu --subdriver qcow2 --sourcetype file --cache none --config --persistent

# --subdriver qcow2 指定磁盘类型
# --config 写入xml文件，永久生效
# --persistent 在线添加，立刻生效
```
#### Error 

* Windows Server 2012 R2 加载virtio的硬盘会提示 ， “由于管理员设置的策略，该磁盘处于脱机状态“
    * 
* 如果bus不同，可能会导致虚拟机无法启动，IDE的bus区分是怎么的？ Unit是如何？
    * [To-Do]
* 采用attach-disk添加，默认的扫描设置是扫描所有的磁盘，由于多路径的问题，多块磁盘前面的元数据信息是一致的，导致PV信息相同，会报“Found duplicate PC....:using /dev/.... not /dev/....
    * [To-Do]暂时无解决方法，如可立即生效则会导致PV出现这个问题，并且无法添加进lvm，建议还是关机修改xml文件或者使用attach-disk后，不要立即生效，重启虚拟机即可。
* Requested operation is not valid: cannot do live update a device on inactive domain
    * 虚拟机启动了才可以添加。

* unsupported configuration: disk bus 'ide' cannot be hotplugged.
    * 只能通过关机修改xml文件去添加 ide 硬盘。
* Windows的Vm，以virtio方式连接的硬盘，无法格式化与修改。在DISKPART中显示为脱机状态。
    * 需要将硬盘初始化，并且设置为联机状体。
    * 可以通过diskpart
```shell
DISKPART> san
DISKPART> san policy=onlineall
DISKPART>list disk
#选中脱机状态的磁盘
DISKPART> select disk 1
DISKPART>attributes disk clear readonly
online disk 1

```
    * 可以在【计算机管理】中，跳到磁盘管理，对问题磁盘右键，选择初始化。


#### 命令说明

* virsh edit

```man
edit domain
           Edit the XML configuration file for a domain, which will affect the
           next boot of the guest.

           This is equivalent to:

            virsh dumpxml --inactive --security-info domain > domain.xml
            vi domain.xml (or make changes with your other text editor)
            virsh define domain.xml

           except that it does some error checking.

           The editor used can be supplied by the $VISUAL or $EDITOR
           environment variables, and defaults to "vi".

```

* virsh attach-disk

```man
attach-disk domain source target [[[--live] [--config] | [--current]] |
       [--persistent]] [--driver driver] [--subdriver subdriver] [--cache
       cache] [--type type] [--mode mode] [--sourcetype sourcetype] [--serial
       serial] [--shareable] [--rawio] [--address address] [--multifunction]

           Attach a new disk device to the domain.  
           source is path for the files and devices. 
           target controls the bus or device under which the disk is exposed to the guest OS. It indicates the "logical" device name.  
           driver can be file, tap or phy for the Xen hypervisor depending on the kind of access; or qemu for the QEMU emulator.

           Further details to the driver can be passed using subdriver. For
           Xen subdriver can be aio, while for QEMU subdriver should match the
           format of the disk source, such as raw or qcow2.  Hypervisor
           default will be used if subdriver is not specified.  However, the
           default may not be correct, esp. for QEMU as for security reasons
           it is configured not to detect disk formats.  type can indicate
           lun, cdrom or floppy as alternative to the disk default, although
           this use only replaces the media within the existing virtual cdrom
           or floppy device; consider using update-device for this usage
           instead.  mode can specify the two specific mode readonly or
           shareable.  sourcetype can indicate the type of source (block|file)
           cache can be one of "default", "none", "writethrough", "writeback",
           "directsync" or "unsafe".  serial is the serial of disk device.
           shareable indicates the disk device is shareable between domains.
           rawio indicates the disk needs rawio capability.  address is the
           address of disk device in the form of pci:domain.bus.slot.function,
           scsi:controller.bus.unit or ide:controller.bus.unit.  multifunction
           indicates specified pci address is a multifunction pci device
           address.
```

* DISKPART

```man
-san 显示或者设置当前的操作系统的SAN策略
-san policy=onlineall
-attributes 操纵卷或磁盘的属性
```
### 修改内存

直接修改XML文件中的memory标签值即可。这个允许操作宿主机的物理资源。（例如，宿主机只有2GB的内存，但VM分配了3GB的内存）

### 修改CPU资源

直接修改XML文件中的vcpu标签即可。

# 参考资料：
* kvm的xml文件详解：https://www.cnblogs.com/mrwuzs/p/8037058.html
* 官方xml文档：https://libvirt.org/formatdomain.html
* 官网安装virtio，亲测centos6，无法使用dnf安装 ： https://docs.fedoraproject.org/en-US/quick-docs/creating-windows-virtual-machines-using-virtio-drivers/index.html
* 安装virtio ： http://blog.51cto.com/tryingstuff/1954531
* windows-kvm常见问题 ：http://blog.51cto.com/zh888/1175476
* 硬盘添加实例：https://blog.csdn.net/chengxuyuanyonghu/article/details/42144079
* Windows的diskpart使用实例-创建：https://jingyan.baidu.com/article/363872ec22e1336e4ba16f85.html
* diskpart实例，较为详细：https://blog.csdn.net/kkfloat/article/details/5959205