---
title: Ubuntu内核降级实例
tags:
  - 内核
categories:
  - Linux
date: 2020-12-21 23:28:22
---
# Linux降级内核

## 检测当前内核版本

```sh
uname –r
```

## 安装目标内核包 

```sh
# 更新apt
apt-get update
# 检测已安装的内核包
dpkg –-list | grep 4.15.0-119

# 目标版本是4.15.0-29-generic
# 主要安装 linux-image-xxxxxx
# 主要安装 linux-headers-xxxxxx
# linux-image-版本号：内核映像文件
# linux-headers-版本号：内核头文件
# linux-image-extra-版本号：内核扩展文件记住，不能删除当前使用的内核版本。

apt install linux-image-4.15.0-29-generic  linux-headers-4.15.0-29 linux-headers-4.15.0-29-generic -y
```



## 删除旧版内核

```sh
#旧版本内核为4.4.0-137 、 4.15.0-119
apt remove *image-4.4.0-137*
apt remove *headers-4.4.0-137*

apt remove *4.15.0-119*
```

## 更新grub

```sh
update-grub
```

> 内核删除后一定要检查grub.cfg文件；
> 被删除的内核不能为当前正在加载的内核；
> 删除内核前，不能锁定内核；

## 防止用户自行升级内核

```sh
apt-mark hold linux-image-generic
apt-mark hold linux-headers-generic
```

如果要升级内核，再执行

```sh
apt-mark unhold linux-image-generic
apt-mark unhold linux-headers-generic
```