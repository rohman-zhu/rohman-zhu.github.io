---
title: Linux安装软件
date: 2018-06-04 07:49:42
tags: Linux
---


# 安装软件



## 安装软件地方式



|         | 优点                       | 缺点                     |
| ------- | ------------------------ | ---------------------- |
| 编译安装    | 可以定制安装目录，按需开启功能等。        | 查找并实验出合适的编译参数。         |
| yum安装软件 | 全自动化安装，不需要为依赖问题发愁。       | 自主性太差，软件功能、路径都固定，不易变更。 |
| 编译源码安装  | 根据自己的需求制定rpm包 -> 搭建yum仓库 |                        |



## FPM安装

FPM是ruby写的，因此系统环境需要ruby ，版本号要大于1.8.5 。



```sh
# 安装 Ruby 模块
$ yum -y install ruby rubygems ruby-devel
# 添加淘宝的Ruby仓库 
$ gem sources -a http://ruby.taobao.org/
# 移除原生的Ruby仓库
$ gem sources -remove http://rubygems.org/
# 安装fpm
$ gem install fpm
```

## FPM参数说明

| 常用参数             | 说明                                 |
| ---------------- | ---------------------------------- |
| -s               | 指定源类型                              |
| -t               | 指定目标类型，即想要制成什么包                    |
| -n               | 指定包的名字                             |
| -v               | 指定包的版本                             |
| -C               | 指定打包的相对路径                          |
| -d               | 指定依赖于哪些包                           |
| -f               | 第二次打包时目录下如果有相同安装包存在，覆盖它            |
| -p               | 输出的安装包的目录，不想放在当前目录下就需要指定           |
| --post-install   | 软件包安装完成之后所要运行的脚本；同--after-install  |
| --pre-install    | 软件包安装完成之前索要运行的脚本；同--before-install |
| --post-uninstall | 软件包卸载完成之后要运行的脚本；同--after-remove    |
| --pre-uninstall  | 软件包卸载完成之前要运行的脚本；同--before-remove   |



## 实例演示

```sh
# 安装 Nignx
# Nignx需要 openssl-devel pcre-devel 的依赖
# 查看本机是否有这两个包的依赖
$ rpm -aq openssl-devel pcre-devel

# TODO 缺少中间环节

# 上传rpm包
$ rpm -ivh nginx-1.6.2-1.x86_64.rpm


```



> 删除软连接：rm -f /软链接名称 ； 
> 
> 注意 ： rm -f /软链接名称/ 是删除整个目录。



## YUM仓库搭建


