---
title: 安装完vnc后Ubuntu无法登录
tags:
  - 故障
catergories:
  - Linux
date: 2020-02-25 13:04:48
---
# 故障现象

在Ubuntu图形界面，反复输入账户密码，无法进入系统。

# 原因分析

进入用户目录，查看 .xsession-errors 文件，发现有 permission denail 字样

根本原因： ~/.ICEauthority 和 ~/.Xauthority 的owner被改成root
间接原因： sudo vncserver（在root账户下执行vncserver）

# 解决方法

通过命令终端进入（ctrl + alt + F2） 将用户文件夹下的 ~/.ICEauthority 和 ~/.Xauthority 用户权限改为普通用户后，重启即可。