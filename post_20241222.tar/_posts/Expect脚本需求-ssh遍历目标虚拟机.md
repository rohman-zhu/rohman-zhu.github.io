---
title: Expect脚本需求-ssh遍历目标虚拟机
tags:
  - expect
categories:
  - Linux
  - 脚本
date: 2021-02-22 00:45:07
---

# 需求背景

有大部分客户端Linux都存有Server端的公钥，Server端需要通过ssh免密对客户端下发命令，但由于是第一次登录，每一次ssh到目标客户端都需要输入yes。

# 脚本

```expect
#!/bin/expect
# 遍历目标服务器范围
for { set i 0} { i<3 } { incr 1 } {
  ssh username@192.168.1.$i
  expect "yes/no"
  send "yes/r"
  expect "$*"
  send "exit/r"
}
exit
```
