---
title: HDS存储服务器
tags:
  - SAN存储
  - HDS
catergories:
  - SAN存储服务器
date: 2020-01-16 00:28:29
---
# HDS

## 缩略语

| 简称 | 全称 | 说明 |
|:---:|:----:|:----:|
|SVP|Service processor| 系统控制台，用于设备的管理|
|DKC|Disk Controller|盘机的控制器部分|
|DKU|Disk Unit|盘机的磁盘柜部分|
|DKA|Disk Adapter| 后端卡，用于连接内部磁盘|
|CHA|Channel Adapter|前端卡，用于连接外部主机|

## SVP

今天看到的SVP，是一个1U的机架服务器构成，内部安装的是windows的操作系统。平时通过SVP来管理磁盘。


## 参考资料

https://wenku.baidu.com/view/7071dc4376c66137ee0619cb.html
