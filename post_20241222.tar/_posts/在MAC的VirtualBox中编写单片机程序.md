---
title: 在MAC的VirtualBox中编写单片机程序
date: 2017-06-30 16:53:37
tags: MCU
categories: MCU
---

# 前言 #
在Mac OS sierra中想要编写单片机程序，并且实现烧录程序到单片机，这是可以实现的。如果不想倒腾，那么只需安装虚拟机，装个windows7，并且用相关的软件，如Keil、STC_ISP等来编写就好了。

# 正文 #
### 一、需要准备的软件 ###
* Virtual Box
* Virtual Box Guest Additions
* Windows7的镜像
* Keil 
* STC_ISP
* USB转串口驱动

<a href="在百度网盘">我已经打包到百度网盘了，点击下载</a>

### 二、安装 ###
* 正常安装Virtual Box
* 安装windows7
* 在windows7中安装VirtualBox GuestAdditions
* 安装跟编写单片机程序相关的软件（如Keil、STC_ISP等）

### 三、在虚拟机中连接单片机 ###
* 连接好相关线路
* 到虚拟机右下角一个USB模样的图标中，点击与单片机相关的硬件，表示装载到虚拟机中
* 这时候windows系统内，会提示没有安装驱动。我这边直接打开驱动程序，会提示不能安装。因此通过设备管理器，找到该设备，指定驱动文件夹位置手动安装，就可以了。

### 四、下载程序 ###
* 打开STC_ISP，选择好HEX文件，点击下载。
* 如果卡在单片机握手什么的，直接重启一下单片机。

（其实就是跟普通的下载流程一样的，这里没什么可以说的）
