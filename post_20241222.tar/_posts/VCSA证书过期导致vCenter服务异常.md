---
title: VCSA证书过期导致vCenter服务异常-【待补充】
tags:
  - 故障
  - VCSA
  - 证书
categories:
  - VMware
date: 2021-09-25 23:16:27
---

# 背景

自行搭建的VCSA在某天突然使用administrator@vsphere.local登录了，随后检查出以下问题：

1. 无法再使用administrator@sphere.loacl登录VCSA或者VCSA IP:5480 控制台；
2. administrator@vsphere.local 疑似被锁定或者过期无法登陆，输入正确的密码后，还是提示请输入密码；
3. root账户密码忘记，无法从控制台登录VCSA，进入SHELL执行操作指令；
4. 关键服务无法启动，vpxd服务无法启用；
5. administrator@vsphere.local登录提示SSL报错；
6. VCSA提示504错误；

# 原因分析

以上有诸多问题，最主要的原因是因为VCSA内部的证书过期，导致相关依赖的服务无法启动。

# 解决方案

重要提示：以下的复原操作，请先拍摄快照！

## 忘记root密码

```sh
# 进入虚拟机Console界面
# 重启VCSA，在虚拟机界面，按 e
# 在linux这行最后增加 init=/bin/bash
# 进入单用户界面
# password root
# reboot -f
```

## 忘记administrator@vsphere.local密码

```sh
# 进入 VCSA Shell

# 重置密码需要开启的服务
service-control --start vmafdd
service-control --start vmdird
service-control --start vmcad

# 指令
/usr/lib/vmware-vmdir/bin/vdcadmintool

# 选择3


```

## 重置STS证书

STS=Security Token Service

操作过程：

```sh
# 创建目录（非必要）
mkdir /root/newsts
cd /root/newsts

# 复制自签证书至目标目录
cp /usr/lib/vmware-vmca/share/config/certool.cfg /root/newsts

# 编辑复制过来的副本证书文件，输入VCSA的IP与主机名
#------certool.cfg---------#
#
# Template file for a CSR request
#

# Country is needed and has to be 2 characters
Country = US
Name = STS
Organization = ExampleInc
OrgUnit = ExampleInc Dev
State = Indiana
Locality = Indianapolis
IPAddress = VCSA的IP
Email = chen@exampleinc.com
Hostname = VCSA的主机名
#------certool.cfg---------#

# 生成秘钥
/usr/lib/vmware-vmca/bin/certool --server localhost --genkey --privkey=/root/newsts/sts.key --pubkey=/root/newsts/sts.pub

# 生成证书
/usr/lib/vmware-vmca/bin/certool --gencert --cert=/root/newsts/newsts.cer --privkey=/root/newsts/sts.key --config=/root/newsts/certool.cfg

# 将证书转成PK12格式
openssl pkcs12 -export -in /root/newsts/newsts.cer -inkey /root/newsts/sts.key -certfile /var/lib/vmware/vmca/root.cer -name "newstssigning" -passout pass:changeme -out newsts.p12

# 将证书导入 JAVA 秘钥库（JKS）
/usr/java/jre-vmware/bin/keytool -v -importkeystore -srckeystore newsts.p12 -srcstoretype pkcs12 -srcstorepass changeme -srcalias newstssigning -destkeystore root-trust.jks -deststoretype JKS -deststorepass testpassword -destkeypass testpassword

/usr/java/jre-vmware/bin/keytool -v -importcert -keystore root-trust.jks -deststoretype JKS -storepass testpassword -keypass testpassword -file /var/lib/vmware/vmca/root.cer -alias root-ca

# 出现交互式提示的时候，输入YES
```

## 重置所有证书（机器证书+解决方案证书）

注意，如果STS证书没有先替换，则无法执行替换所有证书，解决方案的证书均会回滚。

# 参考资料

VCSA中刷新STS证书： https://docs.vmware.com/cn/VMware-vSphere/6.7/com.vmware.psc.doc/GUID-497233EA-AEF9-464B-A9C3-CCAEEA90C801.html