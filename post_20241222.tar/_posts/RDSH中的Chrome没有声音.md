---
title: RDSH中的Chrome没有声音
tags:
  - 故障
categories:
  - VMware
  - Horizon View
date: 2022-10-16 23:54:02
---

# 故障描述

RDSH中的Chrome打开任何音频类的页面，均无声音；
而使用RDSH中的其他浏览器打开同样的页面却有声音；

# 原因分析

谷歌浏览器新特性"Sandbox"，此功能特性不兼容 Horizon View RDSH 会话；

# 解决方法

禁用Chrome浏览器中的沙盒音频；

使用powershell下发指令，新建注册表值：

```ps1
New-Item -Path HKLM:\Software\Policies\Google
New-Item -Path HKLM:\Software\Policies\Google\Chrome
New-ItemProperty -Path HKLM:\Software\Policies\Google\Chrome -Name AudioSandboxEnabled -Value 0;
```

# 参考资料

https://kb.vmware.com/s/article/78264



