---
title: 常用Linux中常用指令
tags:
  - 常用指令
categories:
  - Linux
date: 2022-10-30 15:02:45
---
# Bash 相关知识

```sh
# Bash 变量区分大小写。
STATE="xxxx"

# 赋值有空格，需要使用双引号
STATE="xx xxx"

# 引用已声明的变量用$
STATE="PreValue"
NewSTATE="New VALUE and $STATE"

# 接收交互输入
read response
echo $response
```

参考: https://mp.weixin.qq.com/s/VjWTXFHL2gG400bXL4QH2g

# Nginx相关操作

```sh
# 检查Nginx版本
nginx -version
# 启动Nginx
nginx
# 检测Nginx配置文件
nginx -t
# 重新加载Nginx配置文件
nginx -s reload
```

# CPU 相关的查询

```sh
# CPU基础信息
lscpu

# 可以看到CPU当前主频
cpupower frequency-info

# 查看CPU信息
cat /proc/cpuinfo

# 查看CPU负载信息
top
```

# LVM相关

## pv扩容

```sh
# 底层目标磁盘已扩容

# 系统层识别目标磁盘大小
echo 1 > /sys/block/[目标磁盘]/device/rescan

# pv识别
pvresize /dev/[目标磁盘]
```

## 激活lv卷

```sh
# vgchange 的 -a 是激活 -y是yes
vgchange -ay /dev/[目标卷]
```

# 查看指令运行时间

```sh
time [目标指令]
```

# 查看目标文件系统

```sh
stat -f [目标文件]
```

# 设置IP

```sh
ip addr add [IP/掩码长度] dev [网卡]
ip route add default via [网关]
```

# 检查端口监听情况--tcpdump指令

```sh
# 监听网卡
tcpdump -i [网卡名]

# 监听指定主机
tcpdump -i [网卡名] host [主机IP]

# 监听 TCP端口
tcpdump tcp port [端口]

# 监听 UDP端口
tcpdump udp port [端口]

# 监听2个条件
# 同时筛选 主机 与 端口
tcpdump -i [网卡] host [主机IP] and tcp port [端口]
```

# initramfs 下修改root目录

```sh
mkdir /mnt 
# 挂载root目录
mount /dev/[root设备]  /mnt
chroot /mnt
```

# 配置路由-route指令

```sh
# 增
route add

## 增加网段路由
## 增加 192.168.1.0/24网段，使用默认网关 192.168.0.1
route add -net 192.168.1.0 netmask 255.255.255.0 gw 192.168.0.1
## 指定 IP，使用默认网关 192.168.0.1 ， 等同于主机路由
route add -net 192.168.1.2 netmask 255.255.255.255 gw 192.168.0.1
## 增加主机路由 , 使用默认网关 192.168.0.1
route add -host 192.168.1.2 gw 192.168.0.1
## 增加路由时，指定接口 , dev [网口名称]
route add -net 192.168.1.0 netmask 255.255.255.0 dev eth0


# 删
route del
## 删除网段策略
route del -net 192.168.1.0 netmask 255.255.255.0 gw 192.168.0.1
## 删除主机策略
route del -host 192.168.1.2 gw 192.168.0.1
## 清空整个路由表
route flush

# 改
route change
## 更改主机的路由网关
route change -host 192.168.1.2 gw 192.168.1.254

# 查
route -n
#U 表示该路由是可用的 (up)
#G 表示该路由是一个默认网关 (gateway)
#H 表示该路由是一个主机路由 (host)
#UG 表示该路由同时具有默认网关和可用的属性
#UGH 表示该路由同时具有默认网关、可用和主机路由属性

```

> 参考： https://zhuanlan.zhihu.com/p/619838356#:~:text=route%20%E5%91%BD%E4%BB%A4%E7%94%A8%E4%BA%8E%E6%9F%A5%E7%9C%8B%E5%92%8C%E6%93%8D%E4%BD%9CLinux%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F%E4%B8%AD%E7%9A%84%E8%B7%AF%E7%94%B1%E8%A1%A8%E3%80%82%20%E5%AE%83%E5%85%81%E8%AE%B8%E6%82%A8%E6%B7%BB%E5%8A%A0%EF%BC%8C%E5%88%A0%E9%99%A4%E5%92%8C%E4%BF%AE%E6%94%B9%E8%B7%AF%E7%94%B1%E8%A1%A8%E7%9A%84%E6%9D%A1%E7%9B%AE%EF%BC%8C%E4%BB%A5%E7%A1%AE%E5%AE%9A%E6%95%B0%E6%8D%AE%E5%8C%85%E4%BB%8E%E4%B8%80%E5%8F%B0%E8%AE%A1%E7%AE%97%E6%9C%BA%E5%88%B0%E5%8F%A6%E4%B8%80%E5%8F%B0%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%9A%84%E4%BC%A0%E8%BE%93%E8%B7%AF%E5%BE%84%E3%80%82,%E4%BB%A5%E4%B8%8B%E6%98%AF%E4%B8%80%E4%BA%9B%20route%20%E5%91%BD%E4%BB%A4%E7%9A%84%E5%B8%B8%E7%94%A8%E9%80%89%E9%A1%B9%EF%BC%9Aroute%20-n%EF%BC%9A%E4%BB%A5%E6%95%B0%E5%AD%97%E6%A0%BC%E5%BC%8F%E6%98%BE%E7%A4%BA%E8%B7%AF%E7%94%B1%E2%80%A6

# 配置路由-ip指令

```sh
# 增
# ip route add <目标网络> via <下一跳网关> dev <接口>
# 将 <目标网络> 替换为您要添加路由的目标网络地址，例如 192.168.0.0/24。将 <下一跳网关> 替换为下一跳的网关地址，例如 192.168.1.1。将 <接口> 替换为数据包将通过的网络接口，例如 eth0。
# 要将目标网络 192.168.0.0/24 的数据包通过网关 192.168.1.1 发送到接口 eth0，可以使用以下命令添加路由：
ip route add 192.168.0.0/24 via 192.168.1.1 dev eth0

## 持久化增加
## Ubuntu 18.04 + ，netplan 管理
## 修改netplan文件
网卡：
  routes:
  - to: <目标网段>
    via: <接口>

## Ubuntu 16.04,/etc/network/interfaces
up ip route add 192.168.0.0/24 via 192.168.1.1 dev eth0
## NetworkManager 管理方式
## /etc/NetworkManager/system-connections/<连接名称>
route1=dst=<目标网络>,nh=<下一跳网关>,dev=<接口>
## CentOS
## /etc/sysconfig/network-scripts/route-<InterfaceName>
<目标网段> via <网关> dev <接口>

# 删
sudo ip route del <目标网络> via <下一跳网关> dev <接口>

# 改

# 查
ip route show
```

> 参考： https://developer.aliyun.com/article/1323099#:~:text=%E4%BD%BF%E7%94%A8%20%2Fetc%2Fnetwork%2Finterfaces%20%E6%96%87%E4%BB%B6%201%20%E6%89%93%E5%BC%80%20%2Fetc%2Fnetwork%2Finterfaces%20%E6%96%87%E4%BB%B6%E4%BB%A5%E7%BC%96%E8%BE%91%EF%BC%9A%20sudo,%E3%80%81%20%3C%E4%B8%8B%E4%B8%80%E8%B7%B3%E7%BD%91%E5%85%B3%3E%20%E5%92%8C%20%3C%E6%8E%A5%E5%8F%A3%3E%20%E4%B8%BA%E7%9B%B8%E5%BA%94%E7%9A%84%E5%80%BC%E3%80%82%203%20%E4%BF%9D%E5%AD%98%E5%B9%B6%E5%85%B3%E9%97%AD%E6%96%87%E4%BB%B6%E3%80%82%20%E8%B7%AF%E7%94%B1%E5%B0%86%E5%9C%A8%E6%AF%8F%E6%AC%A1%E5%90%AF%E5%8A%A8%E7%BD%91%E7%BB%9C%E6%8E%A5%E5%8F%A3%E6%97%B6%E8%87%AA%E5%8A%A8%E6%B7%BB%E5%8A%A0%E3%80%82

# 配置防火墙策略--iptables指令

```sh
## 在POSTROUTING区域，配置SNAT策略
iptables -t nat -A POSTROUTING -s [源地址] -j SNAT --to-source [SNAT 地址]

## 在FORWARD区域，配置转发策略
#iptables -I FORWARD -s [源地址] -d [目的地址] -i [接口] -j [策略]
 iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT

# 在出方向上面配置禁止策略
iptables -A OUTPUT -s [源地址] -d [目的地址] -p [协议类型] -j [防火墙策略动作]
# 如：
iptables -A OUTPUT -s [SRC] -d [DST] -p ICMP -j DROP
iptables -A OUTPUT -s [SRC] -d [DST] -p TCP -j DROP
iptables -A OUTPUT -s [SRC] -d [DST] -p UDP -j DROP
```

将当前 iptables 策略做备份

```sh
# 将当前iptables的策略都备份到 iptables.bak
iptables-save > iptables.bak

# 通过备份文件iptables.bak将 策略还原回 iptables
iptables-restore < iptables.bak

```

# 网卡up\down测试

## ifconfig

```sh
ifconfig [interface] {up|down}
```
## ifup \ ifdown

```sh
{ifup|ifdown} [interface]
```

## ip

```sh
ip link set dev [interface] {up|down}
```

# 列出软件安装

## Ubuntu

```sh
dpkg --get-selections 
dpkg -l
```