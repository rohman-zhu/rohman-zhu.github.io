---
title: Connetion Server之间无法同步LDAP
tags:
  - 故障
categories:
  - VMware
  - Horizon View
date: 2022-09-15 00:23:19
---

# 背景

某一次开启windows 本地防火墙，把非常规的端口都禁用，导致标准服务器与副本服务器之间的LDAP复制异常：

- 登录其中一个管理后台，所下发的设置，无法同步到另外一台服务器上面；
- VDM日志里面有大量LDAP复制错误，重复错误xx次；
- 从一台服务器的管理后台，发起对另外一台服务器的备份时，任务无法执行；

# 原因

防火墙拦截了必要端口：

TCP-135
TCP-389
TCP-动态端口
TCP-终结点

# 解决方法

## 确认问题

登录到目标服务器，以管理员身份打开powershell，执行指令

```ps1
repadmin /showrepl localhost:389
```

以上指令会看到具体的报错信息，如RPC不可用、端口不可达；

确定为本地防火墙拦截后，只需添加对应的防火墙端口放行即可。

# 参考资料

https://kb.vmware.com/s/article/2091974

