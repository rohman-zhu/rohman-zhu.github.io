---
title: Linux分区后无法查看到分区
tags:
  - 故障
catergories:
  - Linux
date: 2020-01-19 23:48:36
---

# 故障描述

通过fdisk /dev/sda 分区后，在 fdisk 里可以看到有 sda2 分区 ，可是ls /dev/sd* 目录则无法查看到。

# 原因分析

其实在fdisk分区并保存后，有一段提示信息，表示分区表需要在重启后才能生效。

```sh
The partition table has been altered!

Calling ioctl() to re-read partition table.

WARNING: Re-reading the partition table failed with error 16: 

Device or resource busy.
The kernel still uses the old table.
The new table will be used at the next reboot.
Syncing disks.
```

# 解决方法

使用 partprobe 可以使kernel重新读取分区信息，从而避免重启系统。

# 参考资料

https://man.linuxde.net/partprobe
