---
title: Windows重启进入高级设置的方法
tags:
  - default
categories:
  - Windows Server
date: 2022-09-06 00:02:58
---

# 背景

服务器需要重启进入高级设置，例如禁用数字签名。

# 指令

```cmd
shutdown -r -o -f -t 0
```
