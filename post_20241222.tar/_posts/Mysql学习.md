---
title: Mysql学习
date: 2019-01-01 20:47:51
tags: MySQL
---
# 前言

* 版本 ： 10.3.11-MariaDB Source distribution

# 查看版本的方式

```shell
# 方法一：登录数据库即可
mysql -uroot -p

## ---mysql---
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 10
Server version: 10.3.11-MariaDB Source distribution

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

# 方法二：在mysql的管理界面上，select verison();
# mariaDB 好像没有这个函数。

# 方法三：select @@version；
MariaDB [mysql]> select @@version;
+-----------------+
| @@version       |
+-----------------+
| 10.3.11-MariaDB |
+-----------------+
1 row in set (0.000 sec)

# 方法四：status
MariaDB [mysql]> status
--------------
mysql  Ver 15.1 Distrib 10.3.11-MariaDB, for Linux (x86_64) using readline 5.1

Connection id:		10
Current database:	mysql
Current user:		root@localhost
SSL:			Not in use
Current pager:		stdout
Using outfile:		''
Using delimiter:	;
Server:			MariaDB
Server version:		10.3.11-MariaDB Source distribution
Protocol version:	10
Connection:		Localhost via UNIX socket
Server characterset:	utf8
Db     characterset:	utf8
Client characterset:	utf8
Conn.  characterset:	utf8
UNIX socket:		/tmp/mariaDB.sock
Uptime:			22 min 44 sec

Threads: 8  Questions: 86  Slow queries: 0  Opens: 37  Flush tables: 1  Open tables: 31  Queries per second avg: 0.063
--------------

## ---mysql---

# 方法五：mysql -V
mysql -V
mysql  Ver 15.1 Distrib 10.3.11-MariaDB, for Linux (x86_64) using readline 5.1

```

# 管理Mysql的指令

切换数据库 use

```sql
use Mysql;
```

遍历所有数据库

```sql
show databases;
```

遍历当前数据库中的所有表格

```sql
show tables;
```

遍历表的所有列

```sql
show columns from mysql.user;
```

# 参考资料

* Mysql学习资料： http://www.runoob.com/mysql/mysql-administration.html
