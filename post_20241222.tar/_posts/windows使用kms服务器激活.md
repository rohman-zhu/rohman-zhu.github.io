---
title: windows使用kms服务器激活
tags:
  - default
catergories:
  - WindowsServer
date: 2020-02-05 16:03:00
---

# 端口

服务端开放监听端口 TCP 1688

# 脚本

```ps1
$KMS_SERVER="0.0.0.0"

# 设置激活服务器
slmg -skms $KMS_SERVER
#激活
slmg -ato
# xpr
```