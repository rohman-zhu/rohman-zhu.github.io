---
title: Linux定时任务
date: 2017-10-06 13:14:22
tags: Linux
---
# 定时任务 #

## 常用的软件 ##

### 1.crontab ###

适用于需要周期性执行的任务工作。例如：每5分钟一次服务器时间同步。

### 2.at ###

适合执行一次就结束的调度任务命令。若需要执行 at 命令， 还需要启动ige名为 atd 的服务才行。

### 3.anacron ###

适用于非 7 * 24 小时运行的服务器。

### 4.Crond ###

_Crond_ 是 Linux 系统中用来定期执行命令或者程序任务的一种软件或者服务。

* 一般定时任务存放于 /etc/cron 下
* 守护进程，即一直运行的。
* crontab

#### 格式 ： ####

| 段 | 意义 | 取值范围 |
|:-----:|:------:|:------:|
| 第一段 | 代表分钟 | 00-59 |
| 第二段 | 代表小时 | 00-23 |
| 第三段 | 代表日，天 | 01-31 |
| 第四段 | 代表月份 | 01-12 |
| 第五段 | 代表星期，周 | 0-6 （0代表星期日）|

> 口诀 ： 分时日月周 命令
> 0-59/1 等价于 *

```{.normal}
样例：
//1.
* * * * * /usr/sbin/ntpdate

//2.
30 3，12 * * * /bin/sh /scripts/oldboy.sh
每天凌晨3点和中午12点半时刻，执行 /scripts/oldboy.sh 脚本

//3.
30 */6 * * * /bin/sh /scripts/oldboy.sh
每6个小时的半点时刻，执行 /scripts/oldboy.sh 脚本

//4.
30 8-18/2 * * * /bin/sh /scripts/oldboy.sh
每天在 8点 到 18点之间，每隔两小时的 半点时刻，执行 /scripts/oldboy.sh 脚本

//4.
30 21 * * * /application/apache/bin/apachect1 graceful
每晚21:30 重启apache

//5.
45 4 1,10,22 * * /application/apache/bin/apachectl graceful
表示每月的1，10，22日 在凌晨 4:45 重启 apache

//6.
10 1 * * 6,0 /application/apache/bin/apachectl graceful
表示每一个星期六和星期天 的 凌晨 1:10 重启apache

//7.
0,30 18-23 * * * /application/apache/bin/apachectl graceful
>表示在每天的 18:00，18:30，19:00，19:30，20:00，20:30，21:00，21:30，22:00，22:30，23:00，23:30 重启apache

>表示在每天 18:00 到 23：00 之间每隔30分钟重启 apache。最后一次执行是23:30。

```

> 周和日尽量不要同时使用

#### 特殊符号的意义 ####

| 特殊符号 | 意义 |
|:-----:|:------:|
|   *   |   任意时间    |
|   -   |   表示一个时间范围    |
|   ，   |   分隔时段    |
|   /n  |   每间隔n个单位时间   |

### 实践 1 : 每分钟打印一次自己的名字拼音到“/server/log/自己命名的文件” ###

```{.normal}
$ whereis echo
echo: /usr/bin/echo /usr/share/man/man1/echo.1.gz /usr/share/man/man1p/echo.1p.gz

$ crontab -e
## print username to /server/log/roman...
* * * * * /usr/bin/echo roman >> /server/log/roman

$ crontab -l
```

### 实践 2 ：每隔一分钟，打印一个 + 号到 xxx.txt ，请给出crontab完整命令 ###

```{.normal}
## 每隔一分钟打印一个+号到xxx.txt
$ * * * * * echo "+" >> xxx.txt
```

### 实践 3 ： 每隔 2 个小时将系统的/etc/services 文件打包备份到 /tmp 下。 ###

```{.normal}
// 1.到目标内容上级目录打包

$ cd /etc

// 2.打包的频率是分，包名必须精确到分

$ tar zcvf /tmp/services_$(date +%F-%H).tar.gz ./services

// 3. 确保命令行是正确的，然后写进脚本内.（将脚本放到 /server/scripts/ 文件夹）
$ cd /server/scripts/
$ vim tar.sh

//如果直接在启动计划内添加命令，则需要将相关的符号进行转移

//3.1 测试脚本
$ /bin/sh /server/scripts/tar.sh


// 4. 将脚本添加到定时任务中执行。

// 5. 末尾添加错误输入或输出
> dev/null 2>&1
```

## 小结 ##

* 定时任务需要加注释
* 结尾不要有 >/dev/null 2>&1 因为以及存在输出
* /server/log 目录必须存在才能出结果
* 定时任务的路径一定要绝对路径
* crond 服务必须开启

## 工作中调试定时任务的方法 ##

1. 增加执行任务频率调试任务。
1. 调整系统时间调试任务。
1. 通过脚本日志输出调试定时任务。
1. 注意一些命令带来的问题
1. 注意环境变量导致的定时任务故障
1. 通过 crond 定时任务服务日志调试定时任务 。 （/var/log/cron)
