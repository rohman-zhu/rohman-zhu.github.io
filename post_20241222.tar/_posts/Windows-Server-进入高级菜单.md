---
title: Windows Server 重启进入高级菜单
tags:
  - default
categories:
  - Windows Server
date: 2023-03-27 00:17:04
---
# 需求

需要禁用驱动签名；

# 操作方式

## 方法1

```cmd
shutdown /r /o
```

## 方法2

```cmd
按住Shift + 重启；
```