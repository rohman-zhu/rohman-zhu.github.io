---
title: Ubuntu图形化远程桌面方案-XRDP+GNOME
tags:
  - default
categories:
  - Linux
  - Ubuntu
date: 2023-04-30 17:01:08
---

# 需求分析

Ubuntu 常规远程的方法是 CLI 方式，但是也有GUI界面的需求；

# 操作方式

```sh
apt-get install xrdp gnmoe
```

客户端远程方式：

```sh
mstsc 到目标服务器
```