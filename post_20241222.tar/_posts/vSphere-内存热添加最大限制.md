---
title: VMware 内存热添加最大限制
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2022-09-15 23:27:43
---

# 说明

```sh
VMware has set a maximum value for hot add memory. By default, this value is 16 times the amount of memory assigned to the virtual machine. For example, if the virtual machine memory is 2 GB, the maximum value for hot add memory is 32GB (2x16).

内存热添加相关笔记：

1）新memory大小必须是128的整数倍。
2）如果hot-add前的memory小于3G，最多只能hot-add到3G。
3）如果hot-add前的memory等于3G，则不能hot-add任何memory。
4）如果hot-add前的memory大于3G，最多能hot-add 原先memory的16倍，但不能超过 hardware limit（对VM version 7来说最多到255G，对VM version8来说1011G）。简单的来说就是 limit=min(old_memory * 16, vm_version_7 ? 255G:1011G)

```

# 参考资料

http://hackerzhou.me/2012/05/vmware-hot-add-cpu-memory-feature-notes.html
