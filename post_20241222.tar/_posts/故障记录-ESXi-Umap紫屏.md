---
title: 故障记录-ESXi-Umap紫屏
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2023-10-15 20:14:57
---
# 故障描述

多个ESXi 在未知的情况下，发生资屏，上面的虚拟机发生HA重启；
紫屏记录为 "PF Exception 14 in world xxxx ： Unmap Helper IP 0xXXXXXX addr 0x0"

```log
PCPU 0:xxxx
PCPU 64:xxxxx
PCPU 128 :xxxx
Code start : xxx应该是ESXi运行时间
0xXXXXXXX:Res5MemUnlockTxnRCL ist@esx#nover
0xXXXXXXX:J3_DeleteTransacton@esx#nover
0xXXXXXXX:J3_AbortTransaction@esx#nover
0xXXXXXXX:UnmapLockCommon@esx#nover
0xXXXXXXX:UnmapAsyncClusterProcessing@esx#nover
0xXXXXXXX:HelperQueueFunc@vmkernel#nover
0xXXXXXXX:CpuSched_StartWorld@vmernel
```

# 原因分析

底层有一个存储卷有异常，原本工目标Datastore开启了精简置备、去重压缩功能，Datastore上面的虚拟机任何数据变化，则会触发底层Datastore空间回收；
现在因为这个卷异常，上面的虚拟机的数据变化，则会触发空间回收，因为空间回收异常，导致ESXi直接紫屏；

# 解决方法

1. 关闭ESXi 的空间回收功能；【并不能解决问题,底层空间回收依旧会触发紫屏】
2. 将目标卷上面的虚拟机迁移走。【注意，这个卷上面的操作，都有可能导致ESXi紫屏】
3. 将目标卷卸载并删除；
