---
title: KVM-使用篇
date: 2018-10-27 22:01:51
tags: Linux
---

# 实验环境信息 

* OS:CentOS-6.9-Server-Minimal
* CPU:2u
* Memory:4GB
* 运行在 Vmware Fusion 专业版 8.0.0
* 开启虚拟化管理程序

# 目标
tet
* 创建一台 Centos6.9-Server-Minimal 的 VM[完成时间：20181031]
* 创建一台 Windows10 的 VM [完成时间：20181104]
* 创建一台 Ubuntu1404-5 Server 的VM [完成时间：20181030]

# 试验环境准备

因为我实验的虚拟机是由模板克隆过来的，因此网卡信息需要重新配置。
因为之前太久没有用到该模板了，所以连开机密码也要重新破解，链接见参考资料。

## 网卡变更

```shell
# 查看网卡信息 
# udev 是 Linux2.6 内核里的一个功能，它替代了原来的 devfs，成为当前 Linux 默认的设备管理工具。udev 以守护进程的形式运行，通过侦听内核发出来的 uevent 来管理 /dev目录下的设备文件。不像之前的设备管理工具，udev 在用户空间 (user space) 运行，而不在内核空间 (kernel space) 运行。

cat /etc/udev/rules.d/70-persistent-net.rules

# 可以看到网卡名称为 eth1 , 与虚拟机配置中的网卡MAC地址一致，接下来就是配置eth1的网卡信息。

# CentOS编辑网卡跟Ubuntu编辑网卡配置的路径不一样。
# Ubuntu的是 /etc/networking/interface
vi /etc/sysconfig/network-scripts/ifcfg-eth1
# 添加以下信息,注意区分大小写
TYPE=Ethernet
ONBOOT=yes
DEVICE=eth1
BOOTPROTO=dhcp
# 重启网卡 ， 这个跟UBUNTU是一样的
/etc/init.d/network restart

# 关闭防火墙
/etc/init.d/iptables stop

```
> 为什么 network-scripts/ifcfg-eth1 这个文件必须是ifcfg开头？

## 开启ssh

```shell
ps aux | grep ssh
netstat -ntlp | grep 22
/etc/init.d/sshd start
```

## 配置epal包

```shell
 rpm -ivh http://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm
```
## 安装必要的软件

```shell
yum install qemu-kvm virt-manager python-virtinst libvirt -y
# 查看是否包含kvm内核
lsmod | grep kvm
# 启动 libvirt 服务
/etc/init.d/libvirtd start

# 需要安装这个，否则无法用vnc
yum install virt-viewer -y
```

# 创建虚拟机

## 磁盘准备

```doc

```

```shell
# 创建5GB qcow2 格式的硬盘
qemu-img create -f qcow2 /opt/kvm.demo.qcow2 5G
# 检查是否创建成功
qemu-img info /opt/kvm.demo.qcow2
ls -lh /opt/kvm.demo.qcow2
```

## 准备镜像

```shell
# 虚拟机已经加载ISO镜像
dd if=/dev/cdrom of=/opt/Centos6.9.iso
```

## 创建虚拟机

```shell
# 创建指令
# 监听端口默认从5900开始
# 在指定硬盘位置的时候，一定要标明类型，否则kvm会按照默认的类型，即raw去加载硬盘，这会到导致硬盘空间为0
# 错误： --disk path=/opt/kvm.demo.qcow2
# 正确： --disk path=/opt/kvm.demo.qcow2,format=qcow2
virt-install --virt-type kvm --name kvm-demo --ram 512 --cdrom=/opt/CentOS6.9.ios --network network=default --graphics vnc,listen=0.0.0.0 --noautoconsole --os-type=linux --os-variant=rhel6 --disk path=/opt/kvm.demo.qcow2

# 查看虚拟机状态
virsh list all

```

## 创建虚拟机--Centos

由于一开始挂载错了镜像，需要重新挂载镜像。 操作流程是这样的： 编辑XML文件，定义XML文件，启动虚拟机。 （KVM关机情况下操作，开机状态会更改失效。）


用 virsh edit kvm-demo 查看当前XML配置文件。 （默认路径： /etc/libvirt/qemu/kvm-demo.xml) 如下所示：

```shell
<domain type='kvm'>
  <name>kvm-demo</name>
  <uuid>73a577e4-181a-bd8a-1fa8-d957cc207bce</uuid>
  <memory unit='KiB'>524288</memory>
  <currentMemory unit='KiB'>524288</currentMemory>
  <vcpu placement='static'>1</vcpu>
  <os>
    <type arch='x86_64' machine='rhel6.6.0'>hvm</type>
    <boot dev='cdrom'/>
  </os>
<features>
    <acpi/>
    <apic/>
    <pae/>
  </features>
  <clock offset='utc'/>
  <on_poweroff>destroy</on_poweroff>
  <on_reboot>restart</on_reboot>
  <on_crash>restart</on_crash>
  <devices>
    <emulator>/usr/libexec/qemu-kvm</emulator>
    <disk type='file' device='disk'>
      <driver name='qemu' type='qcow2' cache='none'/>
      <source file='/opt/disk.qcow2'/>
      <target dev='hda' bus='ide'/>
      <address type='drive' controller='0' bus='0' target='0' unit='0'/>
    </disk>
    <disk type='block' device='cdrom'>
      <driver name='qemu' type='raw'/>
      <target dev='hdc' bus='ide'/>
      <readonly/>
      <address type='drive' controller='0' bus='1' target='0' unit='0'/>
    </disk>
    <controller type='usb' index='0' model='ich9-ehci1'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x7'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci1'>
      <master startport='0'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x0' multifunction='on'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci2'>
      <master startport='2'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x1'/>
    </controller>
    <controller type='usb' index='0' model='ich9-uhci3'>
      <master startport='4'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x04' function='0x2'/>
    </controller>
    <controller type='ide' index='0'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x01' function='0x1'/>
    </controller>
    <interface type='network'>
      <mac address='52:54:00:23:20:b8'/>
      <source network='default'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x03' function='0x0'/>
    </interface>
    <serial type='pty'>
      <target port='0'/>
    </serial>
    <console type='pty'>
      <target type='serial' port='0'/>
    </console>
    <input type='mouse' bus='ps2'/>
    <graphics type='vnc' port='-1' autoport='yes' listen='0.0.0.0'>
      <listen type='address' address='0.0.0.0'/>
    </graphics>
    <video>
      <model type='cirrus' vram='9216' heads='1'/>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x02' function='0x0'/>
    </video>
    <memballoon model='virtio'>
      <address type='pci' domain='0x0000' bus='0x00' slot='0x05' function='0x0'/>
    </memballoon>
  </devices>
</domain>
```

需要留意部分：

* 引导 ： <boot dev='cdrom'>
* iso 文件位置 ： <source file='/opt/centos.iso'/> 放置CDROM标签内
* CDROM标签内有一个类型，需要填写为 file 

> type-file 与 type-block 的区别是？

变更操作参考： https://r0manj.github.io/2018/10/27/KVM-变更篇/


### ERROR

* ERROR    Failed to connect socket to '/var/run/libvirt/libvirt-sock': 没有那个文件或目录
    * 需要启动libvirtd

* VNC 服务没有启动，无法通过物理机的VNC远程查看虚拟机中的虚拟机
    * 宿主机不需要启动VNC服务，只要开启VNC桌面的，都可以直接通过监听端口远程。   
    *  如果VNC远程不了，需要将画面质量调至最低

* 使用的是qcow2格式的镜像，安装系统的时候，提示空间太小。
    * 在指定硬盘的时候，需要附上格式 ， 如 --disk=/opt/test.qcow2,format=qcow2
    * 查看xml文件可知，磁盘类型为raw，而我创建的为qcow2
      * 可以到xml文件中，将type的值从 raw 更改为 qcow2 ，保存。 重新定义xml 。 开启虚拟机。
 
* 被中断的系统安装，需要如何重新加载CDROM？
  * 引导 ： <boot dev='cdrom'>
  * iso 文件位置 ： <source file='/opt/centos.iso'/> 放置CDROM标签内
  * CDROM标签内有一个类型，需要填写为 file 

* 安装Windows Server 2012 R2 的时候进度条卡在92% ，但kvm没有报错。
  * 此时查看物理机的空间已经占满，需要分配空间以安装系统。


## 创建Ubuntu 虚拟机

如同 创建Centos虚拟机是一样的。略

## 创建 Windows 虚拟机


Windows Server 2012 R2 安装密钥（只适用安装，不支持激活）

标准版 = NB4WH-BBBYV-3MPPC-9RCMV-46XCB

数据中心版 = BH9T4-4N7CW-67J3M-64J36-WW98Y



M98WF-NY2PP-73243-PC8R6-V6B4Y Retail Key
MR88Y-BXNRY-VH3DR-349CB-3GK8M retail Key
M89WF-NY2PP-73243-PC8R6-V6B4Y retail key


# 参考资料：

* udev信息详解： https://blog.csdn.net/xiaoliu5396/article/details/46531893
* root密码破解： https://www.linuxidc.com/Linux/2018-01/150211.htm
* 配置网卡信息： https://www.cnblogs.com/smyhvae/p/3932903.html
* CM-wget：
* CM-netstat:
* CM-ps:
* CM-scp ： http://man.linuxde.net/scp
* CM-dd :
* 更换国内源： https://blog.csdn.net/a491857321/article/details/53453165
* 配置epel包： http://www.cnblogs.com/gaoyuechen/p/7683471.html
* vir-install : https://blog.csdn.net/reblue520/article/details/51456848
* 关闭selinux ： https://www.linuxidc.com/Linux/2016-11/137723.htm
* VNC设置【存疑】：http://blog.51cto.com/liqingbiao/1741103
* 挂载磁盘【存疑】： https://blog.csdn.net/tpiperatgod/article/details/46459929
* 挂载磁盘 ： https://blog.csdn.net/qq_25730711/article/details/72835565
* KVM变更篇 ： https://r0manj.github.io/2018/10/27/KVM-%E5%8F%98%E6%9B%B4%E7%AF%87/