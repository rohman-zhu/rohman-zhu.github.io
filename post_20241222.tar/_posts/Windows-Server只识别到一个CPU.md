---
title: Windows Server只识别到一个CPU
tags:
  - 故障
categories:
  - Windows Server
date: 2021-08-08 23:07:38
---

# 故障现象

物理服务器有2颗物理CPU，而操作系统只识别到1颗CPU。

使用wmic查询也只有一个CPU、一个逻辑CPU；

```sh
wmic CPU get name
wmic CPU get NumberOfCores
wmic CPU get NumberOflogicalProcessors
```

显示只有1

# 原因分析

1. 硬件故障
2. 操作系统设置故障

# 解决方法

## 原因1，硬件故障

进入服务带外检查，发现CPU状态正常。

## 原因2，操作系统设置异常

进入msconfig，微软配置项处。

进入引导页面，进入高级选项，里面有“引导高级选项”，在处理器个数这一栏目内，发现数量是1。于是将处理器个数前面的复选框，取消勾选，点击确定后，重启操作系统。

# 参考资料

https://blog.csdn.net/sinat_38068807/article/details/89947559
https://blog.csdn.net/jhsword/article/details/96623333