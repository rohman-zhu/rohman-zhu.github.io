---
title: Vmware Horizon Agent 静默安装实例
tags:
  - MSI静默安装
catergories:
  - VMware
  - Horizon View
date: 2020-04-19 22:47:24
---

# 需求

在 Windows 下通过指令实现自动化安装 VMware Horizon View ，安装完后自动重启。

前提条件：

1. Windows 已加域，并将View管理员添加至Administrator组。
2. 使用View管理员登录，运行自动安装脚本。

> 使用View管理员登录安装View Agent，可以避免在脚本中输入管理员密码的明文信息，避免信息安全问题。

需求：

1. 仅安装 核心 、 实时音频视频 、 VMware Horizon View Agent技术支持这三个部件。
2. 脚本中不能出现明文密码，因此只能使用当前账户安装。
3. 指定连接服务器。
4. 安装完后需要输出日志，并且重启服务器。

# 脚本编写

从命令行静默安装 Horizon Agent 时，可以包含特定属性。您必须使用 PROPERTY=value 的格式，以便 Microsoft Windows Installer (MSI) 理解各属性和值。静默升级使用相同的安装命令。

```ps1
.\Vmware Horizon View Agent*.exe /s /v "/qn ADDLOCAL=Core,RTAV,HelpDesk RDP_CHOICE=0 VDM_SERVER_NAME=xx.xx.xx.xx REBOOT=Force" /l C:\View Agent.log
```

升级版，将参数剥离出来；

```ps1
$VDM_SERVER_IP="";
$VDM_SERVER_USERNAME="";
$VDM_SERVER_PWD="";

.\vmware-horizon-view-agent.exe /s /v "/qn RDP_CHOICE=0 VDM_VC_MANAGED_AGENT=0 VDM_SERVER_NAME=$VDM_SERVER_IP VDM_SERVER_USERNAME=$VDM_SERVER_USERNAME $VDM_SERVER_PASSWORD=""$VDM_SERVER_PWD"" ADDLOCAL=Core,ClientDriveRedirection REBOOT=Force" /l [log path];Start-Sleep -Seconds xx;
```

> 注意事项：①密码需要用双引号；②密码中如果特殊含义的字符，比如$，则需要使用`进行转义；

# 参考资料

Horizon Agent 静默安装属性：https://docs.vmware.com/cn/VMware-Horizon-7/7.12/horizon-virtual-desktops/GUID-3096DA8B-034B-435B-877E-5D2B18672A95.html


Microsoft Windows Installer 命令行选项： https://docs.vmware.com/cn/VMware-Horizon-7/7.12/horizon-virtual-desktops/GUID-1FD90D4D-0C7C-4E9E-B12D-974ABF15E398.html

MSI 指令：https://docs.microsoft.com/en-us/windows/win32/msi/reboot
