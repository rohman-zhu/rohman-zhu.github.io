---
title: CentOS7绑定Bond
tags:
  - Network
categories:
  - Linux
  - CentOS
date: 2020-06-07 13:04:56
---
# 操作步骤

1. sudo 或者 root 权限下操作。
2. 关闭NetworkManager （systemctl disable NetworkManager)
3. 配置DNS（/etc/resolv.conf)
4. 加载bonding模块（modprobe bonding）
5. 设置网卡配置文件。

## 创建bond0网卡配置文件

vim /etc/sysconfig/network-scripts/ifcfg-bond0

```conf
DEVICE=bond0
Type=Bond
NAME=bond0
BONDING_ASTER=yes
BOOTPROTO=none
ONBOOT=yes
IPADDR=192.168.1.1
PREFIX=24
GATEWAY=192.168.1.254
NM_CONTROLLED=no
BONDING_OPTS="mode=4 miimon=100 lacp_rate=1"
```

## 更改salve物理网卡的配置文件

例如 网卡 eno1 ， eno2 做成bond 。

vim  /etc/sysconfig/network-scripts/ifcfg-eno1

```conf
DEVICE=eno1
TYPE=Ethernet
BOOTPROTO=none
ONBOOT=yes
NM_CONTROLLED=no
IPV6INIT=no
MASTER=bond0
SLAVE=yes
```

vim /etc/sysconfig/network-scripts/ifcfg-eno2

```conf
DEVICE=eno2
TYPE=Ethernet
BOOTPROTO=none
ONBOOT=yes
NM_CONTROLLED=no
IPV6INIT=no
MASTER=bond0
SLAVE=yes
```

修改完后重启。

## 检测bond的状态

cat /proc/net/bonding/bond0

# 参考资料

https://www.snel.com/support/setup-lacp-bonding-interface-centos-7/