---
title: SSH服务端异常故障记录
tags:
  - 故障
categories:
  - Linux
date: 2022-10-23 15:43:58
---
# 故障描述

服务器端以开启ssh服务，但是用户连接异常，有时能连上，有时异常；

# 原因分析

```
ssh登录服务器时总是要停顿等待一下才能连接上,这是因为OpenSSH服务器有一个DNS查找选项UseDNS默认是打开的。
UseDNS选项打开状态下,当客户端试图登录OpenSSH服务器时,服务器端先根据客户端的IP地址进行DNS PTR反向查询,查询出客户端的host name，然后根据查询出的客户端host name进行DNS 正向A记录查询，验证与其原始IP地址是否一致，这是防止客户端欺骗的一种手段,但一般我们的IP是动态的，不会有PTR记录的，打开这个选项不过是在白白浪费时间而已。
```

# 解决方法

1. 服务器侧配置DNS
2. ssh配置文件增加 "UseDNS no"

# 参考资料

https://blog.csdn.net/qq_37683287/article/details/91969735


