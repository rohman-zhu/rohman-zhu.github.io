---
title: 'Ubuntu1404 在线升级到Ubuntu1604 附-Ubuntu源的区分'
date: 2018-11-01 23:48:02
tags: Linux
---

# 前言

由于不能变更系统内的操作，但又有升级系统的需求，例如一些软件的兼容或者驱动的兼容需要新版本的UBUNTU才能支持，在保留现有的服务并且不更改任何配置的情况下，将系统和内核都进行升级。

要通过apt-get升级需要查看官网的ReleaseNotes ，看是否能够跨版本升级。

# To-do list

* Ubuntu 1404 generic 升级至 Ubuntu 1604 4.4.0-138-generic【20181103完成】

# 操作过程

```shell
# 需要将sources.list的源更改一下。将1404 的 trusty 源 转换为 1604 的 xenial 源
sed -i "s#trustly#xenial#g" /etc/apt/sources.list
sudo apt-get update
sudo apt-get dist-upgrade
```

# 附： Ubuntu各个版本的代号与翻译

Ubuntu 发布版本的官方名称是 Ubuntu X.YY ，其中 X 表示年份（减去2000），YY 表示发布的月份。


| 版本号 | 英文代号 | 中文翻译 | 发布时间 |
|:---:|:----:|:-----:|:----:|
|18.10|Bionic Beaver|仿生海狸|2018/04|
|18.04|Bionic Beaver|仿生海狸|2018/04|
|17.10|Artful Aardvark|机灵的土豚|2017/10|
|17.04|Zesty Zapus|开心的跳鼠|2017/04|
|16.10|Yakkety Yak|高原牦牛|2016/10|
|16.04|LTS Xenial Xerus|好客的非洲地松鼠|2016/4|
|15.10|Wily Werewolf|狡诈的狼人|2015/10/22|
|15.04|Vivid Vervet|活泼的小猴 2015/04/23|
|14.10|Utopic Unicorn|乌托邦独角兽|2014/10/23|
|14.04|LTS Trusty Tahr|值得信赖的塔尔羊|2014/04/18|
|13.10|Saucy Salamander|活泼的蝾螈|2013/10/17|
|13.04|Raring Ringtail|铆劲浣熊|2013/04/25|
|12.10|Quantal Quetzal|缤纷的绿咬鹃|2012/10/18|
|12.04|LTS Precise Pangolin|精准的穿山甲|2012/04/26|
|11.10|Oneiric Ocelot|有梦的虎猫|2011/10/13|
|11.04|Unity成为默认桌面环境 Natty Narwhal|敏捷的独角鲸|2011/04/28|
|10.10|Maverick Meerkat|标新立异的的狐獴|2010/10/10|
|10.04|LTS Lucid Lynx|清醒的猞猁|2010/04/29|
|9.10|Karmic Koala|幸运的无尾熊|2009/10/29|
|9.04|Jaunty Jackalope|活泼的兔子|2009/04/23|
|8.10|Intrepid Ibex|无畏的高地山羊|2008/10/30|
|8.06|官方查不到此版本发布信息 Haughty Husky|骄傲的哈士奇|2008/06/07|
|8.04|LTS Hardy Heron|坚强的苍鹭|2008/04/24|
|7.10|Gutsy Gibbon|勇敢的长臂猿|2007/10/18|
|7.04|Feisty Fawn|烦躁不安的小鹿|2007/04/19|
|6.10|Edgy Eft|尖利的小蜥蜴|2006/10/26|
|6.06|LTS Dapper Drake|整洁的公鸭|2006/06/01|
|5.10|Breezy Badger|活泼的獾|2005/10/13|
|5.04|Hoary Hedgehog|白发得刺猬|2005/04/08|
|4.10|初始发布版本 Warty Warthog|多疣的疣猪|2004/10/20|


## 查看当前版本代号

```shell
lsb_release -a

# 例如
Distributor ID:	Ubuntu
Description:	Ubuntu 14.04.5 LTS
Release:	14.04
Codename:	trusty
```

## Ubuntu 版本更新周期

Desktop 和 Server 版本更新的时间为 6个月

## Ubuntu 的版本支持时间

* 对于 desktop 版本和 server 版本，Ubuntu 会提供至少18个月的技术支持
* 对于 LTS 版本（Long Term Suppot）长期支持版本，desktop 版的会提供至少 3年技术支持，server 版本的会提供至少 5 年即使支持

## Ubuntu 的各个版本（最新发行版主要提供 Desktop 和 Server两种版本）

* Desktop版本：desktop 是 live cd 的名字,什么是 live cd? live cd 是一个刻录在光盘上的操作系统，我们并不需要硬盘就可以直接在光盘上运行这个操作系统。里面也已经集成了很多软件，我们一般可以把这个系统安装到硬盘上，类似于ghost系统，安装速度会比较快。这个版本提供了向导的图形界面的方式，让你一步步来轻松地安装 Ubuntu (一般都安装这个系统的 32 位 i386 版本）
* Alternate版本：是一个最标准的安装版本，采用文本安装界面，里面有很多高级选项，可以安装 desktop ,也可以安装 server 版，适合比较高要求的人来安装，安装速度比 desktop 版慢，但是运行时的效率比 desktop 版本快
* Netbook版本：专门为上网本定制和优化，最近的版本采用了 Unity，为小屏幕提供了一种美观的用户界面，采用了大图标设计，让用户更容易寻找各种应用程序
* DVD版本：里面包括 Desktop 和 Alternate 两种安裝模式，同时集成更多的软件和完整的语言包，假如你没有联网可以选择下这个版本
* Minimal版本：安装 Ubuntu 的最小镜像版本

# 参考资料

* Ubuntu源的区分： https://blog.csdn.net/feiniao8651/article/details/70159157
* Ubuntu源的代号：https://blog.csdn.net/zhengmx100/article/details/78352773
* Ubuntu 1804 ReleaseNotes : https://wiki.ubuntu.com/BionicBeaver/ReleaseNotes?_ga=2.145883700.1807176416.1541224818-1321095893.1541224818