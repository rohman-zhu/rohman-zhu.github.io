---
title: Linux之负载均衡
date: 2017-10-26 22:56:01
tags: Linux
---
# Linux之负载均衡 #

## 集群 ##

集群通信系统是一种用于集团调度指挥通信的移动通信系统，主要应用在专业移动通信领域。该系统具有的可用信道可为系统的全体用户共用，具有自动选择信道功能，它是共享资源、分担费用、共用信道设备及服务的多用途、高效能的无线调度通信系统。

* 特点: 高性能

## 负载均衡 ##

负载均衡，英文名称为Load Balance，其意思就是分摊到多个操作单元上进行执行，例如Web服务器、FTP服务器、企业关键应用服务器和其它关键任务服务器等，从而共同完成工作任务。

## 方向代理 ##

反向代理（Reverse Proxy）方式是指以代理服务器来接受internet上的连接请求，然后将请求转发给内部网络上的服务器，并将从服务器上得到的结果返回给internet上请求连接的客户端，此时代理服务器对外就表现为一个反向代理服务器。

## 用Nginx 来做负载均衡 ##

Nginx可以做反向代理.

## 语法说明 ##

1. upstream 模块应放于nginx.conf配置的http{}标签内.
1. upstream模块默认算法是wrr(权重轮询 weighted round-robin)

| 参数 | 说明 |
|:-----:|:-----:|
| Server 10.0.10.8:80 | 负载均衡后面的RS配置,可以是IP或域名,端口不写,默认是80;高并发场景IP要换成域名,通过DNS做负载均衡.|
|weight|权重,默认是1,权重越大接受的请求越多|
|max_fails=2|最大尝试失败的次数,默认是1,-标识禁止失败尝试.一般建议2-3次|
|backup|热备配置(RSYNC节点的高可用)|
|fail_timeout=20s|失败超时时间,默认是10s|
|down|标志服务器不可用|

## 调度算法 ##

1. 静态调度: rr ,ip_hash , wrr
1. 动态调度: least_conn , fair

### 一致性缓存 ###

由于url_hash在处理宕机或者新增的机器会对缓存压力比较大.

因此一致性hash可以减少宕机情况对整个服务器缓存动荡.

### 1.安装 ###

```{.normal}
# Nginx:

# ./configure --prefix=/application/nginx --user=nginx --group=nginx --with-http_ssl_module --with-http_stub_status_module

# 配置均衡器
# 需要的模块 : upstream ,http_proxy

# vim lb.conf
#--------------

# 定义节点与调度算法
upstream backend {
    server backend1.example.com weight=5;
    server backend2.example.com:800;
}

#http_proxy负责转发与算法
#默认轮询算法(静态算法)

server {
    location / {
        proxy_pass http://backend;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Host $host;
    }
}
```

> proxy_pass 模块用于转发用户的请求

### 2. 运行流程 ###

Web服务器:

1. 172.16.177.137
1. 172.16.177.138

LB 服务器 :

172.16.177.139

目标域名:

1. 172.16.177.137 blog.test.org bbs.test.org
1. 172.16.177.138 blog.test.org bbs.test.org
1. 172.16.177.139 blog.test.org bbs.test.org

在客户机上面添加LB服务器的解析

> echo " 172.16.177.139 blog.test.org bbs.test.org" >> /etc/hosts

客户端--访问blog域名--LB服务器解析--proxy_pass--Web服务器

### 3.用户请求细节 ###

> [请求代理主机访问多虚拟主机]用户向代理服务器发送请求(包含请求头),再有代理服务器向后请求(会丢失请求头).

proxy\_set_header Host $host

### 4. 动静分离 ###

* 当用户请求www.test.com/upload/xx地址实现由upload上传服务器处理请求.
* 当用户请求www.test.com/static/xx地址实现由静态服务器池处理请求.
* 除此之外,对于其他访问请求,全都由默认的动态服务器池处理请求.

```conf
upstream static_pools{

}

upstream upload_pools{

}
upstream default_pools{

}

server{
    location / {
        proxy_pass http://default_pools;
    }
    location /static/ {
        proxy_pass http://static_pools;
    }
    location /upload/ {
        proxy_pass http://upload_pools;
    }
}

```

### 5.根据不同客户端返回响应内容 ###

http\_user_agent

```conf
if($http_user_agent ~* "MSIE")
{
    proxy_pass http://...;
}
if($http_user_agent ~* "Chrome")
{
    proxy_pass http://...;
}
```