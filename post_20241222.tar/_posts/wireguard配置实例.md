---
title: wireguard配置实例
tags:
  - default
categories:
  - default
date: 2024-03-07 01:15:45
---


# 参考
https://devld.me/2020/07/27/wireguard-setup/
