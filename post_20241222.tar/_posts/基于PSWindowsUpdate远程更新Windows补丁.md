---
title: 基于PSWindowsUpdate远程更新Windows补丁
tags:
  - 脚本
categories:
  - Windows Server
date: 2022-05-05 23:00:53
---

# 实现效果

可以通过指令下发指令去安装补丁，类似于Linux的Ansible。（当然也有用Ansible去控制Windows Server）

# 前置条件

网络层

- TCP-5985 （WINRM的HTTP监听端口）
- TCP-135 (Invoke-WUJob使用)
- TCP-RPC动态端口(Invoke-WUJob使用)
- TCP-RPC终结点映射器(Invoke-WUJob使用)

应用层

- 安装 PSWindowsUpdate Module

> 离线安装：1. 安装nugetprovider ，这个文件不能为锁定的状态。2. 安装PSWindowsUpdate Module。

```ps1
# 离线安装 NugetProvider
# 下载安装包
# 进入地址 https://onegetcdn.azureedge.net/providers/providers.masterList.feed.swidtag
# 找到nuget有关的url，进入 https://onegetcdn.azureedge.net/providers/nuget-2.8.5.208.package.swidtag
# 找到nuget.dll 的URl，下载 https://onegetcdn.azureedge.net/providers/Microsoft.PackageManagement.NuGetProvider-2.8.5.208.dll
# 得到 NugetProvider.dll 库文件  Microsoft.PackageManagement.NuGetProvider-2.8.5.208.dll
# 注意，这里要注意文件不要锁定。

# 将目标文件放置到  C:\Program Files\PackageManagement\ProviderAssemblies\nuget\2.8.5.208\

# 查询是否能识别到
Get-PackageProvider -ListAvailable
```

```ps1
# 下载PSWindowsUpdate 的nupkg文件
# 下载地址：https://www.powershellgallery.com/packages/PSWindowsUpdate/
# 下载文件放置到任意目录，例如C:\1-InstallPackage

# 注册目标目录为本地安装仓库
Register-PSRepository -Name Local -SourceLocation C:\1-InstallPackage -InstallationPolicy Trusted

# 安装模块
Install-Module -Name PSWindowsUpdate
```

系统层

- 开启 WinRM 服务
- 客户端与服务端同处一个域内

# 具体实现

Server端、Client端均安装PSWindowsUpdate模块与开启WinRM，并确保防火墙之间的防火墙端口通讯是开通的。

## Server端

```ps1
Invoke-WUJob -ComputerName [客户端主机名] -Scripts { Install-WindowsUpdate -AcceptAll -Install -AutoReboot |Out-File C:\PSWindowsUpdate.log} -Confirm:$false -RunNow
```

注：远程调用不能用Invoke-Command + Install-WindowsUpdate 的方式。例如：

```ps1
# 以下方法不可行,会提示访问拒绝
Invoke-Command -ComputerName [客户端主机名] -ScriptBlock {Install-WindowsUpdate -AcceptAll -Install -AutoReboot}
```

## Client端

如果到WSUS服务器的通讯是正常的话，则可以自动安装补丁，并且安装完成后会重启Server。
安装进度可以看在C:\WindowsUpdate.log,补丁的状态会有这样的变化：Accept --> Download --> Installed .


# 其他已验证过，且不可行的方法汇总

以下记录已经验证过的方法，均来自互联网...

## 通过注册表方式，让服务器重启后自动执行脚本安装

在LKM的RunOnce中添加注册表项，调用 Powershell去执行Windows更新脚本。

```ps1
Set-Item "...\RunOnce\" xxxx

# 脚本内容
Install-WindowsUpdate -AcceptAll -Install -AutoReboot
```

在添加完注册表后，重启服务器后并不会自动执行脚本，需要用户再一次登录进Windows时才会触发，等安装结束后，RunOnce中的注册表项会被自动删除。

```ps1
# 检查是否安装目标补丁
Get-HotFix | Where-Object {$_.HotFixID="" } | Select-Object -Property HotFixID;
```

## Invoke-Command 与 Install-WindowsUpdate 指令结合

Server端发起指令。

```ps1
Invoke-Command -ComputerName [客户端主机名] -ScriptBlock {Install-WindowsUpdate -Acceptall -Install -AutoReboot}
```

以上执行完毕后，会扫描到补丁，并且状态为Accept，但后面就会提示访问拒绝。

远程调用补丁安装，应该使用Invoke-WUJob指令，如下：

```ps1
Invoke-WUJob -ComputerName $serverName -Script {Install-WindowsUpdate -Acceptall -Install -AutoReboot|Out-File C:\1-InstallPackage\PSWindowsUpdate.log} -RunNow
```

# 参考资料

参考资料： https://www.winhelponline.com/blog/how-to-check-if-a-windows-update-kb-is-installed/
离线安装Nuget库文件：https://stackoverflow.com/questions/58349992/how-do-i-install-the-nuget-provider-for-powershell-on-a-offline-machine
