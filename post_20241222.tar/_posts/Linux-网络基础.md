---
title: Linux 网络基础
date: 2017-10-10 15:33:31
tags: Linux
---

## OSI 7层网络模型

- 物理层(通俗：各种网线 、 交换机、路由器等)
- 数据链路层
- 网络层
- 传输层（例如：TCP、UDP）
- 表示层
- 会话层
- 应用层

## 协议

- tcp/ip 协议的三次握手和四次挥手过程

- http协议工作



### 三次握手

| A                               | B                                           |
|:-------------------------------:|:-------------------------------------------:|
| 发送SYNC（seq=x ctrl =syn）         |                                             |
|                                 | 收到SYN，发送SYN，ACK（seq=y，ack=x+1，ctrl=syn,ack) |
| 发送ACK（seq=x+1，ack=y+1，ctrl=ack） |                                             |

### 四次挥手

| A                       | B                 |
|:-----------------------:|:-----------------:|
| 发送FIN+ACK报文，seq=X，ACK=Z |                   |
|                         | ACK=X+1，Seq=Z     |
|                         | FIN=1，ACK=X，Seq=Y |
| 发送ACK报文，ACK=Y，Seq=x     |                   |

## DNS 解析原理

- 顶级域名 ： org ， com ，net ，me， cc

## 域名解析命令

### dig 命令

```
# dig @8.8.8.8 www.baidu.com -trace
```

### nslookup 命令

```
# nslookup
> www.baidu.com
> www.baidu.com
Server:        202.96.134.133
Address:    202.96.134.133#53

Non-authoritative answer:
www.baidu.com    canonical name = www.a.shifen.com.
Name:    www.a.shifen.com
Address: 14.215.177.38
Name:    www.a.shifen.com
Address: 14.215.177.39
```

### host 命令

解析域名

### ping 命令

解析域名

## DNS配置

> 对应文件： /etc/sysconfig/network-scripts/ifcfg-eth0

修改后生效方式：

#### 第一种

- ifdown eth0 停用eth0网卡
- ifup eth0 启用eth0wangka

#### 第二种

针对所有网卡的

- /etc/init.d/network restart

> 网卡配置的 DNS 优先于 /etc/resolv.conf 配置的 ，并且重启网卡，会把 /etc/resolv.conf的内容覆盖掉。

## 修改主机名的规范步骤

1. hostname xxxx
2. vim /etc/sysconfig/network
3. vim /etc/hosts

## 默认网关配置修改

### 第一生效文件

/etc/sysconfig/network-scripts/ifcfg-eth0

### 第二生效文件

/etc/sysconfig/network

> GATWAY =.....

### 第三 -- 命令行修改，临时生效

- 查看网关

  ```
  # route -n
  ```

- 修改网关

  ```
  # route add default gw x.x.x.x
  # route del default gw x.x.x.x
  ```

## 查看网络配置与信息

> ifconfig
ip 
route -n
hostname
netstat
lsof

### 题目： 已知一个端口为333，如何查看端口对应的是什么服务名？

```
# lsof -i :333

# netstat -Intup | grep 333
```

## 网络及服务故障排查

- 通过ping看是否通，如果没通看ICMP协议。
- 网络不稳定

  ```
  # traceroute [url]
  ```
- 路由跟踪，查看路由器故障

  ```
  # tracert -d [url]
  ```
- 检查服务器web有没有开启、服务是否开启、防火墙是否有拦截

  ```
  # telnet [url] [port]
  ```

  不通的情况有：
- 服务没有开启或端口不存在。
- fw 防火墙阻挡。
- 服务监听的端口不在连接的IP上。
- 运营商默认不开，申请开端口。

## 抓包工具

1. tcpdump
2. tcpdump -n icmp -i eth0
3. nmap
4. windows：wireshark，sniffer

### 问题 ： 局域网机器无法上网，如何解决？

1. ping 一个网站 ，看是否有通路，如果通，可能是浏览器或者中毒等问题。
2. ping 网关 ， 排查物理链路（网线，网卡，驱动，IP设置）。
3. ping 网关通的情况下，检查 DNS 设置。
4. 上网路由器以及ISP线路问题。
5. 辅助排查 ： IP地址冲突 ， 其他人员是否能上网。

#### 补充 ： 大面积不能上网故障的排查思路

- 路由器
- ISP
- 核心交换机
- ARP病毒欺骗网关
- 网关地址呗占用
- LDNS出问题

### 问题 ： 网站打开慢如何排查？

1. 先分类，用户个例，还是全部机器出问题。
2. ping一个网站。
   - 如果ping通，不丢包， 那有可能是http服务的问题。
   - 如果ping通，丢包，那有可能是机房带宽不稳定，各个线路不稳定。
3. tracert -d 网站url ，检测路由列表（线路问题）。
4. telnet 域名 端口 ， 检查服务器WEB是否被防火墙阻挡。
5. 查看服务器是否资源过载。
6. 服务器的带宽已经占满了，通过流量监控服务查看。
7. 
> 主要问题可以分3类去思考 ： 线路问题 ， 机房业务问题，外部问题。
