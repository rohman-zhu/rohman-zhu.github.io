---
title: SAN存储划zone与虚拟化创建映射过程
tags:
  - default
categories:
  - 服务器与存储
  - 存储
  - SAN存储
date: 2021-10-15 00:53:51
---

# 过程摘要

1. 识别SAN交换机配置文件
2. 规划连接方式
3. SAN交换机划zone
4. 存储做映射
5. 客户端发起扫描



