---
title: Python程序实例-Selenium应用-获取页面信息
tags:
  - Selenium实例
categories:
  - 基础知识
  - 编程
  - Python
date: 2024-03-16 18:11:15
---
# 需求描述

需要进入多个页面获取信息内容，并输出至文本，用于后期Excel数据展示。

# 涉及知识点

## Python 逐行读取文件

```py
# 方案1
# 全部读取
FILE=open("TEST.demo")
# read()表示一次性读取文件全部内容
LINE=FILE.read()
print(LINE)
FILE.open()

# 方案2
# 逐行读取
FILE=open("TEST.demo")
LINE=FILE.readline()
while LINE:
    print(LINE)
    LINE=FILE.readline()
FILE.close()

# 方案3
# 读取所有行
FILE=open("TEST.demo")
LINES=FILE.readlines()
for LINE in LINES:
    print(LINE)
    LINE=FILE.readline()
FILE.close()

```

## 程序休眠

```py
import time
# 休眠
time.sleep([SECONDS])
```

## for 循环逐行读取

```py
for iterating_var in sequence:
    statements(s)

# 遍历字符串：
for char in 'Python':
    print("Current char $s"% char)

# 遍历0-100的数字：
for i in range(100):
    print(i)

## 等效于 Powershell 语言
# for ($i=0;$i -lt 100;$i ++)

# 遍历50-100的数字：
for i in range(50,100):
    print(i)
```

## 数字整型转换成字符型

```py
TARGET_INT=10
TARGET_STRING=str(TARGET_INT)
```

## 字符型转换为整型

```py
# 默认十进制
TARGET_NUMBER=int("20")

# 改为十六进制
TARGET_NUMBER=int("20",16)
```

## 文件输出

```py
# 覆盖文件内容，作用相当于 echo "" > test.demo
FILE=open('test.demo',"w")
FILE.write("TARGET CONTENT")

# 追加文件内容，作用相当于 echo "" >> test.demo
# 等价于 Powershell 的 Add-Content
FILE=open('test.demo',"a")
FILE.write("TARGET CONTENT")

```

## 字符比较判断

```py
# 汉字比较
TEST_CHAT="用于测试的字符"
TARGET_CHAT="用于匹配判断的字符"
if TEST_CHAT in TARGET_CHAT:
    print("匹配成功")
```

## 字符串拼接

```py
TARGET_STRING1='字符串1'
TARGET_STRING2='字符串2'
TARGET_STRING3='字符串3'
TOTAL_STRING=TARGET_STRING1 + TARGET_STRING2 + TARGET_STRING3
```

## 字符串替代

```py
DEFAULT_STRING="DEFUALTSTRING"
TEMP_STRING="I need to replace DEFUALTSTRING"
NEW_STRING=TEMP_STRING("DEFAULTSTRING","NEWSTRING")
```

## 异常处理或异常

```py
try:
    Code_Block
except [Except_type]:
    Handle_EXCEPT_CODE_Block

try:
    Code Block
except Exception as ex:
    print(ex)
```

# 脚本内容

```py
import selenium.webdriver as webdriver
import time
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from selenium.webdriver。common.keys import Keys

def WriteLog(INFO):
    FILE=open("Output.log","a")
    FILE.write(INFO)
    FILE.close()


def GetXPATHELEM(DRIVER,TARGET_XPATH):
    ELEM=DRIVER.find_element(By.XPATH,TARGET_XPATH)
    return ELEM
    
def HandleElementInfo(DRIVER):
    TARGET_ELEM_XPATH=""
    TARGET_CONTENT=GetXPATHELEM(DRIVER,TARGET_ELEM_XPATH).text
    return TARGET_CONTENT

def HandleURL(DRIVER,TARGET_URL):
    # 避免被服务端禁用，需要暂停10s再执行
    time.sleep(10)
    DEFAULT_URL=""
    NEW_URL=DEFAULT_URL.replace("",TARGET_URL)
    DRIVER.get(NEW_URL)

driver=webdriver.Chrome()
HandleURL(driver,"")

```

# Chrome Driver 下载

https://googlechromelabs.github.io/chrome-for-testing
