---
title: VPN配置-WireGuard配置实例
tags:
  - VPN
categories:
  - Linux
date: 2024-03-22 23:16:31
---

# 需求1--需求说明

通过云服务器、VPN 隧道将内网的服务器打通，实现互联。

拓扑： 内网服务器 <--VPN IPSec--> 云服务器

## 安装WireGuard

```sh
# Ubuntu\Debian
$ sudo apt install wireguard

# RedHat 8
## Method 1
sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm https://www.elrepo.org/elrepo-release-8.el8.elrepo.noarch.rpm
sudo yum install kmod-wireguard wireguard-tools

## Method 2
sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm
sudo subscription-manager repos --enable codeready-builder-for-rhel-8-$(arch)-rpms
sudo yum copr enable jdoss/wireguard
sudo yum install wireguard-dkms wireguard-tools

# CentOS8
## Method 1
$ sudo yum install yum-utils epel-release
$ sudo yum-config-manager --setopt=centosplus.includepkgs="kernel-plus, kernel-plus-*" --setopt=centosplus.enabled=1 --save
$ sudo sed -e 's/^DEFAULTKERNEL=kernel-core$/DEFAULTKERNEL=kernel-plus-core/' -i /etc/sysconfig/kernel
$ sudo yum install kernel-plus wireguard-tools
$ sudo reboot

## Method 2
$ sudo yum-config-manager --setopt=centosplus.includepkgs="kernel-plus, kernel-plus-*" --setopt=centosplus.enabled=1 --save
$ sudo sed -e 's/^DEFAULTKERNEL=kernel-core$/DEFAULTKERNEL=kernel-plus-core/' -i /etc/sysconfig/kernel

## Method 3
$ sudo yum install epel-release
$ sudo yum config-manager --set-enabled PowerTools
$ sudo yum copr enable jdoss/wireguard
$ sudo yum install wireguard-dkms wireguard-tools

# CentOS7
## Method 1
$ sudo yum install yum-utils epel-release
$ sudo yum-config-manager --setopt=centosplus.includepkgs=kernel-plus --enablerepo=centosplus --save
$ sudo sed -e 's/^DEFAULTKERNEL=kernel$/DEFAULTKERNEL=kernel-plus/' -i /etc/sysconfig/kernel
$ sudo yum install kernel-plus wireguard-tools
$ sudo reboot

## Method 2
$ sudo yum install epel-release elrepo-release
$ sudo yum install yum-plugin-elrepo
$ sudo yum install kmod-wireguard wireguard-tools

## Method 3
$ sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
$ sudo curl -o /etc/yum.repos.d/jdoss-wireguard-epel-7.repo https://copr.fedorainfracloud.org/coprs/jdoss/wireguard/repo/epel-7/jdoss-wireguard-epel-7.repo
$ sudo yum install wireguard-dkms wireguard-tools

# MacOS
## Method 1
 brew install wireguard-tools
## Method 2
$ port install wireguard-tools
```

## 实例

### 服务器节点说明

| 角色 | 公网IP | VPN IP |  内网IP |
|:---:|:---:|:---:|:---:|
| 公网服务器 | 1.1.1.1 | 192.168.1.1 | - |
| 内网服务器节点1| - | 192.168.1.11 | 192.168.2.11|
| 内网服务器节点2| - | 192.168.1.12 | 192.168.2.12|

> WireGuard TCP 端口 65535

### 服务器节点安装与配置

#### 生成密钥对

```sh
# 生成私钥
wg genkey > priv_key

# 生成公钥
wg pubkey < priv_key > pub_key

# 会生成两个文件 priv_key , pub_key
```

WireGuard 的服务端与客户端是对等的。生成密钥的步骤适用于服务端，也适用于客户端。

#### 配置 WireGuard 的配置文件

WireGuard 的配置文件一般情况下放在 /etc/wireguard 中，且为了安全考虑，需要将这个目录的所有者设置为 root，权限设置为 700。
一般情况下，配置文件可依次命名为 wgX.conf，其中 X 为任意的编号，wgX 最终也是创建出来的网络接口的名称。
此处，在服务端与客户端中，都将命名为 wg0.conf


```sh
# 本端的配置， Interface 属性
[Interface]
# 本端的VPN内网IP地址
Address = 192.168.1.1/32
# 作为服务端开放的端口
# 为UDP端口
ListenPort = 65535
# 放置刚才生成的私钥，即priv_key内容
PrivateKey = Server private key

# 对端的配置，Peer 属性
[Peer]
# 对端的公钥，即对端生成的pub_key内容
PublicKey = Client public key
# 允许对端访问过来的IP列表；
# 会自动添加至路由策略表；
AllowedIPs = IP Range
```

配置完毕后，启动WireGuard服务

```sh
wg-quick up wg0
```

开启内核IP包转发

```sh
# 编辑 /etc/sysctl.conf， 
vim /etc/sysctl.conf
# 将 net.ipv4.ip_forward = 0 中的 0 改为 1。
net.ipv4.ip_forward = 1
# sysctl -p 使其生效。
sysctl -p

```

### 客户端节点安装与配置


#### 生成密钥对

```sh
# 生成私钥
wg genkey > priv_key

# 生成公钥
wg pubkey < priv_key > pub_key

# 会生成两个文件 priv_key , pub_key
```

WireGuard 的服务端与客户端是对等的。生成密钥的步骤适用于服务端，也适用于客户端。

#### 配置 WireGuard 的配置文件

客户端与服务端不同的地方在于：
- Interface 配置中没有 ListenPort
- Peer 即为服务端，与服务端不同的地方在于多了一个 Endpoint

一般情况下，只有主动发起连接的端需要在 Peer 中指定 Endpoint，此处为服务器的公网 IP 和监听的端口。

```sh
# 本端配置 ，Interface属性
[Interface]
# 本端的 私钥；
PrivateKey = Client private key
# 配置本端的内网IP；
Address = 192.168.1.2/32

# 对端，即服务器端，Peer属性
[Peer]
# 服务端的公钥；
PublicKey = Server public key
# 允许对端的IP流量
AllowedIPs = IP Range
# 服务端的IP与端口；
Endpoint = 1.1.1.1:28385
# 每10秒发送keepalive心跳；
PersistentKeepalive = 10
```

配置完毕后，启动WireGuard服务

```sh
wg-quick up wg0
```

# 需求2--需求说明


通过云服务器、VPN 隧道将内网DMZ区的服务器打通，通过DMZ服务器转发流量包至内网，实现互联。

拓扑： 内网服务器<--双网卡-->内网DMZ服务器 <--VPN IPSec--> 云服务器

## 实例

### 服务器节点说明

| 角色 | 公网IP | VPN IP |  内网IP |
|:---:|:---:|:---:|:---:|
| 公网服务器 | 1.1.1.1 | 192.168.1.1 | - |
| 内网DMZ服务器节点1| - | 192.168.1.11 | 192.168.2.11|
| 内网服务器节点2| - | 192.168.1.12 | 192.168.2.12|

> WireGuard TCP 端口 65535

> 公网服务器：因为作为VPN服务端，需开启流量转发，且需配置防火墙转发策略（集群内的节点若无通讯需求，可不用配置）；
> 内网DMZ服务器节点1：双网卡，因承担流量转发的角色，需要开启流量转发，且需要配置 SNAT 策略；

### 服务器节点安装与配置

#### 生成密钥对

```sh
# 生成私钥
wg genkey > priv_key

# 生成公钥
wg pubkey < priv_key > pub_key

# 会生成两个文件 priv_key , pub_key
```

WireGuard 的服务端与客户端是对等的。生成密钥的步骤适用于服务端，也适用于客户端。

#### 配置 WireGuard 的配置文件

WireGuard 的配置文件一般情况下放在 /etc/wireguard 中，且为了安全考虑，需要将这个目录的所有者设置为 root，权限设置为 700。
一般情况下，配置文件可依次命名为 wgX.conf，其中 X 为任意的编号，wgX 最终也是创建出来的网络接口的名称。
此处，在服务端与客户端中，都将命名为 wg0.conf


```sh
# 本端的配置， Interface 属性
[Interface]
# 本端的VPN内网IP地址
Address = 192.168.1.1/32
# 作为服务端开放的端口
# 为UDP端口
ListenPort = 65535
# 放置刚才生成的私钥，即priv_key内容
PrivateKey = Server private key

# 对端的配置，Peer 属性
[Peer]
# 对端的公钥，即对端生成的pub_key内容
PublicKey = Client public key
# 允许对端访问过来的IP列表；
# 会自动添加至路由策略表；
AllowedIPs = IP Range
```

需要补充端口转发流量，以及iptable进行放行；

```sh
# 放行wg0端口的VPN网段
iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT 
# 放行 VPN 转发到内网的流量
iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.2.0/24 -j ACCEPT 
# 放行内网 转发到 VPN 的流量
iptables -I FORWARD -s 192.168.2.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT 
```

所以最终配置文件应该为：

```sh
# 本端的配置， Interface 属性
[Interface]
# 本端的VPN内网IP地址
Address = 192.168.1.1/32
# 作为服务端开放的端口
# 为UDP端口
ListenPort = 65535
# 放置刚才生成的私钥，即priv_key内容
PrivateKey = Server private key

# 防火墙策略
PostUp = iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT
PostUp = iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.2.0/24 -j ACCEPT
PostUP = iptables -I FORWARD -s 192.168.2.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT

PostDown = iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT
PostDown = iptables -I FORWARD -s 192.168.1.0/24 -i wg0 -d 192.168.2.0/24 -j ACCEPT
PostDown = iptables -I FORWARD -s 192.168.2.0/24 -i wg0 -d 192.168.1.0/24 -j ACCEPT

# 对端的配置，Peer 属性
[Peer]
# 对端的公钥，即对端生成的pub_key内容
PublicKey = Client public key
# 允许对端访问过来的IP列表；
AllowedIPs = IP Range

```

配置完毕后，启动WireGuard服务

```sh
wg-quick up wg0
```

开启内核IP包转发

```sh
# 编辑 /etc/sysctl.conf， 
vim /etc/sysctl.conf
# 将 net.ipv4.ip_forward = 0 中的 0 改为 1。
net.ipv4.ip_forward = 1
# sysctl -p 使其生效。
sysctl -p

```

### 客户端节点安装与配置


#### 生成密钥对

```sh
# 生成私钥
wg genkey > priv_key

# 生成公钥
wg pubkey < priv_key > pub_key

# 会生成两个文件 priv_key , pub_key
```

WireGuard 的服务端与客户端是对等的。生成密钥的步骤适用于服务端，也适用于客户端。

#### 配置 WireGuard 的配置文件

客户端与服务端不同的地方在于：
- Interface 配置中没有 ListenPort
- Peer 即为服务端，与服务端不同的地方在于多了一个 Endpoint

一般情况下，只有主动发起连接的端需要在 Peer 中指定 Endpoint，此处为服务器的公网 IP 和监听的端口。

```sh
# 本端配置 ，Interface属性
[Interface]
# 本端的 私钥；
PrivateKey = Client private key
# 配置本端的内网IP；
Address = 192.168.1.2/32

# 配置 iptables 作为 SNAT
# --to-source 的IP作为内网中的IP地址；
PostUp = iptables -t nat -A POSTROUTING -s 192.168.1.0/24 -j SNAT --to-source 192.168.2.11
PostUp = iptables -t nat -D POSTROUTING -s 192.168.1.0/24 -j SNAT --to-source 192.168.2.11


# 对端，即服务器端，Peer属性
[Peer]
# 服务端的公钥；
PublicKey = Server public key
# 允许对端的IP流量
AllowedIPs = IP Range
# 服务端的IP与端口；
Endpoint = 1.1.1.1:28385
# 每10秒发送keepalive心跳；
PersistentKeepalive = 10

```

配置完毕后，启动WireGuard服务

```sh
wg-quick up wg0
```

开启内核IP包转发

```sh
# 编辑 /etc/sysctl.conf， 
vim /etc/sysctl.conf
# 将 net.ipv4.ip_forward = 0 中的 0 改为 1。
net.ipv4.ip_forward = 1
# sysctl -p 使其生效。
sysctl -p
```

# WireGuard 的缺陷

https://www.cnblogs.com/ryanyangcs/p/14339053.html

## 复杂度

作为终端用户，其实无需考虑协议的复杂度。

如果复杂度真的影响很大，我们肯定早就摆脱 SIP、 H.323 和 FTP 等不能很好地应对NAT的协议了，然而并没有。讲道理，IPsec 比 WireGuard 更复杂是有原因的：它能做的事情太多了。
比如，使用用户名/密码或带有 EAP 的 SIM 卡进行用户认证；也可以扩展新的加密方式。

而 WireGuard 呢？这些功能都没有。这就意味着当某一天它的固定的那些加密方式被破解或削弱了之后，就彻底崩盘了。

```官方
WireGuard 在加密方式上比较偏执，故意砍掉了加密协议的敏捷性，不支持扩展加密协议，因为这么做会大大降低软件的复杂度。如果底层的加密协议出现了漏洞，只能更新所有端点来修复漏洞。
```

## 更新密钥

当 WireGuard 密钥更新后，每一个客户端需要更新配置文件中的 服务端的公钥；

## 加密方式

WireGuard 使用以下加密技术来保障数据的安全：

- 使用 ChaCha20 进行对称加密，使用 Poly1305 进行数据验证。
- 利用 Curve25519 进行密钥交换。
- 使用 BLAKE2 作为哈希函数。
- 使用 HKDF 进行解密。

而 IPSec 和 OpenVPN 使用的都是标准的 ChaCha20-Poly1305 加密算法。

BLAKE2算法是 BLAKE 算法的升级版，而 BLAKE 是 SHA-3 的入围者，与 SHA-2 非常相似，所以没有获奖。如果哪天 SHA-2 被破解了，BLAKE 也很有可能被破解。

IPSec 和 OpenVPN 使用的加密方式和 WireGuard 是类似的，比如对称加密使用的是标准的 ChaCha20-Poly1305 算法。唯一没有用到的就是 BLAKE2，因为它目前没有列入标准。即使不用 BLAKE2，也没什么大不了的，因为 VPN 是使用 HMACs 来保障数据的完整性，即使使用 MD5 也仍然没问题。

我的结论是：实际上所有的 VPN 都可以使用相同的加密技术，WireGuard 在加密或数据完整性方面并没有比其他的 VPN 更安全或更不安全。

然而白皮书上说了，加密不是重点，速度才是。

# 故障处理

## AllowedIPs 进行ACL 设置

AllowedIPs控制了哪些流量允许使用该vpn，未匹配的流量会直连。个人翻墙时会使用全局VPN，但服务器之间连接时，基本不会把wiregaurd当做全局VPN使用。设置这里就非常方便。

AllowedIPs = 0.0.0.0/0,::/0 表示所有ipv4及ipv6的流量都要走vpn，适合个人用户。
AllowedIPs = 10.10.0.0/24,192.168.1.0/24 表示只有目的IP是这两个网段时走wireguard,其余流量走服务器默认的路由。

## 查看日志

wireguard的客户端都会有连接的日志，查看wireguard服务器端日志只能通过查看内核日志的方方式，内核要支持Dynamic Debugging,正常情况下需编译内核开启CONFIG_DYNAMIC_DEBUG，有些发型版已经默认开启。可以执行以下命令进行查看：

```sh
mount | grep debug
debugfs on /sys/kernel/debug type debugfs (rw,relatime)

# 配置开启调试日志
modprobe wireguard 
echo module wireguard +p > /sys/kernel/debug/dynamic_debug/control

# 查看
 dmesg -wH
 journalctl -kf
```

## 报错1: linux做为客户端时启动wireguard报错： RTNETLINK answers: Operation not supported

该报错需重启服务器或客户端

## 报错2: vpn服务器ping客户端时报错： ping: sendmsg: Required key not available

该错最有可能是服务器端的peer部分AllowedIPs配置不对，网上一些教程使用SaveConfig=true，该配置是在关闭或重启wireguard时才添加配置，导致如果客户端连接后如果服务器端未重启，就会出现该错误，不建议使用saveConfig=true。

## 报错3: 服务器端ping客户端时提示： ping: sendmsg: Destination address required
一般是服务器端更改配置后，客户端未重新连接，客户端重新连接即可

## 报错4: 启动wireguard时报错： Error: Unknown device type. Unable to access interface: Protocol not supported 或执行 modprobe wireguard 命令报错： modprobe: FATAL: Module wireguard not found in directory

这个错误通常是因为升级内核导致的，wireguard的内核模块安装在旧版内核上，新内核没有wireguard模块，解决方法是卸载旧版内核、旧版kernel-header、旧版kernel-devel等,重新安装wireguard即可。

# 参考资料

WireGuard 安装说明： https://www.wireguard.com/install/
使用 WireGuard 无缝接入内网: https://devld.me/2020/07/27/wireguard-setup/
https://blog.d0zingcat.dev/p/vpn-connect-work-home/
https://opswill.com/articles/wireguard-howtos.html