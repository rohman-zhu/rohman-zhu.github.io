---
title: OS内使用ipmitools指令修改服务器BMC的IP
tags:
  - default
categories:
  - 服务器与存储
  - 服务器
date: 2022-05-22 16:46:35
---
# 背景

不能重启服务器的前提下，需要修改BMC的IP。

# 设置方法

带外IP，可以在操作系统内更改；带外都是基于ipmi的，所以都可以用ipmitools去修改。主要流程为：

1. 设置IP
2. 设置网关
3. 重启bmc生效

# Windows 操作系统下的操作

Windows用ipmiutil指令

```ps1
# 显示当前BMC的网络设置
ipmiutil lan
# 设置 IP
ipmiutil lan -e -I x.x.x.x
# 设置 子网掩码
ipmiutil lan -e -S x.x.x.x
# 设置 默认网关
ipmiutil lan -e -G x.x.x.x 
# 重启BMC
ipmiutil reset -k
```
# Linux 操作系统下的操作

Linux用ipmitools指令

```sh
# 显示当前BMC的网络设置
ipmitool lan print 1
# 设置 IP
ipmitool lan set 1 ipaddr x.x.x.x
# 设置 子网掩码
ipmitool lan set 1 netmask x.x.x.x
# 设置 默认网关
ipmitool lan set 1 defgw ipaddr x.x.x.x
# 重启BMC
ipmitool bmc reset cold
```

如果出现异常“Could not open device at /dev/ipmi0 or /dev/ipmi/0 or /dev/ipmidev/0: No such file or directory”,可以执行以下指令:

```sh
# 加载以下模块
modprobe ipmi_watchdog
modprobe ipmi_poweroff
modprobe ipmi_devintf
modprobe ipmi_si  加载该模块如果没有不影响ipmi的使用（与系统版本有关）
modprobe ipmi_msghandler  加载该模块如果没有不影响ipmi的使用
```

# 参考资料

- 包下载地址：http://ipmiutil.sourceforge.net/
- Linux与Windows指令参考：https://portal.nutanix.com/page/documents/kbs/details?targetId=kA0600000008T3jCAE
- Linux下IPMI指令异常： https://www.cnblogs.com/samuel610/p/10868804.html

