---
title: Vmware给Linux虚拟机热添加硬盘并创建LVM分区实例
date: 2018-11-07 22:46:14
tags: 
- 虚拟化
catergories:
- Linux
---

# 前言

一般情况下，虚拟机肯定会有硬盘扩容的需求，而且大多数生产环境下，机器还不允许关机添加。目前遇到可以热添加的是Vmware的虚拟机，用的scsi硬盘，因此做一下操作记录，以便复习。

# 操作记录

在Vmware的控制面板上，添加scsi硬盘即可。

进入Linux系统则需要扫描scsi硬件。

```shell
# 输入以下指令
echo "- - -" > /sys/class/scsi_host/host*/scan
# 这里 - - - 之间有两个空格
# host* 不会生效，目前不知道原因
```

改进版扫描脚本v1

```shell
#!/bin/bash
hostNumber=0
# 因为 scsi_host 文件夹下又33个host文件夹
while [ $hostNumber -l 33]
do
    echo "$hostNumber. host has been scaned."
    echo "- - -" > /sys/class/scsi_host/host$hostNumber/scan
    hostNumber=$(( hostNumber + 1 ))
done
```

给脚本添加执行权限即可。

运行脚本后，扫描到新添加的硬盘 sdb ，接下来开始创建LVM分区

```shell
fdisk /dev/sdb

#---fdisk---
# 创建分区
n
# 选择主分区
p
# 分区编号，默认为1
1
# 起始扇区 ，默认即可
回车
# 结束扇区，默认即可
回车
# 更改分区类型
t
# 选择需要更改的分区
1
# 改为 LVM 类型
8e
# 写入分区表
w
#---fdisk---

# 创建 pv
pvcreate /dev/sdb1
# 创建 vg
vgcreate vg-data /dev/sdb1
# 创建 lv
lvcreate -n lv-data -l 100%VG vg-data
# 格式化lv
mkfs.ext4 /dev/vg-data/lv-data
# 挂载lv
mount /dev/vg-data/lv-data /data
# 修改 fstab 列表
#---fstab---
/dev/mapper/vg-data-lv-data /data ext4 default 0 0
#---fstab---
```

# 补充知识点

## Linux系统SCSI磁盘扫描机制解析及命令详细介绍

Linux系统提供多重机制以重新扫描SCSI总线并重认系统中加入的SCSI设备。
在2.4内核方案中，由于动态LUN扫描机制不具备一致性，往往需要中断I/O。
在2.6内核里，LUN扫描有了显著改进并添加了动态LUN扫描机制。
Linux目前缺乏像drvconfig或ioscan那样允许动态SCSI通道重配的命令。

Linux主机对磁盘设备进行重新配置的方式包括：

- 重启系统
- 卸载并重新加载HBA驱动模块
- echo /proc下的SCSI设备列表
- 通过/sys下的属性设置运行SCSI扫描
- 通过HBA厂商脚本运行SCSI扫描

### 系统重启

重启主机是检测新添加磁盘设备的可靠方式。在所有I/O停止之后方可重启主机，同时静态或以模块方式连接磁盘驱动。系统初始化时会扫描PCI总线，因此挂载其上的SCSI host adapter会被扫描到，并生成一个PCI device。之后扫描软件会为该PCI device加载相应的驱动程序。加载SCSI host驱动时，其探测函数会初始化SCSI host，注册中断处理函数，最后调用scsi_scan_host函数扫描scsi host adapter所管理的所有scsi总线。

### 重新加载HBA驱动

通常情况下，HBA驱动在系统中以模块形式加载。从而允许模块被卸载并重新加载，在该过程中SCSI扫描函数得以调用。通常，在卸载HBA驱动之前，SCSI设备的所有I/O都应该停止，卸载文件系统，多路径服务应用也需停止。如果有代理或HBA应用帮助模块，也应当中止。

命令示例：
例如，rac节点上某台服务器执行fdisk –l命令看不到共享磁盘，可尝试执行如下命令：

```sh
# 卸载驱动
modprobe -r lpfc
# 加载驱动
modprobe lpfc
```

### /proc下SCSI扫描

2.4内核中，/proc文件系统提供了可用SCSI设备的列表。如果系统中SCSI设备重新配置，那么所有这些改变通过echo /proc接口反映到SCSI设备中。添加一个设备，主机，channel，target ID，以及磁盘设备的LUN编号会被添加到/proc/scsi/，需指定scsi编号。

命令示例：

```sh
# 0：主机ID
# 1：channel ID
# 2：target ID
# 3：LUN编号

echo "scsi add-single-device 0 1 2 3" > /proc/scsi/scsi
```

该命令会将新磁盘设备添加到/proc/scsi/scsi文件中。如果没有找到相应文件，需为/dev路径下新增磁盘设备创建设备文件名。
如果要删除一个磁盘设备，使用适当的主机，channel，target ID及LUN编号运行如下格式命令：

```sh
# 0：主机ID
# 1：channel ID
# 2：target ID
# 3：LUN编号
echo "scsi remove-single-device 0 1 2 3" > /proc/scsi/scsi
```

### /sys下SCSI扫描

2.6内核中，HBA驱动将SCAN功能导出至/sys目录下，可用来重新扫描该接口下的SCSI磁盘设备。命令如下：

```sh
cd /sys/class/scsi_host/host4/
ls -al scan
echo ‘- - -’ > scan
# ‘- - -’代表channel，target和LUN编号。以上命令会导致hba4下所有channel，target以及可见LUN被扫描。

# RHEL5 或SUSE10：
echo ‘- - -’ > /sys/class/scsi_host/host0/scan
#/sys/class/scsi_host/ 下面有几个host 就扫描几次

# RHEL4 或SUSE9：
echo 1 >> /sys/class/scsi_host/host0/issue_lip

# 同样是/sys/class/scsi_host/ 下面有几个host 就执行几次
echo ‘- - -’ >> /sys/class/scsi_host/host0/scan
```

# 参考资料

https://www.jb51.net/LINUXjishu/67115.html