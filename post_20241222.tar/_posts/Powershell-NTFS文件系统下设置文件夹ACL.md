---
title: Powershell-NTFS文件系统下设置文件夹ACL
tags:
  - default
categories:
  - Windows Server
  - Powershell
date: 2024-07-28 16:22:05
---
# 需求

通过脚本，设置C盘根目录下除了用户文件，其他文件夹禁止用户写入数据；

# 实现方式

对C盘根目录设置 ACL，主要有以下三点：

1. 仅对 C 盘 此目录；
2. 设置用户范围为 BUILTIN\Users；
3. 设置 拒绝写入；

# 目录权限拟定方案

| 目录 | 范围 | 权限 | 动作 |
|:---|:---|:---:|:---|
| C:| folder | Write | Deny |
| Custom Folder | folder,sub folder,file | FullControl | Deny | 
| PerfLogs | DEFAULT | DEFAULT | DEFAULT | 
| Program Files | DEFAULT | DEFAULT | DEFAULT | 
| Program Files(x86) | DEFAULT | DEFAULT | DEFAULT | 
| Users | DEFAULT | DEFAULT | DEFAULT | 
| Windows | DEFAULT | DEFAULT | DEFAULT | 



> 获取隐藏目录，Get-ChildItem [path] -Force

# 实现过程

## v1

对指定目录设置禁止写入

```ps1
<#Golbal Constant #>
$ACL_BASE_PERMISSION_FULLCONTROL="FullControl";
$ACL_BASE_PERMISSION_WRITE="Write";
$ACL_BASE_PERMISSION_READ="Read";

$ACL_ACCESS_CONTROL_TYPE_ALLOW="Allow";
$ACL_ACCESS_CONTROL_TYPE_DENY="Deny";

# 备注：可以让C盘拒绝写入
Function Set-TargetFolderToDenyWrite(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Users";
    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_WRITE,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);
    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_WRITE -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}

# 备注：非系统目录，则可以设置完全拒绝
Function Set-TargetFolderToDenyFC(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Remote Desktop Users";
    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);
    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_FULLCONTROL -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}
```
 
> 注意：上述动作仅对路径中的绝对目录生效，子目录是不生效的；

## v2

对指定目录设置禁止写入，并启用继承；

```ps1
<#Golbal Constant #>
$ACL_BASE_PERMISSION_FULLCONTROL="FullControl";
$ACL_BASE_PERMISSION_WRITE="Write";
$ACL_BASE_PERMISSION_READ="Read";

$ACL_ACCESS_CONTROL_TYPE_ALLOW="Allow";
$ACL_ACCESS_CONTROL_TYPE_DENY="Deny";

# 备注：可以让C盘拒绝写入
Function Set-TargetFolderToDenyWrite(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Users";
    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_WRITE,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);
    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_WRITE -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}

# 备注：非系统目录，则可以设置完全拒绝
Function Set-TargetFolderToDenyFC(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Remote Desktop Users";
    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);

    #$NewAcl.SetAccessRuleProtection($isProtected, $preserveInheritance)
    # $isProtected = $TRUE,表示禁用继承；
    # $preserveInheritance = $TRUE,表示继承的权限保存；
    # 第一个参数负责阻止从父文件夹继承，$FALSE为继承父目录权限;
    # 第二个参数用于删除当前继承的权限，$TRUE为不删除当前继承的权限;    
    #$CURRENT_ACL.SetAccessRuleProtection($FALSE,$TRUE);

    # 第一个参数负责阻止从父文件夹继承，$TRUE为不继承父目录全新；
    # 第二个参数用于删除当前继承的权限，$FALSE为删除当前继承的权限;
    #$CURRENT_ACL.SetAccessRuleProtection($TRUE,$FALSE);

    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_FULLCONTROL -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}
```

> 这个版本仅设置的是目标目录，作用范围仅是“此目录”；

## v3

要对 “此文件夹、子文件夹、文件”设置权限。

```ps1
<#Golbal Constant #>
$ACL_BASE_PERMISSION_FULLCONTROL="FullControl";
$ACL_BASE_PERMISSION_WRITE="Write";
$ACL_BASE_PERMISSION_READ="Read";

$ACL_ACCESS_CONTROL_TYPE_ALLOW="Allow";
$ACL_ACCESS_CONTROL_TYPE_DENY="Deny";

# 备注：可以让C盘拒绝写入
Function Set-TargetFolderToDenyWrite(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Users";
    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_WRITE,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);
    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_WRITE -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}

# 备注：非系统目录，则可以设置完全拒绝
# 范围：目标目录，“此目录”
Function Set-TargetFolderToDenyFC(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Remote Desktop Users";
    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);


    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_FULLCONTROL -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}

# 备注：非系统目录，则可以设置完全拒绝
# 范围：此目录，子目录，文件
Function Set-TargetFolderALLToDenyFC(){
    param($TARGET_FOLDER);
    $IS_DENY_USER_ACL=$FALSE;

    $TARGET_USER="Remote Desktop Users";
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::None

    $CURRENT_ACL=Get-ACL $TARGET_FOLDER;
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);
    $CURRENT_ACL.SetAccessRule($ACCESS_RULE);


    $CURRENT_ACL | Set-ACL -Path $TARGET_FOLDER;

    $CURRENT_ACL=Get-ACL -Path $TARGET_FOLDER;
    $CHECK_STATUS=$CURRENT_ACL.Access | Where-Object {$_.FileSystemRights -eq $ACL_BASE_PERMISSION_FULLCONTROL -and $_.AccessControlType -eq $ACL_ACCESS_CONTROL_TYPE_DENY -and $_.IdentityReference -match "BUILTIN\\$TARGET_USER"};

    if($null -ne $CHECK_STATUS){
        $IS_DENY_USER_ACL=$TRUE;
    }

    return $IS_DENY_USER_ACL;
}
```



# 参考

https://blog.51cto.com/ganzy/6926601
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.security/set-acl?view=powershell-7.4


## 来自 https://www.codenong.com/3282656/

```ps1
# 关于NTFS各个目录范围设置列举：

    ╔═════════════╦═════════════╦═══════════════════════════════╦════════════════════════╦══════════════════╦═══════════════════════╦═════════════╦═════════════╗
    ║             ║ folder only ║ folder, sub-folders and files ║ folder and sub-folders ║ folder and files ║ sub-folders and files ║ sub-folders ║    files    ║
    ╠═════════════╬═════════════╬═══════════════════════════════╬════════════════════════╬══════════════════╬═══════════════════════╬═════════════╬═════════════╣
    ║ Propagation ║ none        ║ none                          ║ none                   ║ none             ║ InheritOnly           ║ InheritOnly ║ InheritOnly ║
    ║ Inheritance ║ none        ║ Container|Object              ║ Container              ║ Object           ║ Container|Object      ║ Container   ║ Object      ║
    ╚═════════════╩═════════════╩═══════════════════════════════╩════════════════════════╩══════════════════╩═══════════════════════╩═════════════╩═════════════╝

# folder only
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::None
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::None
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);

# folder, sub-folders and files
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::None
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);

# folder and sub-folders 
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::None
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);

# folder and files
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::None
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);

# sub-folders and files
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::InheritOnly
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);

# sub-folders
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::InheritOnly
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);

# files
    $INHERITANCE_FLAG = [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    $PROPAGATION_FLAG = [System.Security.AccessControl.PropagationFlags]::InheritOnly
    $ACCESS_RULE=New-Object System.Security.AccessControl.FileSystemAccessRule($TARGET_USER,$ACL_BASE_PERMISSION_FULLCONTROL,$INHERITANCE_FLAG,$PROPAGATION_FLAG,$ACL_ACCESS_CONTROL_TYPE_DENY);
```