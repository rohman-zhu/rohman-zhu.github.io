---
title: Vmware Horizon View添加证书
tags:
  - Vmware Horizon View
catergories:
  - Vmware Horizon View
date: 2020-05-01 15:08:10
---
# 前言

默认情况下，在安装连接服务器或安全服务器时，安装程序会为服务器生成一个自签名证书。但在以下情况中，安装程序仍使用现有证书：

- 如果 Windows 证书存储区中已存在友好名称为 vdm 的有效证书
- 如果您从较早版本升级到 Horizon 7，且在 Windows Server 计算机上配置了有效的密钥存储文件，则安装会提取密钥和证书，并将其导入到 Windows 证书存储区中。

# 生成证书

```sh
openssl pkcs12 -export -out outputFile.pfx -inkey privateKey.key -in certification.crt -cerfile rootCertification.crt
```

# 连接服务器中添加证书

- 新签发的证书将添加到 Windows 证书存储区内的个人 > 证书文件夹。
- 对于连接服务器实例或安全服务器，请将证书的友好名称修改为 vdm。

详细操作：

1. 在 Windows Server 主机上的 MMC 窗口中，展开证书 (本地计算机) 节点并选择个人文件夹。
2. 在“操作”窗格中，转到更多操作 > 所有任务 > 导入。
3. 在证书导入向导中，单击下一步并浏览至存储证书的位置。
4. 选择证书文件并单击打开。
5. 要显示您的证书文件类型，可以从 文件名下拉菜单中选择其文件格式。
5. 键入证书文件中所含私钥的密码。
6. 选择将此密钥标记为可导出。
7. 选择包含所有已扩展属性。
8. 单击下一步，然后单击完成。
9. 新证书会显示在 证书 (本地计算机) > 个人 > 证书文件夹中。
9. 确认新证书包含私钥。
  1. 在证书 (本地计算机) > 个人 > 证书文件夹中，双击新证书。
  2. 在“证书信息”对话框的“常规”选项卡中，确认显示有以下语句：您有一个与该证书对应的私钥 (You have a private key that corresponds to this certificate)。
10. 将证书的友好名称改为 vdm。


# 验证

# 参考资料

https://docs.vmware.com/cn/VMware-Horizon-7/7.12/horizon-installation/GUID-80CC770D-327E-4A21-B382-786621B23C44.html