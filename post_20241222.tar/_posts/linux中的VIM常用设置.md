---
title: linux中的VIM常用设置
date: 2019-01-08 22:18:49
tags: Linux
---
# 前言

Linux中的VIM是一个比较常用的文本编辑器，有些初始化设置可以提前设置好。

# vim的配置文件 .vimrc

* 系统配置 /usr/share/vim/.vimrc , 可以用echo $VIM 确定 VIM 的安装目录。
* 用户 vimrc 文件，放在～/.vimrc , 可以用 echo $HOME 来确定用户主目录。

> 优先级: 用户 vimrc 文件 > 系统的 vimrc 文件

# 修改配置文件

按照我个人需求来按顺序记录，需求最高的写第一个，以此类推。

## 设置行号

```shell
set nu
# nu 是 number 缩写 ， 因此上下两行的效果是一致的。
set number
```

## 设置缩进

```shell
# 设置 tab 长度为4个空格
set tabstop=4
# 设置自动缩进的长度为4个空格
set shiftwidth=4
# 继承前一行的缩进方式，适用于多行注释
set autoindent
```

## 支持中文

```shell
# fileencoding选项是Vim写入文件时采用的编码类型；
set fileencodings=utf-8,ucs-bom,gb18030,gbk,gb2312,cp936
# termencoding选项表示输出到终端时采用的编码类型。
set termencoding=utf-8
# encoding选项用于缓存的文本、寄存器、Vim 脚本文件等
set encoding=utf-8
```

；fileencoding选项是Vim写入文件时采用的编码类型；termencoding选项表示输出到终端时采用的编码类型。

# 参考资料

* VIM入门级基础配置：https://segmentfault.com/a/1190000016330314