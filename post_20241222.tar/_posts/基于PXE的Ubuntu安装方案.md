---
title: 基于PXE的Ubuntu安装方案
tags:
  - PXE
  - Ubuntu
categories:
  - Linux
date: 2020-11-29 23:37:58
---

# 需求分析

1. 一批物理服务器，需要安装Ubuntu 18.04 ，并且有一些定制化的需求，例如内核、软件、驱动等。
2. 物理服务器支持PXE启动，并且系统管理员有限，没有多余的带宽来部署服务器。

# 实现方案

1. 先将一台服务器按照需求安装好对应的功能，例如内核升级、驱动安装等，将服务器所有文件打包成镜像(ESP,boot,根目录)。
2. 在服务器同网段中部署一台PXE Server（包含 DHCP 、 TFTP 、WEB 、 NFS功能），并且部署可以通过PXE启动的镜像。（类似网络PE操作系统）
3. 客户端接入PXE Server，获取到分配的IP，进入PXE的预装系统，执行硬盘分区、系统还原等操作后，重建引导程序后重启。

# 需求拆分

## 定制化的操作系统

业务方需求：

1. 要以UEFI启动，因此需要ESP分区，vfat格式。
2. 文件系统要为XFS，因此boot分区要单独划分，并以 ext4 进行格式化。
3. 系统要为Ubuntu 18.04 ，并且执行一些定制化需求。

> TODO问题1：xfs格式与ext4格式存在冲突问题，会导致无法识别到文件系统，当前未明白原因。

完成安装后，通过rsync进行备份打包

```sh
rsync -aPpv --exclude={"/mnt/*","/sys/*","/proc/*","/dev/*","/tmp/*"} / /mnt/template/ | tee /mnt/template/rsync.log

# -a 执行完全备份
# -P 显示进程
# -p 保留文件属性
# -v 打印日志
```

## 部署PXE服务器

1. 基于Ubuntu 18.04搭建，需要安装的服务 apach2 、 nfs-kernel-server 、 dnsmasq 。
2. 制作启动镜像，需要重建kernel，避免无法通过pxe引导进入操作系统。
3. 模板还原的操作需要通过脚本执行。

### 部署细节

关于nfs的镜像，需要给rw权限，避免在做LVM的时候无法写入

```sh
vim /etc/export
#---
/var/www/html/pxeos *(rw...)
#---

#检查共享列表
exportfs -a
```

关于 DHCP与TFTP服务

```sh
#配置文件
vim /etc/dnsmasq.conf

```

TODO问题列表：

1. PXE引导的grub菜单是哪一个文件提供的，是pxelinux.cfg/default , 还是 /tftp/grub/grub.cfg ，暂时没有理清楚是哪一个文件导致引导不同。
2. 通过还原的服务器，已经重新做了grub.cfg文件、安装了refind启动程序；在启动的时候，直接进入grub，并且提示 unknow filesystem 。


