---
title: 如何将VCSA的SYSLOG转发至ELK【待补充】
tags:
  - syslog
categories:
  - VMware
date: 2021-09-14 22:44:08
---

# 需求

部署了一套ELK环境，需要将vCenter的日志转发至ELK。但是ELK接入日志的要求：

1. 接入的日志要为 json 格式；
2. 时间格式有要求；

但是 vCenter 的输出日志不能直接为 json 格式，ELK无法解析此日志。

# 方案说明

1. 部署一台 rsyslog 日志服务器，用于接收vCenter的日志。
2. 将接收到的日志转为json格式。
3. 将日志转至ELK服务器。

# 前置工作准备

## 信息梳理与规划

| IP | 角色 | 备注 |
|:----:|:------:|:------:|
|IP1|syslog服务器||
|IP2|VCSA服务器||
|IP3|ELK服务器-接收日志||

## 防火墙梳理

| SRC | DST | TCP-Port | UDP-Port | 作用 |
|:-----:|:-----:|:-----:|:----:|:----:|
| VCSA服务器地址 | syslog服务器地址 | 514（可自定义） |  | 将VCSA日志传至syslog|
| syslog服务器地址 | ELK服务器 | 自定义 | |将syslog日志转至ELK服务器|

## syslog服务器信息

- OS：CentOS 7.5-1804
- rsyslog版本： xxx

# 实施阶段

## 安装rsyslog

```sh
yum install rsyslog -y
```

## 配置syslog接收模板

常规配置则为：

```config
#[系统类型].[消息类型]  [日志存放至某一个目录]
#例如：mail.info   /var/log/mail/logs
#解释：表示邮件系统的info日志，存放至/var/log/mail/logs文件中

#若对输出日志有格式要求，可以定义模板；完成定义后，再去应用模板
#模板定义Template
#Template(name="模板名" type="类型")(具体描述)
#使用模板
#[系统类型].[消息类型]  [日志存放至某一个目录];[模板名]
```

json格式简单解释

```confi
#json格式定义
#{}或括号包住头尾
#每一对键值用,隔开
#键与值之间用:隔开
#键与值都需要用""包起来
#例如
#{"键1":"值1","键2","值2"}
#
```

定义list类型模板，可将输出类型转至json格式

```config
Template(name="toJson" type="list"){
  constant("{"})

  constant("}\n")
}
```

## 配置filebeat

## 验证


# 参考资料

《使用Rsyslog进行VMware vSphere和vCenter重要日志管理》 ： https://www.ywnz.com/linuxyffq/4328.html

《将 vCenter Server Appliance日志文件转发到 远程 Syslog 服务器》：https://docs.vmware.com/cn/VMware-vSphere/6.7/com.vmware.vsphere.vcsa.doc/GUID-9633A961-A5C3-4658-B099-B81E0512DC21.html
《rsyslog模板解释》：https://www.cnblogs.com/cherishry/p/6776407.html
《rsyslog输出至json格式》：https://www.iyunv.com/thread-144079-1-1.html

