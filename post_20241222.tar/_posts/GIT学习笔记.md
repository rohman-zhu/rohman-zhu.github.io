---
title: GIT学习笔记
date: 2017-06-11 15:14:37
tags: GIT
categories: GIT学习笔记
---


# 设置GIT的配置信息
```
$ git config --global user.email "you@example.com"
$ git config --global user.name "Your Name"
```



<br>
<br>
<br>
<br>

# ---以下内容后不需要联网,本地操作即可---

<br>
<br>
<br>
<br>


# 创建一个空的文件夹作为本地仓库

打开CMD 或者 Terminal 命令行控制窗口
```
$ mkdir LearnGit
$ cd LearnGit
$ pwd
\...\LearnGit\
```
注解:

1. mkdir + 'directory_name' 是创建文件夹命令.
2. cd + 'directory_name' 是进入指定文件夹命令.
3. pwd 是显示当前路径的命令.
4. cd + '..'是返回上级目录.

# 使当前文件夹作为GIT仓库
```
$ git init
```
注解:
1. ls 显示当前目录下的可见文件与文件夹
2. ls -ah 显示当前目录下所有隐藏文件夹



# 添加文件到仓库
```
$ git add <file> [<file2>]

$ git commit - m "本次提交的版本说明,这样就能从历史记录中找到改动记录"
```

# 修改本地文件
```
$ vim readme.txt
//添加内容
```

查看Git仓库的状态

```
$ git status
```

会发现一下内容

```
$ git status
# On branch master
# Changes not staged for commit:
#   (use "git add <file>..." to update what will be committed)
#   (use "git checkout -- <file>..." to discard changes in working directory)
#
#    modified:   readme.txt
#
no changes added to commit (use "git add" and/or "git commit -a")
```

modified 表示有修改的地方.上面的命令告诉我们，readme.txt被修改过了，但还没有准备提交的修改。

如果我们要看哪里修改了,可以输入:
```
$ git diff "被修改的文件"
```

会出现以下内容

```
$ git diff readme.txt 
diff --git a/readme.txt b/readme.txt
index 46d49bf..9247db6 100644
--- a/readme.txt
+++ b/readme.txt
@@ -1,2 +1,2 @@
-Git is a version control system.
+Git is a distributed version control system.
 Git is free software.
 ```

 注解:
 1. "-"表示删除的内容
 2. "+"表示增加的内容

# 查看提交日志
```
$ git log 
```

会出现以下内容:

```
commit f86e14f9b45add275f9008dcbb3c72eb4e39eef3 (HEAD -> master)
Author: R0manJ <zhur0ngjian@126.com>
Date:   Fri Jun 9 08:51:49 2017 +0800

    add a statement

commit 1d5282852e4e6b967c2fbf8c06dec5f125afdce3
Author: R0manJ <zhur0ngjian@126.com>
Date:   Fri Jun 9 08:49:57 2017 +0800

    add 2 files

commit 31497a8b6e1503181fd39591d35c016c37b895df
Author: R0manJ <zhur0ngjian@126.com>
Date:   Fri Jun 9 08:48:41 2017 +0800

    wrote a readme file
```

我总共提交了3次,所以这里就会出现3个日志,并且每一个提交都有描述,如"add a statement".

----

### 以下是简化输出日志信息的方法

输入:
```
$ git log --pretty=oneline
```

会看到:
```
f86e14f9b45add275f9008dcbb3c72eb4e39eef3 (HEAD -> master) add a statement
1d5282852e4e6b967c2fbf8c06dec5f125afdce3 add 2 files
31497a8b6e1503181fd39591d35c016c37b895df wrote a readme file
```

_注解:_

看到的一大串类似3628164...882e1e0的是commit id（版本号），和SVN不一样，Git的commit id不是1，2，3……递增的数字，而是一个SHA1计算出来的一个非常大的数字，用十六进制表示，而且你看到的commit id和我的肯定不一样，以你自己的为准。为什么commit id需要用这么一大串数字表示呢？因为Git是分布式的版本控制系统，后面我们还要研究多人在同一个版本库里工作，如果大家都用1，2，3……作为版本号，那肯定就冲突了。

# 返回之前的版本

* 首先要知道当前是什么版本

    在Git中，用HEAD表示当前版本，也就是最新的提交3628164...882e1e0（注意我的提交ID和你的肯定不一样），上一个版本就是HEAD^，上上一个版本就是HEAD^^，当然往上100个版本写100个^比较容易数不过来，所以写成HEAD~100。

* 使用 git reset 命令恢复之前的版本
    ```
    $ git reset --hard HEAD^
    ```

# 撤销恢复
    
需要记得之前的 _commit id_ ,再用命令 "git reset" 命令.

    ```
    $ git reset --hard f86e14f9b45add275f9008dcbb3c72eb4e39eef3
    ```


> 这个图片是 _廖雪峰_ 的GIT教程里面的,链接为:http://www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000/0013744142037508cf42e51debf49668810645e02887691000


![版本控制_HEAD](http://www.liaoxuefeng.com/files/attachments/001384907584977fc9d4b96c99f4b5f8e448fbd8589d0b2000/0)

![版本控制_HEADN](http://www.liaoxuefeng.com/files/attachments/001384907594057a873c79f14184b45a1a66b1509f90b7a000/0)

其实就是将 _HEAD_ 指向的内容改一下而已

# 记录每次Git操作命令
```
$git reflog
```


# GIT的文件结构

## 工作区（Working Directory）
就是你在电脑里能看到的目录，比如我的learngit文件夹就是一个工作区：

![工作区](http://www.liaoxuefeng.com/files/attachments/0013849082162373cc083b22a2049c4a47408722a61a770000/0)

## 版本库（Repository）

工作区有一个隐藏目录.git，这个不算工作区，而是Git的版本库。

Git的版本库里存了很多东西，其中最重要的就是称为stage（或者叫index）的暂存区，还有Git为我们自动创建的第一个分支master，以及指向master的一个指针叫HEAD。

<br>

![版本库](http://www.liaoxuefeng.com/files/attachments/001384907702917346729e9afbf4127b6dfbae9207af016000/0)

# 撤销修改
```
$ git checkout -- readme.txt
```

_注解_:
把readme.txt文件在工作区的修改全部撤销，这里有两种情况：

一种是readme.txt自修改后还没有被放到暂存区，现在，撤销修改就回到和版本库一模一样的状态；

一种是readme.txt已经添加到暂存区后，又作了修改，现在，撤销修改就回到添加到暂存区后的状态。

# 删除文件
```
//确认要删除的文件请求
$ rm test.txt
//提交请求
$git commit -m "Remove test.txt"
//撤销删除并且恢复到最新的版本
$git checkout --test.txt
```

<br>
<br>

<br>
<br>

# -------以下内容是需要联网操作-------


<br>
<br>

<br>
<br>

请自行注册GitHub账号。由于你的本地Git仓库和GitHub仓库之间的传输是通过SSH加密的，所以，需要一点设置：

# 第1步 ：创建SSH Key。
>在用户主目录下，看看有没有.ssh目录，如果有，再看看这个目录下有没有id_rsa和id_rsa.pub这两个文件，如果已经有了，可直接跳到下一步。如果没有，打开Shell（Windows下打开Git Bash），创建SSH Key：

```
$ssh-keygen -t rsa -C "youremail@example.com"
```

<br>

接下来会让你设置密码,这个密码是用于上传文件到仓库时用到.

<br>

输入完后,可以在用户主目录里找到.ssh目录，里面有id_rsa和id_rsa.pub两个文件，这两个就是SSH Key的秘钥对，id_rsa是私钥，不能泄露出去，id_rsa.pub是公钥，可以放心地告诉任何人。

# 第2步 : 在GITHUB中添加SSH KEY

登陆GitHub，打开“Account settings”，“SSH Keys”页面：

然后，点“Add SSH Key”，填上任意Title，在Key文本框里粘贴id_rsa.pub文件的内容：

![添SSH_KEY](http://www.liaoxuefeng.com/files/attachments/001384908342205cc1234dfe1b541ff88b90b44b30360da000/0)

为什么GitHub需要SSH Key呢？因为GitHub需要识别出你推送的提交确实是你推送的，而不是别人冒充的，而Git支持SSH协议，所以，GitHub只要知道了你的公钥，就可以确认只有你自己才能推送。

当然，GitHub允许你添加多个Key。假定你有若干电脑，你一会儿在公司提交，一会儿在家里提交，只要把每台电脑的Key都添加到GitHub，就可以在每台电脑上往GitHub推送了。

最后友情提示，在GitHub上免费托管的Git仓库，任何人都可以看到喔（但只有你自己才能改）。所以，不要把敏感信息放进去。

<br>
<br>

```
1、删除文件命令

rm -f 文件名

将会强行删除文件，且无提示

2、删除文件夹以及文件夹中的所有文件命令：

rm -rf  目录名字

其中：

-r：向下递归删除

-f：直接强行删除，且没有任何提示

注意：
使用rm -rf要格外注意，linux中没有回收站，慎重操作。
```

## 遇到的问题

1. ERROR:Your push would publish a private email address.
    - 出现这个问题,只用将Github账号中的邮箱设置为公开的即可


2. ERROR:Permission denied (publickey).
    - 这个问题主要是因为自定义了ssh的路径的,暂时无解......
    - 在生成ssh的时候,路径就按照默认的即可
    - 一般默认的会生成3个文件,分别是 id_rsa  ,  id_rsa.pub  ,  knowhost

## 远程仓库的操作

- 删除
```
$ git remote rm "仓库名"
```

- 创建仓库
```
$ git remote add "仓库名" "ssh"
```

- 提交文件到仓库

```
$git push origin master
```

# 克隆(下载)仓库文件
```
$ git clone "ssh地址"
```

# 分支的意义
>摘抄自廖雪峰老师叫教学网站

分支就是科幻电影里面的平行宇宙，当你正在电脑前努力学习Git的时候，另一个你正在另一个平行宇宙里努力学习SVN。

如果两个平行宇宙互不干扰，那对现在的你也没啥影响。不过，在某个时间点，两个平行宇宙合并了，结果，你既学会了Git又学会了SVN！

分支在实际中有什么用呢？假设你准备开发一个新功能，但是需要两周才能完成，第一周你写了50%的代码，如果立刻提交，由于代码还没写完，不完整的代码库会导致别人不能干活了。如果等代码全部写完再一次提交，又存在丢失每天进度的巨大风险。

现在有了分支，就不用怕了。你创建了一个属于你自己的分支，别人看不到，还继续在原来的分支上正常工作，而你在自己的分支上干活，想提交就提交，直到开发完毕后，再一次性合并到原来的分支上，这样，既安全，又不影响别人工作。

其他版本控制系统如SVN等都有分支管理，但是用过之后你会发现，这些版本控制系统创建和切换分支比蜗牛还慢，简直让人无法忍受，结果分支功能成了摆设，大家都不去用。

但Git的分支是与众不同的，无论创建、切换和删除分支，Git在1秒钟之内就能完成！无论你的版本库是1个文件还是1万个文件。

# 创建分支


每次提交，Git都把它们串成一条时间线，这条时间线就是一个分支。截止到目前，只有一条时间线，在Git里，这个分支叫主分支，即master分支。HEAD严格来说不是指向提交，而是指向master，master才是指向提交的，所以，HEAD指向的就是当前分支。

一开始的时候，master分支是一条线，Git用master指向最新的提交，再用HEAD指向master，就能确定当前分支，以及当前分支的提交点：


![master分支](http://www.liaoxuefeng.com/files/attachments/0013849087937492135fbf4bbd24dfcbc18349a8a59d36d000/0)

当我们创建新的分支，例如dev时，Git新建了一个指针叫dev，指向master相同的提交，再把HEAD指向dev，就表示当前分支在dev上：

![dev分支](http://www.liaoxuefeng.com/files/attachments/001384908811773187a597e2d844eefb11f5cf5d56135ca000/0)

你看，Git创建一个分支很快，因为除了增加一个dev指针，改改HEAD的指向，工作区的文件都没有任何变化！

不过，从现在开始，对工作区的修改和提交就是针对dev分支了，比如新提交一次后，dev指针往前移动一步，而master指针不变：

![在新提交](http://www.liaoxuefeng.com/files/attachments/0013849088235627813efe7649b4f008900e5365bb72323000/0)

假如我们在dev上的工作完成了，就可以把dev合并到master上。Git怎么合并呢？最简单的方法，就是直接把master指向dev的当前提交，就完成了合并：

![合并分支](http://www.liaoxuefeng.com/files/attachments/00138490883510324231a837e5d4aee844d3e4692ba50f5000/0)

所以Git合并分支也很快！就改改指针，工作区内容也不变！

合并完分支后，甚至可以删除dev分支。删除dev分支就是把dev指针给删掉，删掉后，我们就剩下了一条master分支：

![最终分支](http://www.liaoxuefeng.com/files/attachments/001384908867187c83ca970bf0f46efa19badad99c40235000/0)

## 实战

### 创建分支
```
$git checkout -b "分支名"
```

_注解:_

* git checkout命令加上-b参数表示创建并切换，相当于以下两条命令：

    ```
    $ git branch "分支名"
    $ git checkout "分支名"
    ```

* git checkout 命令相当于指定当前分支


### 查看当前分支

```
$ git branch
```

_注解 :_

git branch命令会列出所有分支，当前分支前面会标一个*号。

### 合并分支
```
git merge "分支名"
```

>如果主分支没有更新,而其他分支有更新,则可以快速合并,但在实际开发中,会遇到主分支与其他分支同时都更新了,这时就无法快速合并.

![分支的冲突](http://www.liaoxuefeng.com/files/attachments/001384909115478645b93e2b5ae4dc78da049a0d1704a41000/0)

>Git用<<<<<<<，=======，>>>>>>>标记出不同分支的内容，我们修改如下后保存.

```
$ git add readme.txt 
$ git commit -m "conflict fixed"
```

![修改过后的分支](http://www.liaoxuefeng.com/files/attachments/00138490913052149c4b2cd9702422aa387ac024943921b000/0)

### 删除分支
```
$ git branch -d "分支名"
```

### Fast Forward 模式合并

### 禁用Fast Forward 模式合并
通常，合并分支时，如果可能，Git会用Fast forward模式，但这种模式下，删除分支后，会丢掉分支信息。

如果要强制禁用Fast forward模式，Git就会在merge时生成一个新的commit，这样，从分支历史上就可以看出分支信息。

```
git merge --no-ff -m "merge with no-ff" "分支名"
```

* 团队开发分支如下:
![团队开发](http://www.liaoxuefeng.com/files/attachments/001384909239390d355eb07d9d64305b6322aaf4edac1e3000/0)

## 在提交前,保存当前工作分支

>应用场景:
你当前在dev分支上工作,可是发现了master分支上面有一个急需修复的bug!

我们的解决思路是这样的:

1. 创建一个新的分支
    
    ```
    $ git checkout -b issue-01
    ```

2. 完成修改并提交
    
    ```
    $ git add "文件名"
    $ git commit -m "修复完xxx"
    ```

3. 回到master分支,合并 _issue-01_ 分支

    ```
    $ git merge --no-ff -m"修复了一个BUG" issue-01
    ```

4. 删除 _issue-01_ 分支
    
    ```
    $ git branch -d issue-01
    ```

可是!这里就要求我们把手头上的工作做完,才去修复,这样就会比较麻烦.

因此,Git提供了一个stash功能，可以把当前工作现场“储藏”起来，等以后恢复现场后继续工作：

```
$ git stash
```

查看到当前的工作空间:

```
$ git stash list
```

恢复当前的工作空间有两种方法:

1. 这个方法会保存stash,需要用 _git stash drop_ 方法删除
    ```
   $  git stash apply
    ```

2. 用这个方法的话,不仅恢复当前工作空间,并且删除stash

    ```
    $ git stash pop
    ```

## 开发新功能
建立分支名字为" _feature-xxx "

# 标签

* 创建标签

    ```
    $ git tag "tag_name"
    ```

* 创建带文字说明的标签

    ```
    $ git tag -a v0.1 -m "version 0.1 released" 3628164
    ```

    _注解 :_
    用-a指定标签名，-m指定说明文字.

* 创建一个带私钥的标签
    ```
    $ git tag -s v0.2 -m "signed version 0.2 released" fec145a
    ```
    _注解 :_ 通过-s用私钥签名一个标签

* 查看标签

    ```
    $ git tag
    ```

* 查看标签的具体信息

    ```
    $ git show "tag_name"
    ```

* 删除标签
    ```
    $ git tag -d "tag_name"
    ```

* 推送标签到远程仓库
    ```
    $ git push origin <tagname>
    ```

    _注解 :_ 这里的" origin " 是一个远程仓库的名字,这个名字可以自定义的. 

* 一次性把所有标签全部推送到远程仓库上
    ```
    $ git push origin --tags
    ```
    _注解 :_ 这里的" origin " 是一个远程仓库的名字,这个名字可以自定义的. 

* 删除远程仓库上面的标签



    > 如果标签已经推送到远程，要删除远程标签就麻烦一点，先从本地删除：
    
    
    ```
    $ git tag -d v0.9
    Deleted tag 'v0.9' (was 6224937)
    ```

    > 然后，从远程删除。删除命令也是push，但是格式如下：

    ```
    $ git push origin :refs/tags/v0.9
    To git@github.com:michaelliao/learngit.git
    - [deleted]         v0.9
    ```

> 如果忘记打标签,事后要补上怎么办?


```
    $ git tag "tag_name" "commit_id"
```

# 配置别名
有没有经常敲错命令？比如git status？status这个单词真心不好记。

如果敲git st就表示git status那就简单多了，当然这种偷懒的办法我们是极力赞成的。

我们只需要敲一行命令，告诉Git，以后st就表示status：
    
```
     $ git config --global alias.st status
```

再例如:

```
    $ git config --global alias.co checkout
    $ git config --global alias.ci commit
    $ git config --global alias.br branch
```

_注解 :_ --global参数是全局参数，也就是这些命令在这台电脑的所有Git仓库下都有用。如果不加，那只针对当前的仓库起作用。

<br>


在撤销修改一节中，我们知道，命令git reset HEAD file可以把暂存区的修改撤销掉（unstage），重新放回工作区。既然是一个unstage操作，就可以配置一个unstage别名：

```
    $ git config --global alias.unstage 'reset HEAD'
```

当你敲入命令：

```
$ git unstage test.py
```

实际上Git执行的是：

```
$ git reset HEAD test.py
```


>跟环境变量很像

> 每个仓库的Git配置文件都放在.git/config文件中.

>而当前用户的Git配置文件放在用户主目录下的一个隐藏文件.gitconfig中.

<br>

# 搭建本地Git服务器(略)
GitHub就是一个免费托管开源代码的远程仓库。但是对于某些视源代码如生命的商业公司来说，既不想公开源代码，又舍不得给GitHub交保护费，那就只能自己搭建一台Git服务器作为私有仓库使用。