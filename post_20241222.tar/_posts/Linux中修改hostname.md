---
title: Linux中修改hostname
date: 2019-01-01 20:31:22
tags: Linux
---

# 前言：

* OS : CentOS Linux release 7.5.1804 (Core)

# 临时修改主机名

```shell
hostname new-hostname
```

# 永久修改主机名

修改 /etc/hostname 文件即可，并修改/etc/hosts文件中对应127.0.0.1 所对应的域名，否则会出现“ can;t resolve host xxx”

> Fedora发行版将主机名存放在/etc/sysconfig/network文件中;