---
title: Vscode的问题
date: 2019-04-05 16:05:29
tags: Software
---

# Vscode的问题

## 问题1： 出现command 'markdown.extension.onEnterKey' not found

原因：

1. Markdown插件未加载；
2. Vscode的版本过低；

