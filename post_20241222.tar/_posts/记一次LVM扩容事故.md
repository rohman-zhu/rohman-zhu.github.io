---
title: 记一次LVM扩容事故
tags:
  - 故障修复
catergories:
  - Linux
date: 2020-01-11 23:54:19
---

# 前言

只扩容lv卷，但没有扩扩lv pool 

## 如何修复lvm

挂载磁盘进入修复模式，输入指令

扫描LVM