---
title: Linux之监控
date: 2017-11-25 15:16:25
tags: Linux
---
# 监控 #

## 监控系统需要监控的方面 ##

1. 本地资源:负载uptime,CPU(top,sar),磁盘(df),内存(free),IO(iostat),RAID,温度,passwd文件的变化,本地所有文件的指纹.
1. 网络服务:端口,URL,DB,丢包,进程数,网络流量.
1. 其他设备: 路由器,交换机端口流量, 打印机,Windows等
1. 业务数据:用户登录次数,用户登录网站次数,输入验证码失败的次数,某一个API接口流量并发,电商网站订单,支付交易的数量.

## 监控工具 Nagios ##

### 介绍与优势 ###

_Nagios_ 是一款开源的网络以及服务的监控工具.可以监控windows,linux,unix等系统的主机各种状态信息,交换机,路由器等网络设备,主机端口以及URL服务等,根据不同古战级别发送警告信息(邮件,微信,短信等)给管理员.

> windows可以作为被监控的主机,但不能作为监控服务器.

官网地址:`https://www.nagios.org`

### 特点 ###

1. 监控网络服务(SMTP,POP3,HTTP,TCP,PING等)
1. 监控主机资源(CPU,负载,IO状态,虚拟及正事内存以及磁盘利用率等)
1. 简单的插件设计模式使得用户可以方便定制符合自己的服务的检测方法.
1. 并行服务检查机制.
1. 具有定义网络分层结构的能力,用 _parent_ 主机来定义网络主机间的关系,这种关系可以用来发现和明晰主机宕机或不可达的状态.
1. 当服务或主机问题产生与解决后将警告发给联系人.
1. 支持分布式检查机制

### Nagios监控系统构成 ###

1. 主程序:Nagios(服务端软件)
1. 插件程序(nagio-plugins)
1. 附件插件(NRPE,NSClient,NSCA,NDOUtils)

#### 几个附加程序 ####

##### NRPE:半被动模式 #####

* 存在位置 : NRPE软件工作于被监控端,操作系统为 Linux \ Unix
* NRPE作用 : 用于在被监控的远程 Linux/Unix 主机上执行脚本插件获取数据回传给服务器端,以实现对这些主机资源的监控.
* 存在形式 : 守护进程(agent)模式,开启的端口5666
* 本地资源 : 负载uptime,CPU(top,sar),内存(free,swap),IO(iostat),RAID级别,本地所有文件指纹识别监控.

##### NSClient++:半被动模式 #####

* 存在位置 : 用于被监控端为windows系统的服务
* 作用 : 功能相当于Linux下的NRPE.

> 用于监控Windows主机时,安装再windows主机上的组件.

##### NSCA:纯被动模式的监控 #####

* 位置:NSCA需要同时安装再nagios的服务端和客户端(被监控端).
* 作用: 用于让被监控的远程Linux/Unix主机主动将监控到的信息发给Nagios服务器.

### Nagios监控的简单原理 ###

#### NRPE 运行原理 ####

NRPE放在被监控的主机上面.

Nagios -> check\_nrpe |----->| NRPE -> {check\_disk,check\_load,...} -> Local Resources and Services

* 端口:5666

### 安装 ###

#### 服务端安装 ####

```sh
# 1.配置yum源
# 2.调整字符集
echo 'export LC_ALL=C' >> /etc/profile
source /etc/profile
# 3.关闭防火墙 & selinux
chkconfig iptables off
setenfore 0
vi /etc/selinux/config
# 4.定时任务--时间同步
echo '*/10 * * * * /usr/sbin/ntpdata pool.ntp.org > /dev/null 2>&1' >>/var/spool

crontab -l
# 5.install gcc and lamp env etc

yum install unzip
yum install gcc glibc-common -y
yum install gd gd-devel -y
yum install httpd php php-gd -y
yum install mysql* -y

# 6.添加用户和组
useradd -m nagios
useradd apache
useradd nagcmd

usermod -a -G nagcmd nagios
usermod -a -G nagcmd nagcmd

# 7.download and install nagios
解压忽略(3.5版本)
./configure --with-command-group=nagcmd

# 7.1安装
[3.5版本的]
make install-init
make install-config
make install-commandmode
make install-webconf

[新版本]
#make all
#make install
#make install-init
#make install-commandmode
#make install-webconf
#make install-config

# 8 config web
htpasswd -cb /usr/local/nagios/etc/htpasswd.users username passwd

# 9 install nagios-plugins
yum install perl-devel
# nagios-plugins-1.4.16
./configure --with-nagios-user=nagios --with-nagios-group=nagios --enable-perl-modules

# 10 install NRPE
# include check_nrpe command
./configure
make all
make install
make install-plugin
make install-daemon
make install-daemon-config


```

#### 客户端安装 ####

```sh
# 1.配置yum源
# 2.调整字符集
echo 'export LC_ALL = C' >> /etc/profile
source /etc/profile
# 3.关闭防火墙 & selinux
chkconfig iptables off
setenfore 0
vi /etc/selinux/config
# 4.定时任务--时间同步
echo '*/10 * * * * /usr/sbin/ntpdata pool.ntp.org > /dev/null 2>&1' >>/var/spool

# 5.添加nagios用户
useradd -m nagios

# 6.install nagios-plugins
./configure --prefix=/usr/local/nagios --enable-prel-modules --enable-redhat-pthread-workaround
make && make install

# 7.install nrpe
./configure
make all
make install-plugin
make install-daemon
make install-daemon-config

# 8.install soft for iostat
yum install sysstat -y
# 把相关的的软件复制到/nagios/libexec
# 修改权限
chmod 755 /libexec/check_memory.pl
chmod 755 /libexec/check_iostat

# 9.Modify nrpe.configure
# No.79
vi ./nrpe.conf +79
#----
allowhost=x.x.x.x(target host)
# del 199-203
```

| 配置文件 | 说明 |
|:------:|:-------:|
| cgi.cfg | 控制 CGI 访问的配置文件|
| nagios.cfg | Nagios 主配置文件 |
| resource.cfg |变量定义文件，又称为资源文件，在此文件中定义变量，以便由其他配置文件引用，如$USER1$|
| objects | objects 是一个目录，在此目录下有很多配置文件模板，用于定义 Nagios 对象|
| objects/commands.cfg | 命令定义配置文件，其中定义的命令可以被其他配置文件引用 |
| objects/contacts.cfg | 定义联系人和联系人组的配置文件
| objects/localhost.cfg | 定义监控本地主机的配置文件|
| objects/printer.cfg | 定义监控打印机的一个配置文件模板，默认没有启用此文件 |
| objects/switch.cfg | 监控路由器的一个配置文件模板，默认没有启用此文件 |
| objects/templates.cfg | 定义主机和服务的一个模板配置文件，可以在其他配置文件中引用|
| objects/timeperiods.cfg | 定义 Nagios 监控时间段的配置文件 |
| objects/windows.cfg | 监控 Windows 主机的一个配置文件模板，默认没有启用此文件 |

> 备注:Nagios 在配置方面非常灵活，默认的配置文件并不是必需的。可以使用这些默认的配置文件，也可以创建自己的配置文件，然后在主配置文件 nagios.cfg 中引用即可。

主要配置:

* host.cfg
* service.cfg

#### 配置主机服务 ####

```sh
cd ./objects/
vi ./hosts.cfg

#----
define host{
    # use 模板名字
    use linux-server
    host_name client
    alias   client2
    address 10.0.0.8
}

define command{
    command_name check_nrpe
    command_line $USER$/check_nrpe -H $HOSTADDRESS$ -c $ARG1$
}
#----
```

流程:

```sh
# 在nagios.cfg添加:
cfg_file=/usr/local/nagios/etc/objects/host.cfg
cfg_file=/usr/local/nagios/etc/objects/service.cfg

# 生成host.cfg文件
head -50 localhost.cfg > hosts.cfg

# 编辑hosts.cfg增加被监控的主机
define host {
    use     linux-server
    host_name   webxxx
    alias       webxxx2
    address     192.168.1.x
}

define hostgroup{
    hostgroup_name      linux-servers
    alias               linux-servers2
    members             web-xxx
}

# 配置service.cfg配置文件
define service{
    use     generic-service
    host_name   web-xxx
    service_description Disk Partition
    check_command   check_nrpe!check_disk
}

# 检查语法
/etc/init.d/nagios checkfonfig

# 修改访问权限
vim ./nagios/etc/cgi.cfg
nagiosadmin->user

# 重启nagios
```

### 监控模式定义以及监控模式 ###

* 主动模式
* 被动模式

本地监控,一般选择NRPE(被动模式);

对于web服务,数据库这种对外提供服务的监控,一般选择主动模式.