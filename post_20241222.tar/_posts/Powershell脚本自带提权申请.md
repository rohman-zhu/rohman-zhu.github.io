---
title: Powershell脚本自带提权申请
tags:
  - powershell
categories:
 - Windows Server
date: 2020-05-11 23:20:08
---

# 参考资料

https://superuser.com/questions/108207/how-to-run-a-powershell-script-as-administrator