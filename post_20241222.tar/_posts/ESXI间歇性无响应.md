---
title: ESXI间歇性无响应
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2022-01-10 23:53:47
---
# 故障现象

加入vCenter的ESXi宿主机，会经常出现“未响应”的情况。需要重新连接才能恢复，但是过一会又会断连。

# 原因分析

https://kb.vmware.com/s/article/1005757?lang=zh_cn

# 解决方法

在vCenter中，给VCSA添加一个参数，然后重启VCSA。

```操作记录
1. 在vCenter实例中，进入配置，高级选项
2. 添加参数config.vpxd.heartbeat.notRespondingTimeout，并将值设置为120 。
3. 重启VCSA。
```

# 其他参考资料

https://kb.vmware.com/s/article/2127098?lang=zh_CN
