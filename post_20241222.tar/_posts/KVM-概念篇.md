---
title: KVM-概念篇
date: 2018-10-27 22:01:31
tags: Linux
---

# 前言

由于最近在接触虚拟化的内容，而自己使用的是Vmware Vsphere一套来实现虚拟化，接触到现在，梳理一下当前的架构（将硬件虚拟化的ESXI主机+ VSAN存储 + VLAN网络）去构建，而自己所有操作都是基于Vsphere Client来实现。虽然Vmware的Vsphere是时下最热门、也是稳定的虚拟化解决方案，但是在Openstack的冲击下，将来我也有可能要接触到Openstack。因此今天就学习一下，KVM（Kernel-Based Virtual Machine),笔记将会记录 VM的创建 、 VM变更 、 VM优化三个方面。

# 关键词

## Kernel-Based Virtual Machine 开源虚拟化模块

KVM是一个开源的系统虚拟化模块，Linux 2.6.20之后集成在Linux的各个主要发行版本中。要实现KVM需要硬件支持：

* CPU方面 如 Intel-VT （Virtualization Technology）、 AMD-V等。
* 内存方面 如 Intel-EPT \ AMD 的 RVT技术。

KVM是基于硬件的完全虚拟化（Full-Virtualization）。

## Full-Virtualization 、 Paravirtualization 、 Hardware Assisted

Full-Virtualization 即全虚拟化：

最流行的虚拟化方法使用名为hypervisor的一种软件，在虚拟服务器和底层硬件之间建立一个抽象层。VMware和微软的Virtual PC是代表该方法的两个商用产品，而基于核心的虚拟机（KVM）是面向Linux系统的开源产品。

hypervisor可以捕获CPU指令，为指令访问硬件控制器和外设充当中介。因而，完全虚拟化技术几乎能让任何一款操作系统不用改动就能安装到虚拟服务器上，而它们不知道自己运行在虚拟化环境下。主要缺点是，hypervisor给处理器带来开销。

在完全虚拟化的环境下，hypervisor运行在裸硬件上，充当主机操作系统；而由hypervisor管理的虚拟服务器运行客户端操作系统（guest OS）。

Paravirtualization 即准虚拟化：

全虚拟化是处理器密集型技术，因为它要求hypervisor管理各个虚拟服务器，并让它们彼此独立。减轻这种负担的一种方法就是，改动客户操作系统，让它以为自己运行在虚拟环境下，能够与hypervisor协同工作。这种方法就叫准虚拟化（para-virtualization）。

Xen是开源准虚拟化技术的一个例子。操作系统作为虚拟服务器在Xen hypervisor上运行之前，它必须在核心层面进行某些改变。因此，Xen适用于BSD、Linux、Solaris及其他开源操作系统，但不适合对像Windows这些专有的操作系统进行虚拟化处理，因为它们无法改动。

准虚拟化技术的优点是性能高。经过准虚拟化处理的服务器可与hypervisor协同工作，其响应能力几乎不亚于未经过虚拟化处理的服务器。准虚拟化与完全虚拟化相比优点明显，以至于微软和VMware都在开发这项技术，以完善各自的产品。

![Architectural Comparison](http://ossi4.51cto.com/attachment/201210/164957216.jpg)

## 平台虚拟化 

## 软件虚拟化 


## Intel VT

Intel VT即Intel公司的Virtualization Technology虚拟化技术。
Intel VT可以让一个CPU工作起来像多个CPU在并行运行，从而使得在一部电脑内同时运行多个操作系统成为可能。这种VT技术并不是一个新鲜事物，市面上已经有一些软件可以达到虚拟多系统的目的，比如VMware workstation、Virtual PC等，使用这种技术就可以单CPU模拟多CPU并行，可以实现单机同时运行多操作系统。

## QEMU

QEMU是一套由法布里斯·贝拉(Fabrice Bellard)所编写的以GPL许可证分发源码的模拟处理器，在GNU/Linux平台上使用广泛。

QEMU有两种主要运作模式：

* User mode模拟模式，亦即是用户模式。QEMU能启动那些为不同中央处理器编译的Linux程序。
* System mode模拟模式，亦即是系统模式。QEMU能模拟整个电脑系统，包括中央处理器及其他周边设备。它使得为跨平台编写的程序进行测试及除错工作变得容易。其亦能用来在一部主机上虚拟数部不同虚拟电脑。


## EPEL

EPEL (Extra Packages for Enterprise Linux)是基于Fedora的一个项目，为“红帽系”的操作系统提供额外的软件包，适用于RHEL、CentOS和Scientific Linux.

```shell
# 配置EPEL包
# 清华大学镜像 https://mirrors.tuna.tsinghua.edu.cn/epel/
rpm -ivh https://mirrors.tuna.tsinghua.edu.cn/epel/6Server/x86_64/epel-release-6-8.noarch.rpm

```

```Doc
# man rpm

rpm命令是RPM软件包的管理工具。
rpm原本是Red Hat Linux发行版专门用来管理Linux各项套件的程序，由于它遵循GPL规则且功能强大方便，因而广受欢迎。
逐渐受到其他发行版的采用。RPM套件管理方式的出现，让Linux易于安装，升级，间接提升了Linux的适用度。

rpm(选项)(参数)

-i<套件档>或--install<套件档>：安装指定的套件档；
-v：显示指令执行过程；
-h或--hash：套件安装时列出标记；
-e<套件档>或--erase<套件档>：删除指定的套件；
-a：查询所有套件；
-b<完成阶段><套件档>+或-t <完成阶段><套件档>+：设置包装套件的完成阶段，并指定套件档的文件名称；
-c：只列出组态配置文件，本参数需配合"-l"参数使用；
-d：只列出文本文件，本参数需配合"-l"参数使用；
-f<文件>+：查询拥有指定文件的套件；
-i：显示套件的相关信息；
-l：显示套件的文件列表；
-p<套件档>+：查询指定的RPM套件档；
-q：使用询问模式，当遇到任何问题时，rpm指令会先询问用户；
-R：显示套件的关联性信息；
-s：显示文件状态，本参数需配合"-l"参数使用；
-U<套件档>或--upgrade<套件档>：升级指定的套件档；
-vv：详细显示指令执行过程，便于排错。
```

## libvirt

libvirt是提供了一个方便的方式来管理虚拟机和其他虚拟化功能的软件的集合，如存储和网络接口管理。这些软件包括一个API库，一个守护进程（Libvirtd），和一个命令行实用程序（virsh）。
libvirt的首要目标是能够管理多个不同的虚拟化供应商/虚拟机管理程序提供一个单一的方式。

# 实验环境

教程中

* OS ： Centos 6.4 （Run in Vmware Workstation 8 )
* 硬件支持： Intel-VT 或者 AMD-V（CPU） ； EPT 或者 RVT  （内存）
* 配置epal包
* 安装KVM模块 （qemu-kvm virt-manager python-virtinst)


# 参考资料

* KVM介绍（3）： I/O 全虚拟化和准虚拟化[KVM I/O QEMU Full-Virtualization Para-Virtualization] https://www.cnblogs.com/sammyliu/p/4543657.html
* rpm指令查询 ： http://man.linuxde.net/rpm
* lsmod指令查询 ： http://man.linuxde.net/lsmod
* 百科-虚拟化技术 ： https://baike.baidu.com/item/%E8%99%9A%E6%8B%9F%E5%8C%96%E6%8A%80%E6%9C%AF/276750?fr=aladdin