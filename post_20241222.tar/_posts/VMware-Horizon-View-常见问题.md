---
title: VMware Horizon View-常见问题
tags:
  - 常见问题
categories:
  - VMware
  - Horizon View
date: 2024-03-07 12:47:06
---

# Server类故障

## 目标VDI提示被禁用，无法通过客户端重置桌面

### 原因分析

1. Connection Server 托管的vCenter服务异常；
2. 目标VDI对应的虚拟机不存在；


# Agent类故障

## 目标VDI在Connection Server中提示“无法访问代理”

### 原因分析

1. VDI内的网络异常，到Connection Server的必要端口没有放行；
2. VDI内的Agent进程异常，客户端内的VMware Horizon View Agent没有正常运行，其中的关联服务没有启动；
3. VDI内没有办法正常解析Connection Server的域名，导致无法与对端建立连接；【DNS解析异常】
3. Connection Server与VDI的通讯密钥需要更新；

原因1，必要端口：

| SRC | DST | TCP-Port | Description |
|:---:|:---:|:---:|:----|
| Agent | CS | 4001 | Java Message Service communication , JMS |
| Agent | CS | 4002 | Java Message Service communication , Java Message Service (JMS) when using enhanced security (default). |
| Agent | CS | 389 | Only required when doing an unmanaged agent registration, for example, RDSH agent install without linked-clone or instant-clone component. |

参考： https://ports.esp.vmware.com/home/Horizon

可以在操作系统中执行相关指令确认：

```sh
# Windows , run powershell as administrator
netstat -ano | findstr [Target TCP port]

# Linux , run command as sudo permission
netstat -ano | gre [Target TCP port]
```

原因2，关联服务

```sh
# Windows , run powerhsell as administrator
netstat -ano | findstr vmware

# [TODO] Should have :

# Linux , run command as sudo permission
ps -aux | grep vmware

# Should have : 
# viewagent/jre/bin/java 
# viewagent/bin/GetMachineId.sh 
# viewagent/DekstopDaemon/desktopDaemon
# viewagent/VMwareBlastServer/BlastServer
```
