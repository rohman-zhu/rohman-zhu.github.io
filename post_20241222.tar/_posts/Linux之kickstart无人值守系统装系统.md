---
title: Linux之kickstart无人值守系统装系统
date: 2017-11-14 15:48:16
tags: Linux
---
# 无人值守装系统(PXE+APACHE+DHCP+TFTP+KICKSTART) #

* DHCP_Server 用于给客户端提供IP地址以及PXE文件的位置.
* Web_Server 存放系统镜像以及kickstart的配置文件.
* TFTP_Server 存放PXE文件以及相关的启动文件

---
相关IP地址:

* DHCP_Server:192.168.1.2
* Web_Server:192.168.1.3
* TFTP_Server:192.168.1.4

## 1.1 什么是PXE ##

PXE(preboot execute environment，预启动执行环境)是由Intel公司开发的最新技术，工作于Client/Server的网络模式，支持工作站通过网络从远端服务器下载映像，并由此支持通过网络启动操作系统，

在启动过程中，终端要求服务器分配IP地址，再用TFTP（trivial file transfer protocol）或MTFTP(multicast trivial file transfer protocol)协议下载一个启动软件包到本机内存中执行，由这个启动软件包完成终端（客户端）基本软件设置，从而引导预先安装在服务器中的终端操作系统。

## 1.2 PXE工作过程 ##

![PXE工作原理示意图](http://images.cnitblog.com/blog/370046/201406/152331547498487.jpg)

PXE客户端 (发送UDP广播请求)-> DHCP服务 (DHCP服务器提供信息) -> PXE客户端 (请求下载启动文件)-> TFTP服务 (响应并提供文件)-> PXE 客户端 (请求下载自动应答文件) -> Http服务 (客户端安装操作系统) -> PXE客户端

### 1.2.1 获取相关的pxe程序 ###

```Linux
# 安装syslinux
# syslinux是一个引导加载程序,而且兼容各种介质.syslinux是一个小型的Linux操作系统,目的是简化首次安装Linux的时间,并建立维护或者其他特殊用途的启动盘
# yum install syslinux

# 将Linux的pxe文件复制到TFTP文件夹中(TFTP下面会讲到安装,默认启动的路径在/var/lib/tftpboot/)
# cp /usr/share/syslinux/pxelinux.0 /var/lib/tftpboot/

# 将iso镜像中的/image/pxeboot/initrd.img和vmlinux复制到/var/lib/tftpboot/下
# scp -P22 root@192.168.1.3:/var/www/html/cdrom/images/pxeboot/{initrd.im,gvmlinuz} /var/lib/tftpboot/

# 复制iso镜像中的/isolinux/*.msg 到 /var/lib/tftpboot/文件夹中
# cp /var/www/html/cdrom/isolinux/*.msg /var/lib/tftpboot/

# 在/var/lib/tftpboot/中创建一个pxelinux.cfg目录
# mkdir /var/lib/tftpboot/pxelinux.cfg

# 将iso镜像中的/isolinux目录中的isolinux.cfg复制到pxelinux.cfg目录下,同时改名为default
# cp /var/www/html/cdrom/isolinux/isolinux.cfg /var/lib/tftpboot/pxelinux.cfg/default

```

修改default文件

```default
# 设置启动的是'label ks'中的内容
default ks
# 显示 'boot:'提示符.为'0'时则不显示,将会直接启动'default'参数中指定的内容.
prompt 1
#在用户输入之前的超时时间,单位为0.1秒
timeout 6
# 显示某个文件的内容,注意文件的路径.
# 默认是在/var/lib/tftpboot/目录下
# 也可以指定其他的全路径下的msg文件
display boot.msg

# 'label'指定在'boot'提示符下输入的关键字,比如boot:linux[ENTER],这个会启动'label linux'下标记的kernel和initrd.img文件
label linux
    # kernel 参数指定要启动的内核
    kernel vmlinuz
    # append指定追加给内核的参数,能够在grub里使用的追加给内核的参数.
    append initrd=initrd.img
label ks
    kernel vmlinuz
    #指定ks.cfg文件
    append ks=http://192.168.1.3/ks.cfg initrd=initrd.img
```

> Linux初始RAM磁盘（initrd）是在系统引导过程中挂载的一个临时根文件系统，用来支持两阶段的引导过程。initrd文件中包含了各种可执行程序和驱动程序，它们可以用来挂载实际的根文件系统，然后再将这个 initrd RAM磁盘卸载，并释放内存。在很多嵌入式Linux系统中，initrd 就是最终的根文件系统。

## 2. DHCP服务器安装 ##

DHCP（Dynamic Host Configuration Protocol，动态主机配置协议）是一个局域网的网络协议，使用UDP协议工作， 主要有两个用途：给内部网络或网络服务供应商自动分配IP地址，给用户或者内部网络管理员作为对所有计算机作中央管理的手段.

在本次案例中,DHCP服务器用于给客户机分配IP地址以及TFTP服务器的IP地址.

```Linux
# 安装DHCP服务
# yum -y install dhcp

# 复制配置模板文件到DHCP的配置目录中
# cp -f /usr/share/doc/dhcp-4.1.1/dhcpd.conf/sample /etc/dhcp/dhcpd.conf

# 修改/etc/dhcp/dhcp.conf配置文件,内容如下:
# vi /etc/dhcp/dhcp.conf
# ---
ddns-update-style interim;
ignore client-updates;
# pxelinux启动文件位置;
filename "pxelinux.0";
# TFTP Server的IP地址;
next-server 192.168.1.4;

subnet 192.168.1.0 netmask 255.255.255.0{
    option routers 192.168.1.4;
    option subnet-mask 255.255.255.0;

    range dynamic-bootp 192.168.1.100 192.168.1.200;
    default-lease-time 21600;
    max-lease-time 43000;
}

# 启动DHCP服务
# /etc/init.d/dhcpd start
```

> 这里有可能会出现客户机无法找到ip地址,需要关闭防火墙和selinux.

## 3.TFTP_Server 安装与配置 ##

TFTP（Trivial File Transfer Protocol,简单文件传输协议）是TCP/IP协议族中的一个用来在客户机与服务器之间进行简单文件传输的协议，提供不复杂、开销不大的文件传输服务。端口号为69。

```Linux
# 安装tftp-server
# yum install tftp-server -y

# 编辑tftp服务的配置
# vi /etc/xinetd.d/tftp
# ---
service tftp
{
    socket_type = dgram
    protocol = udp
    wait = yes
    user = root
    server = /usr/sbin/in.tftpd
    server_args = -s /var/lib/tftpboot
    disable = no
    per_source = 11
    cps = 100 2
    flags = IPv4
}

# 启动服务
# /etc/init.d/xinetd restart
```

## 4. 安装HTTP服务 ##

可以用 _Apache_ 或者 _Nginx_ , 具体安装教程在以往的文章中由详细记录.

> 创建一个站点目录挂载光盘镜像.

## 6.创建ks.cfg ##

### 6.1 语法 ###

* 命令段
* 脚本段

### 6.2 定制配置文件 ###

```cfg
#platform=x86, AMD64, or Intel EM64T
#version=DEVEL
# Firewall configuration
firewall --disabled
# Install OS instead of upgrade
install
# Use network installation
url --url=http://192.168.1.3/cdrom/
#这个选项告诉安装程序：到服务器192.168.1.3 的HTTP根目录下的cdrom 文件夹下寻找安装介质
# Root password
rootpw --iscrypted $1$vsvtP./e$6PVMNfJd.shq2LgFJjYfA1
# System authorization information
auth  --useshadow  --enablemd5
# Use graphical install
graphical
firstboot --disable
# System keyboard
keyboard us
# System language
lang en_US
# SELinux configuration
selinux --disabled
# Installation logging level
logging --level=info
# Reboot after installation
reboot
# System timezone
timezone  --isUtc Asia/Shanghai
# Network information
network  --bootproto=dhcp --device=eth0 --onboot=on
# System bootloader configuration
# Redhat system
# key --skip

bootloader --append="rhgb quiet" --location=mbr --driveorder=sda

# Clear the Master Boot Record
zerombr
# Partition clearing information
clearpart --all --initlabel
# Disk partitioning information
part /boot --fstype="ext4" --size=200
part swap --fstype="swap" --size=1024
part / --fstype="ext4" --size=8192
part /home --fstype="ext4" --size=2048

%packages
@base

%end
```