---
title: 【待补充】VMware无法克隆虚拟机
tags:
  - VMware
  - 故障
catergories:
  - 虚拟化
date: 2020-01-17 23:48:34
---

# 故障描述

在克隆虚拟机的时候，显示无法创建快照。

查看vmware.log，看到创建快照的时候出现error。

# 原因

目前参考网络的资料是，因为客户端的 vmtool 配置项异常。需要补充一个配置项。

