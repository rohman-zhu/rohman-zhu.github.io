---
title: LNMP-Zabbix-6.2.1-部署案例
tags:
  - Zabbix
  - LNMP
categories:
  - Linux
date: 2022-10-30 14:27:15
---
# 环境准备

Ubuntu-20.04

MySQL-8.0.22
php-8.1.9
Nginx-1.22.0
zabbix-6.2.1


> 弃用 MariaDB - 10.9.3，编译安装需要替换包中的工具；改用mysql8；
> MySQL下载地址：https://cloud.tencent.com/developer/article/1799089

# 部署记录

## OS准备

略

```sh
# 前置依赖
apt-get install libxml2-dev libxml2 bzip2 libcurl-dev libfmt-dev

bison
libbison-dev
zlib1g
zlib1g-dev
libcurl4-openssl-dev
libarchive-dev
boost-devel
libboost-all-dev
gcc
gcc-c++
libevent-dev
libgnutls28-dev
libaio-dev
libssl-dev
libxml2-dev
build-essential
libfmt-dev
libncurses5-dev 
libncursesw5-dev
```

## 安装 MySQL8

下载地址：https://dev.mysql.com/get/Downloads/MySQL-8.0/mysql-boost-8.0.22.tar.gz

安装MySQL 8.0.22资料参考地址：https://www.cnblogs.com/mhing/articles/14054727.html

```sh
# 安装依赖
sudo apt install build-essential cmake bison libncurses5-dev libssl-dev pkg-config

# 编译
cmake -DCMAKE_INSTALL_PREFIX=/usr/local/mysql -DMYSQL_DATADIR=/usr/local/mysql/data -DWITH_BOOST=boost -DFORCE_INSOURCE_BUILD=ON
# -DCMAKE_INSTALL_PREFIX： 指定安装路径
# -DMYSQL_DATADIR ： 指定数据存放路径
# -DMYSQL_UNIX_ADDR ：指定套间字路径
# -DDEFAULT_CHARSET ： 设置字符集
# -DDEFAULT_COLLATION ： 设置字符校验集
# -DWITH_BOOST ： 指定Boost扩展源码路径
# -DFORCE_INSOURCE_BUILD=ON ： 定义是否强制进行源内构建。建议使用源外构建，因为它们允许来自同一源的多个构建，并且可以通过删除构建目录来快速执行清理。
# 参数含义 https://dev.mysql.com/doc/refman/8.0/en/source-configuration-options.html

# 编译安装
make && make install
# 编译速度慢的问题，可以使用 指令make -j [ CPU核数]
# https://blog.csdn.net/wangjingfei/article/details/4969942

# 添加用户
groupadd mysql
useradd -g mysql mysql

# 创建数据库-数据目录
mkdir -p /usr/local/mysql/data
chown -R mysql:mysql /usr/local/mysql

# 初始化数据库
/usr/local/mysql/bin/mysqld --initialize --user=mysql --basedir=/usr/local/mysql --datadir=/usr/local/mysql/data
# 初始密码在 mysqld.conf 配置的报错日志中 ，参数项为 log-error=
# 参考资料：https://blog.csdn.net/zonghua521/article/details/78198052


# 编辑MySQL服务端的配置文件
/etc/mysql/mysql.conf.d/mysqld.cnf
[mysqld]
socket = /tmp/mysql.sock
basedir = /usr/local/mysql
datadir = /usr/local/mysql/data
# 编辑MySQL客户端配置文件
/etc/mysql/mysql.conf.d/mysql.cnf
[client]
socket = /tmp/mysql.sock
 
# 配置服务项
sudo cp /usr/local/mysql/support-files/mysql.server /etc/init.d/mysqld
sudo chmod +x /etc/init.d/mysqld
update-rc.d mysqld defaults
service mysqld start

# 看服务是否已启动
ps -aux|grep mysql
lsof -i:3306

# 重置初始密码
# 登录MySQL数据库
# 以下为SQL指令
# mysql 旧版本的修改方法；
use mysql;
update user set passowrd=password('我是密码') where user='root' and host='localhost';
flush privileges;

# MySQL 8.0的修改方法
# 参考https://blog.csdn.net/qq_38265784/article/details/80915098
use mysql;
alter user 'root'@'localhost' identified with mysql_native_password by '我是密码';
flush privileges;

# 查看是否有其他用户；
select user from user;

mysql.infoschema
mysql.session
mysql.sys
root
# 参考：https://kalacloud.com/blog/how-to-list-all-users-in-mysql/
# 参考：https://www.linuxprobe.com/mysql-show-all-users.html
```





## WEB服务器安装-Nginx-1.22.0

```sh
# 解压Nginx文件
tar xvf nginx-1.22.0.tar.gz
# 进入目录文件
./configure --prefix=/usr/local/nginx
# 编译安装
make && make install
# 检测安装是否正确
nginx -version
# 启动Nginx
nginx
# 检测Nginx配置文件
nginx -t
# 重新加载Nginx配置文件
nginx -s reload

# 检测是否能正常启动业务
curl localhost
```

## PHP服务安装-php-8.1.9


| 序号 | 8.1.9版本参数 | 5.5.38版本参数 |  参数说明 |
|:---:|:---|:---|:----: |
|1| prefix ||安装目录|
|2|with-config-file-path|| 配置文件目录 |
|3|with-bz2||
|4|with-curl||
|5|enable-ftp||
|6|enable-sockets||
|7|disable-ipv6||
|8|with-gd||
|9|with-jpeg-dir=?||
|10|with-png-dir=?||
|11|with-freetype-dir=?||
|12|enable-gd-native-ttf||
|13|with-iconv-dir=?||
|14|enable-mbstring||
|15|enable-calendar||
|16|with-gettext||
|17|with-libxml-dir=?||
|18|with-zlib||
|19|with-pdo-mysql=mysqlnd||
|20|with-mysqli=?||
|21|with-mysql=?||
|22|enable-dom||
|23|enable-xml||
|24|enable-fpm ||
|25|with-libdir=lib64||
|26|enable-bcmath||
|27|enable-mbstring|oniguruma是一个处理正则表达式的库，开启此功能需要这个库。|
|28|with-gd||
|29|with-libxml-dir=?||
|30|with-apxs2=?| Apache 相关服务 |
|31|with-openssl||
|32|enable-gd||
|33|with-jpeg||
|34|with-webp||
|35|with-freetype||
|36|without-sqlite3||
|37|with-fpm-user|调用fpm的用户||
|38|with-fpm-group|调用fpm的组||

```sh
./configure --prefix=/usr/local/php-8.1.9 --with-config-file-path=/usr/local/php-8.1.9/etc --with-bz2 --with-curl --enable-ftp --enable-sockets --disable-ipv6 --with-gd --with-jpeg-dir=/usr/local --with-png-dir=/usr/local --with-freetype-dir=/usr/local --enable-gd-native-ttf --with-iconv-dir=/usr/local --enable-mbstring --enable-calendar --with-gettext --with-libxml-dir=/usr/local --with-zlib --with-pdo-mysql=mysqlnd --with-mysqli=mysqlnd --with-mysql=mysqlnd --enable-dom --enable-xml --enable-fpm --with-libdir=lib64 --enable-bcmath --enable-mbstring --with-gd  --with-libxml-dir=/usr/local  --with-openssl --enable-gd --with-jpeg --with-webp --with-freetype -without-sqlit3 --with-fpm-user=nginx --with-fpm-group=nginx

# 安装
make -j 4 && make install

# 配置文件

cp /usr/local/php/etc/php-fpm.conf.default /usr/local/php/etc/php-fpm.conf
cp /usr/local/php/etc/php-fpm.d/www.conf.default /usr/local/php/etc/php-fpm.d/www.conf

# 修改 www.conf
# 将启动的User修改为 nginx

# 启动 php-fpm
php-fpm

# 检测是否监听
lsof -i:9000

# 验证是否可以与Nginx结合使用
# 参考https://www.cnblogs.com/jiangxiaobo/p/10879457.html
# Nginx创建一个站点，加入配置文件
location ~ .php$ {
root html;
fastcgi_pass 127.0.0.1:9000;
fastcgi_index index.php;
fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
include fastcgi_params;
}
# 重启Nginx后

# 浏览器访问 localhost/index.php
```

> 参考：https://osfere.com/linux/how-to-build-install-and-configure-latest-php-on-centos

> 参考：https://www.cnblogs.com/jiangxiaobo/p/10879457.html



> 安装依赖 apt-get install libbz2-dev libpng-dev libwebp-dev libjpeg-dev libfreetype-dev libfreetype6-dev libonig-dev libsqlite3-dev

## Zabbix服务安装-Zabbix-6.2.1

```sh
./configure --prefix=/usr/local/zabbix --enable-server --enable-agent --with-mysql --enable-ipv6 --with-net-snmp --with-libcurl --with-libxml2
make install
```

> 安装依赖 apt-get install libsnmp-dev

初始化Zabbix

```sql
create database zabbix default charset utf8;
create user 'zabbix'@'localhost' identified by '我是密码';
grant all on zabbix.* to 'zabbix'@'localhost';
flush privileges;
```

```sh
#导入zabbix初始化的数据库表格
# 需要数据库超级权限才可以导入
mysql -uroot zabbix -p < ./database/mysql/schema.sql
mysql -uroot zabbix -p < ./database/mysql/images.sql
mysql -uroot zabbix -p < ./database/myslq/data.sql

# 将安装包内的UI目录下的文件拷贝至 html文件内

# Nginx配置Zabbix_Server
location ~*.\.(php|php5)$
{
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi.conf;
}

index index.html index.php;

# Zabbix初始账户密码为 Admin\zabbix , 一定要尽快更改密码
```

### 问题

post_max_size 要求是16M
max_execution_time 要求是 300
max_input_time 要求是 300

# 参考

https://rohman-zhu.github.io/2017/12/09/ZABBIX%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/
