---
title: Linux下的dm设备
tags:
categories:
  - Linux
date: 2020-06-01 10:41:58
---
# 前言

之前在Linux中，看到一些名字为 dm-xx 的设备。
其实dm是Device Mapper的缩写，Device Mapper 是 Linux 2.6 内核中提供的一种从逻辑设备到物理设备的映射框架机制，在该机制下，用户可以很方便的根据自己的需要制定实现存储资源的管理策略，当前比较流行的 Linux 下的逻辑卷管理器如 LVM2（Linux Volume Manager 2 version)、EVMS(Enterprise Volume Management System)、dmraid(Device Mapper Raid Tool)等都是基于该机制实现的。

> Device Mapper是Linux操作系统中块设备一级提供的一种主要映射机制，现在已被多数Linux下的逻辑卷管理器所采用。在该机制下，实现用户自定义的存储资源管理策略变得极其方便。理解device mapper所提供的映射机制，也是进一步理解Linux下一些常见逻辑卷管理器实现的基础。

# dm-xx 与 当前设备的对应关系

使用命令 dmsetup ls 查看，dm后面的数字对应(253,xx)后面的数字。

```sh
[root@mylnx01 ~]# dmsetup ls 
VolGroup03-LogVol00--PS--user--snapshot (253, 8)
VolGroup00-LogVol00--PS--user--snapshot (253, 2)
VolGroup05-LogVol00     (253, 3)
VolGroup04-LogVol00     (253, 5)
VolGroup05-LogVol00--PS--user--snapshot (253, 4)
VolGroup03-LogVol00     (253, 7)
VolGroup02-LogVol00--PS--user--snapshot (253, 10)
VolGroup02-LogVol00     (253, 9)
VolGroup01-LogVol00     (253, 11)
VolGroup00-LogVol01     (253, 1)
VolGroup04-LogVol00--PS--user--snapshot (253, 6)
VolGroup00-LogVol00     (253, 0)
VolGroup01-LogVol00--PS--user--snapshot (253, 12)
```

使用 dmsetup info 查看详细信息。

# 参考资料

- https://www.cnblogs.com/kerrycode/p/6187148.html

- https://www.ibm.com/developerworks/cn/linux/l-devmapper/index.html