---
title: NOSQL之Memcached缓存服务实战
date: 2017-11-24 14:16:13
tags: Linux
---
# Memcached #

Memcached 是 开源的,支持高性能,高并发的分布式内存缓存系统.有 _服务端_ 与 _客户端_ .

作用:

通过自身内存中缓存关系型数据库的查询结果,减少数据库自身被访问的次数,以提高动态web应用的速度,提高网站架构的并发能力和可拓展性.

类似的软件:

* Memcached (纯内存型)
* Redis/Memcachedb (可持久存储,即可以使用内存,也可以使用磁盘存储)
* Squid/Nginx (内存或内存加磁盘缓存)

## 特性 ##

1. 协议简单
1. 支持 epoll/kqueue异步I/O模型,使用libevent作为事件处理通知机制.
1. key/value键值数据类型
1. 全内存缓存,效率高

## 运行 ##

```sh
#启动Memcached
# memcached -m 16m -p 11211 -d -u root -c 8192
# -m指定缓存大小,-p指定端口 -d指定为daemon运行 , -c 指定并发数(默认1024)
```

memcached相关语法:

```sh
# <command> <key> <flags> <exptime> <bytes> \r\n
# <datablock>\r\n
# <status>\r\n
```

| 相关参数 | 意思 |
|:-------:|:------:|
|command| set无论如何都要进行写入数据,会覆盖老数据;add 只有对应数据不存在时才会添加数据;replace只有数据存在时进行替换数据;append往后追加数据 : append \<key> datablock\<status>?;prepend 往前追加:prepend \<key> datablock\<status>;cas按版本号更改|
|key|普通字符串,要求小于250个字符,不包含空格和控制字符|
|flags| 客户端用来表示数据格式的数值,如json,xml,压缩等|
|exptime|存活时间为s,0为永远,小于30天,60\*60\*24\*30为秒数,大于30天为unixtime|
|bytes|byte字节数,不包含\r\n,根据长度截取 存/取 的字符串,可以是0,即为存空串|
|datablock|文本行,以\r\n结尾,可以包含\r或者\n|
|status| STORED / NOT\_STORED / EXISTS / NOT\_FOUND / ERROR / CLIENT\_ERROR / SERVER\_ERROR 服务端会关闭连接以修复 |

## PHP环境下安装memcache客户端 ##

```sh
# PHP的插件要执行phpize
# /aaplication/php/bin/phpize
# cd memcahe-2.2.7
# ./configure --enable-memcache --with-php-config=/application/php/bin/php-config
# make && make install
```

相关文章 : `http://www.jb51.net/article/70158.htm`

## Memcache内存管理机制 ##

### Malloc内存管理机制 ###

Memory Allocation , 动态内存分配 , 使用场景一般在于无法知道内存具体位置的时候,却想要班定真正的内存空间.

通过动态内存分配后,对使用完的内存用free回收.

> 容易产生内存碎片并降低操作系统对内存的管理效率.加重操作系统内存管理器的负担,甚至,会导致操作系统比memcached进程本身还慢.

### Slab内存管理机制 ###

Slab Allocation

1. 提前将内存分配为1MB的若干个slab,再针对slab进行小对箱填充chunk,避免大量重复的初始化和清理,减轻了内存管理组的负担.(chunk类似block用于存放数据)

slab尾部剩余空间:

如果不足一个chunk,则会浪费内存空间.

> 规划slab大小 = chunk大小 * n整数

## memcache 对 对象检测机制 ##

1. 不主动检测item对象是否过期,而是在get时才会检查item对象是否过期以及是否应该删除.
1. 当删除item对象时,一般不释放内存空间,而是作为标记删除,将指针放入slot回收插槽,下次分配的时候直接使用.
1. 当内存空间满的时候,才会根据LRU算法把最近最少使用的item对象删除.
1. 数据存入可以设定过期时间,但数据过期后不会立即删除,而是在get时才会检查item对象是否过期以及是否应该删除.
1. 如果不希望系统使用LRU算法清除数据,可以使用-M参数.

> Least Recently Used的缩写，即最近最久未使用，常用于页面置换算法，是为虚拟页式存储管理服务的。
