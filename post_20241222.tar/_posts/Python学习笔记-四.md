---
title: Python学习笔记(四)
date: 2017-11-20 09:12:19
tags: Python
---
# Python 学习笔记 四 #

## 错误/调试 ##

在操作系统提供的调用中，返回错误码非常常见。比如打开文件的函数open()，成功时返回文件描述符（就是一个整数），出错时返回-1。

### 错误处理 ###

```python
try:
    print('try...')
except Error as e:
    print('except',e)
finally:
    print('finally...')
print('End')
```

> 由于没有错误发生，所以except语句块不会被执行，但是finally如果有，则一定会被执行（可以没有finally语句）。

Python的错误其实也是class，所有的错误类型都继承自 _BaseException_ ，所以在使用except时需要注意的是，它不但捕获该类型的错误，还把其子类也“一网打尽”。

```java
try
{
    pass
}
catch(Exception e)
{
    System.out.println(e)
}
```

如果不捕获错误，自然可以让Python解释器来打印出错误堆栈，但程序也被结束了。既然我们能捕获错误，就可以把错误堆栈打印出来，然后分析错误原因，同时，让程序继续执行下去。

Python内置的logging模块可以非常容易地记录错误信息：

```python
try:
    pass
except Exception as e:
    logging.exception(e)
```

### 调试 ###

断言:

凡是用print()来辅助查看的地方，都可以用断言（assert）来替代：

```python
def foo(s):
    n = int(s
    assert n != 0 , 'n is zero'
    return 10/n
def main():
    foo('0')
```

assert的意思是，表达式n != 0应该是True，否则，根据程序运行的逻辑，后面的代码肯定会出错。

如果断言失败，assert语句本身就会抛出AssertionError

## IO编程 ##

IO编程中，Stream（流）是一个很重要的概念，可以把流想象成一个水管，数据就是水管里的水，但是只能单向流动。Input Stream就是数据从外面（磁盘、网络）流进内存，Output Stream就是数据从内存流到外面去。对于浏览网页来说，浏览器和新浪服务器之间至少需要建立两根水管，才可以既能发数据，又能收数据。

### 文件读写 ###

以读文件的模式打开一个文件对象，使用Python内置的open()函数，传入文件名和标示符：

```python
f = open('/Users/michel/test.text','r')
#读取成功,调用read()方法就可以一次读完全部能容
f.read()
#最后有一步是关闭文件,释放资源
f.close()
```

标示符'r'表示读，这样，我们就成功地打开了一个文件。

* 调用read()会一次性读取文件的全部内容，如果文件有10G，内存就爆了，所以，要保险起见，可以反复调用read(size)方法，每次最多读取size个字节的内容。

* 调用readline()可以每次读取一行内容，调用readlines()一次读取所有内容并按行返回list.

设置字符编码:

```python
f = open('/Users/michael/gbk.txt', 'r', encoding='gbk')
f.read()
```

写文件:

写文件和读文件是一样的，唯一区别是调用open()函数时，传入标识符'w'或者'wb'表示写文本文件或写二进制文件：

```python
>>> f = open('/Users/michael/test.txt', 'w')
>>> f.write('Hello, world!')
>>> f.close()
```

>当我们写文件时，操作系统往往不会立刻把数据写入磁盘，而是放到内存缓存起来，空闲的时候再慢慢写入。只有调用close()方法时，操作系统才保证把没有写入的数据全部写入磁盘。忘记调用close()的后果是数据可能只写了一部分到磁盘，剩下的丢失了。

### StringIO & ByteIO ###

这个不是对文件操作,而是对内存中的流来操作

## 进程和线程 ##

对于操作系统来说，一个任务就是一个进程（Process），比如打开一个浏览器就是启动一个浏览器进程，打开一个记事本就启动了一个记事本进程，打开两个记事本就启动了两个记事本进程，打开一个Word就启动了一个Word进程。

有些进程还不止同时干一件事，比如Word，它可以同时进行打字、拼写检查、打印等事情。在一个进程内部，要同时干多件事，就需要同时运行多个“子任务”，我们把进程内的这些“子任务”称为线程（Thread）。

### 多进程 ###

Unix/Linux操作系统提供了一个fork()系统调用，它非常特殊。普通的函数调用，调用一次，返回一次，但是fork()调用一次，返回两次，因为操作系统自动把当前进程（称为父进程）复制了一份（称为子进程），然后，分别在父进程和子进程内返回。

子进程永远返回0，而父进程返回子进程的ID。这样做的理由是，一个父进程可以fork出很多子进程，所以，父进程要记下每个子进程的ID，而子进程只需要调用getppid()就可以拿到父进程的ID。

```python
import os

print('Process (%s) start ...' % os.getpid())
# Only works on Unix/Linux/Mac
pid = os.fork()
if pid == 0:
    print('child,parentpid is (%s)' % os.getppid)
else:
    print('Parent')
```

小结:

* Unix/Linux下,可以用fork()调用实现多进程
* 要实现跨平台,可以使用multiprocessing
* 进程间通信是通过Queue,pipes实现的

### 多线程 ###

Python的标准库提供了两个模块：_thread和threading，_thread是低级模块，threading是高级模块，对_thread进行了封装。绝大多数情况下，我们只需要使用threading这个高级模块。

## 正则表达式 ##

* 用\d可以匹配一个数字
* \w可以匹配一个字母或数字
* .可以匹配任意字符
* 用*表示任意个字符（包括0个）
* 用+表示至少一个字符
* 用?表示0个或1个字符
* 用{n}表示n个字符
* 用{n,m}表示n-m个字符
* 要做更精确地匹配，可以用[]表示范围
* ^表示行的开头，^\d表示必须以数字开头
* $表示行的结束，\d$表示必须以数字结束。

```python
#匹配010 - 12345
正则表达式: \d{3}\-\d{5}
```