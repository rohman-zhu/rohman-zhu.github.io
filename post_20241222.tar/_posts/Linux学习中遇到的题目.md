---
title: Linux学习中遇到的题目
date: 2017-10-02 21:28:20
tags: Linux
---
# 企业面试题 或者 课程练习题目 #

## 如何查询 file.txt 文件 第20行到第30行的内容 ##

查询一个xx.txt 20 - 30 行的内容

- M1:

```{.normal}
# head -30 xx.txt | tail -11
```

- M2：

```{.LinuxCommand}
# sed -n '20,30p' xx.txt
```

## 如何过滤出已知目录（/home/)，子目录下所有的一级目录 ##

_M1:_

```{.normal}
# ls -l | grep "^d"

```

### 【知识点】 正则表达式 ###

一些特殊的符号表示一些特殊的作用和功能

| 符号 | 意义 |
|:---------:|:--------:|
|.  |单个任意的字符|
|*  |重复前面任意0个或多个字符|
|^x |表示以x开头|
|$x |表示以x结尾|

_M2:_

```{.normal}
# ls -lF | grep /
# ls -lF | grep "/$"
```

### 【知识点】 ls -F 指令 ###

>在每个输出项后追加文件的类型标识符，具体含义：“*”表示具有可执行权限的普通文件，“/”表示目录，“@”表示符号链接，“|”表示命令管道FIFO，“=”表示sockets套接字。当文件为普通文件时，不输出任何标识符；

_M2.1 :_

```{.normal}
# ls -lp | grep /
```

### 【知识点】 ls -p 指令 ###

> -p 指令表示给目录文件加上 '/'

_M3 :_

```{.normal}
# find ./ -type d maxdepth 1
```

### 【知识点】find的两个参数 ###

> -maxdepth<目录层级>：设置最大目录层级；

_M4 :_

```{.normal}
# tree -Ld 1
```

### 【知识点】 tree的参数 ###

tree指令是用于显示目录树结构

```{.normal}
#安装
# rpm -qa tree
```

> -L 表示层数
> -d b表示目录

_M5 :_

```{.normal}
# ls -lF | awl '/^d/'
```

_M6 :_

```{.normal}
# ls -lF | sed -n '/^d/p'
```

## 如何切换会上一个路径 ##

```{.normal}
# cd /temp
# cd -
```

因为在环境变量中（‘env’）会存放着这个就路径的数据。

```{.normal}
OLDPWD=/tmp
```

## 如何快速查找并显示到当前页面 ##

```{.normal}
# ls -lrt
```

### 【知识点】 ls 的参数 ###

- -r : 以文件名反序排列并输出目录内容列表；
- -t : 以文件修改时间排序。
- --color=auto ,让查看的文件类型以不同的颜色显示。

### 如何将查找内容显示行号 ###

```{.normal}
#过滤内容
# grep -n xxx.txt

cat内容
# cat -n xxx.txt

# nl xxx.txt

```

## 如何对不同开机启动级别设置自启服务？ ##

用 chkconfig 命令 以sshd为例子

```{.normal}
# chkconfig --level 35 sshd on

# chkconfig --list sshd
```

### 【知识点】 chkconfig 指令 ###

chkconfig管理脚本的要求。

1. 需要通过 /etc/init.d/xxxx restart 格式正常重启服务。
1. 脚本开头需要如下两行。

```{.normal}
# chkconfig: 35 56 24
# description : xxx linux test.
```

## 解释一下Linux的1-6开机级别 ##

```{.normal}
0. 关机模式
1. 单用户
2. 无NFS的多用户模式
3. 文本模式（完整的多用户模式）
4. 未使用
5. 图形模式
6. 重启模式
```

## /etc 目录为linux系统的默认的配置文件及服务启动命令的目录 ，需要进行打包 ##

tar zcvf 路径【筐】 目标【苹果】

```{.normal}
# tar zcvf etc.gz /etc
```

### 关于tar指令的参数 ###

- -c或--create：建立新的备份文件；
- -z或--gzip或--ungzip：通过gzip指令处理备份文件；
- -v或--verbose：显示指令执行过程；
- -f<备份文件>或--file=<备份文件>：指定备份文件；
- -t或--list：列出备份文件的内容；
- -X,  --exclude-from  FILE ;
- -x或--extract或--get：从备份文件中还原文件；

## /etc目录为linux系统的默认的配置文件及服务启动命令的目录 ，现需要进行打包（排除server目录）##

_M1 :_

```{.normal}
# tar zcvf etc.gz --exclude="etc/server" /etc
```

_M2 :_

```{.normal}
# touch exclude.list
# echo /etc/server >> exclude.list
# tar zcvfX etc.gz exclude.list /etc
```

## 解压etc.gz 文件 ##

```{.normal}
# tar xf etc.gz /home
```

## 取xxx.txt内容中的第3，第6列 ##

```{.normal}
# awk '{print $3 " "$6}' xxx.txt

# cut -d" " -f3,6 xxx.txt
```

> cut 是简单的取列的命令， -d指定分隔符，-f数字，取第几列的内容。

## 如果向磁盘写入数据提示如下错误 ： No space left on device，通过 df -h查看磁盘空间发现没满，请问可能是什么原因？ ##

可能是inode数量被消耗尽了。

</br>

用 df -i 查看是否消耗尽了inode数量。

</br>

企业工作中邮件临时队列/bar/spool/clientmquene这里很容易被大量小文件占满，导致"No space left on device"的错误。 clientmquene 目录只有安装了 sendmail服务，才会有。

> centOS5.8默认就会安装sendmail，centOS6.6默认就没有安装sendmail.

## 一个100M（100 000 K） 的磁盘分区，分别写入1K的文件或写入1M的文件，分别可以写多少个 ##

1. 默认风趣常规情况下，对大文件来讲inode是足够的。而block数量消耗的会更快，BLOCK为4k的情况，1M的文件不会有磁盘浪费情况，所以文件数量大概为 100 / 1 = 100 个。
1. 对于小文件 0.1 k ，inode 会消耗的更快。默认分区的时候block数量是大于inode数量的。

【知识点】

- 该题目是考察文件系统inode 和 block 的知识。
- Inode 是存放文件属性信息的 （也包含指向文件实体的指针），默认大小是128byte（c58），256（c64）。
- block 是存放文件实际内容的，默认大小 1K（boot）或者 4K（非系统分区默认给4K）。
- 默认较大分区常规企业真实场景情况下，inode数量是足够的，而block数量晓得会更快。

## 为什么查询到目录至少有两个硬链接 ##

因为每一目录都有 ./ 自身一个链接，../上级目录的链接。

## 为了防止木马入侵，文件和目录什么权限，安全临界点？ ##

> 思路 ： 要将文件或者目录 设置为 不能写与删。

```{.normal}
目录 755 root root

文件 644 root root
```

## 项目 ： 服务器用户权限管理改造方案与实施项目 ##

## 授权oldboy目录以及其子目录755的权限，请给出命令。 ##

```{.normal}
# chmod -R 755 oldboy
```

## 将oldboy目录以及其子目录的属主改为oldboy，组为root，请给出命令 ##

```{.normal}
# chown -R oldboy.root oldboy
```

## 添加一个用户oldboy ，并指定属于sa组，要求组ID为801，uuid为808，并且不建立家目录，禁止其登录 ##

```{.normal}
# groupadd -g 801 sa
# useradd -u 808 -M -s /sbin/nologin -g sa oldboy
```

## vim 命令编辑器快捷键复习 ##

vim分为两种模式： 命令模式 与 编辑模式

> 命令模式

- 保存 ， Esc + wq + enter
- 退出 ， Esc + q + enter
- 光标强制移到文件的最后一行，shift + g
- 光标移到开头 ， g + g
- 将光标移到本行的开头 ， ^ , 0
- 将光标移到本行的结尾 ， $
- 删除一行 ， d + d
- 回撤操作 ， u
- 向下搜索 ， / + 搜索内容
- 向上搜索 ， ？ + 搜索内容
- 对搜索内容向下查找 ， n
- 对搜索内容向上查找 ， N
- 把A替换成B ， : + % + s + / + A + / + B + / + g

## Cache 与 Buffer 的区别 ##

1. Cache：缓存区，是高速缓存，是位于CPU和主内存之间的容量较小但速度很快的存储器，因为CPU的速度远远高于主内存的速度，CPU从内存中读取数据需等待很长的时间，而  Cache保存着CPU刚用过的数据或循环使用的部分数据，这时从Cache中读取数据会更快，减少了CPU等待的时间，提高了系统的性能。

> Cache并不是缓存文件的，而是缓存块的(块是I/O读写最小的单元)；Cache一般会用在I/O请求上，如果多个进程要访问某个文件，可以把此文件读入Cache中，这样下一个进程获取CPU控制权并访问此文件直接从Cache读取，提高系统性能。

1. Buffer：缓冲区，用于存储速度不同步的设备或优先级不同的设备之间传输数据；通过buffer可以减少进程间通信需要等待的时间，当存储速度快的设备与存储速度慢的设备进行通信时，存储慢的数据先把数据存放到buffer，达到一定程度存储快的设备再读取buffer的数据，在此期间存储快的设备CPU可以干其他的事情。

> Buffer：一般是用在写入磁盘的，例如：某个进程要求多个字段被读入，当所有要求的字段被读入之前已经读入的字段会先放到buffer中。

## 如何恢复MBR记录 ##

```{.normal}
#复制#1扇区的引导文件
# dd if=/dev/sda of=mbr.bin bs=512 count=1

恢复#1扇区的引导文件
# dd if=mbr.bin of=/dev/sda bs=512 count=1
```

## 磁盘分区的重点 ##

1. 磁盘分区的实质就是针对0磁头0磁道1扇区的前446字节后面接下来的64bytes的分区表进行设置，即主要是划分起始以及结束磁头号，及扇区号和柱面号。
1. 分区工具有fdisk（适合小于2T的磁盘分区），parted（适合大于2T的磁盘分区，可以对小于2T的磁盘分区），fdisk首选，只有大于2T时采取选parted。

## 文件系统 ##

### SAS/SATA 硬盘文件系统选择 ###

1. reiserfs 大量小文件业务首选（100K以内）
1. xfs 门户的数据库MySQL业务。
1. ext4 视频下载，流媒体，数据库，小文件业务，可以作为默认。
1. ext2 没有日志，用于CDN网络加速服务的。

> xfs,reiserfs 需要单独安装。默认不支持，大量服务器使用多文件系统维护可能不方便。
> 大并发并不是过多的做磁盘系统的优化，而是在架构前端增加缓存，存储数据库的前段增加缓存。

## SSH服务无法连接 ##

故障原因：

- 有可能是网卡ip地址与端口号设置错误
- sshd 服务没开启
- 是否允许用户密码登陆
- 是否被防火墙拦截

### 关于IP设置，有两种方法 ###

#### 方法一 ####

直接修改 /etc/sysconfig/network-script/ifcfg-ethX 文件

#### 方法二 ####

用命令 ifconfig 指令

```{.normal}
# ifconfig 网卡名字 IP地址
# ifconfig eth1 x.x.x.x
```

## 公司所采用的系统是什么版本的 ##

通过两个指令查询

```{.normal}
# cat /etc/redhat-release
# uname -r
```

答案是： 采用的是CentOS6.9，x86_64位系统。

## 处理以下文件内容,将域名取出并根据域名进行计数排序处理 ##

```{.txt}
# text.txt
http://www.baidu.org/index.html
http://www.baidu.org/1.html
http://post.baidu.org/index.html
http://mp3.baidu.org/index.hml
http://www.baidu.org/3.html
http://post.baidu.org/2.html
```

思路:除去重复+计数重复,运用sort指令,加上uniq -c指令来计数.

```{.normal}
# awk -F / '{print $3}' |sort | uniq -c
```

方法二:

用cut指令来切割

```{.normal}
# cut -d / -f3 test.txt|sort|upiq -c
```

方法三:

```{.normal}
# awk -F "/" '{S[#3]=S[$3]+1}END{ for(k in S)} print k,S[K]}' test.txt
```