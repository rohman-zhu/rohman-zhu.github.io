---
title: VCSA中虚拟机迁移按钮是灰色的
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2024-07-21 22:31:59
---

# 故障描述

在VCSA中，选中目标虚拟机做迁移动作时，虚拟机的Migrate选项是灰色的，不可点击的。

# 原因分析

虚拟机处于备份状态中，无法进行vMotion。或者备份已经结束了，但虚拟机的状态未自动恢复正常。
在虚拟机备份完成后，没有移除 vCenter Server 数据库 vpx_disabled_methods 表中的条目时，可能会出现此问题。

# 解决方法

1. 确定目标虚拟机的ID，vm-xxxxx;
2. WEB 浏览器打开这个地址:
```ps1
# <ExamplevCenterFQDNorIP> 替换 为 VCSA 地址；
https://<ExamplevCenterFQDNorIP>/mob/?moid=AuthorizationManager&method=enableMethods
```
3. 使用 SSO 账户登录；
4. 在 entity 的 VALUE 框中，将 MOID 替换为 虚拟机的ID；
5. 在 method 的 VALUE框中；
```ps1
填入 <method> RelocateVM_Task </method> ；
```
6. 点击调用方法 Invoke Method;
7. 刷新浏览器，重新执行虚拟机vMotion；

# 参考：
https://knowledge.broadcom.com/external/article?legacyId=1029926
https://www.cnuu.net/server/os/vmware/vmware-vsphere-%e8%99%9a%e6%8b%9f%e6%9c%ba%e8%bf%81%e7%a7%bb%e6%8c%89%e9%92%ae%e7%81%b0%e8%89%b2%e8%a7%a3%e5%86%b3%e6%96%b9%e6%a1%88.html
https://blog.csdn.net/avenjan/article/details/135113397