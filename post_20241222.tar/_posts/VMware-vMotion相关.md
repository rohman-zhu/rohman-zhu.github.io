---
title: VMware-vMotion相关
tags:
  - vMotion
categories:
  - VMware
  - vSphere
date: 2024-05-19 00:36:59
---
# vMotion 相关文章

## Powered-off vMotion (relocate) of a large virtual machine across datastores may timeout in vCenter

https://knowledge.broadcom.com/external/article/318734/poweredoff-vmotion-relocate-of-a-large-v.html

## vMotion 同时迁移的限制

https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.vcenterhost.doc/GUID-25EA5833-03B5-4EDD-A167-87578B8009B3.html#GUID-25EA5833-03B5-4EDD-A167-87578B8009B3

## Multiple-NIC vMotion in vSphere

https://knowledge.broadcom.com/external/article?legacyId=2007467

## Troubleshooting vMotion

https://blogs.vmware.com/vsphere/2019/09/troubleshooting-vmotion.html

## How to Tune vMotion for Lower Migration Times?

https://blogs.vmware.com/vsphere/2019/09/how-to-tune-vmotion-for-lower-migration-times.html

## How is Virtual Memory Translated to Physical Memory?

https://blogs.vmware.com/vsphere/2020/03/how-is-virtual-memory-translated-to-physical-memory.html

## The vMotion Process Under the Hood

https://blogs.vmware.com/vsphere/2019/07/the-vmotion-process-under-the-hood.html

## vSphere 7 - vMotion Enhancements

The vSphere vMotion feature enables customers to live-migrate workloads from source to destination ESXi hosts. Over time, we have developed vMotion to support new technologies. The vSphere 7 release is no exception to that, as we greatly improved the vMotion feature. The vMotion enhancements in vSphere 7 include a reduced performance impact during the live-migration and a reduced stun time. This blog post will go into details on how the vMotion improvements help customers to be comfortable using vMotion for large workloads.

![vMotion发展](https://blogs.vmware.com/vsphere/files/2020/03/vmotion-history-2048x463.png)

To understand what we improved for vMotion in vSphere 7, it is imperative to understand the vMotion internals. Read the vMotion Process Under the Hood to learn more about the vMotion process itself.

### Large VM vMotion Challenges

vSphere is the perfect platform to host large virtual machines (VMs) — also referred to as “Monster” VMs — with the current per VM resource maximums set to 256 vCPU’s and 6 TB of memory. However, we noticed that customers running workloads in large VMs were not always comfortable live-migrating these VMs. That was due to a potential impact on workload performance during the vMotion process, and a switch-over (stun) time that took too long.

For example, large transactional database platforms that are dealing with a substantial number of I/Os could experience performance degradation during a vMotion, although the precise impact strongly depends on the workload’s characteristics & sizing. The enhanced logic for vMotion in vSphere 7 overcomes all these challenges and allows us to live-migrate large workloads without significant impact on performance or availability.

### Memory Pre-copy Optimizations

As explained in this video, we need to keep track of all the changed memory pages for a VM during its vMotion operation. Because it is a live-migration, the guest OS inside the VM will keep writing data to memory during the vMotion. We need to track and resend memory pages that are overwritten during a vMotion.

![vMotion ](https://blogs.vmware.com/vsphere/files/2020/03/vMotion-page-trace-v2-old.png)

The vMotion process installs a page tracer on all the vCPUs that are configured for the VM. By doing so, vMotion understands what memory pages are being overwritten. This is referred to as a ‘page fire’ during page tracing. We are distributing the tracing work to all the vCPU’s for the VM that is live-migrated.

To install the page tracer and to process a page fire, the vCPUs are briefly stopped. It’s only microseconds, but stopping all vCPUs disrupts the workload. Scaling up the compute resources of a VM increases the impact of a vMotion operation. After stopping the vCPUs for the tracing work, all memory Page Table Entries (PTE) are set to read-only, and the Translation Lookaside Buffers (TLB) are flushed to avoid TLB hits and force a page table walk so the vMotion process fully understands what memory pages have been overwritten. Learn more on these memory constructs in this blog

### How we do it in vSphere 7

The biggest impact comes from having to stop all the vCPUs for page tracing. What if we can install the page tracers without the need to stop all vCPUs? With vSphere 7, we are introducing the “Loose Page Trace Install.” The method for page tracing mostly remains the same but instead of using all vCPUs, we now only claim one vCPU to perform all the tracing work. All the other vCPUs that are entitled to the VM just continue to run the workload without interruption.

![vSphere 7 vmotion](https://blogs.vmware.com/vsphere/files/2020/03/vMotion-page-trace-v2-new.png)

### Page Table Granularity

So we reduced the cost of tracing, but what if we can make it even more efficient? We optimized the way we set memory to read-only, meaning there’s less work to be done on this part. Less work means increased efficiency. The way memory is set to read-only prior to vSphere 7 is on a 4KB page granularity. All the individual 4KB pages needed to be set to read-only access.

![Page](https://blogs.vmware.com/vsphere/files/2020/03/pagetableoverviewv2.png)

As of vSphere 7, the Virtual Machine Monitor (VMM) process will set the read-only flag at a much larger granularity, on 1GB pages. If a page fire (a memory page is overwritten) occurs, the 1GB PTE is broken down into 2MB and 4KB pages. VMware engineers have seen that a VM is typically not touching all of its memory during a vMotion process. The memory working set size during a vMotion is typically only 10-30%. If more memory is used during the vMotion time, the cost efficiency will be less.

### Switch-over Phase Enhancements

All the enhancements we have discussed so far are done in the memory pre-copy phase, where the tracing happens. Once we reach memory convergence, meaning almost all memory is copied to the destination host, vMotion is ready to switch-over to the destination ESXi host. In this last phase, the VM on the source ESXi host is suspended and the checkpoint data is sent to the destination host. Remember that we want the switch-over time (stun time) to be 1 second or less. For large VMs, this has become a challenge because of workload sizes that have increased over time.

In the switch-over phase, we send over the checkpoint data and the memory bitmap. The memory bitmap is used to track all the memory of a VM. It know what pages are overwritten and still need to be transmitted the destination ESXi host. As vMotion transfers the last memory pages, the VM on the destination host begins to power on. But it might still need the last pages left for transmission. To identity these pages on the destination, we use the bitmap that is transferred from the source. If customers overcommit memory, the swapped-out pages are tracked in the optional swap bitmap.

![full bitmap](https://blogs.vmware.com/vsphere/files/2020/03/fullbitmapv2.png)

### How vSphere 7 does it

With VMs running 6TB of memory (or potentially even more in the future), the bitmap is already 192MB. To stay under 1 sec of switch-over time, we need the bitmap to be smaller as sending over 192MB could take up to a second or more. What if we could compact the bitmap, and only send over the information that you really need?

![vSphere 7 compacted bitmap](http://blogs.vmware.com/vsphere/files/2020/03/compactedbitmapv2.png)

At this stage we have already copied most of the memory pages, so only the last remaining memory pages need to be sent. Using a compacted memory bitmap, vMotion is able to send bitmaps for large VMs over in milliseconds, drastically lowering the stun time.

### Performance Improvements

These enhancements to vMotion in vSphere 7 allow workloads to be live-migrated with almost no performance degradation during a vMotion. The following diagram is an example of a test to show you the potential performance gains in vSphere 7. The testbed is a large VM (72 vCPU / 512GB) running a HammerDB workload. We monitor the commits/sec over a timeline with a 1 second granularity.

A couple of key takeaways that we noticed during this test in vSphere 7, compared to vSphere 6.7, are:

- We no longer experience the performance impact during the page trace phase.
- The stun time remains within 1 second instead of taking multiple seconds.
- The overall live-migration time is almost 20 seconds shorter.

![vSphere6.7 vSphere7 ](https://blogs.vmware.com/vsphere/files/2020/03/vmotion7-improvements.png)

Your mileage may vary depending on vMotion network configurations and VM sizing, but this is an exemplary test to show the potential benefits of these vMotion improvements.

### To Conclude

The improvements made in vMotion with vSphere 7 are enormous and greatly reduce the cost paid for a vMotion. You don’t need to anything to enjoy the new and improved vMotion logic, other than to upgrade your systems to vSphere 7.

参考：https://blogs.vmware.com/vsphere/2020/03/vsphere-7-vmotion-enhancements.html


## vSphere-7-Storage vMotion Improvements

参考： 

https://blogs.vmware.com/vsphere/2020/06/vsphere-7-storage-vmotion-improvements.html

## ESXi提升vMotion速率 ， vMotion的属性设置

Here’s the situation I was facing. Two Vmware vCenter 7.0.3. clusters on opposite sides of the country, connected via a a 10gig point to point ethernet circuit, and that circuit tends to have a bit of packet loss (0.5%-1%) under heavy utilization. Being cross country, it of course also has latency, typically in 55ms RTT range.

Vmware supports long distance vMotion. They claim you can do it with latency as high as 150ms. I found that to be the case, but whether a zero-loss site to site VPN across the internet, or across this high speed point to point link, I was never able to get vMotion to average more than a few hundred megabits. That is of course complete garbage if you’re trying to move terabytes of VM’s without downtime. If they’re frequently changing, and the rate of change exceeds the speed at which you can move data, you may even find vMotion impossible to use.

I found the above was due to the packet loss. I’ve done the same tests across a proper 10gig wave between locations, with the same latency but without the lossiness. On those I’d see a gigabit or two, but still far from full utilization. I suspect I could get that up to several gigabits after what I’ve learned and will share here, I just didn’t go back to test.

The cause of the problem is the vMotion (hot migrations) and provisioning (cold migrations) network stacks are based on decades out-of-date TCP configurations. They use a choice of two ancient congestion control algorithms, New Reno or Cubic, and both of those treat loss as congestion. When they see loss, they overreact and greatly reduce the TCP window size, causing your throughput to nosedive, then they take an excruciatingly long time to open it back up, and chances are another bit of loss will occur, compounding the issue.

Across this same lossy link, I did testing between two linux nodes set to use the BBR congestion control algorithm, and some other minor tuning I found at https://fasterdata.es.net/host-tuning/linux/test-measurement-host-tuning/:

```sh
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
```

With that config in place, I can frequently push 7+ Gbps with a single TCP session, where with the default linux congestion control of cubic, and default settings, I’d be lucky to average more than a gigabit.

Vmware doesn’t allow you to tinker with congestion control or windowing / buffer settings. So my workarounds for this were focused mostly on multi-stream vmotion, after reading pages like these:

https://core.vmware.com/resource/how-tune-vmotion-lower-migration-times#section1
https://kb.vmware.com/s/article/2007467
I tinkered extensively with the number of vmotion vmkernel ports defined, and custom values in the following settings:

```sh
Migrate.NetExpectedLineRateMBps
Migrate.VMotionStreamHelpers
Net.TcpipRxDispatchQueues
Migrate.BindToVmknic
```

I probably went through about 30 permutations of settings, and the one that I finally arrived at was:

```sh
Two target vmkernel ports
Five source vmkernel ports

Migrate.NetExpectedLineRateMBps = 2000
Net.TcpipRxDispatchQueues = 5
Migrate.BindToVmknic = 2
Migrate.VMotionStreamHelpers = 48
```

I know that sounds kind of insane to have 48 stream helpers, but I went all the way to 64 in +8 jumps and 48 had the highest throughput for my 16 pCore source vMotion server. With the above config, 55ms 10gig circuit with ~1% loss, I was able to do cross country live vmotions of both VM state and storage at upwards of 2.4 Gbps. I did start out with more vmkernel ports on the target, but for whatever reason, while this config allows for 48 TCP sessions spread evenly across the five source vmkernel ports, they’d still only target two unique IP addresses, so the other three served no purpose.

This above config is also particularly useful if you have a Cogent point to point / metroE circuit between locations, because those are often rate limited to around 2 gbps per TCP session even if you’re paying for a full 10gig circuit. Since vMotion spreads the flows evenly across all the TCP sessions, this will let you better utilize the link with no one session hitting the rate limit and being throttled.

Next up, I found a second way to get around this issue which could be of interest to those who want more of a bandaid fix to evacuate one cluster for another; i.e. not permanent. I happened across this reddit thread where u/LatinSuD reported having similar issues solved by the use of socat to proxy the TCP session to the remote host. This was intriguing for me because I know my lossy link, in the hands of a modern TCP tuning, is capable of nearly wire speed. I tested it out and it worked. With only crude tuning, I was able to achieve 4 Gbps of vMotion between the same hosts and across the same link, where I could only get 2.4 Gbps with native tuning options. There’s probably more to go too if socat were running on a more modern system, but I have it on an old four core Xeon E3-1225 dating to 2011, so truly ancient hardware. The system has a Mellanox Connect-X 3 10gig NIC.

Here was my config:

Source ESXi host vmotion vmkernel interface: 10.88.0.9/24
Source ESXi host vmotion network default gateway override: 10.88.0.1
Target ESXi host vmotion vmkernel interface: 10.99.0.9/24
socat proxy linux system vmotion interface: 10.88.0.1

```sh
One target vmkernel port
One source vmkernel port

Migrate.NetExpectedLineRateMBps = 2000
Net.TcpipRxDispatchQueues = 5
Migrate.BindToVmknic = 2
Migrate.VMotionStreamHelpers = 5
```

The above config results in the source vmotion server wanting to talk to port 8000 on the target 10.99.0.9. However, since it’s been given a default gateway (you could also add a custom static route if needed) of the socat server, it’s going to send its packets to that system regardless.

On the socat server, I alter the packets with a destination NAT rule so it delivers those packets to itself instead of discarding or attempting to route them (if forwarding were enabled):

```sh
iptables -t nat -A PREROUTING -p tcp -d 10.99.0.9 --dport 8000 -j DNAT --to-destination 10.88.0.1:8000

```

I also have the earlier sysctl settings in place, and most importantly, BBR congestion control:

```sh
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc=fq
net.ipv4.tcp_congestion_control=bbr
```

Make sure no CPU throttling as socat is cpu-bound:

```sh
cpupower frequency-set -g performance
```

Now start socat up to forward the received packets to the vmotion target:

```sh
socat TCP4-LISTEN:8000,fork,reuseaddr,bind=10.88.0.1 TCP4:10.99.0.9:8000
```

With the above config, the source vmotion server will use five TCP sessions. Its packets are intercepted by the socat server, rewritten to have a target of the local interface IP, socat is listening and accepts them, five socat children are spawned and connected to the target vmotion interface. It then forwards them as part of a new proxied TCP session to the target vmotion interface. Because of the proxying, the TCP conversation between source and socat occur on the local fast and non-lossy network, and the TCP conversation between the socat server and the target vmotion uses the BBR algorithm and a tuned TCP stack to achieve massively improved throughput. Like I said, old server with a 12 year old CPU and many years old NIC, still saw 4+ Gbps on this lossy link.
https://www.ispcolohost.com/2023/10/02/speeding-up-long-distance-vmotion/


### ESXi 属性信息

https://github.com/lamw/esxi-advanced-and-kernel-settings/blob/master/esxi-80a-advanced-settings.md