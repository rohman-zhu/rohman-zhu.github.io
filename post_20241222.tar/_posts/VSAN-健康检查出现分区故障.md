---
title: VSAN-健康检查出现分区故障
tags:
  - 故障
categories:
  - VMware
  - vSphere
  - vSAN
date: 2023-10-06 22:20:15
---
# 故障描述

vSAN集群的健康检查中，出现分区错误，有一台主机的vSAN分区为2号，其他主机的vSAN分区为1号。

# 原因分析

1. 网络异常：vSAN节点之间网络不通；
2. 版本问题：vSAN节点之间版本不一致；
2. 目标主机未开启集群发现；

# 解决方法

先确认 vSAN Kernel 网络流量是否正常；

```sh
# 获取 vSAN 网卡信息
esxcli vsan network list
# 获取 IP 配置信息
esxcli network ip interface ipv4 get
# 结合上述信息，确定vSAN用的 vmk 、IP信息；

# 发起ping测试
ping [目标IP]

# 指定对应网卡发起ping测试
vmkping -I [vSAN用的网卡] [目标IP]
```

> 确定网络是否正常，另外MTU也是需要关注的；

确定磁盘版本是否一致；

```sh
esxcli system settings advanced list -o /Virsto/DiskFormatVersion
```

> 如果磁盘版本不一致，则需要检查ESXi版本是否一致，是否有升级；

检查分区更新值

```sh
# 确认成员更新值
esxcfg-advcfg -g  /VSAN/IgnoreClusterMemberListupdates
# 如果值为1，则表示目标主机当前状态为“禁止从 vCenter Server 中更新集群成员”
# 需要重新执行指令：
esxcfg-advcfg -s 0 /VSAN/IgnoreClusterMemberListupdates
```

# 参考资料

解决VMware vSAN分区故障：https://m.fx361.com/news/2018/1106/18285695.html
如何使用旧格式版本格式化 VSAN 磁盘组 ：https://kb.vmware.com/s/article/2146221?lang=zh_CN
vSAN 运行状况服务 - 网络运行状况 - vSAN 群集分区：https://kb.vmware.com/s/article/2108011?lang=zh_CN
如何处理 VSAN 群集中的隔离/分区情形？：https://blog.51cto.com/vsdsrevolution/1375800
Configuring vSAN Unicast networking from the command line (2150303)： https://kb.vmware.com/s/article/2150303
手动关闭并重新启动 vSAN 集群：https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.vsan-monitoring.doc/GUID-31B4F958-30A9-4BEC-819E-32A18A685688.html
