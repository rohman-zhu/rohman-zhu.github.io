---
title: Keepalived高可用集群
date: 2017-11-16 18:17:11
tags: Linux
---
# Keepalive #

起初是为LVS设计的,专门用来监控LVS集群系统中各个服务节点的状态,后来又加入了VRRP的功能(Virtual Router Redundancy Protocol 虚拟路由器冗余协议),因此配合除了LVS服务外,也可以作为其他服务(nginx,haproxy)的高可用软件.

> VRRP出现是为了解决静态路由出现的单点故障问题.

主要两大用户:healthcheck , failover

## VRRP ##

Virtual Router Redundacy Protocol,解决静态路由器的单点故障,VRRP时通过一种竞选协议机制来将故障路由器的任务给某台VRRP.

* VRRP是通过IP多播的方式实现通信
* 主发包,备接包,当备接不到主发的包的时候,就启动接管程序接管主的资源.

## failover ##

实现LB Master主机和 Backup 主机之间故障转移何自动切换.(这里针对有两个负载均衡)

## healthcheck ##

1. keepalived.conf里面配置就可以实现LVS.
1. keepalive可以对LVS下面的集群节点做监控检查.

负载均衡定期检查RSYNC的可用性决定是否给其分发请求.

## keepalived 故障切换转移原理 ##

1. 在keepalived directors正常工作时,主Director节点会不断向被节点广播心跳消息,告诉备节点设备--主节点设备正常.
1. 当主节点发生故障时,备节点就无法检测到主节点的心跳,今儿调用自身的接管程序,接管主节点的IP资源与服务.
1. 当主节点恢复时,备节点会释放主节点故障时自身接管的IP资源与服务,恢复到原来的自身备用角色.

## 配置keepalive ##

官网 `http:\\www.keepalived.org`

这里用的是 1.2.16 的版本.

相关的配置可以用man keepalived.conf查看,这里只列出80%

```sh
# ln -s /user/src/kernel/2.6 /usr/src/linux

# 到keepalive的文件包里面
# ./configure
# 出现以下相关内容即可
Use IPVS Framework  : Yes
IPVS sync daemon support: Yes
Use VRRP Framework : Yes
# make && make install

# 规范启动
# cp /usr/local/etc/rc.d/init.d/keepalived /etc/init.d/

# 配置启动脚本参数
# cp /usr/local/etc/sysconfig/keepalived /etc/sysconfig/

# 创建默认的keepalived配置文件路径
# mkdir /etc/keepalived
# cp /usr/local/etc/keepalived/keepalived.conf /etc/keepalived
```

keepalived的配置文件

```conf
!Configuration File for keepalived

!全局变量
!Comments start with ’#’ or ’!’ to the end of the line and can start anywhere in a line.
!contains subblocks of Global definitions, Static routes, and Static rules
global_defs{
    notification_email{
        !管理员邮箱
        admin@example.com
    }
    notification_email_from admin@example.com
    !邮箱服务器的地址设置
    smtp_server xx.xx.xx.xx
    smtp_connect_timeout 30

    !string,identifying the machine,(do not have to be hostname,default:localhostname)
    router_id LVS_DEVEL
}

!Static routes/address/rules
!Keepalived can configure static addresses, routes, and rules. These addresses are NOT moved by vrrpd, they stay on the machine.  If you already  have  IPs and routes on your machines and your machines can ping each other, you don’t need this section.

static_ipaddress{
    192.168.1.2/24 dev eth0 scope global
}

static_routes{
    192.168.1.1/24 via 192.168.1.100
}

static_rules{
    from 192.168.1.1/24 table 1
    to 192.168.1.1/24 table 2
}

!Adds a scritpt to be executed periodically.Its exit code will be recorded for all VRRP instances which are monitoring it with non-zero weight.
vrrp_script <SCRIPT_NAME>{
    !path of the script to execute
    script <STRING>|<QUOTED-STRING>
    !seconds between script invocations,default 1 second
    interval <INTEGER>
    !seconds after which script is considered to have failed
    timeout <INTEGER>
    !adjust priority by this weight,default 2
    weight <INTEGER : -254..254>
    !required number of successes for OK transition
    rise <INTERGER>
    !required number of successes for KO transition
    fall <INTEGER>
}

!describes the movable IP for each instance of a group in vrrp_sync_group.
!Here are describes two IPs(on inside_network an on_outside_network)on machine "my_hostname",!which belog to the group VG_1 and which will trasition together on any state change.

vrrp_instance inside_network{
    !Initial state,MASTER | BACKUP
    !As soon as the other machine(s) come up,
    !an election will be held and the machine
    !With the highest priority will become MASTER
    !So the entry here do not matter a whole lot
    state MASTER

    !Interface for inside_network,bound by vrrp
    interface eth0

    !Use VRRP Virtual MAC.
    use_vmac [<VMAC_INTERFACE>]

    !Send/Recv VRRP messages from base interface instea dof
    vmac_xmit_base

    !force instance to use IPv6(when mixed IPv4 and IPv6 config)
    native_ipv6

    !Ignore VRRP interface faults(default unset)
    dont_track_primary

    ! optional,monitor these as well
    ! go to FAULT state if any of these go down
    track_interface{
        eth0
        eth1
        eth2 weight <-254..254>
        ...
    }

    ! add a tracking script to the interface (<SCRIPT_NAME>is the name of the vrrp_script entry)
    track_script{
        <SCRIPT_NAME>
        <SCRIPT_NAME> weight <-254..254>
    }

    !Default IP for binding vrrpd is the primary IP on interface.If you want to hid the location of vrrpd, use this IP as src_addr for multicast or unicast vrrp packets.(Since it is multicast,vrrpd will get the reply packet no matter what src_addr is used).
    !Optional
    mcast_src_ip <IPADDR>
    unicast_src_ip <IPADDR>
    ! VRRP version to run on interface
    version<2 or 3>

    !addresses add|del on change to MASTER , to BACKUP.With the same entries on other machines, the opposite transition will be occurring.
    virtual_ipaddress{
        <IPADDR>/<MASK> brd <IPADDR> dev <STRING> scope <SCOPE> label <LABEL>
        192.168.200.17/24 dev eth1
        192.168.200.18/24 dev eth2 label eth2:1
    }

    # Note: authentication was removed from the VRRPv2 specification by RFC3768 in 2004.
    #    Use of this option is non-compliant and can cause problems; avoid using if possible,
    #   except when using unicast, where it can be helpful.
    authentication {
        # Authentication block
        # PASS||AH
        # PASS - Simple password (suggested)
        # AH - IPSEC (not recommended))
        auth_type PASS
        # Password for accessing vrrpd.
        # should be the same on all machines.
        # Only the first eight (8) characters are used.
        auth_pass 1234
    }

}

```

主要配置:

* 从文档中可以看到,我们需要配置主要有全局参数(global_defs),email & router\_id
* 如果有需要定时执行的脚本,则配置vrrp\_script 块, script位置,interval,weight
* 配置主机标签vrrp\_instance ,里面设置state,网卡接口,主机ip,virtual_id,优先级priorioty,adver\_int,authentication,为主机虚拟ip,检测脚本
* 用上一个步骤里面的虚拟IP配置虚拟服务器

主:

```conf
!Configuration file for keepalived
global_defs{
    notification_email{
        zhur0ngjian@126.com
    }
    notification_email_from zhur0ngjian@126.com
    smtp_server 127.0.0.1
    smtp_connect_timeout 30
    router_id MASTER_ROUTER
}

vrrp_instance V1_1{
    state MASTER
    interface eth1
    virtual_router_id 51
    mcast_src_ip 172.16.177.150
    priority 50
    adver_int 1
    authentication{
        auth_type PASS
        auth_pass chtopnet
    }
    virtual_ipaddress{
        10.0.1.1
    }
}

virtual_server 10.0.1.1 80{
    delay_loop 6
    lb_algo rr
    lb_kind DR
    persistence_timeout 50
    protocol TCP

    real_server 172.16.177.150 80 {
        weight 3
        TCP_CHECK {
            connect_timeout 10
            nb_get_retry 3
            delay_before_retry 3
            connect_port 80
        }
    }

    real_server 172.16.177.151 80{
        weight 3
        TCP_CHECK {
            connect_timeout 10
            nb_get_retry 3
            delay_before_retry 3
            connect_port 80
        }
    }
}
```

被:

```conf
!Configuration file for keepalived
global_defs{
    notification_email{
        zhur0ngjian@126.com
    }
    notification_email_from zhur0ngjian@126.com
    smtp_server 127.0.0.1
    smtp_connect_timeout 30
    router_id BACKUP_ROUTER
}

vrrp_instance V1_1{
    state BACKUP
    interface eth1
    virtual_router_id 51
    mcast_src_ip 172.16.177.151
    priority 50
    adver_int 1
    authentication{
        auth_type PASS
        auth_pass chtopnet
    }
    virtual_ipaddress{
        10.0.1.1
    }
}

virtual_server 10.0.1.1 80{
    delay_loop 6
    lb_algo rr
    lb_kind DR
    persistence_timeout 50
    protocol TCP

    real_server 172.16.177.150 80 {
        weight 3
        TCP_CHECK {
            connect_timeout 10
            nb_get_retry 3
            delay_before_retry 3
            connect_port 80
        }
    }

    real_server 172.16.177.151 80{
        weight 3
        TCP_CHECK {
            connect_timeout 10
            nb_get_retry 3
            delay_before_retry 3
            connect_port 80
        }
    }
}
```

主备的配置文件需要注意:

1. 在vrrp_instance节点中,主备的实例名字可以不一样,但virtual\_router\_id必须一样.
1. virtual\_router\_id的作用是区分不同的vrrp组,因此在同一网段内,不同的vrrp组不能重复id.
1. 一个 virtual\_server节点中配置多个 real\_server,需要注意 TCP_CHECK与'{' 之间的空格,如果没有空格,则从上往下数第二个real\_server会识别不到.
1. VIP可以和主机真实IP地址不在同一个网段,但必须在环境中搭建VPN.

启动服务

```Linux
# keeplived需要通过ip地址添加来启动服务
# ip addr add 10.0.0.18/24 dev eth0
# /etc/init.d/keepalived start
```

> 对外提供服务的是VIP(virtual ip)

## 场景应用 ##

假设我们的集群架构中,有两台机器是作为LB存在,分别是LB1(主),LB2(备) ; 两台 LB 通过 _keepalive_ 建立关系 , 当一台 _LB_挂了,立即启用 _备用LB_ .

我用的 _load Balance_ 软件是 Nginx , 所谓宕机就是 _Nginx_ 和 _keepalive_ 这两个服务停止了,然而当 _Nginx_ 停止服务的时候 ,keepalive 是不能识别到的(Keepalive不会关闭,不会让 _备用LB_ 接管 _主LB_ 接受到的请求)

因此,我们要写一个监控Nginx状态的脚本

```sh
#!/bin/bash
# Monitoring Nginx status
if [ "$(ps -ef|grep "nginx : master process"|grep -v grep)"=="" ]
then
    /application/nginx/sbin/nginx
    sleep 5
    if [ "$(ps -ef|grep "nginx : master process"|grep -v grep)"=="" ]
    then
    killall keepalived
    fi
fi
```

升级版:

```sh
# cat /etc/keepaalived/check_nginx.sh
Count1="netstat -antp |grep -v grep|grep nginx|wc -l"
if [ $Count1 -eq 0 ]
then
    /application/nginx/sbin/nginx
    sleep 2
    Count2="netstat -antp|grep -v grep|grep nginx|wc -l"
    if [ $Count2 -eq 0 ]
    then
        /etc/init.d/keepalived stop
    else
        exit 0
    fi
else
    exit 0
fi
```

这个脚本可以放到 _keepalived.conf_ 里面 _vrrp\_script_ 节点中,这里可以每隔相应的时间执行一次脚本.

在工作时,keepalived根据用户设定的策略判断服务器上的程序是否正常运行,如果故障则将这台服务器从热备组移出.

在实例中重要参数: nopreempt , 当主LB挂了,备LB接管,主恢复,不自动接管