---
title: 记一次RD授权故障
tags:
  - 故障
categories:
  - Windows Server
date: 2020-05-24 12:16:04
---

# 故障现象

Windows Server部署了RD会话的服务，需要指向RD授权服务器，否则只有120天的“宽限期限”。120天之后，是无法直接使用mstsc远程到目标服务器亦或是基于RD会话的服务也将不可用，例如VMware Horizon View的基于“RD会话主机”设立的
RD桌面或者应用将不可用。

# 原因分析

1. RDSH资源机没有设置指向RD授权服务器、设置授权模式。
2. RDSH资源机设置RD授权服务器后没有生效。
3. RD授权服务器宕机，无法正常提供服务。
4. RD会话主机角色被禁用。

# 解决方法

因为License无法使用MSTSC连接，可以使用 mstsc /admin 进行连接。

## 原因1：

> “RDSH资源机没有设置指向RD授权服务器、设置授权模式。”

设置方法：

1. 进入组策略编辑器 gpedit.msc
2. 选择 计算机配置 -> 管理模板 -> Windows组件 -> 远程桌面服务 -> 远程桌面会话主机 -> 授权 。
3. 将“使用指定的远程桌面许可证服务器”，设置为目标RD授权服务器。
4. 将“设置远程桌面授权模式” ，设置为按用户。
5. 网络端口禁用。

设置完后需要重启。

## 原因2：

> “RDSH资源机设置RD授权服务器后没有生效。”

我在每台服务器上面运行了注册表后，没有重启服务器。每台服务器虽然不再提示“远程桌面授权模式尚未配置”的告警，并且在RD诊断器中，可以看到已经连接授权服务器，但本质上是没有生效的。

可以通过以下脚本设置。

```ps1
# 待补充
# 重启
reboot
```

## 原因3：

检测 LicenseServer:135 端口是否开放。

## 原因4：

通过命令查询，RDS会话主机的安装状态，如果返回的是0，表示该角色已禁用，需要安装。

```ps1
reg query "HKLM\SOFTWARE\Microsoft\ServerManager\ServicingStorage\ServerComponentCache\RDS-RD-Server" /v InstallState
```

# 参考资料

https://docs.azure.cn/zh-cn/virtual-machines/troubleshooting/troubleshoot-rdp-no-license-server