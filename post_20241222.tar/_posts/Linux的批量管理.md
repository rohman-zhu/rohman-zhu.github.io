---
title: Linux的批量管理
date: 2017-10-16 21:21:20
tags: Linux
---
# 批量管理方案 #

一般会有三种方案:

* 面对中小企业的 sshkey 密钥方案
* 面对门户网站的 PUPPET
* 其他: SALTSTACK

## SSH ##

我们一般用的是SSH2加密协议,具体原理待补充.

常用的两个命令:

* ssh-keygen -t dsa 用于生产公钥和私钥
* ssh-copy-id -i 公钥的地址 目标机器

这里有一个形象的比喻:

* 公钥 - 锁
* 私钥 - 钥匙

我们常用ssh无密码登录,可以采用将公钥发布给信任的机器.

### 如何提速 ###

修改sshd的配置文件即可,/etc/ssh/sshd.conf

* UseDns no
* Auth...DNS no

### 如何用ssh登录目标机器 ###

机器:

* 被访问的机器 : 10.0.0.7 Server
* 需求访问的机器 : 10.0.0.8 Client

要实现该功能,首先在_Server_端操作:

```{.normal}
# 创建公钥与私钥
# ssh-keygen -t dsa
# -t是指定密钥的类型

# 将公钥发布到目标机器上
# ssh-copy-id -i ~/.ssh/id_dsa.pub Client@10.0.0.8
```

在输入完Client密码后,就可以在_Server_端用ssh登陆Client了

#### 故障排查 ####

以上的操作,都是基于ssh的端口为22.如果端口不为22,而是被修改为其他端口,则会出现以下错误:

```{.normal}
ssh: umask 077; test -d .ssh || mkdir .ssh ; cat >> .ssh/authorized_keys: Name or service not know
```

目前找到一种解决方案,亲测有效:
</br>
在复制公钥到机器的时候,添加双引号

* ssh-copy-id -i ~/.ssh/id_rsa.pub "-p 1024 Client@10.0.0.7" 即可

### ssh连接小结 ###

1. 切换到别人的机器 ,ssh -p端口号 username@ip
1. 直接执行命令 ,ssh -p端口号 username@ip 命令(全路径)
1. 第一次ssh连接的时候,本地会产生一个密钥文件 ~/.ssh/know_hosts文件

## SCP ##

secure copy (remote file copy program)

### 上传 ###

* scp -P 端口号 -avz 要上传的文件(全路径) username@ip:/存放路径

### 下载 ###

* scp -P 端口号 -avz username@ip:/目标路径  存放文件的目录(全路径)

### 小结 ###

1. scp是加密的远程拷贝,而cp仅是本地拷贝
1. 可以把数据从一台机器推送给另外一台机器 , 也可以从其他服务器把数据来回本地
1. 每次都是全量完整拷贝,因此效率不高,适合第一次拷贝用,如果需要增量拷贝,用rsync.

## sftp ##

这是一个FTP服务器,基于SSH,即是加密传输
</br>
格式:
</br>
sftp -oPort=端口号 username@ip

### SFTP下载 ###

get 目录 本地存放的目录(全路径)

### SFTP上传 ###

put 需要上传的文件(全路径) 存放的目录(全路径)

## 缺陷 ##

1. 用的是root用户,权限太大,有可能会误操作破坏系统

## 如何批量管理,批量部署 ##

两个部分:

* 分发服务器
* 分发对象

应用:

* 将机器名字对应到hosts文件里面,再发给所有用户机

部署其实是通过脚本来实现的:

```{.linuxCommand}
# vim /server/scripts/test.sh

#!/bin/sh
# 加入系统函数库
. /etc/init.d/functions
for n in 7 8 9
do
    scp -P1024 hosts oldgirl@10.0.0.$n:~
    if[$? -eq 0]
        then
            action "fenfa $1 ok" /etc/true
        else
            actiong "fenfa $1 fail" /etc/false
    fi
done
```

## 如何让其他机器免密码登陆 ##

### 客户机免密码登陆服务机 ###

思路 : 服务机通过 scp 将 私钥文件放置客户机的 .ssh 目录下面, 服务及再通过 ssh-copy-id 将公钥给予自己.

* 服务机 : Server , 10.0.0.7 : 1024
* 客户机 : Client , 10.0.0.8 : 1024

```{.LinuxCommand}

# scp -p1024 .ssh/id_dsa Client@10.0.0.8

# ssh-copy-id -i .ssh/id_dsa_pub "-p1024 Server@10.0.0.7"

```

那么在客户机下就可以用Client用户无密码登录Server机了

## 如何实现从A指定目录批量分发文件到B,C用户的家目录 ##

```{.linuxCommand}
#!/bin/sh
. /etc/init.d/functions
if[$# -ne 1]
then
    echo "USAGE : $0 FILENAME"
    exit 1
fi
for n in 8 9
do
    scp -P 1024 -rp $1 commonTestMan@10.0.0.$n &>/dev/null
    if[$? -eq 0]
    then
        action "$n is ok" /bin/true
    else
        action "$n is fail /bin/false
    fi
done
```

## 如何快速查看所有机器的负载load,cpu,内存等信息 ##

创建脚本

```{.LinuxCommand}
#!/bin/sh
if[$# -ne 1]
then
    echo "USAGE:$0 CMD"
    exit 1
fi
for n in 8 9
do
    ssh Server@10.0.0.$n $1 2>/dev/null
done
```

### SHELL脚本编程知识点 ###

* 符号#!用来告诉系统它后面的参数是用来执行该文件的程序
* '$#'表示输入的参数
* '-ne'表示不等于
* "if" 表达式 如果条件为真则执行then后面的部分：最终以fi结尾
* $+数字 一般是位置参数的用法
* $0 脚本文件的名字

## 如何实现远程实时同步 ##

```{.linuxCommand}
#!/bin/sh
if [ $# -ne 2]
then
    echo "USAGE:$0 FileName RemoteDiretory"
    exit 1
fi
for n in 8 9
do
    scp -rp $1 commonTestMan@10.0.0.$n:~ &>/dev/null&& \
    ssh -t commonTestMan@10.0.0.$n sudo rsync $1 $2 &>/dev/null
    if [ $? -eq 0]
    then
        action "$1 to $2 10.0.0.$n is ok" /bin/true
    else
        action "$1 to $2 10.0.0.$n is fail" /bin/false
    fi
done
```

## Expect非交互脚本语言 ##

### expect样例 ###

```{.xx.exp}
#!/bin/expect
if { $argc != 3 }{
    send_user "usage : expect scp-expect.exp file host dir\n"
    exit
}

#define var
set file [lindex $argv 0]
set host [lindex $argv 1]
set dir  [lindex $argv 2]
set password "123456"

#spawn scp /etc/hosts root@10.0.0.142:/etc/hosts
spawn scp -P22 -p $file root@host:$dir
set timeout 60
expect{
    -timeout 2
    "yes/no" {send "yes\r";exp_continue}
    "*password" {send "$password\r"}
    timeout {puts "expect connect timeout,pls contact oldboy.";return}
}
expect eof


```
