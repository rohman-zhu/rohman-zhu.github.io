---
title: GIT+HEXO快速部署
tags:
  - default
catergories:
  - default
date: 2020-03-15 21:56:34
---
# 环境

|Iten| Detail|
|:----:|:----:|
|OS|CentOS 7|
|Kernel|Linux 3.10.0-862.el7.x86_64|
|Node version|13.9.0|
|npm version|6.13.7|
|hexo version|4.2.0|
|Git version|1.8.3.1|

# 一、安装与配置 git

```sh
yum install git-core -y
git --version

git --global user.name "r0manj"
git --global user.email "zhur0ngjian@126.com"
```

# 二、安装 node.js

使用yum安装只会安装到老版本，直接到官网下载最新的源码包，采用源码安装。

官网：http://nodejs.cn/download/
淘宝镜像：https://npm.taobao.org/mirrors/node/

```sh
# 解压安装包
tar xvf node-v13.9.0-linux-x64.tar
# 将安装包拷贝到 /usr/local/node-13.9.0目录下。（略）
# 将bin目录的可执行文件添加到环境变量中
echo "export PATH=$PATH:/usr/local/node-13.9.0/bin" >> /etc/profile
source /etc/profile
# 配置国内npm镜像源
npm config set registry http://registry.npm.taobao.org
```

# 三、安装hexo

```sh
npm install hexo-cli -g
```

# 四、创建GitHub代码仓库与初始化hexo博客

GITHUB创建代码仓库（略）

创建空目录后执行初始化操作

```sh
hexo init

npm install --save hexo-deployer-git

# 生成标签页和目录页
hexo new page tags
hexo new page categories
```

> 需要在tags和categories的页面里添加属性，type:"tags" 、type:"categories"

配置hexo的 _config.yml 文件，设置git的相关账号。

```yml
deploy:
  type: git
  repo: git@github.com:R0manJ/R0manJ.github.io.git
  branch: master
```

# 五、到GitHub上的仓库添加这台服务器的ssh-key

到仓库的setting界面，进入Deploy keys，点击 “Add deploy key”，将服务器的公钥添加进去。

# 六、其他操作

## 配置samba服务

可以部署samba服务将post文件夹共享出来。

## 防火墙配置

图省事就关闭了

```sh
firewal-cmd --state
systemctl disable firewalld
```

# 参考资料

https://www.cnblogs.com/huay/p/11266803.html

https://blog.csdn.net/tian330726/article/details/80791388

samba服务-1：https://blog.csdn.net/u013230234/article/details/81639801

samba服务-2：https://blog.csdn.net/weixin_41078837/article/details/80570693

CentOS7防火墙操作相关：https://www.cnblogs.com/xxoome/p/7115614.html