---
title: LINUX目录
date: 2017-10-03 11:31:55
tags: Linux
---

# 常规目录 #

* /usr/local/

用户安装的软件都会放在这里，相当于Windows系统的软件默认安装路径(c:\program file)

* /usr/src/

内核源码存放目录

* /var/

存放可变数据的路径

```
/var/log 日志文件
/var/secure
/var/messages
/var/spool/cron/root < == 定时任务所在的路径

$ 查看定时任务：
$ crontab -l
$ cat /var/spool/cron/root
```

* /proc/

显示主机信息的虚拟路径

```
/proc/meninfo 内存信息

/proc/cupinfo CPU信息

/proc/interrupt CPU中断信息

/proc/loadavg 负载

/proc/mounts 设备挂载信息
```

内核优化也会将结果写进proc里面去

```
$ 修改操作

$ vim /etc/sysct1.conf

$ cat/proc/sys/net/ipv4/tcp_tw_reuse
```

对本路径里面的文件进行修改并不会永久生效，当机器重启后，所有修改都会丢失。


# 其他重要目录 #

* /etc/inittab

设置系统启动时，init进程将把系统设置成什么样的运行级别，以及加载相关级别对应启动文件


* /etc/profile.d

登录后执行的脚本所在地

* /etc/motd

登录后显示的字符串

* /etc/xxxx-release

系统版本，红帽的为 redhat-release , Cent的为centos-release

* /etc/passwd

账号信息文件

* /etc/shadow

密码信息文件

* /etc/gshadow

组密码信息文件

* /etc/sudoers

可以执行使用sudo命令的配置文件

```
$ visudo < == 编辑文件，添加用户权限
$ visudo -c < == 检查语法文件
```