---
title: Linux开关机命令
date: 2017-10-05 17:30:02
tags: Linux
---
# 系统电源操作 #

## 关机 ##

* shutdown -h now
* shutdown -h +1 1分钟后关机
* init 0
* halt 立即停止系统，需要人工关闭电源。
* poweroff 立即停止系统，并且关闭电源。

## 重启 ##

* reboot 
* shutdown -r now
* shutdown -r +1
* init 6

## 注销 ##

* logout
* exit
* ctrl + d 快捷键

## 【快捷键】 ##

| 按键 | 功能 |
|:-----:|:-------:|
|ctrl + a | 光标移动到行首（ahead of line），相当于通常的Home键|
|ctrl + e | 光标移动到行尾（end of line）|
|ctrl + c | 取消当前行输入的命令|
|ctrl + d | 登出 |
|ctrl + l | 清屏，相当于执行clear命令|
|ctrl + u | 清除（剪切）光标之前的内容 |
|ctrl + k | 清除（剪切）光标之后的内容 |
|ctrl + r | 查找|
|ctrl + y | 粘贴|
