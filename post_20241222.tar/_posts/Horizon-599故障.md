---
title: Horizon-599故障
tags:
  - 故障
categories:
  - VMware
  - Horizon View
date: 2024-04-01 01:14:06
---

# 故障描述

1. 连接服务器、安全服务器无法连接TCP-443；
2. 连接 https://安全服务器 ，显示599；
3. 连接服务器的日志（C:\ProgramData\VMware\VDM\log\xxx.log），显示 MEMORY-ALARM:physical memory use = 97% ,[ws_perfmon]High memory use....

# 原因分析

直接原因：服务器内存已经用满，出现内存泄漏的情况；
根本原因：出现补丁更新，未重启；

# 解决方法

重启服务器。
