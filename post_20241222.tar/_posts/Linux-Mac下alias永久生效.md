---
title: Linux/Mac下alias永久生效
date: 2018-11-04 10:40:42
tags: Linux
---

# alias 命令

alias命令用来设置指令的别名。我们可以使用该命令可以将一些较长的命令进行简化。使用alias时，用户必须使用单引号''将原来的命令引起来，防止特殊字符导致错误

alias命令的作用只局限于该次登入的操作。若要每次登入都能够使用这些命令别名，则可将相应的alias命令存放到bash的初始化文件/etc/bashrc中。

## 语法

```shell
# alias语法
alias (选项) (参数)

# 选项
# -p：打印已经设置的命令别名。

# 参数
# 命令别名设置：定义命令别名，格式为“命令别名=‘实际命令’”。

# 删除别名
unalias(选项)(参数)
```

```man
   source filename [arguments]
              Read and execute commands from filename  in  the  current  shell
              environment  and return the exit status of the last command exe-
              cuted from filename.  If filename does not contain a slash, file
              names  in  PATH  are used to find the directory containing file-
              name.  The file searched for in PATH  need  not  be  executable.
              When  bash  is  not  in  posix  mode,  the  current directory is
              searched if no file is found in PATH.  If the sourcepath  option
              to  the  shopt  builtin  command  is turned off, the PATH is not
              searched.  If any arguments are supplied, they become the  posi-
              tional  parameters  when  filename  is  executed.  Otherwise the
              positional parameters are unchanged.  The return status  is  the
              status  of  the  last  command exited within the script (0 if no
              commands are executed), and false if filename is  not  found  or
              cannot be read.
```

# To-Do list

* 将kvm常用的几个命令都设置别名。[完成时间：20181104]

# 实例

```shell
# 编辑bashrc文件
vim ~/.bashrc
# ---添加以下内容---
alias kvm-list-all='virsh list --all'
alias kvm-edit='virsh edit'
# ---保存退出---

#配置生效
source ~/.bashrc
```

# 参考资料

* alias 命令： http://man.linuxde.net/alias