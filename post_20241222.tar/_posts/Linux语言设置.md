---
title: Linux语言设置
date: 2017-10-04 14:44:59
tags: Linux
---

## 前言 ##
在查看内容的时候出现乱码，原因即是linux显示不出中文字体，所以这时候要调整字体。

## 实践 ##
1. 查看当前系统语言
```
$ echo $LANG
```

2. 查看已经安装的语言包
```
$ locale
```

3. 如果没有就自行安装下载
```
yum groupinstall chinese-support
```

4. 将语言修改成中文
```
临时更换语言
$ LANG = 语言名称

修改默认语言
$ vim /etc/sysconfig/il8n
LANG = 语言名臣
```
修改完后重启
