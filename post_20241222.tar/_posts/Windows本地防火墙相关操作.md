---
title: Windows本地防火墙相关操作
tags:
  - 防火墙
categories:
  - Windows Server
date: 2022-07-04 00:04:52
---

# 前言

Windows 本地防火墙与常规的Linux防火墙还是有区别的，策略匹配顺序、策略放行优先级有着较大的差异。

默认配置：

- 未创建的策略，默认情况下是拒绝。（推荐设置为拒绝，这个也可以自行设置）

匹配原则：

1. 显式定义的允许规则将优先于默认阻止设置。
2. 显式阻止规则将优先于任何冲突的允许规则。（“拒绝优先”）
3. 更具体的规则将优先于不太具体的规则，2 中提及的显式阻止规则除外。 （例如，如果规则 1 的参数包含 IP 地址范围，而规则 2 的参数包含一个 IP 主机地址，则规则 2 的优先级更高。） 

> 实际测试下来，建议忽略规则3，无实际意义。

> 若要打开 Windows 防火墙，请转到“开始”菜单，选择“运行”，键入“WF.msc”，然后选择“确定”。 

# 相关powershell指令

## 打开防火墙

```ps1
Set-NetFirewallProfile -Profile Private,Domain,Public -Enabled True
```

## 创建防火墙策略

```ps1
# 创建TCP-3389入站策略,并允许192.168.1.1，192.168.1.2匹配
New-NetFirewallRule -DisplayName "Accept TCP 3389" -Direction Inbound -LocalPort 3389 -Protocol TCP -Action Accept -RemoteAddress {192.168.1.1},{192.168.1.2};
# 创建UDP-3389出站策略
New-NetFirewallRule -DisplayName "Accept UDP 3389" -Direction Outbound -LocalPort 3389 -Protocol UDP -Action Block;
```

## 修改防火墙应用的地址范围

```ps1
# 修改上述创建的TCP-3389策略的应用范围为192.168.1.3
Get-NetFirewallRule -DisplayName "*TCP*3389*" | Get-NetFirewallAddressFilter | Set-NetFirewallAddressFilter -RemoteAddress {192.168.1.3};
```

## 启动某一个防火墙策略

```ps1
Get-NetFirewallRule -DisplayName "*TCP*3389*" | Set-NetFirewallRule -Enabled True;
```

# 参考资料

最佳实践：https://docs.microsoft.com/zh-cn/windows/security/threat-protection/windows-firewall/best-practices-configuring
https://docs.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule?view=windowsserver2022-ps
Powershell 与 防火墙相关指令: https://www.pstips.net/manage-firewall-using-powershell.html
Set-NetFirewallAddressFilter : https://docs.microsoft.com/en-us/powershell/module/netsecurity/set-netfirewalladdressfilter?view=windowsserver2022-ps
Set-NetFirewallPortFilter : https://docs.microsoft.com/en-us/powershell/module/netsecurity/set-netfirewallportfilter?view=windowsserver2022-ps
New-NetFirewallRule : https://docs.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule?view=windowsserver2022-ps
Set-NetFirewallRule : https://docs.microsoft.com/en-us/powershell/module/netsecurity/set-netfirewallrule?view=windowsserver2022-ps
Get-NetFirewallPortFilter : https://docs.microsoft.com/en-us/powershell/module/netsecurity/get-netfirewallportfilter?view=windowsserver2022-ps
显示动态端口 : https://docs.microsoft.com/zh-CN/troubleshoot/windows-server/networking/default-dynamic-port-range-tcpip-chang