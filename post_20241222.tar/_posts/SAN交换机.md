---
title: SAN交换机
tags:
  - SAN交换机
catergories:
  - SAN存储服务器
date: 2020-01-15 08:02:25
---

# SAN交换机

近期接触了几个SAN交换机，因此这篇文章会记录相关信息。

## 指令

```sh
# 查看交换机的总体健康状态
switchstatusshow

# 查看交换机基本信息
switchshow

# 查看端口状态
portshow

# 查看交换机散热风扇的状态
fanshow

# 查看交换机的电源状态
psshow

# 查看环境温度
tempshow

# 查看交换机的内部消息日志的操作指令
# To display the system message log ,with no page breaks
errdump
# To display the system message log one at a time
errshow
# To clear the system message log
errclear

# 查看SAN交换机的相关信息
chassisshow

# 收集交换诊断数据相关：
# 显示诊断信息和状态信息：
supportshow
# 将数据打包、上传至指定的FTP服务器
supportsave
# 显示 panic dump 文件的内从，帮助诊断系统panic的原因
pdshow

#显示连接到交换机的所有设备
nsshow
# 显示连接到Fabric的所有设备
nsallshow
# 显示 Fabric 中的所有交换机
fabricshow

# 检查license文件和交换机的wwn号
licenseshow
wwn

# 检查Fabric OS的版本
version

# 查看 Control Blade的状态
hashow

# 查看各个Blade的状态
slotshow

# 端口速率修改
portcfgspeed

# reset端口
protEnable
portcfgpersistentenable

```


## 参考资料

Brocade 光纤交换机常用命令：https://wenku.baidu.com/view/9d36cc4acd1755270722192e453610661fd95a49.html