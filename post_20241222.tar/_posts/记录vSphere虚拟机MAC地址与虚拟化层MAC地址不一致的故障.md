---
title: 记录vSphere虚拟机MAC地址与虚拟化层MAC地址不一致的故障【待补充】
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2023-03-04 22:55:58
---
# 背景

虚拟机OS内，业务不知道出于什么考虑，竟然在OS内把MAC地址改了，而虚拟化层对这个虚拟机的MAC地址并没有更改，所以导致虚拟机的网络流量异常。

# 待办

1. 复现虚拟机MAC不一致的故障场景；【需包含Windows 、 Linux】
2. 如何识别OS的MAC地址与虚拟化层不一致；【需避免此类问题】

# 参考资料