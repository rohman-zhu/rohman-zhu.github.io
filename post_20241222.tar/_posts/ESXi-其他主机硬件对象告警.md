---
title: ESXi-其他主机硬件对象告警
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2023-04-05 22:08:12
---
# 故障描述

ESXi出现告警，显示“其他主机硬件对象的状态”告警；

到 ESXi 的 监控--硬件运行状况--警示和告警中，有“System Management Software 1 SEL  Fullness” ;

# 原因分析

SLE = Esxi System Event Log , 是ESXi的事件日志，这里表示ESXi的事件记录已经满了，需要清理一下。

# 解决方法

进入ESXi Shell，执行指令

```esxi shell
# 查询
localcli hardware ipmi sel get

# 清理日志
localcli hardware ipmi sel clear

```

# 参考资料

https://www.cnblogs.com/5201351/p/16867372.html