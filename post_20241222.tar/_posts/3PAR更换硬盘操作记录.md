---
title: 3PAR更换硬盘操作记录
tags:
  - 故障处理
categories:
- 服务器与存储
- 存储
- SAN存储
date: 2020-12-05 21:03:19
---

# 背景简述

3PAR存储上有2块硬盘亮故障告警灯，需要做更换操作。

# 操作过程

先登录3PAR存储的管理，确认故障硬盘

```sh
# ssh 到目标存储
ssh 3paradm@xx.xx.xx.xx

# 确认故障硬盘以及chunklet
showpd -c -failed -degraded
# 可以看到硬盘的status为failed的硬盘
# 确认in use的chunklet是否迁移完毕，变成0
```

检测是否有chunklet迁移的任务正在进行。

> 默认情况下，如果硬盘status为failed状态，会触发chunklet迁移的任务。

```sh
servicemag status
# 可以看到任务不是 in progress 状态，而是 successed 的状态。
```

已确认故障硬盘没有chunklet正在使用，并且没有与故障硬盘相关的chunklet迁移任务。

此时允许更换硬盘。

更换完硬盘后，要检测OS是否发起了数据回迁的任务。

```sh
showpd -c
servicemag

# 故障硬盘的槽位信息会保留1-3天。但是其ID后面会多一个 ？ 符号  ， 例如 4:4:0?
```

确认数据回迁完毕，并且告警灯消失，整个更换操作完成。