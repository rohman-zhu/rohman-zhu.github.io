---
title: HPE-SAN存储热备盘比例
tags:
  - default
categories:
  - 服务器与存储
  - 存储
  - SAN存储
date: 2024-05-04 23:39:36
---
# 背景说明

做SAN存储扩容时，需要供应商做扩容方案。对应的硬件所堆积出来的硬件可用容量到底怎么计算的？这里面有几个问题：

1. 裸容量是多少？
2. 可用容量是多少？
3. 热备盘比例是多少？

# 可查资料

```
Spare rate
A key parameter in the spare policy is the spare rate. The spare rate is a target amount of space to set aside for sparing expressed relative to the number of disks of a given type in the system. A spare rate of 24, for example, sets target spare space equal to the size of one drive for every 24 drives in the array.
The spare rate is defined based on the hardware configuration in the array as follows:
• Spare rate = 40 if there are any magazines present in the array (e.g., 10,000)
• Spare rate = 24 for all others such as 7400/7400c, 7450/7450c, etc.

Sparing algorithms defined
The spare option is set for the entire array and applied to each disk type (SSD, FC, NL) in the following way.
• Default: Roughly 2.5 percent with minimums
Small configurations (e.g., 7000’s with less than 48 disks, 10000’s with less than 80 disks) have a spare space target equal to the size of two of the largest drives of the type being spared.
• Minimal: Roughly 2.5 percent without minimums
Minimal is the same as default except for small configurations. When the configuration is small, minimal will only set aside spare space equal to one of the largest drives (compared to two for default) of the type being sized.
• Maximal: One disk’s worth in every cage
Spare space is calculated as the space of the largest drive of the drive type being sized for each disk cage.
• Custom: Implemented manually by the administrator using the createspare, showspare, and removespare commands.
```

> 默认比例为 2.5%；最大比例为 12%；

# 参考资料

https://community.hpe.com/t5/hpe-3par-storserv-storage/check-spare-capacity-on-disk-driver/td-p/7085333
