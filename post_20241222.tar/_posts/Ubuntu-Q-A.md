---
title: Ubuntu--Q&A
date: 2019-12-14 23:44:08
tags: 
- Linux
- Ubuntu
categories: 
- Linux
---

# 常见问题记录

## Could not get lock /var/lib/dpkg/lock-fronted-open 

故障描述：使用apt-get的时候出现

```报错信息
E: Could not get lock /var/lib/dpkg/lock-frontend - open (11: Resource temporarily unavialable)
E: Unable to acquire the dpkg fronted lock (/var/lib/dpkg/lock-frontend), is another process using it?
```

原因分析：其他进程正在运行，导致资源被锁不可用；而资源被锁的原因可能是上次运行安装或者更新时没有正常完成，所以才会有报错。
解决方法：

方法一：根据报错信息删除对应文件即可。

```sh
rm /var/lib/dpkg/lock-frontend
```

方法二：结束apt-get进程

```sh
ps -aux | grep apt-get 
kill -s 9 [PID]
```

## ssh 比较慢

一般是ssh开启了 DNS 反向查询，将该属性值设置为no ，并重启sshd服务即可。

```sh
vim /etc/ssh/sshd_config

# UseDNS yes
UseDNS no

/etc/init.d/sshd restart
```

## ext3、ext4 有5%的空间损耗？

在 mkfs.ext4 格式化时， 会出现“ xxx blocks(5.00%) reserved for the super user " 提示。

从ext2文件系统开始，格式化的时候默认都会保留一定空间给特定用户写入。避免磁盘写满时，而无法使用操作系统。

> 默默吐槽，Google搜出来的东西跟百度搜出来的东西就是不一样，Google详细很多。

参考问题：https://unix.stackexchange.com/questions/7950/reserved-space-for-root-on-a-filesystem-why

参考资料：http://man7.org/linux/man-pages/man5/ext4.5.html