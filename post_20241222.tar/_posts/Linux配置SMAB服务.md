---
title: Linux配置SAMBA服务
date: 2019-04-04 18:36:29
tags: Linux
---

# 前言

* OS ： Ubuntu-16.04
* Samba version : 4.3.11-Ubuntu

# 安装与配置

```sh
# 1. 安装 samba服务
apt-get install samba -y
# 2. 检查 samba 版本
samba
# 3. 配置 samba 配置文件，先备份
cp /etc/samba/smb.conf /etc/samba/smb.conf.bak
# 4. 编辑配置文件
vim /etc/samba/smb.conf
```

在配置文件中添加节点

```sh
# 用户显示的文件夹名
[TEST-Dir]
    # 描述，即文件夹的显示信息
    comment = test directory 
    # 该共享文件夹的路径
    path = /home/user/
    browseable = yes
    # 设定该共享服务是否能够被游客访问，其同义选项有guest ok。
    public = no
    # 设定该共享服务是否为只读，该选项有一个同义选项writeable。
    read only = no
    # 设定能够使用该共享服务的用户和组，其值的格式与user选项一样。
    valid users = user
    create mask = 0777
    directory mask = 0777 
    force user = nobody
    force group = nogroup
    available = yes

```

设置用于共享的账号与密码

```sh
# user 是 /etc/passwd 中的账户
sudo smbpasswd -a user
# 重启Samba服务
sudo service smbd restart
```

