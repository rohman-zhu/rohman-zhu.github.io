---
title: yum_命令
date: 2017-10-03 11:49:29
tags: Linux
---
# yum linux里包管理 #
_yum_ 帮助解决以来问题

* 下载 _tree_ 包，然后调用 _rpm_ 命令安装tree包
```
$ yum install tree(包名) -y
```

* 查看包组
```
$ yum grouplist
$ yum groupinstall 'grouplist'
```

* 查找
```
$ yum search '关键字'
$ yum search all
```

* 移除
```
$ yum remove tree -y
```

* 升级
```
$ yum update -y
```