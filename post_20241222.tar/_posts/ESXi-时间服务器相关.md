---
title: ESXi-时间服务器相关
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2023-07-30 16:16:51
---
# ESXi中的NTP服务

## 作用

1. 宿主机时间校准；
2. 虚拟机时间校准；

> 虚拟机高级菜单中取消勾选“与主机同步时间”，每一次VMware Tools重启时，均会与主机同步时间。

## 相关指令--ntpq

```sh
# 查询指令
ntpq -p ESXi_host_IP

# 出现以下内容
remote refid st t when poll reach delay offset jitter
==============================================================================
*10.11.12.130.0.0.0 1 - 46 64 377 43.76 -5.58 40000
```

### 显示结果说明

| 参数项 | 说明 |
|:----|:----|
| remote |	已配置的上游 NTP 服务器的主机名或 IP 地址。|
| refid | 	与 NTP 服务器同步的时间流的标识。如果收到的 refid 为“.INIT.”，则说明 ESXi/ESX 主机未从已配置的 NTP 服务器收到响应。 |
| st	| Stratum 值代表上游 NTP 服务器的层次结构。值越高，表明 NTP 服务器越偏离根时间源。这些值是相对值，可以通过 NTP 服务器手动设置。|
| t |	用于 NTP 通信的软件包交换类型。通常“u”表示单播 UDP。|
| when |	自上次尝试轮询已配置的上游 NTP 服务器以来所经过的时间（秒）。|
|poll |	ESXi/ESX 主机轮询已配置的 NTP 服务器的间隔（秒）。|
|reach |	8 位八进制 (base 8) 的移位寄存器，在连接已配置的 NTP 服务器时，每一位代表成功 (1) 或失败 (0)。值 |377 是 11111111 (base 2)，指出在上 8 个轮询间隔期间，每个查询均已成功。
|delay	|已配置的 NTP 服务器与 ESXi/ESX 主机之间通信的往返延迟（毫秒）。|
|offset	|已配置 NTP 服务器与 ESXi/ESX 主机之间的时间偏移（毫秒）。理想值为接近 0 的值。|
|jitter	|在已配置 NTP 服务器的时间时钟脉冲之间观察到的时间抖动或偏差。理想值为接近 0 的值。|

> By default, the NTP polling interval is 64 seconds.

## 查询网络流量信息

### 方法1

```sh
# 使用以下命令获取可用 VMkernel 网络接口的列表：
esxcfg-vmknic -l

# 使用以下命令捕获端口 123 上流经 NTP 服务器的 NTP 网络流量：
tcpdump-uw -c 4 -n [使用目标网卡] host [NTP 服务器地址] and port 123
# 例如：
tcpdump-uw -c 5 -n -i vmk0 host 10.11.12.13 and port 123

```

### 方法2

```sh
# 查看可用网卡
esxcfg-vswif -l

# 使用以下命令捕获端口 123 上流经 NTP 服务器的 NTP 网络流量：
esxcfg-vswif -c 4 -n -i [使用目标网卡] host [NTP 服务器地址] and port 123
```

## 查询日志

需要配置日志信息：

```sh
# 创建日志地址
mkdir /var/log/ntp

# 增加日志文件存放配置
# /etc/ntp.conf
vim /etc/ntp.conf

# 增加以下四行内容
statistics loopstats
statsdir /var/log/ntp/
filegen peerstats file peers type day link enable
filegen loopstats file loops type day link enable
```

# 参考资料

VMware官方KB：https://kb.vmware.com/s/article/1005092?lang=zh_CN
NTP默认查询间隔：https://techhub.hpe.com/eginfolib/networking/docs/switches/5120si/cr/5998-8502_nmm_cr/content/436058975.htm