---
title: 阿里云服务器无法固定IP与Hostname
tags:
  - 故障
  - 阿里云
catergories:
  - 虚拟化
date: 2020-01-28 22:13:19
---

# 故障描述

手动更改IP与DNS，主机名。重启后全部复原。

# 原因分析

开机的时候，服务器启动了初始化程序ECS Initial Project。

# 解决方法

关闭这个自启的初始化程序即可。

1. 运行 msconfig 
2. 到服务 找到 vminit 
3. 取消勾选该服务 ， 确定禁用时间为当下的时间即可。
4. 重启。

