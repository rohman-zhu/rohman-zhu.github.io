---
title: VMware vSphere虚拟机vMotion事宜
tags:
  - vMotion
categories:
  - VMware
date: 2021-08-08 23:20:36
---

# VMware ESXi间虚拟机vmotion

## 应用场景

虚拟机迁移至其他计算节点或者计算资源与存储资源一起迁移

## 流程

1. 确定ESXi主机的VM Kernel网络都有配置vmotion；
2. 确定源ESXi与目标ESXi有的TCP-8000端口有开通；
