---
title: Linux的openssl升级
tags:
  - openssl
categories:
  - Linux
date: 2020-12-09 23:51:58
---

# 需求背景

由于 OpenSSL 存在安全漏洞，官方建议升级至 OpenSSL 1.1.1 i 版本。


# 升级操作

去官网下载安装包。

## CentOS的编译安装

```sh
# 编译安装需要提前安装好 gcc 和 make
yum install gcc make

# 进入解压openssl目录
tar xvf ./openssl-1.1.1i.tar.gz

# 进入解压后的目录
cd ./openssl-1.1.1i

# 执行配置文件，安装在 /usr/local/openssl
./config --prefix=/usr/local/openssl

# 执行编译并安装
make && make install

# 将原本的openssl删除或重命名
whereis openssl
mv /usr/bin/openssl /usr/bin/openssl.old

# 创建新版openssl的软连接
ln -s /usr/local/openssl/bin/openssl /usr/bin/openssl

# 验证openssl是否可用
openssl version
```

如果不可以用，可能是libssl.so.1.1 和 libcrypto.so.1.1 依赖出现问题，可以参照一下以下指令：

```sh
# 先要确认依赖的位置
ldd /usr/local/openssl/bin/openssl

# 创建依赖的软连接
ln -s /usr/local/openssl/lib/libssl.so.1.1 /usr/lib64/libssl.so.1.1
ln -s /usr/local/openssl/lib/libcrypto.so.1.1 /usr/lib64/libcrypto.so.1.1
```

## Ubuntu 18.04 , Ubuntu 20.04


```sh
# 编译安装需要提前安装好 gcc 和 make
apt-get install gcc make

# 进入解压openssl目录
tar xvf ./openssl-1.1.1i.tar.gz

# 进入解压后的目录
cd ./openssl-1.1.1i

# 执行配置文件，安装在 /usr/local/openssl
./config --prefix=/usr/local/openssl

# 执行编译并安装
make && make install

# 将原本的openssl删除或重命名
whereis openssl
mv /usr/bin/openssl /usr/bin/openssl.old

# 创建新版openssl的软连接
ln -s /usr/local/openssl/bin/openssl /usr/bin/openssl

# 验证openssl是否可用
openssl version
```

如果不可以用，可能是libssl.so.1.1 和 libcrypto.so.1.1 依赖出现问题，可以参照一下以下指令：

```sh
# 先要确认依赖的位置
ldd /usr/local/openssl/bin/openssl

# 创建依赖的软连接
ln -s /usr/local/openssl/lib/libssl.so.1.1 /usr/lib/libssl.so.1.1
ln -s /usr/local/openssl/lib/libcrypto.so.1.1 /usr/lib/libcrypto.so.1.1
```
