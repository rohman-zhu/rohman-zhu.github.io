---
title: Network setup
date: 2017-10-01 22:53:18
tags: Linux 
---

This have two way to setup internet-config,'setup' command and others.

- Path : /etc/sysconfig/network-scripts/ifcfg-eth1

## Network driver file ##

```
$cat /etc/sysconfig/network-scripts/ifcfg-eth1
BOOTPROTO = none # <== 其中，proto取值可以是：none，引导时不使用协议；static 静态分配地址；bootp,使用BOOTP协议；或者DHCP，使用DHCP协议；
```

- 开启网卡
```
$/etc/init.d/network restart <== ONBOOT = yes 网卡文件中该属性必须位YES
$ifup NetworkDirver <== Make NetworkDirver working
$ifdown NetworkDirver <== Shutdown NetWorkDirver 
```

- Checking network status
```
$ifconfig
$ip ad

```

## DNS config ##
- PATH : /etc/resolv.conf

### DNS config summary ###
1. 客户端DNS可以在网卡配置文件里面设置。( /etc/sysconfig/network-scripts/...)
2. 客户端DNS也可以在 /etc/resolv.conf 里面设置。
3. 网卡里的设置DNS 优先于 /etc/resolv.conf。

* PS： 上面的配置在DNS服务器重启的时候会清除, ($ /etc/init.d/network restart)

## /etc/hosts file ##

The static table lookup for hostname.

hosts企业里面的作用：
1. 开发，产品，测试等人员，用于通过正式的域名测试产品。
2. 服务器之间的调用可以用域名（内部的DNS），方便迁移。
