---
title: SQL常用指令
tags:
  - 常用指令
categories:
  - default
date: 2022-10-30 14:53:56
---

# 常用指令记录

## MySQL初始化

```sh
/usr/local/mysql/bin/mysqld --initialize --user=mysql --basedir=/usr/local/mysql --datadir=/usr/local/mysql/data
```

> 此指令会初始化MySQL的root账户密码，放在日志文件内。

## 更改数据库的 root 密码

```sql
use mysql;
alter user 'root'@'localhost' identified with mysql_native_password by '我是密码';
flush privileges;
```

## 查询数据库的用户

```sql
use mysql;
select user from user;
```

## 创建数据库

```sql
create database zabbix default charset utf8;
```

## 创建数据库用户与授权

```sql
create user 'zabbix'@'localhost' identified by '我是密码';
grant all on zabbix.* to 'zabbix'@'localhost';
flush privileges;
```