---
title: Ubuntu配置VNC
tags:
  - default
catergories:
  - default
date: 2020-02-25 15:20:13
---
