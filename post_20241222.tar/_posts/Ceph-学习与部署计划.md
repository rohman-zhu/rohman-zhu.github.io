---
title: Ceph-学习与部署计划
tags:
  - 学习笔记
categories:
  - Linux
  - Ceph
date: 2021-01-31 15:39:35
---
# 背景

需要学习部署Ceph与基础运维能力作为技能储备。
Deadline:2021-03-31