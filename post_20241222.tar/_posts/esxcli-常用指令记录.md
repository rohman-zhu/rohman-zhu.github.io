---
title: esxcli 常用指令记录
tags:
  - 常用指令
categories:
  - VMware
  - vSphere
date: 2022-05-22 16:24:15
---

# 网络测试

```sh
# 显示所有网卡 
esxcli network nic list
# 关闭网卡 
esxcli network nic down -n vmnic[X]
# 开启网卡 
esxcli network nic up -n vmnic[X]

# 参考 https://kb.vmware.com/s/article/2006074

# 使用vmkernel网卡去ping 
vmkping -I  vmk0 [Target IP]

# 使用巨帧
vmkping -d -s 8972 x.x.x.x

# 参考 ： https://kb.vmware.com/s/article/1003728?lang=zh_cn
```

# 负载查看

```sh
esxtop

# 常用视图
u=Disk Device
d=Disk Adapter
x=vSAN

# 其他视图
c=CPU
m=Memory
n=Network
p=Power Management
```

# 安装补丁

esxcli software vib update -d /vmfs/xxxxxxxx.zip
esxcli software vib install -d /vmfs/xxxxxxxx.zip

# 设置标准交换机模式

```sh
esxcli network vswitch standard policy failover set -l [Policy] -v [vSwitch] -a vmnic[X],vmnic[X]
esxcli network vswitch standard portgroup policy failover -set -p "Management Network" -l [Policy] -a vmnic[X],vmnic[X]
```

[Policy]有以下4种：

explicit – according to the list
portid – based on the originating virtual port
mac – on source MAC-hash
iphash – based on IP-hash

# 版本查看

```sh
vmware -v
```

# 存储连接状态

```sh
esxcli storage core device list -d=device_ID 命令。

on- 设备已连接。
dead- 设备已进入 APD 状态。APD 定时器已启动。
dead timeout- APD 超时已过期。
not connected- 设备处于 PDL 状态。
```

# 回收精简制备vmdk的空间

```sh
vmkfstools -K /vmfs/volume/xxxx/xxxx.vmdk
# -K|--punchzero  该选项会对所有清零块取消分配，只留下那些先前分配且包含有效数据的块。生成的虚拟磁盘为精简格式的虚拟磁盘。
```

# 虚拟机相关操作

```sh
# 查看虚拟机信息 
esxcli vm process list
vim-cmd vmsvc/getallvms

# 结束虚拟机进程
esxcli vm process kill --type[soft,hard,force] --world-id=[WorldNumber]
# 关闭虚拟机操作系统=soft
vim-cmd vmsvc/power.shudown [WorldNumber]
# 强制关闭虚拟机=hard
vim-cmd vmsvc/power.off [WorldNumber]

# 检测是否有相关任务
vim-cmd vmsvc/get.tasklist [WorldNumber]
```

# 检查目标文件系统Inode情况

```sh
stat -f /
```

# 进入维护模式

```sh
esxcli system maintenanceMode Set --enabled [yes/no]
```
# esxcfg命令列表

```sh
# 防火墙
esxcfg-firewall

# 路由表
esxcfg-route

# vmkernel网卡
esxcfg-vmknic

# 当前网卡信息
esxcfg-vswif

# 虚拟机交换机
esxcfg-vswitch

# 物理网卡信息
esxcfg-nics

# 显示HBA设备
esxcfg-vmhbadevs
```

# VSAN磁盘组操作

```sh
# 删除
esxcli vsan storage remove -u [磁盘组UUID]
esxcli vsan storage remove -s [缓存层 SSD NAAID]
esxcli vsan storage remove -d [容量层 NNID]
```

# 退出VSAN集群

```sh
esxcli vsan cluster get
esxcli vsan cluster leave
```

VSAN相关指令：https://docs.vmware.com/en/VMware-vSphere/7.0/com.vmware.vsphere.vsan-monitoring.doc/GUID-7799D2D7-2513-4372-92EA-4A1FB510E012.html

# 输出日志

```
vm-support -w [指定路径]
```

https://kb.vmware.com/s/article/1010705?lang=zh_CN

# 重启管理程序

```sh
/etc/init.d/hostd restart
/etc/init.d/vpxa restart
```
Restarting the Management agents in ESXi (1003490):https://kb.vmware.com/s/article/1003490

# 扩容空间

```sh
vpxd_servicecfg storage lvm autogrow
```

# 获取Dump日志

一般情况下，ESXi紫屏后会产生DUMP日志，一般放置在 /var/core 目录下，

获取dump日志

```sh
# 一般在/root/ , /var/core/目录中都能找到zdump文件
# 将zdump文件转为日志文件
esxcfg-dumppart -L [vmkernel-zdump-filename]
```

参考： https://kb.vmware.com/s/article/1006796?lang=zh_CN

# 配置 zdump 文件

参考：https://kb.vmware.com/s/article/2081902

```sh
#获取当前配置
esxcli system coredump file get
```
# 查询文件锁定

```sh
vmfsfilelockinfo -p [路径]
```

# VCSA指令-查看证书

```sh
for store in $(/usr/lib/vmware-vmafd/bin/vecs-cli store list | grep -v TRUSTED_ROOT_CRLS); do echo "[*] Store :" $store; /usr/lib/vmware-vmafd/bin/vecs-cli entry list --store $store --text | grep -ie "Alias" -ie "Not After";done;

```

参考： https://kb.vmware.com/s/article/82332

# 获取USB设备

```sh
lsusb
```

# 参考

- 存储相关：https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.storage.doc/GUID-A5D85C33-A510-4A3E-8FC7-93E6BA0A048F.html
- 关闭虚拟机电源： https://kb.vmware.com/s/article/1004340?lang=zh_CN
- esxcfg命令：https://blog.csdn.net/rrs123/article/details/77587702
