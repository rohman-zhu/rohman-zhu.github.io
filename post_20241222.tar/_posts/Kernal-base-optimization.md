---
title: Kernal base optimization
date: 2017-10-01 22:50:25
tags: Linux
---
# 内核基础优化 #

配置文件:

* 路径 : etc/sysctl.conf
* 生效 : sysctl -p

小提示:

* tip_1 : In 'vim' mode , use key (shift + g) turn to the end of the article.
* tip_2 : In 'vim' mode , use key (shift + insert) to paste content .

## 1.修改sysctl.conf文件 ##

### [Commonly used] Web server high concurrent status ###

* net.ipv4.tcp\_fin_timeout = 2 默认是60秒
* net.ipv4.tcp\_tw_reuse = 1 表示开启重用。允许将TIME-WAIT sockets重新用于新的TCP连接，默认为0，表示关闭；
* net.ipv4.tcp\_tw_recyle = 1 表示开启TCP连接中TIME-WAIT sockets的快速回收，默认为0，表示关闭。

#### [原理]TCP three-way-handshake ####

```{.normal}
  === > syn
< === syn + ack
  === > ack
```

##### What is SYN #####

全称是_Synchronize Sequence Numbers_,是TCP/IP建立连接时使用的握手信号。

###### SYN ATTACK ######

SYN攻击属于DDoS攻击的一种，它利用TCP协议缺陷，通过发送大量的半连接请求，耗费CPU和内存资源。SYN攻击除了能影响主机外，还可以危害路由器、防火墙等网络系统，事实上SYN攻击并不管目标是什么系统，只要这些系统打开TCP服务就可以实施。服务器接收到连接请求（syn= j），将此信息加入未连接队列，并发送请求包给客户（syn=k,ack=j+1），此时进入SYN_RECV状态。当服务器未收到客户端的确认包时，重发请求包，一直到超时，才将此条目从未连接队列删除。配合IP欺骗，SYN攻击能达到很好的效果，通常，客户端在短时间内伪造大量不存在的IP地址，向服务器不断地发送syn包，服务器回复确认包，并等待客户的确认，由于源地址是不存在的，服务器需要不断的重发直至超时，这些伪造的SYN包将长时间占用未连接队列，正常的SYN请求被丢弃，目标系统运行缓慢，严重者引起网络堵塞甚至系统瘫痪。

##### What is ACK #####

全称是_Acknowledgement Number_,即是确认字符，在数据通信中，接收站发给发送站的一种传输类控制字符。表示发来的数据已确认接收无误。

## 2.Hide your operated-system version ##

里面的默认内容是:

```{.normal}
# cat /etc/issue
CentOS release 6.9 (Final)
Kernel \r on an \m
```

修改方式是

```{.normal}
# >etc/issue
```

## 3.Modify login shell information ##

* Path : /etc/
* Create new file : /etc/motd

## 4.Locked system file ##

Some system files is so important that common user could not modify without permission.
Such as passwd,shadow,group....

</br>
锁文件操作

```{.normal}
# chattr +i /etc/passwd /etc/shadow /etc/group /etc/inittab
```

</br>
解锁文件

```{.normal}
#chattr -i /etc/passwd /etc/shadow /etc/group /etc/inittab
```

</br>
把重要命令藏起来

```{.normal}
$mv `which chattr` /home/roman
```

## 5.Add password to grup-shell ##

Because we can change root's password in boot-shell and enter 'grup' shell.

```{.normal}
# /sbin/grub-md5-crypt
# vim /boot/grub/menu.lst
# 顶端添加一行代码
# password --md5 [grub-md5-crypt产生的密码]

```

## 6.Ban other terminal ping host computer ##

添加语句到syscntl,禁止其他用户ping

```{.normal}
# echo "net.ipv4.icmp_echo_ignore_all=1" >> /etc/sysctl.conf
```

更新设置

```{.normal}
$sysctl -p
```

## 7.Fixed bugs ##

Update the software.

```{.normal}
$yum install openssl openssh bash -y
```

## 8.Modify yum source ##

### Download command -- wget ###

```{.normal}
# wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-6.repo
```

> -O指令表示重新命名下载的文件

## 9.关于临时邮件处理 ##

在CentOS5系列的系统会默认安装Sendmail服务，因此邮件临时寸放点的路径是/var/spool/clientmqueue

</br>

在CentOS6默认情况下是没有安装Sendmail 服务，而是改装了Postfix，存放的路径在 /var/spool/postfix/maildrop/。

### 9.1手动清理的方法 ###

```{.normal}
Centos_5
# find /var/spool/clientmqueue/ -type f | xargs rm -f

Centos_6
# find /var/spool/postfix/maildrop/ -type f | xargs rm -f
```

### 9.2定时任务 ###

将上面的命令携程脚本，做成定时任务。

### 9.3 关闭 selinux 和 iptables ###

```shell
# 永久关闭 selinux
sed -i "s#enforcing#disabled#g" /etc/selinux/config
# 永久关闭 防火墙
chkconfig iptables off
```
## 10.Summary ##

1. 不用root用户管理，普通用户通过sudo授权管理。
1. 更改远程链接ssh服务端口，禁止root用户远程链接，改成只监听内网IP。
1. 定时自动跟新服务器时间，使其和互联网时间同步。
1. 配置yum更新源，从国内更新源下载安装软件包。
1. 关闭seLinux 以及 iptables。
1. 定时自动清理邮件目录垃圾文件，防止inodes节点被占满。
1. 精简保留必要的开机自启动服务（如crond,sshd,network,rsyslog）。
1. Linux内核参数优化 /etc/sysctl.conf,执行sysctl -p 生效果。
1. 锁定关键系统文件如（/etc/passwd /etc/shadow /etc/group 、/etc/inittab等