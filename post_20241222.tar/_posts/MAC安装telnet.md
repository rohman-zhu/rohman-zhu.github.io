---
title: MAC安装telnet
date: 2019-01-06 21:30:26
tags: MAC
---
# 前言

MAC从10.13后就没有telnet指令，需要自己手动安装。

# 安装过程

```shell
# 安装 Homebrew
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
# 安装telnet
brew install telnet
# 做一个link
brew link telnet
```

# 参考资料

* MAC上安装telnet：https://ccie.lol/knowledge-base/xnu-macos-install-telnet/
