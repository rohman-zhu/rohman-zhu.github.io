---
title: Ubuntu 18.04修改网卡
tags:
  - Ubuntu
catergories:
  - Linux
  - Ubuntu 18.04
date: 2020-03-05 23:27:09
---

# How to configure static ip

To configure a static IP address on your Ubuntu 18.04 server you need to modify a relevant netplan network configuration file within /etc/netplan/ directory.

For example you might find there a default netplan configuration file called 01-netcfg.yaml or 50-cloud-init.yaml with a following content instructing the networkd deamon to configure your network interface via DHCP:

```yaml
# This file describes the network interfaces available on your system
# For more information, see netplan(5).
network:
  version: 2
  renderer: networkd
  ethernets:
    enp0s3:
      dhcp4: yes

# This file describes the network interfaces available on your system
# For more information, see netplan(5).
network:
  version: 2
  renderer: networkd
  ethernets:
    enp0s3:
     dhcp4: no
     addresses: [192.168.1.222/24]
     gateway4: 192.168.1.1
     nameservers:
       addresses: [8.8.8.8,8.8.4.4]
```

# 修改完后

```sh
netplan apply
```

# 参考资料

https://linuxconfig.org/how-to-configure-static-ip-address-on-ubuntu-18-04-bionic-beaver-linux

https://www.jianshu.com/p/1378e6abd94d