---
title: PHP
date: 2017-10-21 23:33:47
tags: Linux
---
# LNMP之PHP #

## 1.CGI ##

CGI(Common Gateway Interface),通用网关接口,用于HTTP服务器与其他机器上的程序服务通信交流的一种工具,CGI程序必须运行在网络服务器上.

* 主要缺点: 性能差,因为每次HTTP服务器遇到动态程序都需要重新启动解析器来解析,然后再将结果返回给HTTP服务器.

## 2.FASTCGI ##

是一个可伸缩,高速地在HTTP服务器和动态脚本语言间通信的接口.(Linux 下是Socket,也可以是ip_Socket)

* 主要优点: 动态语言和HTTP服务器分离出来.主要支持Apache,Nginx,lighttpd.
* 接口采用C/S结构,分为客户端(HTTP服务器)和服务端(动态语言解析服务器)
* PHP动态语言服务端可以启动多个FastCGI的守护进程
* http服务器通过 FastCGI客户端和动态语言FastCGI服务端通信.(例如php-fpm)

### 2.1.运行原理 ###

Nginx不支持对外部动态程序的直接调用或者解析,所有的外部程序(包括PHP)必须他通过FastCGI接口来调用.

</br>

FastCGI接口在Linux下是Socket(这个Socket可以是文件,也可以是ip socket).

</br>

为了调用CGI程序,还需要一个FastCGI的wrapper(wrapper可以理解成用于启动另一个程序的程序,包装),这个wrapper绑定在某一个固定socket上,如端口或者文件socket.

</br>

当Nginx将CGI请求发送给这个Socket的时候,通过FastCGI接口,wrapper接收到请求,然后派生出一个新的线程,这个线程调用解释器或者外部程序处理脚本并读取返回数据.

</br>

wrapper再将返回的数据通过FastCGI接口,沿着固定的socket传递给Nginx,最后Nginx将数据发送给客户端.

## 3.安装PHP ##

```{.LinuxCommad}
wget http://cn.php.net/get/php-5.3.27.tar.gz/from/cn2.php.net/mirror

wget http://cn2.php.net/get/php-5.3.27.tar.gz/from/this/mirror

# 安装相关的依赖库

# 需要的软件有:zlib libxml libjpeg freetype libpng gd curl libiconv zlib-devel libxml2-devel libjpeg-devel freetype-devel libpng-devel gd-devel curl-devel

yum install zlib-devel libxml2-devel libjpeg-devel libiconv-devel
yum install freetype-devel libpng-devel gd-devel curl-devel

# 安装libmcrypt库,在此采用的是epel源方法来安装libmcrypt包

yum -y install libmcrypt

# 执行安装脚本
vim install.sh
#---------------
./configure \
--prefix=/application/php-5.3.27 \
--with-mysql=/application/mysql \
--with-iconv-dir=/usr/local/libiconv \
--with-freetype-dir \
--with-jpeg-dir \
--with-png-dir \
--with-zlib \
--with-libxml-dir=/usr \
--enable-xml \
--disable-rpath \
--enable-safe-mode \
--enable-bcmath \
--enable-shmop \
--enable-sysvsem \
--enable-inline-optimization \
--with-curlwrappers \
--enable-mbregex \
--enable-mbstring \
--enable-fpm \
--with-mcrypt \
--with-gd \
--enable-gd-native-ttf \
--with-openssl \
--with-mhash \
--enable-pcntl \
--enable-sockets \
--with-xmlrpc \
--enable-zip \
--enable-soap \
--enable-short-tags \
--enable-zend-multibyte \
--enable-static \
--with-xsl \
--with-fpm-user=nginx \
--with-fpm-group=nginx \
--enable-ftp

# -------------

# Before make
ln -s /application/mysql/lib/libmysqlclient.so.18 /usr/lib64/

make install

# 配置php解析文件
# 在php主目录下
cp php.ini-production   /application/php/lib/php.ini

#在软件目录下的etc文件夹内
cp php-fpm.conf.default  ./php-fpm.conf


# 启动php进程
/php/sbin/php-fpm
lsof -i:9000

# 测试
# 在nginx的一个站点下写一个
# test_phpinfo.php代码测试php
#------
<?php
    phpinfo();
?>
#-------

# 编辑location节点
# ------------
location ~*.\.php  {
    fastcgi_pass 127.0.0.1:9000;
}

# 输入域名测试
```

### 3.1.知识补充:Nginx location语法 ###

* = 严格匹配。如果这个查询匹配，那么将停止搜索并立即处理此请求。
* ~ 为区分大小写匹配(可用正则表达式)
* !~为区分大小写不匹配
* ~* 为不区分大小写匹配(可用正则表达式)
* !~*为不区分大小写不匹配
* ^~ 如果把这个前缀用于一个常规字符串,那么告诉nginx 如果路径匹配那么不测试正则表达式。

## 4.WordPress博客实战 ##

### 4.1到官网下载tar文件 ###

www.wordpress.org

<a href=`http:www.wordpress.org >下载地址</a>

### 4.2解压安装 ###

tar xvf wordpress.tar

复制当前整个目录到nginx的html的blog文件节点下.

### 4.3修改blog节点的配置文件 ###

vim /conf/nginx.conf

```{.LinuxCommand}
server{
    listen 80;
    server_name blog.test.org;
    root html/blog;

    location / {
        index index.php index.html;
    }

    location ~*.\.(php|php5)?$
    {
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
    include fastcgi.conf;
    }
}

# ngnix -t
# ngnix -s reload
```

### 4.4出现的问题 ###

#### 403 ####

这个问题可能是html目录下的权限问题导致的.

#### 没有安装mysql拓展 ####

默认的php配置文件在./lib下

1. yum install mysql-devel
1. 修改php目录下面的php.ini ,在里面添加两个命令 :

extension=mysql.so
extension="/usr/lib64/php/modules/"

#### 4.3.1 location匹配字符讲解 ####

* = 开头表示精确匹配
* ^~ 开头表示uri以某个常规字符串开头，理解为匹配 url路径即可。nginx不对url做编码，因此请求为/static/20%/aa，可以被规则^~ /static/ /aa匹配到（注意是空格）。
* ~ 开头表示区分大小写的正则匹配
* ~* 开头表示不区分大小写的正则匹配
* !~和!~*分别为区分大小写不匹配及不区分大小写不匹配 的正则
* / 通用匹配，任何请求都会匹配到。

## 5.BBS实战 ##

### 5.1创建用户 ###

### 5.2创建配置文件 ###

```{.configure}
server{

    listen 80;
    server_name bbs.test.org;
    location / {
        index index.php index.html index.htm;
    }
    location ~* \.(php|php5)?$ {
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index_php;
        include fastcgi.conf;
    }
}

```

### 5.3将相关的文件放置html的节点下 ###

下载Discuz,解压,将./upload里面的内容解压至html/bbs;

### 5.4给该目录文件授权 ###

因为我们是在root用户下面操作的,所以所有文件或文件夹,操作用户是root,属组也是root,而我们通过nginx连上的网页,用户默认为nginx,因此在安装的时候,会显示相关目录不能读写.

### 5.5完成测试 ###

安装完成后,需要将该虚拟主机的域名添加至hosts文件中.