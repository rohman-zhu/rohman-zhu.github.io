---
title: Windows无法启动配置...
date: 2017-10-05 10:27:11
tags: Windows
---

在重装过程中出现这个警告弹窗，按了确定后就重启，重启完后又出现这个弹窗。
以下就是解决方案：

1. 按 shift + F10 ，出现命令窗口。

2. 进入 oobe 文件夹。
```
# cd c:\WINDOWS\system32\oobe
```

3. 运行 msoobe 程序
```
# msoobe
```

4. 根据引导完成程序安装。
