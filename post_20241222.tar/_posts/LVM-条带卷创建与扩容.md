---
title: LVM-条带卷创建与扩容【待补充】
tags:
  - LVM
categories:
  - Linux
date: 2023-01-31 23:44:48
---
# 需求1：创建条带卷

## 需求背景

业务需求如果有连续大量的读取与写入，可以创建一个条状卷（RAID0）来提高数据IO效率；


## 条状卷（条带卷）的设置特点

- 当您创建条状逻辑卷时，您可以使用 lvcreate 命令的 -i 参数指定条带的数量。这决定了逻辑卷是条带的物理卷数量。条带的数量不能大于卷组中的物理卷数量（除非使用 --alloc 任何参数）。【关键参数 -i】
- 如果组成条状逻辑卷的基本物理设备不同，则条状卷的最大大小由最小的底层设备决定。例如，在双委派的分条中，最大大小为较小的设备的大小。在三位分条中，最大大小为最小设备的三倍。【木桶效应】

```sh
# /dev/sda , /dev/sdb 做成条带卷；
pvcreate /dev/sda /dev/sdb
vgcreate vg-sprite /dev/sda /dev/sdb
# 条带宽度Sprites为2；
# 默认条带大小 Sprite Size 为 64K；
lvcreate -n lv-sprite -i 2 -l +100%free vg-sprite
```

## 问题：条带大小对性能的影响是什么？

> Sprite=2，Sprite Size=4k,写入速度较高，但是写入延迟也高；
> Sprite=2，Sprite Size=12K，写入速度相比4K低，但是写入延迟低；

## 问题：条带宽度对性能的影响是什么？

OS为Ubuntu ， 文件系统为ext4

> Sprite=1，读写速度为a；
> Sprite=2，读写速度大约为2a；

OS为Ubuntu，文件系统为xfs

> Sprite=1，读写速度为a；
> Sprite=2，读写速度大约为a，甚至低于a；

## 参考资料

创建条状卷：https://access.redhat.com/documentation/zh-cn/red_hat_enterprise_linux/7/html/logical_volume_manager_administration/lv_stripecreate


# 需求2：条带卷扩容

## 需求背景

原本的条带卷空间不足，需要扩容；

## 设置特点

扩容的方式：磁盘数量=条带数量

