---
title: VMware-UAG-监控方案记录
tags:
  - UAG
categories:
  - VMware
  - Horizon View
date: 2022-11-24 00:37:44
---

# 背景

UAG一般被用来替换Horizon的安全服务器，但其底层是Photon Linux，OS已经是经由VMware自行封装过一层了，常规的Zabbix不仅安装会较为繁琐，可能一些监控指标也不能满足需求。

UAG我需要关注的几个指标有：

常规的（Zabbix应该也能实现的）：

- CPU 使用率；
- Memory 使用率；
- 磁盘使用率；

非常规的：

- 连接的会话数；
- 业务是否正常；

# 监控方案说明

UAG原生会提供 SNMP 与 REST API 两个方案 ， 可惜两个方案均为互补关系，其中一个并不能满足我们的需求。
因此需要结合两者来做监控方案。

# 实践

## SNMP

开启SNMP可以在UAG的管理界面操作：

1. 进入UAG管理后台 https://[UAG IP]:9443
2. 进入系统设置
3. 勾选 SNMP

进入OS内：

```sh
# 修改团体名称，默认为public
vim /etc/snmp/snmpd.conf

# 修改完毕后，重启snmpd服务
systemctl restart snmpd

# 测试是否能正常提供数据
snmpwalk -v 2c -c [新团体名] 127.0.0.1 1.3.6
```

## REST API

开启REST API，需要先创建一个专门用于调取的账户，在UAG的管理后台中可以直接添加账户。

进入REST API获取数据 https://<UAGIP>:9443/rest/v1/monitor/stats

关注：
- authenticatedSessions ，指示正在进行的已通过身份验证的会话（已登录会话）数。【不可超过2000】
- Blast\session,指示活动的 BLAST 会话数。
- totalCpuLoadPercent,指示 CPU 负载百分比。
- freeMemoryMb,指示可用的未用内存量（以 MB 为单位）。
- usedDiskSpacePercentage,指示磁盘使用情况（以百分比为单位）。

# 参考资料

UAG SNMP ：https://kb.vmware.com/s/article/83677
REST API：https://docs.vmware.com/en/Unified-Access-Gateway/2209/uag-deploy-config/GUID-2E9974D9-2F38-494E-95D1-877AA487203D.html

