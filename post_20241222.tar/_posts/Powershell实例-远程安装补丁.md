---
title: Powershell实例-远程安装补丁
tags:
  - powershell
categories:
  - Windows Server
date: 2024-04-01 00:49:57
---
# 需求说明

1. 给远端的服务器安装补丁；
2. 检查是否需要重启；

# 实例脚本

```ps1
# Date:2024-03-31
# Version : v2

# Global Veriable
$WINRM_PORT=5985;
# Target Windows Update  inneed;
$TARGET_WUKB_ARRARY="KB5035849","KB5035849";
$TARGETSERVER_List=$args[0];
if($null -eq $PSCREDENTIAL){$PSCREDENTIAL=Get-Credential;}

# Log
Function Get-Log{
    param($TYPE,$CONTENT);
    $TIMESPAN1=Get-Date -Format "yyyy-MM-dd";
    $TIMESPAN2=Get-Date -Format "HH:mm:ss";
    Write-Host "[$TIMESPAN1][$TIMESPAN2][$TYPE]$CONTENT;";
    Add-Content "$TYPE.log" "[$TIMESPAN1][$TIMESPAN2][$TYPE]$CONTENT;";
}

# Check windows updates is installed
Function Check-WindowsUpdate{
    param($TARGET_WUKB_ARRARY,$PSSESSION);

    # 
    $WU_CHECK_BLOCK={
        param($TARGET_WUKB);
        $INSTALL_FLAG=$TRUE;
        $INSTALL_KB_CHECK=Get-HotFix | Where-Object {$_.HotFixID -match $TARGET_WUKB};
        if($null -eq $INSTALL_KB_CHECK){
            $INSTALL_FLAG=$FALSE;
        }
        return $INSTALL_FLAG;
    }

    for($i = 0 ;$i -lt $TARGET_WUKB_ARRARY.Length;$i++){
        $WU_PRE_CHECK_FLAG=Invoke-Command -Session $PSSESSION -ArgumentList $TARGET_WUKB_ARRARY[$i] -ScriptBlock $WU_CHECK_BLOCK;
        if(!$WU_PRE_CHECK_FLAG){
            break;
        }
    }

    <#注意 ArgumentList 无法传递数组；2024-03-31，废案；
    $WU_CHECK={
        param($TARGET_WUKB_ARRARY);
        $INSTALL_FLAG=$FALSE;
        for($i = 0; $i -lt $TARGET_WUKB_ARRARY.Length;$i++){
            $ISINSTALLED=Get-HotFix | Where-Object {$_.HotFixID -match $TARGET_WUKB_ARRARY[$i]};
            if($null -eq $ISINSTALLED){
                $INSTALL_FLAG=$TRUE;
                Write-Host "$(hostname) need install $($TARGET_WUKB_ARRARY[$i]);"
            }
        }
        return $INSTALL_FLAG;
    }    



    $READY_FLAG=Invoke-Command -Session $PSSESSION -ScriptBlock $WU_CHECK -ArgumentList $TARGET_WUKB_ARRARY;
    #>

    if(!$WU_PRE_CHECK_FLAG){
        Get-Log "INFO" "$($PSSESSION.ComputerName) need to install windows update "
        Invoke-WuJob -ComputerName $PSSESSION.ComputerName -Script {Install-WindowsUpdate -AcceptAll -IgnoreReboot | Out-File C:\InstallWindows.log} -RunNow -Confirm:$FALSE -ErrorAction Ignore;
    }else{
        Get-Log "INSTALL-WU" "$($PSSESSION.ComputerName) don't need to intall $TARGET_WUKB_ARRARY";
    }
}

# Check target windows server;
Function Check-RebootStatus{
    param($PSSESSION);

    $CHECK_REBOOT_BLOCK={
        #$ISNEED_REBOOT=$FALSE;
        $ISNEED_REBOOT=Get-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired";
        if($null -eq $ISNEED_REBOOT){
            return $FALSE;
        }else{
            return $TRUE;
        }
    }

    $REBOOT_FLAG=Invoke-Command -Session $PSSESSION -ScriptBlock $CHECK_REBOOT_BLOCK;

    if($REBOOT_FLAG){
        Get-Log "INFO" "$($PSSESSION.ComputerName) need to reboot";
        Get-Log "REBOOT" "$($PSSESSION.ComputerName)";
    }
}

# Start check target server;
Function Start-CheckTargetServer{
    param($TARGETSERVER_LIST_FILE);

    Get-Content $TARGETSERVER_LIST_FILE | ForEach-Object{
        $SERVERNAME=$_.Trim();
        Get-Log "INFO" "Start connect to $SERVERNAME ";
        $SESSION=New-PSSession -ComputerName $SERVERNAME -Port $WINRM_PORT -Credential $PSCREDENTIAL;

        Check-WindowsUpdate $TARGET_WUKB_ARRARY $SESSION;
        Check-RebootStatus $SESSION;
    }

}

Start-CheckTargetServer $TARGETSERVER_List;


```

# 参考资料

Invoke-Command 传参：https://www.cnblogs.com/talentzemin/p/16976197.html