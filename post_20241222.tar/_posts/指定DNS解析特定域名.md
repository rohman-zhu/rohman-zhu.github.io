---
title: 指定DNS解析特定域名
tags:
  - DNS
categories:
  - Linux
date: 2021-02-22 00:22:57
---
# 背景

有一套存储是通过一个域名来对外提供服务，客户端需要通过域名来连接存储。

虚拟机需要解析这个制定域名才能实现挂载存储，而这个域名需要使用存储自带的DNS才可以。
然而存储的DNS是在其局域网内，存储的DNS与业务网络并不相通，因此业务网络中的DNS无法实现转发DNS请求到存储的DNS上。

因此虚拟机有这两个要求：
1. 正常情况下还是需要使用业务网络的DNS，即非存储的域名解析都要在业务网络DNS中执行。
2. 存储的域名解析则需要在存储的DNS中执行。

# 方案

## 方案一

在Linux的DNS配置中增加轮询机制，使存储的域名解析请求到制定DNS。

缺点：这种方式也会让正常业务的DNS解析请求到存储的DNS上，其次存储的域名解析还是有概率到正常业务网络的DNS上。

```resolv.conf
nameserver DNS1
nameserver DNS2
# 实现DNS轮询
option rotate
```

## 方案二

在Linux中安装dnsmasq，这个软件可以制定dns解析请求。

```sh
# 安装dnsmasq
apt-get install dnsmasq

# 配置dnsmasq
vim /etc/dnsmasq.conf
#--
# 指定DNS解析请求
server=/存储用的域名/制定DNS
# 指定通用的DNS请求文件
resolv-file=/etc/dnsmasq-resolv.conf
# 表示严格按照resolv-file文件中的顺序从上到下进行DNS解析，直到第一个解析成功为止。
strict-order
# 提供DNS服务
listern-address=127.0.0.1
#--

# 配置全局DNS
vim /etc/dnsmasq-resolv.conf
#---
nameserver 正常业务网络的DNS
#---

# 配置Linux的DNS
vim /etc/resolv.conf
#---
nameserver 127.0.0.1
#---

# 停用本地的DNS服务，并关闭开机自启。
systemctl stop systemd-resolved
systemctl disable systemd-resolved

# 启用dnsmasq，并开启开机自启。
systemctl start dnsmasq
systemctl enable dnsmasq

# 测试业务
nslookup 存储域名
nslookup 业务域名
```

## 方案三

业务网络与存储网络的DNS相通，则在业务网络的DNS中配置DNS转发请求。

