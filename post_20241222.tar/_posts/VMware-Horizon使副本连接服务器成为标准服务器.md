---
title: VMware Horizon使副本连接服务器成为标准服务器
tags:
  - default
categories:
  - VMware
  - Horizon View
date: 2022-11-27 23:17:32
---
# 背景

一般部署架构中，会部署多台连接服务器，在架构中只有一台标准服务器、其他均为副本服务器。

多个连接服务器使用 AD LDS LDAP 配置在它们之间复制数据。在一个实例（连接服务器 AD LDS）中进行更改时，这些更改将复制到其他连接服务器。

如果连接服务器实例失败，组中的其他实例将继续运行。故障实例恢复后，更改将复制回服务器。您将看到安装在程序和功能中列出的每个连接服务器上的 AD LDS 实例。

在Windows服务器的程序和功能中，可以看到 AD LDS Instance VMwareVDMDS；

## 什么时候需要切换角色？

当标准服务器因各种原因需要下线替换，此时就需要将副本服务器切换成标准服务器；

而标准服务器与副本服务器之间的区别是：LDAP 操作的 FSMO 角色持有者。

## 如何确定 FSMO 角色的持有者

在任意一个连接服务器：

1. 进入 LDP.exe ； 
2. 进入 Connection --> Connect，Server填写127.0.0.1，端口389；(因为本身就是从连接服务器中打开的ldp)
3. 绑定访问LDAP的凭据，点击 Connection --> Bind ， 选择 "Bind as currently logoned on User"
4. 进入 View --> Tree ;
5. 选择 Tree View 中的 CN=Schema,CN=Configuration,CN=xxxxxxxx；
6. 可以在主体内容中看到条目"fSMORoleOwner"确定角色；

## 如果 FSMO 角色在一个需要移除的连接服务器上面

如果 FSMO 角色在一个需要移除的连接服务器，则需要手动提升其他服务器为 fSMORoleOwner ;

故障服务器转移FSMO 角色，以管理员身份打开Powershell：

```ps1
dsmgmt 
"roles" 
"connections" 
"connect to server localhost:389" 
"quit" 
"transfer schema master" 
"quit" 
"quit"
```
登录需要提升角色的连接服务器，以管理员身份打开Powershell

```ps1
# 要在本地 LDAP 实例所在的集群中将当前节点设置为模式主节点，请输入以下命令：
dsmgmt 
"roles" 
"connections" 
"connect to server localhost:389" 
"quit" 
"Size schema master" 
"quit" 
"quit"
```

要在全局 LDAP 实例所在的集群中将当前节点设置为模式主节点，请输入以下命令：

```ps1
dsmgmt 
"roles" 
"connections" 
"connect to server localhost:22389" 
"quit" 
"transfer schema master" 
"quit" 
"quit"
```

## 已经移除FSMO角色的连接服务器

需要移除掉VDMDS角色，如果目标服务器的389阻塞，导致复制中断，则容易引发授权不同步的问题。因此需要移除掉目标角色的功能：

```ps1
vdmadmin -S -r -s <connection_server_to_remove>
```

# 参考资料

https://kb.vmware.com/s/article/2064157?lang=en_US&queryTerm=2064157
https://docs.vmware.com/cn/VMware-Horizon/2106/horizon-upgrades/GUID-1B116018-B472-4B27-BF55-23EAB3FD821A.html
https://www.toutiao.com/article/7101678316058444288/?wid=1669562208287

