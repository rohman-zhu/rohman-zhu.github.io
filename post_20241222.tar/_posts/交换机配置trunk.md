---
title: 交换机配置trunk
date: 2019-01-02 22:44:36
tags: 交换机
---
# 前言

近期会将看到交换机相关概念补充进此篇学习笔记中。

#  华为-配置接口GE0/0/1的链路类型为Trunk

```shell
system-view
interface gigabitethernet 0/0/1
# 缺省情况下,trunk类型接口只允许加入 VLAN 1
port link-type trunk
# 让一个或多个VLAN的报文通过trunk接口, 需要加上[trunk allow-pass] [vlan]
# 放行一段连续的vlan号 ,vlan 10 到 vlan 30
port trunk allow-pass vlan 10 to 30
# 放行一段不连续的vlan号
port trunk allow-pass vlan 10 20 30
# 放行所有vlan
port trunk allow-pass vlan all
# 默认是放通vlan1的
# 关闭vlan1
undo trunk allow-pass vlan 1
```

# 思科-配置接口GE0/0/1的链路类型为Trunk

```shell
# 进入配置模式
configure terminal
# 指定一个端口或者进入一个端口的配置模式
interface gigabitethernet 0/0/1
# 设置该端口的模式
switchport mode trunk
# 放行一段连续的vlan号 ,vlan 10 到 vlan 30
swithport trunk allow vlan 10-30
# 设置允许访问的vlan
switchport access vlan 5
```

# 参考资料

* 思科配置trunk : https://www.cisco.com/c/en/us/td/docs/switches/datacenter/nexus5000/sw/configuration/guide/cli/CLIConfigurationGuide/AccessTrunk.html
* 华为交换机配置:https://forum.huawei.com/enterprise/zh/thread-334821-1-1.html