---
title: Linux考题
date: 2017-10-18 22:32:57
tags: Linux
---
# 考题 #

## 写出下列端口对应的服务 ##

|   port  | 服务  |
|:-------:|:------:|
|   21  |   ftp |
|   22  |   ssh |
|   25  |   smtp    |
|   3306    |   mysql   |
|   873     |   rsync   |
|   161     |   snmp    |
|   111     |   rpc |
|   3389    |   windows的远程桌面    |
|   80      |   www/http |
|   443     |   https   |
|   110     |   pop3    |
|   53      |   dns |
|   514 |   rsyslog |

## 6块 600G的SAS盘做RAID5后,计划装系统部署 mysql 从数据库提供读服务.做 RAID 5 后,给出分区方案,分区后如何不重启就能生效 ##

* 分出
* 6 * 600 G , 只能party来分区

## 已知 A / B 服务器的SSH服务的端口均为 52113 ,用户为root,密码是123456,现在想把A服务器的/etc目录拷贝到B服务器的/tmp目录,要求文件属性不能改变,且不需要交互手工输入密码,也不能使用SSH KEY的方式,请通过expect加 scp 命令给出详细的操作命令或脚本 ##

```{.expect}
#!/bin/expect

set password "123456"

swap scp /etc "root@A:/tmp -p1024"

expect{
    "yes/no" $yes
    "*password" $password
}
```

## 如何批量改文件名字 ##

* 假设 文件名是 : stu\_finished\_1_Delete.jpg
* 目标文件名是 : stu\_finished\_1.jpg

### shell方式来更改 ###

```{.shell}
# f = stu_finished_Delete.jpg
# mv $f `echo $f | sed 's#_Delete##g'`

# 编写脚本
# vim /server/scripts/rename.sh

----------

#!/bin/sh
for f in `ls *Delete*.jpg`
do
    mv $f `echo $f | sed 's#_Delete$$g'
```

### rename 命令 ###

> rename from to file

```{.command}
# rename "_Delete" "" *.jpg
```

## 统计网站某一时间段所有IP的对应PVC数排序,打印出前10位 ##

## DNS解析原理 ##

## http通信原理 ##

## TCP/IP的三次握手和四次断开 ##

## MySQL集群和高可用方案有哪些 ##

* 一主多从,一台从库用于备份,一台从库则给开发连接.
* 级联
* 双柱则用keepalive让两台服务器相互写数据

## MySQL如何实现读写分离 ##

用MySQL_proxy

## 开发有一堆数据插入,如何防止插入的中文数据产生乱码 ##

在客户端和服务端中把字符集都设置同一个字符集.

## 如何备份服务器 ##

根据服务器的性能来查看,50G的数据量要用到4-5个小时

## key\_buffer_size参数作用,如何修改这个参数而不重启数据库 ##

这是MyISAM引擎的缓存数据大小设置,在数据库中设置这个参数,然后再修改配置文件.