---
title: 实例-如何快速找到Datastore内的模板【待补充】
tags:
  - 模板
categories:
  - VMware
date: 2021-08-08 23:36:40
---

# 背景

现有环境中有一套vCenter因特殊原因，无法继续使用。现需要重新搭建一台vCenter，将现有的ESXI全迁移至新的vCenter中。由于迁移过程中，未记录原来环境中的模板，导致模板未在新的vCenter中注册。

# 需求

1. 找到这些模板
2. 将模板注册到vCenter中
3. 将模板迁移至指定目录

# 解决方法

将虚拟机转换成模板时，将创建 .vmtx 文件。.vmtx 文件将替换虚拟机配置文件（.vmx 文件），所以可以搜索一下vmtx文件，即可以找到所有模板机。

```sh
cd /vmfs/volumes/
find -iname ".vmtx"
```




https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.vm_admin.doc/GUID-CEFF6D89-8C19-4143-8C26-4B6D6734D2CB.html