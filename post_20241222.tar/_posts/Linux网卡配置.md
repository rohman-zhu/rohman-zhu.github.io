---
title: Linux网卡配置
date: 2019-01-12 22:12:26
tags: Linux
---

# 环境

* Ubuntu-16.04-Desktop
* CentOS-7-Server

配置静态的IP、DNS。

# Ubuntu-16.04

