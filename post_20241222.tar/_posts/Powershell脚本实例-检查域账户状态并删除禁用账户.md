---
title: Powershell脚本实例-检查域账户状态并删除禁用账户
tags:
  - Powershell
categories:
  - Windows Server
date: 2024-03-31 01:00:28
---
# 需求

目标： 通过WMRM将指令下发至远端服务器，删除该服务器内无效的用户配置（AD账户已被禁用），以释放空间；

1. 获取远端服务器的用户配置信息列表，路径为 C:\Users\；检查目标账户是否为停用状态；
2. 若为停用状态的账户，则下发指令删除配置文件；

# 脚本思路

1. 向远端获取该服务器的用户列表 : Get-ChildItem -Path "C:\Users";
2. 判断账户是否停用: $USER_INFOS=net user $TARGET_USERNAME /domain;$USER_INFOS[7] - match "No";
3. 删除用户配置；

# 脚本实例

```ps1
# Date : 2024-3-30
# Version : v1
#requires -RunAsAdministrator

# Global veriable
$DOMAIN="";
$TARGETSERVER_LIST=$args[0];
$WINRM_PORT="";
if($null -eq $PSCREDENTIAL){$PSCREDENTIAL=Get-Credential;}

# Function Delete user profile
Function Start-DelUserProfile{
    param($TARGET_USERNAME,$TARGET_SERVER_PSSESSION);

    $DELUSERPROFILE_BLOCK={
        param($TARGET_USERNAME,$DOMAIN);
        # get user SID
        $USER_SID = (New-Object Security.Principal.NTAccount($DOMAIN, $TARGET_USERNAME)).Translate([Security.Principal.SecurityIdentifier]).Value;

        Get-WmiObject -ClassName Win32_UserProfile -Filter "SID='$USER_SID'" |
        ForEach-Object {
            $_.Delete();
            Write-Host "$TARGET_USERNAME 's profile dir has been deleted."
        }   
    }

    Invoke-Command -Session $TARGET_SERVER_PSSESSION -ScriptBlock $DELUSERPROFILE_BLOCK -ArgumentList $TARGET_USERNAME,$DOMAIN;


}


# Check target user status;
Function Start-CheckUserStatus{
    param($TARGET_USERNAME,$TARGET_SERVER_PSSESSION);
    
    # Check on localfile
    $LOCAL_STATUS="NULL";
    ## Disabled user file check.
    $ISVALID=Get-Content disabled-user.list | Where-Object {$_ -like "$TARGET_USERNAME"};
    if($null -eq $ISVALID){
        Write-Host "Target user : $TARGET_USERNAME , cannot be found on disbaled-user.list.";
    }else{
        Write-Host "Target user : $TARGET_USERNAME , was been found on disbaled-user.list.";
        $LOCAL_STATUS="DISABLED";
        Start-DelUserProfile $TARGET_USERNAME $TARGET_SERVER_PSSESSION;

    }

    $ISVALID=Get-Content enabled-user.list | Where-Object {$_ -like "$TARGET_USERNAME"};
    if($null -eq $ISVALID){
        Write-Host "Target user : $TARGET_USERNAME , cannot be found on enabled-user.list.";
    }else{
        Write-Host "Target user : $TARGET_USERNAME , was been found on enabled-user.list.";
        $LOCAL_STATUS="ENABLED";
    }

    if("NULL" -match $LOCAL_STATUS){
        $TARGET_USER_STATUS=$(net user $TARGET_USERNAME /domain);
        if($TARGET_USER_STATUS[7] -match "Yes"){
            Add-Content enabled-user.list $TARGET_USERNAME;
            Write-Host "Target user : $TARGET_USERNAME was enabled , add to enabled-user.list."
        }elseif($TARGET_USER_STATUS[7] -match "No"){
            Add-Content disbaled-user.list $TARGET_USERNAME;
            Write-Host "Target user : $TARGET_USERNAME was disabled , add to disabled-user.list."
            Start-DelUserProfile $TARGET_USERNAME $TARGET_SERVER_PSSESSION;
        }
    }
}

# Start current mission
Function Start-InvokeDelUserProfil{
    param($TARGETSERVER_LIST_FILE);

    # Init local file
    Add-Content enabled-user.list "";
    Add-Content disabled-user.list "";

    Clear-Content enabled-user.list;
    Clear-Content disbaled-user.list;

    # Start handle
    Get-Content $TARGETSERVER_LIST_FILE | ForEach-Object {
        $TARGET_SERVERNAME=$_.Trim();
        Write-Host "Start handle target server : $TARGET_SERVERNAME . ";

        $TARGET_SERVER_PSSESSION=New-PSSession -ComputerName $TARGET_SERVERNAME -Port $WINRM_PORT -Credential $PSCREDENTIAL;
        $TARGET_USER_SET=Invoke-Command -Session $TARGET_SERVER_PSSESSION -ScriptBlock {Get-ChildItem "C:\Users"};

        for($i = 0 ;$i -lt $TARGET_USER_SET.Length ; $i++){
            $TARGET_USERNAME=$TARGET_USER_SET[$i].Name;
            Start-CheckUserStatus $TARGET_USERNAME $TARGET_SERVER_PSSESSION;
        }

    }

    # Archive user list;
    $TIMESPAN=Get-Date -Format "yyyyMMdd-HHmm";
    Rename-Item enabled-user.list enabeld-user-$TIMESPAN.list;
    Rename-Item disbaled-user.list disabled-user-$TIMESPAN.list;
} 

Start-InvokeDelUserProfil $TARGETSERVER_LIST;


```

# 参考资料

删除配置文件：https://blog.vichamp.com/2017/12/27/deleting-user-profiles/#:~:text=%E4%BB%A5%E4%B8%8B%E6%98%AF%E4%BD%BF%E7%94%A8%E6%96%B9%E6%B3%95%EF%BC%9A%20%E9%A6%96%E5%85%88%EF%BC%8C%E8%B0%83%E6%95%B4%20%24domain%20%E5%92%8C%20%24username,%E5%8F%98%E9%87%8F%E6%8C%87%E5%90%91%E6%82%A8%E6%83%B3%E5%88%A0%E9%99%A4%E7%9A%84%E7%94%A8%E6%88%B7%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6%E3%80%82%20%E7%84%B6%E5%90%8E%EF%BC%8C%E5%9C%A8%20PowerShell%20%E4%B8%AD%E4%BB%A5%E7%AE%A1%E7%90%86%E5%91%98%E7%89%B9%E6%9D%83%E8%BF%90%E8%A1%8C%E4%BB%A5%E4%B8%8B%E4%BB%A3%E7%A0%81%EF%BC%9A%20123456789101112