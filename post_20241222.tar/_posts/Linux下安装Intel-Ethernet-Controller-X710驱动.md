---
title: Linux下安装Intel Ethernet Controller X710驱动
tags:
  - 服务器
  - Linux
categories:
  - 服务器与存储
  - 服务器
date: 2024-02-05 00:20:29
---

# 故障现象

Linux中无法识别到X710的网卡，使用 lspci 指令可以看到目标网卡可以在系统中识别到，但是无法直接使用用 ip ad无法看到对应端口。因此是驱动问题，需要手动安装驱动。

# 解决方法

```sh
# 查看原版驱动
lspci | grep net
# 可以看到所有网卡信息

# 下载驱动
https://www.intel.cn/content/www/cn/zh/download/18026/intel-network-adapter-driver-for-pcie-40-gigabit-ethernet-network-connections-under-linux.html?wapkw=Intel(R)%20Ethernet%20Controller%20X710

# 解压驱动包
tar vxf i40e-2.22.18.tar.gz
# 进入src目录
cd i40e-2.22.18/src/
# 安装
make install
# 更新内核文件
modinfo i40e
# 重启
reboot
# 检查驱动
ethtool -i [对应网口]
```

# 参考资料

https://www.cnblogs.com/xujiecnblogs/p/17401832.html
