---
title: Linux文件系统
date: 2017-10-04 04:19:07
tags: Linux
---


```
$ ls -lhi

2834587 -rw-r--r--    1 r0man  staff   1.7K 10  1 20:03 _config.yml
7364288 -rw-r--r--    1 r0man  staff   174B 10  4 04:19 db.json
2823389 drwxr-xr-x  436 r0man  staff    14K 10  1 20:00 node_modules
7372948 -rw-r--r--    1 r0man  staff   631B 10  1 20:00 package.json

```

### 第一列 ###
> -i 表示显示INODE


inode(index node)为索引节点。它是文件或者目录，在c磁盘里的唯一标识，linux读取文件首先要读取到这个索引节点。

### 第二列 ###

第一个字符表示文件类型，普通文件为 '-' ， 目录为'd' 。


后面九个字符代表文件权限 ， （r（read） w（write） x（执行） -）

第11个字符'.' ,是跟seLinux相关的 ， 当seLinux开启的时候才会出现。

```
$ 查看selinux的状态
$ getenforce
```

### 第三列 ###

文件的硬链接数；硬链接是文件一个入口，就像硬盘挂载上，可以访问。

### 第四列 ###
属主或用户 （Usr）
<br/>
对应权限位第2到第4为 用户权限位。

### 第五列 ###
文件对应的属组或用户组。（Group）
<br/>
对应权限位第5到第7为 属组权限位。

### 第六列 ###
表示文件或者目录的大小

### 第 七 ，八，九 列 ###
表示文件被改动的时间

### 第十列 ###
表示文件或者目录的名字


## 文件的INODE标识 ##
磁盘被格式化后，会被分成两个部分，分别是Inode 与 Block 。
<br/>

Inode存放的是文件的属性信息，还有指向功能，唯独不包含文件名字；Block是用于存放数据的。
<br/>

Block的大小一般有1k，2k，4k几种，其中引导分区为1k，其他普通分区4k。

- 一个文件可能占用多个block，每读取一个block就会消耗一次磁盘I/O。
- 如果要提升IO性能，那么尽可能一次性读取尽量多的数据。
- block的色织也是在格式化分区的时候，mkfs.ext4 -b 2048 -l 256 /dev/sdb


<br/>

Inode是一串数字，不同的文件对应的inode在文件系统中是唯一的。
<br/>



查看Inode大小
```
$ dumpe2fs /dev/sda3 | grep -i "Inode size"

Inode       256
```
通过该命令查找这，默认单位是字节。

> -i 表示忽略匹配样式中的字符大小写。

> dumpe2fs 用于查看格式化后的磁盘信息的。

<br/>
也可以通过df命令来查看挂载的磁盘inode情况。

```
$ df -i
```

> df命令用于显示磁盘分区上的可使用的磁盘空间。默认显示单位为KB。可以利用该命令来获取硬盘被占用了多少空间，目前还剩下多少空间等信息。
 
## Linux 文件类型 ##
1. 纯文本（ASCII）：文件内容可以直接读取到数据。
2. 二进制文件（binary），linux可执行文件（命令）就属于这种格式。
3. 数据格式的文件（data），有些程序在运行的过程会读取某些特定格式的文件。

```
$ 查看文件类型
$ file /etc/hosts
```

-type指令参数
```
-type c
    File is of type c :
    b block(buffered) special 块设备
    c character (unbuffered ) special 字符设备
    d directory 目录
    p name pipe (FIFO) 
    f regular file (-) 普通文件
    l symbolic link 符号链接
    s 套接字

```

## 各类时间戳 ##

* Access ： 访问时间 -atime
* Modify ： 修改时间 ， 内容发生变化 -mtime
* Change ： 变化时间 ， 包含Modify ， 权限、属主 、 用户组 find

> ls -l --time-style=long-iso 显示的是修改时间

 