---
title: Ubuntu无法进入OS
tags:
  - 故障
categories:
  - Linux
date: 2022-11-13 23:41:20
---

# 故障描述

一台Ubuntu 14.04 服务器的Zabbix-Agent故障，在log日志中看到异常，重启Zabbix-Agent也无效；于是决定重启服务器OS，但是服务器发起重启后，竟然无法启动操作系统了。

- 服务器常规启动，加载完grub菜单后就黑屏；但是服务器可以ping通；
- 服务器选择高级选项，选择常规内核，会出现Loading initial ramdisk... ，然后卡住；但是服务器可以ping通；
- 服务器选择高级选项，选择常规内核（恢复模式），会出现"Staring NETBIOS name server [OK]"，然后卡住；但是服务器可以ping通；

# 原因分析

1. Linux OS的自启服务导致启动进程卡住；
2. fstab有异常参数，导致加载异常；

# 解决方法

两种原因均需要进入单用户模式修改配置，按照常规的方法应该是无法进入单用户模式的，修改完毕后就黑屏；
我是修改恢复模式的加载项，即选择高级菜单，恢复模式，按e进入编辑；

```grub
把ro recovery删除，换成熟悉的 rw init=/bin/bash

按 Ctrl + x 启动；
```

## 原因1

如果是因为服务卡住，可以进入 /etc/init/ 目录下，将对应的服务配置先重命名；

如：

```sh
mv /etc/init/samba-ad-dc.conf /etc/init/samba-ad-dc.conf-bak
```

可惜本次故障不是这个原因导致的，接着排查。

## 原因2

怀疑是fstab有些异常参数导致的故障，检查fstab关于根目录的描述是这样的：

```sh
# 设备名称　　　挂载点　　分区的类型　　挂载选项　　dump选项　　fsck选项
# 故障现场的是这样的：
[设备] / ext4 errors=remount-ro,usrquota,grpquota 0 1

# 我一般的设置是这样的：
[设备]  / ext4 defaults 0 1
```

```sh
# 关于 errors=remount-ro
常规设置有三个参数
errors={continue|remount-ro|panic}

这个是在挂载遇到错误时有三种处理方式：
1. 忽略错误，继续挂载；
2. 重新挂载，改为只读模式；
3. 取消挂载，报系统错误，即panic态；

# 状态1：这种状况一般都是因为系统发现磁盘硬件故障或文件系统中文件被损坏以后而采起的保护机制致使的。为了保护数据不破坏分区中已有内容，Linux在挂载文件系统时就只用read-only只读方式加载了。
# 如：
# 1.系统文件损坏；  
# 2. 磁盘有坏道；  
# 3. fstab文件配置错误，如分区格式错误错误(将ntfs写成了fat)、配置指令拼写错误等。

# 常用的挂载选项
# auto/noauto：默认auto支持；是否支持系统自动挂载，是否支持-a选项
# user/nouser：默认nouser不支持；是否支持普通用户挂载此设备
# ro：按制度权限挂载
# rw：按可读可写权限挂载
# pri：swap设备需要指定优先级
# defaults：默认支持rw，nouid，dev，auto，nosuer，async（若不写入则默认支持

# dump选项，设置是否让备份程序备份文件系统，0为不备份，1为每天次，如果上次是用dump备份，将显示备份至今的天数

# fsck选项：告诉系统是否检查分区，0为不校验，大于0表示需要校验；1为优先校验，2位次级校验（也就是在1校验后再进行校验）
```
