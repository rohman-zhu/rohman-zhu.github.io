---
title: Shell脚本逐行读取文本
date: 2020-01-04 01:05:59
tags:
- Shell
catergories:
- Linux
---

# 前言

逐行读取文本是一个常用的操作，可以通过 for 或者 while 语句来实现。

## 方法一：cat & while

```sh
cat DEMO.txt | while read line
do
    echo $line
done
```

## 方法二： while

```sh
while read line
do
    echo $line
done < DEMO.txt
```

## 方法三： for & cat

```sh
for line in `cat DEMO.txt`
do
    echo $line
done
```

> 注意： 这个方法是逐个元素输出，而不是逐行输出。

## 参考资料

https://www.cnblogs.com/iloveyoucc/archive/2012/07/10/2585529.html