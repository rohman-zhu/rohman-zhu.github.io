---
title: vSphere安全性
tags:
  - 信息安全
categories:
  - VMware
  - vSphere
date: 2021-11-07 23:08:08
---
# 参考资料

https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere.security.doc/GUID-52188148-C579-4F6A-8335-CFBCE0DD2167.html