---
title: VCSA-503故障-证书到期
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2023-07-30 17:39:17
---

# 故障现象

1. 登录vCenter的WEB界面，提示503报错；
2. 登录vCenter的管理界面(https://VC-IP:5480)，提示服务异常；

# 原因分析

1. 证书过期后未及时更新，导致服务异常；

## 检查方式1

登录vCenter的web界面，点击证书详情，可以看到证书到期时间；

## 检查方式2

```sh
# 检查指令
for store in $(/usr/lib/vmware-vmafd/bin/vecs-cli store list | grep -v TRUSTED_ROOT_CRLS); do echo "[*] Store :" $store; /usr/lib/vmware-vmafd/bin/vecs-cli entry list --store $store --text | grep -ie "Alias" -ie "Not After";done;
```

# 解决方法

注意，以下操作执行前，请给VCSA虚拟机执行快照！！

另外需关闭HA功能

```sh
vcha-destroy -f
```

启动必要服务

```sh
#检查服务启动情况：
service-control --status
#手动启动服务：
service-control --start applmgmtd
service-control --start vmafdd
```

## STS证书过期

Center Single Sign-On Security Token Service (STS) 签名证书是内部 VMware 证书；

```sh
# 创建目录
mkdir newsts
cd newsts
pwd 
#resulting output: /root/newst

# 将 certool.cfg 文件复制到新目录中
cp /usr/lib/vmware-vmca/share/config/certool.cfg /root/newsts

# 打开 certool.cfg 文件的副本并进行编辑，以便使用本地 Platform Services Controller 的 IP 地址和主机名。
vim certool.cfg
# Template file for a CSR request
#
# Country is needed and has to be 2 characters
Country = US
Name = STS
Organization = ExampleInc
OrgUnit = ExampleInc Dev
State = Indiana
Locality = Indianapolis
IPAddress = 10.0.1.32
Email = chen@exampleinc.com
Hostname = homecenter.exampleinc.local

# 生成密钥
/usr/lib/vmware-vmca/bin/certool --server localhost --genkey --privkey=/root/newsts/sts.key --pubkey=/root/newsts/sts.pub

# 生成证书
/usr/lib/vmware-vmca/bin/certool --gencert --cert=/root/newsts/newsts.cer --privkey=/root/newsts/sts.key --config=/root/newsts/certool.cfg

# 将证书转成pk12格式
openssl pkcs12 -export -in /root/newsts/newsts.cer -inkey /root/newsts/sts.key -certfile /var/lib/vmware/vmca/root.cer -name "newstssigning" -passout pass:testpassword -out newsts.p12

# 将证书添加到JAVA密钥库
/usr/java/jre-vmware/bin/keytool -v -importkeystore -srckeystore newsts.p12 -srcstoretype pkcs12 -srcstorepass testpassword -srcalias newstssigning -destkeystore root-trust.jks -deststoretype JKS -deststorepass testpassword -destkeypass testpassword

/usr/java/jre-vmware/bin/keytool -v -importcert -keystore root-trust.jks -deststoretype JKS -storepass testpassword -keypass testpassword -file /var/lib/vmware/vmca/root.cer -alias root-ca
# 出现提示时，键入 Yes 接受证书以将其添加到密钥库。

```

## 根证书替换

需要先获取：
1. administrator@vsphere.local密码
2. VCSA的FQDN；

```sh
# 生成脚本路径：
# LINUX版本的VCSA：/usr/lib/vmware-vmca/bin/certificate-manager
# WINDOWS版本的VCSA：C:\Program Files\VMware\vCenter Server\vmcad\certificate-manager.bat

# 选择4,Regenerate a new VMCA Root Certificate and replace all certificates。

# 根据提示，输入指定信息

# 重启服务
service-control --stop --all
service-control --start vmafdd
service-control --start vmdird
service-control --start vmcad
service-control --start --all


```

## 更换方式2，全部证书重置

> 2024-08-16

需要先获取：
1. administrator@vsphere.local密码
2. VCSA的FQDN；
3. 获取VCSA的FQDN、VCSA的hostname；

```sh
/usr/lib/vmware-vmafd/bin/vmafd-cli get-pnid --server-name localhost
/usr/lib/vmware-vmafd/bin/vecs-cli entry list --store MACHINE_SSL_CERT --text | grep -A1 Alternative
```

```sh
# 生成脚本路径：
# LINUX版本的VCSA：/usr/lib/vmware-vmca/bin/certificate-manager
# WINDOWS版本的VCSA：C:\Program Files\VMware\vCenter Server\vmcad\certificate-manager.bat

# 选择8,Reset all Certificates

# 关键字段！！以下两个字段需要先确认自身的FQDN后填写，不可乱填写
# IPAddress
# FQDN

# 根据提示，输入指定信息

# 重启服务
service-control --stop --all
service-control --start vmafdd
service-control --start vmdird
service-control --start vmcad
service-control --start --all
```

# 后续待办

1. 【高优先级】证书监控；
2. 证书自动续签；

# 参考资料

检查证书：https://kb.vmware.com/s/article/82332
503报错相关处理步骤：https://kb.vmware.com/s/article/67818?lang=zh_cn
更换STS证书：https://docs.vmware.com/cn/VMware-vSphere/6.7/com.vmware.psc.doc/GUID-497233EA-AEF9-464B-A9C3-CCAEEA90C801.html#:~:text=%E7%94%B1%E4%BA%8E%20vCenter%20Single%20Sign-On%20Security%20Token%20Service%20%28STS%29,%E7%AD%BE%E5%90%8D%E8%AF%81%E4%B9%A6%E6%98%AF%E5%86%85%E9%83%A8%20VMware%20%E8%AF%81%E4%B9%A6%EF%BC%8C%E5%9B%A0%E6%AD%A4%E8%AF%B7%E5%8B%BF%E6%9B%BF%E6%8D%A2%E5%AE%83%EF%BC%8C%E9%99%A4%E9%9D%9E%E8%B4%B5%E5%85%AC%E5%8F%B8%E8%A6%81%E6%B1%82%E6%9B%BF%E6%8D%A2%E5%86%85%E9%83%A8%E8%AF%81%E4%B9%A6%E3%80%82%20%E5%A6%82%E6%9E%9C%E8%A6%81%E6%9B%BF%E6%8D%A2%E9%BB%98%E8%AE%A4%E7%9A%84%20STS%20%E7%AD%BE%E5%90%8D%E8%AF%81%E4%B9%A6%EF%BC%8C%E5%BF%85%E9%A1%BB%E7%94%9F%E6%88%90%E4%B8%80%E4%B8%AA%E6%96%B0%E8%AF%81%E4%B9%A6%E5%B9%B6%E5%B0%86%E5%85%B6%E6%B7%BB%E5%8A%A0%E5%88%B0%20Java%20%E5%AF%86%E9%92%A5%E5%BA%93%E3%80%82
重新生成新的VMCA根证书并替换所有证书：https://docs.vmware.com/cn/VMware-vSphere/6.7/com.vmware.psc.doc/GUID-D944C044-B682-4427-90F8-55B8770F21AF.html
自动替换VCSA证书：https://kb.vmware.com/s/article/2112281?lang=zh_cn
STS证书处理KB：https://kb.vmware.com/s/article/79248?lang=zh_cn
vCenter使用VMCA续订证书：续订证书时发生意外错误：https://www.dinghui.org/vcenter-vmca-machine-cert.html
VCSA 7.0 证书过期后的修复工作：https://ngx.hk/2023/01/10/vcsa-7-0%e8%af%81%e4%b9%a6%e8%bf%87%e6%9c%9f%e5%90%8e%e7%9a%84%e4%bf%ae%e5%a4%8d%e5%b7%a5%e4%bd%9c.html