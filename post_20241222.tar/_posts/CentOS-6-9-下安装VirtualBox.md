---
title: CentOS_6.9_下安装VirtualBox
date: 2017-11-05 13:52:02
tags: Linux
---
# Linux\_CentOS_6.9安装VirtualBox #

## 1.安装VirtualBox ##

### 1.0 安装相关的环境与内核 ###

```{.Linux}
# yum groupinstall "Development Tools"
# yum install kernel-devel
#yum install qt qt-x11
```

> Qt是一个1991年由Qt Company开发的跨平台C++图形用户界面应用程序开发框架.

### 1.1下载VirtualBox的rpm包 ###

官网 `https://www.virtualbox.org/wiki/Downloads`

### 1.2开始安装VirtualBox\ ###

```{.Linux}
# yum install VirtualBox-4.3-4.3.26_98988_el7-1.x86_64.rpm
```

## 2.在VirtualBox安装Centos_Minimal ##

现在6.9的版本,主要分分为LiveDVD,BinDvD,MinimalDvD三种版本

* LiveDVD是带有可以体验的系统,一般已经集成了相关的软件,如搜狐浏览器,rsync等.
* BinDvD是普通安装版，需安装到计算机硬盘才能用，bin一般都比较大，而且包含大量的常用软件，安装时无需再在线下载（大部分情况）。
* MinimalDvD这就是一个精简的系统.通常也就几百M.

国内的镜像地址:

China CMCC Taian Branch（泰安移动）
`http://mirrors.ta139.com/centos/`
China NetEase（163网易）
`http://mirrors.163.com/centos/`
China Northeastern University, Shenyang Liaoni（东北大学）
`http://mirror.neu.edu.cn/centos/`
China Sohu Inc, Beijing P.R. China（搜狐CentOS镜像）
`http://mirrors.sohu.com/centos/`
China Star Studio of UESTC（电子科技大)
`http://mirrors.stuhome.net/centos/`
China University of Science and Tech of China（中科大）
`http://centos.ustc.edu.cn/centos/`

### 2.1 安装过程中需要注意的问题 ###

* Disc Found 检查镜像的时候跳过.
* 注意给/boot,swap分区分配适当的空间.

### 2.2 网卡配置 ###

这里出现了一点点小问题:

1. 网络采用NAT的方式,物理机不能跟虚拟机互相ping通.
1. 网络采用桥接模式,没有选择好对应桥接的网卡,导致不能ping通局域网内的机器.
1. 虚拟机采用带链接的复制方式,网卡没有初始化,导致不能配置网络.

#### 问题一 ####

未解决 -.-

#### 问题二 ####

物理机上面有多块网卡(eth0,enp7s0...),只有enp7s0连接着局域网,所以就需要通过桥接该网卡,这里要通过虚拟机的配置来实现.

#### 问题三 ####

由于在复制虚拟机的时候,没有初始网卡,所以复制完的虚拟机,MAC地址都跟前面的机器一样,所以一定要勾选上初始网卡.

查看本机的网卡,可以查看 /etc/udev/rules.d/70-persistent-net.rules 文件里面的信息.

### 2.3系统优化 ###

1. 修改ssh的端口号(22),位置/etc/sshd/config
1. 禁止其他机器ping通 , 位置/etc/sysctl.conf(net.ipv4.icmp_echo_ignore_all=1)
1. 修改默认启动界面提示信息,位置 /etc/issue
1. 修改shell登陆信息,位置/etc/motd
1. 移动并锁住相关的命令文件,如rm指令由原来的/bin/rm移到其他地方.(chattr)

### 2.4 查看相关资源利用 ###

#### 2.4.1 CPU ####

lscpu

cat /proc/cpuinfo

#### 2.4.2 内存 ####

free -m

cat /proc/meminfo

#### 2.4.3硬盘分布情况 ####

lsblk

fdisk