---
title: ESXi-无法通过OVF创建虚拟机-提示只有管理此主机的服务器XX.XX.XX.XX才能访问此主机的资源设置
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2024-07-07 16:21:10
---

# 故障描述

登录ESXi后，无法通过OVF部署虚拟机，会提示“失败-只有管理此主机的服务器‘vCenter IP’才能访问此主机上的资源设置”。

# 原因分析

该ESXi已被vCenter接管，无法通过此ESXi去创建虚拟机，而需要通过vCenter部署虚拟机。

# 解决方法

核心就是先暂停ESXi与vCenter之间的通讯，可以参照以下方法：

1. 登录vCenter，选中目标ESXi，选择断开连接；
2. 登录目标ESXi，选择通过OVF部署。

