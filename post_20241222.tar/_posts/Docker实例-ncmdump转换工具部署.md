---
title: Docker实例-ncmdump转换工具部署
tags:
  - default
categories:
  - Docker
date: 2024-10-05 21:40:40
---

# 需求背景描述

网易云音乐是ncm格式的，目前Github上面有开源的项目，可以转换ncm文件为mp3格式，项目地址 https://github.com/taurusxin/ncmdump

编译出一个ncmdump文件，是一个可执行文件，指令为

```sh
ncmdump -v

ncmdump -d source_dir

ncmdump -d source_dir -r

# 处理单个或多个文件并输出到指定目录
ncmdump 1.ncm 2.ncm -o output_dir

# 处理文件夹下的所有以 ncm 为扩展名并输出到指定目录，不包含子文件夹
ncmdump -d source_dir -o output_dir

# 递归处理文件夹并输出到指定目录，并保留目录结构
ncmdump -d source_dir -o output_dir -r
```

## 编译ncmdump文件

需要有git指令与编译环境所需的环境，指令为 git ， cmake

```sh
# 克隆仓库
git clone https://github.com/taurusxin/ncmdump.git

# 更新子模块
cd ncmdump
git submodule update --init --recursive

# CMake编译
# Linux / macOS
cmake -DCMAKE_BUILD_TYPE=Release -B build


# Windows MinGW / Linux / macOS
cmake --build build -j 8

# 编译完后会产生ncmdump
# 可以拷贝到 /bin 目录下面
```

## 转成Docker形式

因为 ncmdump 是需要一个OS环境处理的，想到可以弄成Docker，分为两个路径 ，分别是原文件的 orgin_file ， 转化后的文件 convert_file 文件夹；

```sh
# 获取 ubuntu 20.04 的镜像
docker pull dockerproxy.cn/ubuntu:20.04

# 创建 ubuntu 20.04 的容器
docker run -it --name ncmdump dockerproxy.cn/ubuntu:20.04

# 将 ncmdump 放入容器
docker cp ./ncmdump ncmdump:/bin/

# 连接 docker
docker exec -it ncmdump /bin/bash

## 进入docker
# 赋予ncmdump执行权限
chmod +x /bin/ncmdump

# 安装cron自动执行脚本
apt-get update
apt-get install cron

# 编辑自动执行的脚本
crontab -e
```

将ncm的文件放入 orgin_file ， 转化后的文件即可放置到 convert_file ；

