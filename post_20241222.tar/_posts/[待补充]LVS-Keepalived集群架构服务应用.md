---
title: LVS&Keepalived集群架构服务应用
date: 2017-11-23 08:32:22
tags: Linux
---
# LVS & Keepalive #

`http://www.linuxvirtualserver.org/zh/`

## 相关名词 ##

| 名称 | 备注 |
|:---:|:----:|
|Virtual IP Address | |
|Real Server IP Address | 在集群下面节点上使用的IP地址,物理IP地址 |
|Director IP Address | 用于连接内网的IP地址,实际为物理网卡的IP地址|
| Client IP Address | 客户端用户计算机请求集群服务器的IP地址 |

## LVS ##

Linux Virtual Server

> 使用软件配置LVS时,不能直接配置内核中的ipvs,而是需要管理工具ipvsadm进行管理.

小结笔记:

1. 实现负载调度的工具是IPVS,工作在LINUX内核层面
1. LVS自带的IPVS管理工具是ipvsadm
1. keepalived实现管理IPVS以及对负载均衡器的高可用.
1. RedHat工具Piranha_Web管理实现调度的工具IPVS

## LVS 集群的三种模式 ##

### ARP协议 ###

Address Resolution Protocol , 地址解析协议,使用ARP协议可实现通过IP地址获得对应主机的物理地址(MAC).

32位的IP地址 --> 48位的MAC地址

> ARP协议不需要配置服务
> ARP协议要求通信的主机双方必须在同一个物理网段
> ARP是第三层协议(OSI)

### 查询ARP ###

#### Windows下 ####

```cmd
# arp -a 查询所有缓存表
# arp -d 清除ARP缓存表
# arp -s 绑定ARP
```

#### Linux下 ####

```sh
# -c 次数 -s 源
/sbin/arping -I eth0 -c 3 -s 10.0.0.162 10.0.0.253
/sbin/arping -U -I eth0 10.0.0.162
NAME arping -send ARP REQUEST to a neighbour host
SYNOPSIS arping [-c count][-w dead-line][-s source] -I interface destination
```

#### ARP 缓存表是一把双刃剑 ####

1. 主机有了ARP缓存表,可以加快ARP的解析速度,减少局域网内广播风暴.
1. 正时游了ARP缓存表,给恶意黑客带来了共计服务器主机的风险,这就是ARP欺骗攻击.
1. 切换路由器,负载均衡器等设备时,可能会导致网络中断.

##### 如何无缝添加新的路由器 #####

要求:

1. 旧的配置导入新的配置里面.
1. arping 指定客户端所有ARP缓存表.
1. 切换路由器,负载均衡器等设备时,可以能会导致网络中断.

##### ARP的相关问题 ######

1. ARP病毒,ARP欺骗
1. 高可用服务器之间切换时要考虑ARP缓存问题
1. 路由器等设备无缝迁移时要考虑ARP缓存问题

### VS/NAT ###

Virtual Server via Network Address Translation

> 入站DNAT,出站SANT,入站出站都经过LVS,可以修改端口.

### VS/DR ###

Virtual Server via Direct Routing(直接路由)

主要特征:

* LVS只负责入站请求

#### 原理 ####

1. 通过更改数据包的目标MAC地址实现数据包转发.
1. 所有节点和LVS要处于一个局域网.

> 修改数据包的目的MAC地址,入站经过LVS,出站不经过LVS,直接返回给客户,不能改端口,LAN内使用

### TUN ###

IP Tunneling

原理:

1. 负载均衡通过把请求的报文通过IP隧道的方式转发至真实服务器,而真实服务器将响应处理后返回客户端用户.(请求报文不经过原目的地址的改写(包括MAC),直接封装成另外的IP报文)
1. 由于真实服务器将响应处理后的报文直接返回给客户端用户,因此,最好RSYNC有一个外网IP地址.

> 不改变数据包内容,数据包外部封装一个IP头,入站经过LVS,出站不经过LVS,直接返回客户,不能改端口,LAN/WAN使用

### FULLNAT ###

Full Network Address Translation

### LVS调度算法 ###

固定调度算法: rr , wrr , dh , sh
动态调度算法:

* wlc (Weighted Least-Connection 加权最小连接数调度)
* lc (Least-Connection 最小连接数调度)
* lblc (Locality-Based Least-Connection 基于地址的最小连接调度)
* lblcr(Locality-Based Least-Connection with Replication 基于地址带重复最小连接数调度)

> 一般网络服务(类似Http/Mail/MySQL等)常用的调度LVS算法为:rr,wlc,wrr

### 实际安装 ###

注意:

1. Centos5.x 使用1.24版本
1. Centos6.x 使用1.26版本
1. 提前安装 : yum install libnl* popt* -y
1. 安装完后,执行ipvsadm(modprobe ip\_vs)把ip\_vs模块加载到内核
