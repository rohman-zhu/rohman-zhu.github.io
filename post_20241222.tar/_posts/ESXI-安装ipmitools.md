---
title: ESXI 安装ipmitools
tags:
  - ipmi
categories:
  - VMware
  - vSphere
date: 2024-02-05 00:12:25
---

# 下载ipmitool-esxi-vib软件

https://vswitchzero.files.wordpress.com/2019/08/ipmitool-esxi-vib-1.8.11-2.zip

```sh
# MD5值核验
ipmitool-esxi-vib-1.8.11-2.zip = 444af4ce1dc68418583dba2926093980
ipmitool-1.8.11-2-offline_bundle.zip = 44cb77cc8bd7f969b8e74eb33aec8d71
ipmitool-1.8.11-2.x86_64.vib = 173db5b9f205d9c10d9458ff76d8954b
```

# 上传VIB文件并安装

```sh
# 修改安装许可级别
esxcli software acceptance set --level=CommunitySupported

# 安装软件
esxcli software vib install -v /tmp/ipmitool-1.8.11-2.x86_64.vib

# 执行ipmitool指令
/opt/ipmitool/ipmitool

# 卸载ipmitool指令
esxcli software vib remove -n ipmitool
```

# 参考资料

https://vswitchzero.com/ipmitool-vib/