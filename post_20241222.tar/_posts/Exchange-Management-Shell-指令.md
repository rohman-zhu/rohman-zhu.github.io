---
title: Exchange Management Shell 指令
tags:
  - Exchange
catergories:
  - Windows Server
date: 2020-03-01 23:21:53
---

# Move-ActiveMailboxDatabase

```ps1
# Example 1:
Move-ActiveMailboxDatabase -Server MBX1

# This example performs a server switchover for the Mailbox server MBX1. All active mailbox database copies on MBX1 will be activated on one or more other Mailbox servers with healthy copies of the active databases on MBX1.
```

参考： https://docs.microsoft.com/en-us/powershell/module/exchange/database-availability-groups/move-activemailboxdatabase?view=exchange-ps

# Get-MailboxDatabaseCopyStatus

Use the Get-MailboxDatabaseCopyStatus cmdlet to view health and status information about one or more mailbox database copies.

参考：https://docs.microsoft.com/en-us/powershell/module/exchange/database-availability-groups/get-mailboxdatabasecopystatus?view=exchange-ps

# Test-ServerHealth

Use the Test-ServiceHealth cmdlet to test whether all the Microsoft Windows services that Exchange requires on a server have started. The Test-ServiceHealth cmdlet returns an error for any service required by a configured role when the service is set to start automatically and isn't currently running.

参考：https://docs.microsoft.com/en-us/powershell/module/exchange/server-health-and-performance/test-servicehealth

# Test-MAPIConnectivity

Use the Test-MapiConnectivity cmdlet to verify server functionality by logging on to the mailbox that you specify. If you don't specify a mailbox, the cmdlet logs on to the SystemMailbox on the database that you specify.

参考：https://docs.microsoft.com/en-us/powershell/module/exchange/mailboxes/test-mapiconnectivity?view=exchange-ps

# Get-ExchangeServer

Use the Get-ExchangeServer cmdlet to view the properties of Exchange servers.

```ps1
Get-ExchangeServer | ft Name,Edition,AdminDisplayVersion

# Exchange CU23 (Cumulative Updates 23),Version is 15.0.0.1497.002
# https://www.microsoft.com/en-us/download/details.aspx?id=58392
# Require： DotNet4.7.2
```

参考：https://docs.microsoft.com/en-us/powershell/module/exchange/organization/Get-ExchangeServer