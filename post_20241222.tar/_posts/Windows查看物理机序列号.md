---
title: Windows查看物理机序列号
tags:
  - default
categories:
  - Windows Server
date: 2021-06-20 23:25:06
---

# 说明

需要查看服务器序列号

## 指令

```sh
wmic bios get serialnumber
```

## 参考资料

https://www.sneppets.com/software/wmic-exe-is-not-recognized-as-an-internal-or-external-command-operable-program-or-batch-file/

https://blog.csdn.net/discover2210212455/article/details/82711930