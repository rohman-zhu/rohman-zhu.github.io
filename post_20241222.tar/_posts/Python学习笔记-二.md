---
title: Python学习笔记(二)
date: 2017-11-18 17:54:04
tags: Python
---
# Python 学习 #

## 对集合的操作 ##

### 切片Slice ###

```python
# 一个集合L中有[1,2,3,4,5]这些元素,现在要把2与3取出来
L[1:4]
#L[n:z] 数组的下标从0开始的,这里表示取了第n个元素,到z-1个元素
```

> Python支持L[-1]取倒数第一个元素，那么它同样支持倒数切片

```python
#[1,2,3,4,5,6]
>>>L[-2:-4]
[4,5]

#间隔n个来取
L[::n]
```

### 迭代 ###

Python内置的enumerate函数可以把一个list变成索引-元素对，这样就可以在for循环中同时迭代索引和元素本身：

```python
>>>for i,value in enumerate(['A','B','C']):
    print(i,value)
```

通过collections模块的Iterable类型判断一个对象是否为可迭代对象:

```python
>>> from collections import Iterable
>>> isinstance('abc', Iterable) # str是否可迭代
True
>>> isinstance([1,2,3], Iterable) # list是否可迭代
True
>>> isinstance(123, Iterable) # 整数是否可迭代
False
```

### 生成列表 ###

```python
>>>[x*x for x in range(1,11)]
[1,4,9,16,25,36,49,64,81,100]
>>>[x*x for x in range(1,11) if x%2 == 0]
[4,46,64,100]
>>>[m + n for m in 'ABC' for n in 'XYZ']
['AX','AY','AZ','BX','BY','BZ','CX','CY','CZ']
>>>d = {'x':'A','y':'B','z':'C'}
>>>for k , v in d.items()
    print(k,'=',v)
y=B
x=A
z=C
>>>#列表生产式也可以使用两个变量来生成list
>>>d={'X':'A','Y':'B','Z':'C'}
>>>[k+'='+v for k ,v in d.items()]
['Y=B','X=A','Z=C']
>>>#把一个list中所有的字符串都变成小写的:
>>>L = ['Hello','World','Apple']
>>>[s.lower() for s in L]
['hello','world','apple']
```

---

练习:把一个list ['Hello','World',18,'Apple',None]里面的字符串都变成小写的

```python
>>>L=['Hello','World',18,'Apple',None]
>>>[s.lower() for s in L if isinsistance(s,str)]
```

### 生成器generate ###

generate说白了就是省空间的list

```python
>>>#List
>>>L=[x*x for x in range(10)]
>>>#Generate
>>>g=(x*x for x in range(10))
>>>打印用next()函数,很像iterator.next() -.-
>>>next(g)
0
>>>#generator保存的是算法，每次调用next(g)，就计算出g的下一个元素的值，直到计算到最后一个元素，没有更多的元素时，抛出StopIteration的错误。
>>>for n in g:
    print(n)
>>>#一个函数定义中包含yield关键字，那么这个函数就不再是一个普通函数，而是一个generator;

```

---

练习:写一个杨辉三角.

<a href='https://www.liaoxuefeng.com/wiki/0014316089557264a6b348958f449949df42a6d3a2e542c000/0014317799226173f45ce40636141b6abc8424e12b5fb27000'>此处存疑</a>

```python
def triangles():
    a=[1]
    while True:
        yield a
        a=[sum(i) for i in zip([0+a,a+[0]])]
#1
#11
#121
#1331
n=0
results=[]
for t in triangles():
    print(t)
    results.append()
    n+=1
    if n == 10:
        break
results.append()

```

### 迭代器 ###

可以直接作用于for循环的数据类型有以下几种:

* 一类是集合数据类型，如list、tuple、dict、set、str等；
* 一类是generator，包括生成器和带yield的generator function。

## 函数式编程 ##

### map() ###

map()函数接收两个参数，一个是函数，一个是Iterable，map将传入的函数依次作用到序列的每个元素，并把结果作为新的Iterator返回。

```python
>>> list(map(str, [1, 2, 3, 4, 5, 6, 7, 8, 9]))
['1', '2', '3', '4', '5', '6', '7', '8', '9']
```

### reduce() ###

reduce把一个函数作用在一个序列[x1, x2, x3, ...]上，这个函数必须接收两个参数，reduce把结果继续和序列的下一个元素做累积计算，其效果就是：

```python
>>> from functools import reduce
>>> def fn(x, y):
...     return x * 10 + y
...
>>> reduce(fn, [1, 3, 5, 7, 9])
13579
```

### filter() ###

filter()接收一个函数和一个序列,filter()把传入的函数依次作用于每个元素，然后根据返回值是True还是False决定保留还是丢弃该元素。

```python
def is_odd(n):
    return n % 2 == 1

list(filter(is_odd, [1, 2, 4, 5, 6, 9, 10, 15]))
# 结果: [1, 5, 9, 15]
```

### sorted() ###

```python
>>>#sorted()函数也是一个高阶函数，它还可以接收一个key函数来实现自定义的排序，例如按绝对值大小排序：
>>> sorted([36, 5, -12, 9, -21], key=abs)
[5, 9, -12, -21, 36]
```

---

练习:L = [('Bob', 75), ('Adam', 92), ('Bart', 66), ('Lisa', 88)],用sorted()分别对名字和成绩进行排序.

```python
>>>L = [('Bob', 75), ('Adam', 92), ('Bart', 66), ('Lisa', 88)]
>>>sorted(L)
[('Adam', 92), ('Bart', 66), ('Bob', 75), ('Lisa', 88)]

# Sorted by score
def def_num(t):
    return t[1]
L.sort(key=def_num)

# Sorted by name
# Default:
L.sort()
# Defined a function
def def_name(t):
    return t[0]
L.sort(key=def_name)
```

### 返回函数 ###

```python
def lazy_sum(*args):
    def sum():
        ax = 0
        for n in args:
            ax = ax + n
        return ax
    return sum
```

---

闭包:

注意到返回的函数在其定义内部引用了局部变量args，所以，当一个函数返回了一个函数后，其内部的局部变量还被新函数引用，所以，闭包用起来简单，实现起来可不容易。

练习:利用闭包返回一个计数器函数，每次调用它返回递增整数：

```python
def createCounter():
    count = 0
    def counter():
        nonlocal count
        count += 1
        return count
    return counter
# PS: nonlocal是在python3中才可以用,python2.7中没有,解决方法是用列表list来处理
def createCounter():
    count = [0]
    def counter():
        count = count[0] + 1
        return count
    return counter
```

### 匿名函数 ###

关键字lambda表示匿名函数，冒号前面的x表示函数参数。

```python
>>>f = lambda x : x*x
>>>f(5)
25
```

---

练习:用lambda改造下面函数

```python
def is_odd(n):
    return n % 2 == 1

L = list(filter(is_odd, range(1, 20)))

################

L = list(filter(lambda x : x%2 == 1,range(1,20)))
```

### Decorator ###

在代码运行期间动态增加功能的方式，称之为“装饰器”（Decorator）。

<a 'href=https://www.liaoxuefeng.com/wiki/0014316089557264a6b348958f449949df42a6d3a2e542c000/0014318435599930270c0381a3b44db991cd6d858064ac0000'>此处存疑</a>

### Partial function ###

简单总结functools.partial的作用就是，把一个函数的某些参数给固定住（也就是设置默认值），返回一个新的函数，调用这个新函数会更简单。
