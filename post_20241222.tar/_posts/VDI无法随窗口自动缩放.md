---
title: VDI无法随窗口自动缩放
tags:
  - 故障
  - VDI
categories:
  - VMware
  - Horizon View
date: 2021-08-08 23:26:09
---
# 故障现象

VDI无法自动调节分辨率，无法随窗口自适应变化。

# 原因

虚拟机的显卡问题

# 解决方法

虚拟机的显卡配置，选择自动检测。