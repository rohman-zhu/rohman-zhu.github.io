---
title: '[待补充]expect脚本学习--实现自动化登录脚本'
date: 2018-11-08 23:02:59
tags: Linux
---

# 前言

今天看到很多自动ssh连接的脚本，免去输入密码，任何需要输入的shell都可以使用expect脚本解决，因此也必要学习一下。

# To-Do list

* 自动生成otp脚本，demo.exp username , 免去输入 y

# 参考资料

* expect实例讲解：http://www.cnblogs.com/lixigang/articles/4849527.html
  