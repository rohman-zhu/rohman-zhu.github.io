---
title: SUSE-Linux网络配置
tags:
  - 网络配置
categories:
  - Linux
date: 2024-05-22 00:15:40
---

# 简介

包含SUSE Linux的网络配置、iptable配置。

## 网卡编辑

```sh
# 配置IP
cd /etc/sysconfig/network/
vim ifcfg-eth0


#---配置文件ifcfg-eth0
BOOTPROTO='static'
IPADDR='192.168.1.1/24'

# 配置网关
cd /etc/sysconfig/network
vim routes

#---配置文件routes
default 192.168.1.254

# 重启网络服务
rcnetwork restart
```

## 防火墙配置

SUSE Linux的默认防火墙策略中写了很多策略，INPUT表中，默认是DROP；

```sh
# 清除iptable配置
iptables -F
iptables -X

# 设置 INPUT 表的默认策略为ACCEPT
iptables -P INPUT ACCEPT
```