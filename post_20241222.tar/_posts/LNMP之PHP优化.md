---
title: LNMP之PHP优化
date: 2018-01-20 18:56:49
tags: Linux
---
# PHP优化-- 拓展安装方式 #

## PHP缓存加速器介绍 ##

### 操作码与缓存 ###

客户端请求一个PHP程序,服务器的PHP引擎会解析该PHP程序,并将其编译为特定的操作码文件(OperateCode).

默认情况,opcode执行完后会被丢弃.而,Opcode cache的原理就是将这个编译后的操作码保存下来,放入共享内存里,以便下次调用.

### PHP缓存软件 ###

* xcache
* eaccelerator
* APC(Alternative PHP Cache)
* ZendOpcache

## 使用Xcache ##

安装前需要执行以下操作:

```sh
# 解决相关的Warning出现
echo 'export LC_ALL=C' >> /etc/profile

# 安装perl-devel,如果不装,那么在安装图形转换的软件可能会出现错误
yum install perl-devel -y

```

视频采用的是3.2.x,安装过程是:

```sh
wget http://xcache.lighttpd.net/pub/Releases/3.2.0/xcache-3.2.0.tar.bz2

tar xf xcache-3.2.0.tar.bz2

cd xcache-3.2.0
/application/php/bin/phpize
./configure --enable-xcache --with-php-config=/application/php/bin/php-config

make

make install 
```

## memcache ##

## ImageMagick软件 ##

## imagick php 拓展插件 ##

## PHP配置 ##

路径是 /application/PHP/lib/php.ini

结尾添加:

```
extension_dir = "拓展插件的路径"
extension = xx1.so
extension = xx2.so
```
## 小结 ##

本章内容主要是讲PHP的插件安装,安装一些功能性插件与优化插件,对于功能性插件如果不知道是否要使用,最好直接安装上,优化插件选择其中一个即可(如 Xcache ). 

http://www.tudou.com/programs/view/Ef8GkNnfm2w/ 这个是PHP加速器压力测试过程讲解,视频是否还在?
