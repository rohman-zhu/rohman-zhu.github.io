---
title: Linux热移除iSCSI硬盘
tags:
  - 虚拟化
categories:
  - Linux
date: 2020-12-06 15:25:13
---

# 需求分析

一台Linux上有一个sda需要回收，已跟业务方确认不再使用。

# 操作步骤

1. 确认操作系统中的sda对应虚拟化层的哪一个磁盘。（避免误删）
2. 确认操作系统中，该sda盘已不再使用，执行以下指令。

```sh
# 指令常规操作是 echo 1 > /sys/block/devName/device/delete
echo 1 > /sys/block/sda/device/delete
```

3. 再到虚拟化层，删除对应的硬盘。（此处为高危操作，请谨慎操作！）
