---
title: Ubuntu18.04设置NTP与网卡
tags:
  - 18.04
categories:
  - Linux
  - Ubuntu
date: 2020-05-24 18:11:07
---

# 网卡设置

18.04开始网卡配置不再是 /etc/network/interfaces 控制，而是在 /etc/netplan/ 下的 yaml文件。

> yaml文件是通过缩进控制分级，不能使用tab。

```yaml
network:
  version: 2
  ethernets:
    eno1:
      addresses:
        - 192.168.1.1/24
      gateway4: 192.168.1.254
```

保存后使用 netplan apply ，使网卡生效。

DNS不再是直接修改 /etc/resolv.conf 来控制，默认DNS服务器都会指向本地 127.0.0.53， 并且由 systemd-resolved 控制。

配置文件存放于 /etc/systemd/resolve/resolv.conf 

```conf
[Resolve]
DNS=8.8.8.8 8.8.8.4
```

重启 systemd-resolved 服务。

```sh
systemctl restart systemd-resolved.service
```

查看DNS设置状态

```
systemd-resolved --status
```

# 设置NTP

设置时区

```sh
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
```

设置NTP服务器地址

```sh
vim /etc/systemd/timesyncd.conf

#---timesyncd.conf---#
[Time]
NTP=
#---timesyncd.conf---#

timedatectl set-ntp yes

systemctl restart systemd-timesyncd.service
```

# 参考资料

https://wiki.archlinux.org/index.php/Systemd-timesyncd