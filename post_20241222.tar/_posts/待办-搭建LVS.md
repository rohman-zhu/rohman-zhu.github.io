---
title: '[待办]搭建LVS'
date: 2018-10-22 23:56:26
tags: Linux
---

# 环境准备

* OS：Ubuntu1604-4.4.0-131-generic
* LVS策略采用： RD
  
