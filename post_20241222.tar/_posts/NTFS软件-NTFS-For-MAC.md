---
title: NTFS软件-NTFS For MAC
tags:
  - NTFS
catergories:
  - Software
  - Software For Mac
date: 2020-04-19 23:58:53
---
# 前言

MAC不能直接在NTFS格式的移动硬盘进行写入操作，需要额外安装一个软件“NTFS for MAC”。该软件默认试用期为10天，试用期时间到了后，可以卸载重装再延长试用期。

- MACOS Version：10.15.3
- NTFS for Mac Version：15.6.37

# 操作流程

1. 到“设置与偏好”中，鼠标移到“NTFS For MAC”右键，点击移除“NTFS For MAC”设置偏好面板。
2. 加载NTFS for Mac 的安装文件dmg，运行里面的“卸载NTFS For MAC”，暂时先不要重启。
3. 打开terminal终端工具，进入 /Library/Application Support/目录,提权后删除本目录下的Paragon Software目录，重启PC。
4. 加载NTFS for Mac 安装文件，运行安装程序后，重启PC。
