---
title: Linux的RSYNC服务
date: 2017-10-15 09:21:31
tags: Linux
---
# RSYNC #

Remote synchronization,可以通过网络将两台机器进行数据备份。开源、快速、可实现全量与增量数据备份数据。

## 1.什么是全量、增量备份 ##

全量就是指全部文件进行备份。增量就是指对相同的文件进行第二次备份，只对有改动的文件备份。

> 备份时的命名规范：目录以IP地址命名，文件以时间命名

## 2.NFS的工作模式 ##

### 2.1第一种工作模式：本地（Local） ###

相当于是本机操作：

1. rsync -avz /etc/hosts /tmp 等价于cp指令
1. rsync -avz --delete /null /tmp/ 等价于rm指令

### 2.2第二种工作模式：远程（Remote） ###

1. PUSH : rsync -avzP -e 'ssh -p 22' /tmp/ root@10.0.0.8:/tmp
1. PULL : rsync -avzP -e 'ssh -p 22' root@10.0.0.8:/tmp /tmp/

> -e表示指定隧道,即是指定了端口.

## 3.关乎rsync命令的参数 ##

|   参数  |   意义  |
|:-------:|:------:|
|   -v  |   --verbose(详细的,冗长的),详细模式输出,传输时的进度等信息   |
|   -z  |   --compress,传输时进行压缩以提高传输效率 |
|   -a  |   --archive(归档),表示以递归形式传输文件,并保持所有文件的属性  |
|   -r  |   --recursive(递归的,循环的)  |
|   -t  |   --times保持文件时间信息    |
|   -o  |   --owner保持文件的数组信息   |
|   -p  |   --perms保持文件权限 |
|   -g  |   --group保持文件数组信息   |
|   -P  |   --progress 显示同步的过程以及传输时的进度等信息 |
|   -D  |   --devices保持沈北文件信息   |
|   -l  |   --link保留软连接 |

> 常用的是avz属性,相当于vzrtopg

## 4.RSYNC Server配置步骤 ##

### 在/etc/rsyncd.conf加入配置 ###

```{.rsyncd}
######################################################################################################
#                      ******进程相关全局配置******
######################################################################################################
#    后面的值可根据自己的实际情况更改
#    pid file 守护进程pid文件
#    port 守护进程监听端口，可更改，由xinetd允许rsyncd时忽略此参数
#    address 守护进程监听ip，由xinetd允许rsyncd时忽略此参数
pid file = /var/run/rsyncd.pid
port = 873
address = 192.168.1.2
#rsyncd 守护进程运行系统用户全局配置，也可在具体的块中独立配置,
uid = root
gid = root
#允许 chroot，提升安全性，客户端连接模块，首先chroot到模块path参数指定的目录下
#chroot为yes时必须使用root权限，且不能备份path路径外的链接文件
use chroot = yes
#只读
read only = no
#只写
write only = no
#允许访问rsyncd服务的ip，ip端或者单独ip之间使用空格隔开
hosts allow = 192.168.0.1/255.255.255.0 198.162.145.1 10.0.1.0/255.255.255.0
#不允许访问rsyncd服务的ip，*是全部(不涵盖在hosts allow中声明的ip，注意和hosts allow的先后顺序)
hosts deny = *
#客户端最大连接数
max connections = 5
#欢迎文件路径，可选的
#motd file = /etc/rsyncd/rsyncd.motd
#日志相关
#    log file 指定rsync发送消息日志文件，而不是发送给syslog，如果不填这个参数默认发送给syslog
#    transfer logging 是否记录传输文件日志
#    log format 日志文件格式，格式参数请google
#    syslog facility rsync发送消息给syslog时的消息级别，
#    timeout连接超时时间
log file = /usr/local/logs/rsyncd.log
transfer logging = yes
log format = %t %a %m %f %b
syslog facility = local3
timeout = 300

######################################################################################################
#                      ******模块配置(多个)******
######################################################################################################
#模块 模块名称必须使用[]环绕，比如要访问data1,则地址应该是data1user@192.168.1.2::data1
[data1]
#模块根目录，必须指定
path=/home/username
#是否允许列出模块里的内容
list=yes
#忽略错误
#ignore errors
#模块验证用户名称，可使用空格或者逗号隔开多个用户名
auth users = data1user
#模块验证密码文件 可放在全局配置里
secrets file=/etc/rsyncd/rsyncd.secrets
#注释
comment = some description about this moudle
#排除目录，多个之间使用空格隔开
exclude = test1/ test2/

```

```{.normal}
#Rsync server
#Created by Roman 2017-10-15 14:50
##rsyncd.conf start##
uid = rsync
gid = rsync
use chroot = no
#最长连接时间
max connection = 200
#超时时间
timout =600
#进程号
pid file =/var/run/rsyncd.pid
lock file = /var/run/rsync.lock
log file = /var/log/rsyncd.log
#忽略错误
ignore errors
read only = false
#客户端是否可以查看服务器内的文件列表
list = false
hosts allow = 10.0.0.0/24
#认证用户,为了安全,设置了一个虚拟用户
auth users = rsync_backup
#账号密码
secrets file = /etc/rsync.password
############################
[backup]
comment = backup by roman 14:50 2017-10-15
path = /backup

```

### 创建rsync用户以及共享的目录 ###

### S端创建密码文件 ###

1. echo "rsync_backup:oldboy" > /etc/rsync.password
1. chmod 600 /etc/rsync.password
1. rsync --daemon
1. 检查 netstat -lntup | grep rsync

## RSYNC Client 配置 ##

### C端创建密码文件 ###

1. echo "oldboy" />/etc/rsync.password
1. chmod 600 /etc/rsync.password

### RSYNC 操作 ###

PUSH:

* rsync [OPTION] SRC... [USER@]HOST::DEST

例如:

* rsynv -avz /tmp rsync_backup@10.0.0.10::backup --password-file=/etc/rsync.password

## 4.RSYNC的故障排查 ##

### Connection refused ###

检查防火墙或者服务是否开启.

## 补充知识点 : 进程管理 ##

* pkill指令 : pkill 进程名字
* kill指令 : kill 进程编号

```{.norml}
# cat /var/run/rsync.pid
```

---------

关于echo: echo是可以穿件文件的,例如 echo "rsync_backup:oldboy" > /etc/rsync.password

* echo 的内容代表的是 用户和密码 ; 用户名 : 密码 ;

> rsync.password 里面的用户 跟 /etc/rsyncd.conf 里面的 auth users是一样的.

## 设置RSYNC服务的步骤 ##

Deamon工作模式

1. 创建配置文件 /etc/rsyncd.conf(默认不存在的)
1. 创建rsnc用户,用于rsync服务的
1. 创建密码文件,"用户名:密码",/etc/rsync.password
1. 启动服务. rsync --daemon
1. 添加至开机启动项 . echo "rsync --daemon" >> /etc/rc.local

> 密码文件要设置权限,非root用户不能修改,chomd 600 /etc/rsync.password

### 客户端配置步骤 ###

1. 创建密码文件,文件里面只存放密码即可,因为登陆的时候默认带了用户名
1. 上传备份 , 即push
1. 下载备份 , 即pull

```{.normal}
# rsync -avz /temp rsync_backup@10.0.0.7::backup --password-file=/etc/rsync.password
```

## Rsync 的优缺点 ##

1. 优点:
* 增量备份同步
* 支持socket(daemon)

1. 缺点:
* 大量小文件同步的时候,比对时间较长,有时候会出现rsync进程停止.(解决方案:打包成一个压缩文件 ; drbd(文件系统同步复制block))
* 同步大文件,例如10G文件有时会中断.只要未完成同步前,文件都为隐藏文件.