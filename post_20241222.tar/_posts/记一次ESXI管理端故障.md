---
title: 记一次ESXI管理端故障
tags:
  - 故障处理
categories:
  - VMware
  - vSphere
date: 2021-02-22 00:02:25
---
# 故障现象

vCenter已经无法管理ESXI，并且无法单独连接此ESXI。
ESXI上的业务还在正常运行，应该是管理进程异常。

# 原因分析

可能是ESXI的Management Agent 异常，可以通过ESXI的console去重启Management Agent。

# 操作流程

为了避免重启Management Agent时，ESXI 卡在 “Stopping ESXI Management Agent”界面，因此需要提前打开 ESXI Shell 和 SSH 。

1. 从物理服务器的带外KVM进入ESXI，开启ESXI Shell  与 SSH。
2. 重启 Management Agent 。

如果出现异常，可以通过 ssh 或者 ESXI Shell 中断重启进程。

如果以上方法无效，可以采用以下方法，先迁移业务：
（此时业务已经无法通过vCenter去管控，必须人为干预，重新注册虚拟机。）

1. 先记录故障ESXI上的虚拟机，包含 IP 、 虚拟机名 、 底层所用的Datastore 。
2. 从vCenter中移除未响应的ESXI（因为要重新注册虚拟机，如果当前ESXI上的虚拟机还在注册状态，则无法执行注册指令。移除ESXI并不会影响ESXI上的业务。）
3. 联系虚拟机对应的运维人员，约定时间关机后，找到虚拟机对应vmx文件，执行注册。
4. 虚拟机执行开机，联系业务管理员检测业务。


