---
title: Windows-动态访问控制
tags:
  - 学习笔记
categories:
  - Windows Server
date: 2021-01-31 17:51:27
---
# DAC动态访问控制

文件的访问控制是基于 NTFS 文件系统来执行的。因此要使用此特性，文件系统必须为NTFS。

## NTFS 特性

1. 节约空间
2. 磁盘压缩
3. 更加安全
4. EFS加密
5. 磁盘配额
6. 卷影副本
7. 单个文件最大支持64GB

## 访问控制

操作流程：

1. DC中启用足额策略：计算机管理-系统-KDC-KDC支持声明、复合身份验证和Kerberos Armoring
2. 声明属性:在动态访问控制中，创建声明，如department 、title
3. 创建规则：在动态访问控制中，进入 Central Access Rules中，创建规则
4. 创建策略：在动态访问控制中，进入 Central Access Policy 中添加规则
5. 目标文件服务器，选中对应文件夹的属性，高级，中央策略，选择对应Policy

Claim Types 声明
Central Access Rules 规则
Central Access Policy 策略（包含多个规则）

> Policy 通过组策略发布，在客户端生效。

### “拒绝优先”

ACL列表中，依次从上至下执行，被列为拒绝权限的用户，优先执行。

## 需求场景

创建一个public的文件夹，仅允许公司内的主管访问。

### 传统做法

创建一个安全组，将主管的AD拖进同一个安全组，然后再对Public进行授权。