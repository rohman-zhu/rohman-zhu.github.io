---
title: 监控Nagios部署
date: 2017-12-02 16:42:52
tags: Linux
---
# Nagios部署实战 #

最近看了4,5天的nagios教程,翻阅了很多资料,尝试着去部署一遍,每次都在用rrdtool和pnp4nagios呈现图表界面出错("Please check the documentation for information about the following error."),今天完完整整按照一篇文章来搭建Nagios监控,结果成功了,这里写一下笔记总结.

## 参考文章 ##

* 力荐 `https://www.cnblogs.com/5201351/p/4328393.html`
* 参考 `https://www.cnblogs.com/Leo_wl/p/6338041.html`
* 参考 `https://www.ibm.com/developerworks/cn/linux/1309_luojun_nagios/`

## 开始实战 ##

### 软件版本以及下载地址 ###

* Nagios 3.5.1
* rrdtool 1.3.8
* pnp4nagios 0.6.21

下载地址:

* Nagios : `https://www.nagios.org/downloads/nagios-core/thanks/?skip=1&t=1511299844`
* Nagios-plugins : `https://www.nagios.org/downloads/nagios-plugins/`
* rrdtool :  `https://oss.oetiker.ch/rrdtool/pub/?M=D`
* pnp4nagios : `https://sourceforge.net/p/pnp4nagios/code/ci/0.6.21/tarball`

### 安装Nagios ###

先安装依赖

```sh
yum install gcc make -y
#glibc是GNU发布的libc库，即c运行库。glibc是linux系统中最底层的api，几乎其它任何运行库都会依赖于glibc。glibc除了封装linux操作系统所提供的系统服务外，它本身也提供了许多其它一些必要功能服务的实现。
yum install glibc glibc-common -y
yum install httpd php -y
#GD库是php处理图形的扩展库，GD库提供了一系列用来处理图片的API，使用GD库可以处理图片，或者生成图片，也可以给图片加水印。
yum install gd gd-devel -y
```

添加nagios用户,nagcmd组,将nagios和apache用户加进nagcmd组中

```sh
useradd nagios
groupadd nagcmd
usermod -a -G nagcmd nagios
usermod -a -G nagcmd apache
```

> -a Add the user to the supplementary group(s). Use only with the -G option.

源码安装nagios

```sh
cd nagios-3.5.1
./configure --with-command-group=nagcmd
#编译所有源码
make all
#安装主程序,CGIs,网页文件,会生成bin,libexec,sbin,share,var目录
make install
#安装etc配置目录
make install-config
#安装nagios启动脚本
make install-init
#为nagios网站添加安装httpd配置文件
make install-webconf
#外部命令访问nagios 配置文件的权限,为./var/rw设置为0775,改所有组为nagcmd
make install-commandmode
```

Nagios插件包:

```sh
./configure --with-nagios-user=nagios --with-nagios-group=nagcmd
make && make install
```

为 _nagios_ 网站设置密码:

```sh
htpasswd -c /usr/local/nagios/etc/htpasswd.users nagiosadmin
New password:
Re-type new password:
Adding password for user nagiosadmin
```

到这里为止,第一部安装,到此为止.

### RRDTOOL + PNP4Nagios ###

```sh
yum install perl rrdtool php-gd perl-Time-HiRes rrdtool-perl -y
./configure --prefix=/usr/local/pnp4nagios --with-rrdtool=/usr/bin/rrdtool --with-nagios-user=nagios --with-nagios-group=nagios
make all
make fullinstall
```

配置pnp4nagios软件,需要修改pnp4nagios/etc目录,以及pages , check_commands目录下的所有文件后缀.

```sh
cd /usr/local/pnp4nagios/etc
mv misccommands.cfg-sample misccommands.cfg
mv nagios.cfg-sample nagios.cfg
mv rra.cfg-sample rra.cfg
mv pages/web_traffic.cfg-sample pages/web_traffic.cfg
cd check_commands/
mv check_all_local_disks.cfg-sample check_all_local_disks.cfg
mv check_nrpe.cfg-sample check_nrpe.cfg
mv check_nwstat.cfg-sample check_nwstat.cfg
```

启动npcd服务:

```sh
/etc/init.d/npcd restart
#启动httpd
/etc/init.d/httpd restart
```

检测是否成功配置:

浏览器输入网址: `http://<Nagios地址>/nagios`

如果显示成功,则根据页面底部提示把install.php文件改名或者移除.

### nagios与pnp4nagios结合 ###

在 /usr/local/nagios/etc/objects/commands.cfg 修改 process-host-perfdata 和 process-service-perfdata

```sh
define command{
        command_name    process-host-perfdata
        command_line    /usr/bin/perl /usr/local/pnp4nagios/libexec/process_perfdata.pl -d HOSTPERFDATA
        }

define command{
        command_name    process-service-perfdata
        command_line    /usr/bin/perl /usr/local/pnp4nagios/libexec/process_perfdata.pl
        }
```

定义模板,编辑/usr/local/nagios/etc/objects/templates.cfg,加入如下内容:

```sh
define host {
        name       hosts-pnp
        register      0
        action_url    /pnp4nagios/index.php/graph?host=$HOSTNAME$&srv=_HOST_
        process_perf_data               1
        }

define service {
        name       srv-pnp
        register      0
        action_url  /pnp4nagios/index.php/graph?host=$HOSTNAME$&srv=$SERVICEDESC$
        process_perf_data               1
        }
```

修改nagios配置文件/usr/local/nagios/etc/nagios.cfg

```sh
process_performance_data=1                          //默认为0
host_perfdata_command=process-host-perfdata         //默认前面有注释符#
service_perfdata_command=process-service-perfdata   //默认前面有注释符#
```

对需要图标显示的服务站点,添加 srv-pnp 模板

```sh
define service{    # 添加监控sda1磁盘
        use     srv-service
        host_name       192.168.0.28
        service_description     check_disk_hda1
        check_command           check_nrpe!check_hda1
        max_check_attempts 5
        normal_check_interval 1
}
```

### 客户端操作 ###

由于客户端是被监视的,所以只需要安装 _nrpe_ 和 _nagios-plugins_ 这个软件就好了.同时修改一下nrpe的配置文件,添加允许的服务器监控.

>Yum安装的话,要添加epel拓展源

```sh
yum install epel-release -y
yum install nrpe -y
yum install nagios-plugins-all -y

vi /etc/nagios/nrpe.cfg
---
allowhosts=x.x.x.x
dont_blame_nrpe=1
---
/etc/init.d/nrpe start
```

## 小结 ##

以上操作都是对版本有要求的,可能在nagios4.3.4里面的图形显示会出些问题,一直无法生产画面,网络上面的解决方案都是说使用bulk的模式就不会有问题了,可是一直都没有解决.(待解决吧).

另外再写一下几个关键的配置:

1. 安装Nagios的时候,有make install-webconfig,这个可以配置apache的节点,省去自己配置的麻烦.
1. Nagios的权限问题,这个是要通过htpasswd来生产用户与密码,然后再修改httpd的配置文件,将认证文件导向htpasswd.users.
1. 监控任何一台机器,先要定义host节点(主机名字,主机地址),再定义监控的服务(PING...)

> 听师兄说这个用的很少了,所以这个章节作为了解,以后有需求或者再查阅相关文档就好了.