---
title: Windows因为没有激活而自动关机
tags:
  - 故障
categories:
  - Windows Server
date: 2020-12-27 00:00:16
---
# 故障现象

服务器从Windows Server 2008 升级至 Windows Server 2012R2 。服务器会在一个小时内自动关机。

# 原因分析

查看系统日志

有以下信息

```
以下是日志信息：

进程 C:\WINDOWS\system32\wlms\wlms.exe (DESKTOP-V470) 由于以下原因已代表用户 NT AUTHORITY\SYSTEM 启动计算机 DESKTOP-V470 的 关机: 其他(计划内)

 原因代码: 0x80000000
 关机类型: 关机
 注释: 此 Windows 安装的许可证期限已过期。即将关闭操作系统。
```

# 解决方法

将服务器激活

## 使用key激活

输入正确的key，联网激活。

## 制定kms服务器，连接kms服务器激活

```bat
slmgr.vbs /skms [KMS服务器地址]

slmgr.vbs /ato
```

### 指令解析

slmgr是Software LicenseManger的简称，是Windows软件授权管理工具。slmgr是管理系统激活和密钥、证书的主要组件。slmgr的所有功能都是通过slmgr.vbs提供的，采用VBScript命令行方式执行。

```
SLMGR语法格式基本语法：

slmgr.vbs [MachineName [User Password]] [Option]

其中：
* MachineName ： 远程计算机名 （缺省为本机）
* User ：             具有相应权限的计算机用户
* Password：        用户密码
* Option：            为SLMGR的参数，参下。

Option 常用参数选项：

-ipk <产品密钥>     安装产品密钥（替换现有密钥）
-upk                    卸载产品密钥
-ato                    激活Windows
-dli  [激活 ID | All]  显示许可证信息（默认：当前许可证）
-dlv [激活 ID | All]  显示详细的许可证信息（默认：当前许可证）
-xpr                    当前许可证状态的截止日期

高级参数选项：

-cpky                   从注册表中清除产品密钥（阻止泄露引起的攻击）
-ilc <许可证文件>   安装许可证
-rilc                    重新安装系统许可证文件
-rearm                 重置计算机的授权状态 （去除水印）
-dti                      显示安装 ID以进行脱机激活
-atp <确认 ID>     使用电话方式提供的确认 ID 激活产品

KMS相关选项：

-skms                    设置KMS服务器名
-skms           设置KMS服务器端口号
-skms    设置KMS服务器名和端口号
-ckms    清除KMS服务器名和端口号并设为初始状态

```

> KMS 服务器默认使用的是 TCP-1688 端口。