---
title: 通过ipmitool重置服务器带外密码
tags:
  - 带外
  - ipmi
categories:
  - 服务器与存储
  - 服务器
date: 2021-11-21 17:27:15
---

# 背景

服务器一般都有设置带外管理，由于没有正常交接。导致无法进入带外，而重置带外需要在服务器重启后进入BIOS中操作。但业务一般不允许重启，所以可以通过操作系统内执行ipmi工具重置密码。

# 操作过程

智能型平台管理接口（Intelligent Platform Management Interface）

## 安装ipmitool

```sh
# Ubuntu
apt-get install ipmitool

# CentOS
yum install ipmitool
```

## 加载ipmitool模块

```sh
modprobe ipmi_devintf
modprobe ipmi_si
```

## 查看带外设置的用户并重置密码

Linux 操作系统

```sh
# 查询带外用户列表
ipmitool user list 1

# 重置带外用户密码
ipmitool user set password [用户ID] [新密码]
```

# 参考资料

https://zhuanlan.zhihu.com/p/370457043
https://www.cnblogs.com/lianglab/p/14106113.html