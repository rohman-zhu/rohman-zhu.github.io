---
title: LVM扩容
date: 2018-10-16 23:50:12
tags: Linux
---

# 需求 #

* Linux-14.04-3.3.0.24-generic
* 硬盘50G空间，sda
* 采用LVM分区方式
* 现需要加多一块硬盘，同样也是50G，sdb

# 实践 #

```shell
# df -T
# pvdisplay
# vgdisplay
# lvdisplay
# 增加一块磁盘 sdb ，利用fdisk创建一个名为sdb1的扩展分区，占sdb全部空间。
# fdisk /dev/sdb
#---

Command(m for help):n
Partition type:
    p primary(0 primary, 0 extended, 4 free)
    e extended
Select(default p):p
Partition number(1-4,default 1):1
First sector(2048-xxxxx,default xxxxx):
Using default value xxxxx
Last sector,+sectors or +size...:
Using default value xxxxxx

Command(m for help):t
Selected partition 1
Hex code(type L to list codes):8e
Changed system type of partition 1 to 8e(Linux LVM)

Command(m for help):w
The partition table has been altered!

Calling ioctl() to re-read partition table.
Syncing disks.

# 利用pvcreate 在分区sdb1上创建名为sdb1的PV：
# pvcreate /dev/sdb1

# 把刚创建好的sdb1 PV加到 VG中
# vgextend ubuntu-vg /dev/sdb1
# vgdisplay

# 拓展 /dev/ubuntu-vg/root LV
# lvextend -L+50G /dev/ubuntu-vg/root

# 更新文件系统
# resize2fs /dev/mapper/ubuntu--vg-root
```

# 解释 #

三个概念：

* Physical Volume（PV）
* Volume Group（VG）
* Logical Volume（LV）
   
# 问题 #

