---
title: Linux 故障修复集
date: 2017-10-02 11:23:06
tags: Linux
---

# 修复CentOS-7启动引导 #

## 一、修复MBR：##

MBR（Master Boot Record主引导记录）：

硬盘的0柱面、0磁头、1扇区称为主引导扇区。其中446Byte是bootloader，64Byte为Partition table，剩下的2Byte为magic number。

备份MBR：

```
#dd if=/dev/sda of=/root/mbr.bak count=1 bs=512
```

破坏bootloader：

```
#dd if=/dev/zero of=/dev/sda count=1 bs=200
```

这里边block size只要小于等于446即可。

修复方式：

1. 借助其他系统挂载磁盘修复。

修复方式同光盘修复类似，也是使用grub2-install命令。

2. 借助安装光盘修复。

### 插入Linux安装盘 ### 

1. 装入光盘，在光盘引导界面选择troubleshooting：
2. 选择进入救援模式（Recue a CentOS system )：
3. 按回车键继续：
4. 进入磁盘挂载选择模式：磁盘将会被挂载至/mnt/sysimage/下

* continue 以rw方式挂载分区。
* read only 以ro方式挂载分区。
* skip 跳过，将来自己手工挂载磁盘。

5. 选择continue，稍等片刻，提示已经挂载完成。
6. 此时进入救援模式的命令行：
7. 使用grub2-install命令重建bootloader,并且显示无错误后，重启系统。

```
#grub2-install root-directory=/mnt/sysimage /dev/sda
#sync
#reboot
```
<a href="http://www.linuxidc.com/Linux/2015-03/114678.htm">原文地址</a>

# 硬件故障 #

先查看内核日志文件，检查问题
```
$ dmesg
```