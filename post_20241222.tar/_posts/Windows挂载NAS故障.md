---
title: Windows挂载NAS故障
tags:
  - 故障
  - NAS
  - SAMBA
categories:
  - Windows Server
date: 2020-06-01 06:11:32
---

# 故障描述

前提条件：

1. windows server已经加域。
2. 该管理员是属于Administrators组下面。
3. 服务器到 NAS 的防火墙已经开通。
4. 采用samba协议连接。

端口：

| 类型 | 端口 | 备注 |
|:---:|:----:|:----:|
|TCP| 139，445|139(NetBIOS-SSN),445(Microsoft-DS)|
|UPD| 137,138,139，445|137-138(Nmbd)|

在OS中添加网络映射盘后，到CMD（以管理员身份运行）没有办法访问该映射盘。

程序报错：

```log
The system cannot find the path specified.
```

# 原因分析

UAC将Administrators组的成员视为标准用户。

# 解决方案

## 临时解决方法：

在管理员模式下执行 net use 重新映射

```ps1
net use [映射盘符]    \\[NAS IP]\Volume Name  
```

## 根治方法：

1. 单击“ 开始”，在“ 启动程序和文件”框中键入regedit，然后按Enter。
2. 找到并右键单击注册表子项HKEY_LOCAL_MACHINE \ SOFTWARE \ Microsoft \ Windows \ CurrentVersion \ Policies \ System。
3. 点击“ 新建”，然后单击“ DWORD值”。
4. 键入EnableLinkedConnections，然后按Enter。
5. 右键单击EnableLinkedConnections，然后单击“ 修改”。
6. 在“ 数值数据”框中，键入1，然后单击“ 确定”。
7. 退出注册表编辑器，然后重新启动计算机。

# 参考资料

https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2008-R2-and-2008/ee844140(v=ws.10)?redirectedfrom=MSDN