---
title: Windows-组策略编辑器无法打开
tags:
  - 故障
categories:
  - Windows Server
date: 2023-03-29 23:11:21
---

# 故障描述

使用gpedit.msc，会提示报错“文件所在的卷以被外部更改，文件不再有效”；

# 解决方法

重置GroupPolicy文件夹；

```ps1
Rename-Item C:\Windows\Sytem32\GroupPolicy C:\Windows\Sytem32\GroupPolicy-bak
```