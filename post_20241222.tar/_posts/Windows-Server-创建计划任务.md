---
title: Windows Server 创建计划任务
tags:
  - Powershell
categories:
  - Windows Server
date: 2024-05-03 16:08:26
---

# 需求描述

任务1：创建自动化任务，到指定时间自动运行脚本；
任务2：通过远程下发指令，时间自动化创建自动任务；

# 实现方式

## 任务1操作实例-CLI操作界面

参考：
1. https://learn.microsoft.com/zh-cn/powershell/module/psscheduledjob/register-scheduledjob?view=powershell-5.1
2. https://learn.microsoft.com/en-us/powershell/module/scheduledtasks/new-scheduledtask?view=winserver2012r2-ps

```ps1
# 叫什么：一个名为 TEST 的自动任务
$TASKNAME="TEST";

# 干什么：并执行 test.ps1 脚本
$TESTSCRIPT="C:\test.ps1";
$ACTION=New-ScheduledTaskAction -Execute "Powershell" -Argument $TESTCRIPT;

# 什么时候做：在每周三，晚上7:30执行；
$JOBTRIGGER=New-JobTrigger -Weekly -At "9:00 PM" -DaysOfWeek Wednesday -WeeksInterval 1;

# 谁：拥有最高权限
# 有啥注意事项：无论有没有用户登录，都执行
$PRINCIPAL=New-ScheduledTaskPrincipal -UserId [USER] -LogonType S4U

# 创建任务信息
$SCHEDULEDTASKOBJECT=New-ScheduledTask -Action $ACTION -Trigger $JOBTRIGGER -Principal $PRINCIPAL
# 注册任务
Register-ScheduledTask -TaskName $TASKNAME -InputObject [SchedledTaskObjectName];
```


## 任务1操作实例-GUI操作界面

参考：https://www.cnblogs.com/lishidefengchen/p/4381565.html

环境说明:
1. Powershell 目录：C:\Windows\SysWOW64\WindowsPowerShell\v1.0\PowerShell.exe;
2. 脚本位置：C:\test.ps1;

### 运行“任务计划程序”

1. windows + R;
2. 输入 taskschd.msc;

### 创建任务

常规页面：
1. 填写任务名称；
2. 勾选“不敢用户是否登录都要运行”
3. 勾选“使用最高权限运行”；【如果有涉及提权操作，则需要勾选】
4. 配置选择为对应的OS版本；

触发器页面：
1. 新建；
2. 设置自动执行的频率与时间；

操作页面：
1. 操作，选择“启动程序”；
2. 程序或脚本，输入“powershell”或者Powershell的绝对路径“C:\Windows\SysWOW64\WindowsPowerShell\v1.0\PowerShell.exe”；
3. 添加参数（可选）,输入脚本的绝对路径，用英文状态的双引号包裹；

点击确定；

### 如何DEBUG

有可能任务运行会失败或者未按预期执行，可以选中任务，点击运行后，可以在“历史History”标签页中看到执行情况。
不过此时获取的信息还是比较有限，所以可以在脚本中增加 Start-Transcript 与 Stop-Transcript 指令，检查执行情况。


# TASK_LOGON_TYPE 类型

参考: https://learn.microsoft.com/en-us/windows/win32/api/taskschd/ne-taskschd-task_logon_type

```ps1
typedef enum _TASK_LOGON_TYPE {
  TASK_LOGON_NONE = 0,
  TASK_LOGON_PASSWORD = 1,
  TASK_LOGON_S4U = 2,
  TASK_LOGON_INTERACTIVE_TOKEN = 3,
  TASK_LOGON_GROUP = 4,
  TASK_LOGON_SERVICE_ACCOUNT = 5,
  TASK_LOGON_INTERACTIVE_TOKEN_OR_PASSWORD = 6
} TASK_LOGON_TYPE;
```

```ps1
TASK_LOGON_NONE
Value: 0
The logon method is not specified. Used for non-NT credentials.


TASK_LOGON_PASSWORD
Value: 1
Use a password for logging on the user. The password must be supplied at registration time.


TASK_LOGON_S4U
Value: 2
The service will log the user on using Service For User (S4U), and the task will run in a non-interactive desktop. When an S4U logon is used, no password is stored by the system and there is no access to either the network or to encrypted files.


TASK_LOGON_INTERACTIVE_TOKEN
Value: 3
User must already be logged on. The task will be run only in an existing interactive session.


TASK_LOGON_GROUP
Value: 4
Group activation. The groupId field specifies the group.


TASK_LOGON_SERVICE_ACCOUNT
Value: 5
Indicates that a Local System, Local Service, or Network Service account is being used as a security context to run the task.



TASK_LOGON_INTERACTIVE_TOKEN_OR_PASSWORD
Value: 6
Not in use; currently identical to TASK_LOGON_PASSWORD.

Windows 10, version 1511, Windows 10, version 1507, Windows 8.1, Windows Server 2012 R2, Windows 8, Windows Server 2012, Windows Vista and Windows Server 2008:  First use the interactive token. If the user is not logged on (no interactive token is available), then the password is used. The password must be specified when a task is registered. This flag is not recommended for new tasks because it is less reliable than TASK_LOGON_PASSWORD.

```







