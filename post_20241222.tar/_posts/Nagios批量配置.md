---
title: Nagios批量配置
date: 2017-12-09 15:17:20
tags: Linux
---
# Nagios批量配置 #

工作环境中有很多机器需要配置监控,所以就需要批量配置脚本.

## 第三方软件 ##

* Centreon
* Nagios FAQ

作业:
RAID,CPU温度

U盘里面的PE系统

