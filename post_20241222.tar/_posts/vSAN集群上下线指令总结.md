---
title: vSAN集群上下线指令总结
tags:
  - 指令
categories:
  - VMware
  - vSAN
date: 2022-03-05 21:00:36
---

# 需求

需要指令关机。

# vSAN集群下线

```ESXi shell

```

# vSAN集群上线

```ESXi shell

```
