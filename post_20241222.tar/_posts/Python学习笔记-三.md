---
title: Python学习笔记(三)
date: 2017-11-19 19:26:26
tags: Python
---
# Python学习笔记 三 #

为了编写可维护的代码，我们把很多函数分组，分别放到不同的文件里，这样，每个文件包含的代码就相对较少，很多编程语言都采用这种组织代码的方式。在Python中，一个.py文件就称之为一个模块（Module）。

## 模块 module ##

> 类似C语言中的include 或者 java中的import

## 作用域 ##

在一个模块中，我们可能会定义很多函数和变量，但有的函数和变量我们希望给别人使用，有的函数和变量我们希望仅仅在模块内部使用。在Python中，是通过_前缀来实现的。

> private 在 python中用\_代替

```python
def _private_1(name):
    return 'Hello, %s' % name

def _private_2(name):
    return 'Hi, %s' % name

def greeting(name):
    if len(name) > 3:
        return _private_1(name)
    else:
        return _private_2(name)
```

在模块里公开greeting()函数，而把内部逻辑用private函数隐藏起来了，这样，调用greeting()函数不用关心内部的private函数细节，这也是一种非常有用的代码封装和抽象的方法，即：

外部不需要引用的函数全部定义成private，只有外部需要引用的函数才定义为public。

## 安装第三方模块 ##

在命令提示窗口下运行'pip'命令

```command
# 第三方库都会在Python官方的pypi.python.org网站注册，要安装一个第三方库，必须先知道该库的名称，可以在官网或者pypi上搜索，比如Pillow的名称叫Pillow，因此，安装Pillow的命令就是：
# pip install Pillow
```

### 安装常用模块 ###

在使用Python时，我们经常需要用到很多第三方库，例如，上面提到的Pillow，以及MySQL驱动程序，Web框架Flask，科学计算Numpy等。用pip一个一个安装费时费力，还需要考虑兼容性。我们推荐直接使用Anaconda，这是一个基于Python的数据处理和科学计算平台，它已经内置了许多非常有用的第三方库，我们装上Anaconda，就相当于把数十个第三方模块自动安装好了，非常简单易用。

下载地址:`https://www.anaconda.com/download/#macos`

默认情况下，Python解释器会搜索当前目录、所有已安装的内置模块和第三方模块，搜索路径存放在sys模块的path变量中

```python
>>>import sys
>>>sys.path
>>>添加路径
>>>sys.path.append('new path')
```

> 另外一种添加路径的方式:设置环境变量PYTHONPATH，该环境变量的内容会被自动添加到模块搜索路径中。设置方式与设置Path环境变量类似。注意只需要添加你自己的搜索路径，Python自己本身的搜索路径不受影响。

## 面向对象编程 ##

面向对象的设计思想是从自然界中来的，因为在自然界中，类（Class）和实例（Instance）的概念是很自然的。Class是一种抽象概念，比如我们定义的Class——Student，是指学生这个概念，而实例（Instance）则是一个个具体的Student，比如，Bart Simpson和Lisa Simpson是两个具体的Student。

所以，面向对象的设计思想是抽象出Class，根据Class创建Instance。

面向对象的抽象程度又比函数要高，因为一个Class既包含数据，又包含操作数据的方法。

### 类与实例 ###

_class_ 后面紧接着是类名，即Student，类名通常是大写开头的单词，紧接着是(object)，表示该类是从哪个类继承下来的，如果没有合适的继承类，就使用object类，这是所有类最终都会继承的类。

```python
class Student(object):
    pass
########
class Student(object):
    def __init___(self,name,score):
    self.name = name
    self.score = score
```

>注意:特殊方法“\_\_init\_\_”前后分别有两个下划线！！！
>注意: \_\_init\_\_ 方法的第一个参数永远是self，表示创建的实例本身，因此，在\_\_init\_\_方法内部，就可以把各种属性绑定到self，因为self就指向创建的实例本身。

有了\_\_init\_\_方法，在创建实例的时候，就不能传入空的参数了，必须传入与\_\_init\_\_方法匹配的参数，但self不需要传，Python解释器自己会把实例变量传进去：

```python
bart = Student('Bart Simpason',58)
```

>第一个参数永远是实例变量self，并且，调用时，不用传递该参数。

### 访问限制 ###

如果要让内部属性不被外部访问，可以把属性的名称前加上两个下划线\_\_，在Python中，实例的变量名如果以\_\_开头，就变成了一个私有变量（private），只有内部可以访问，外部不能访问，所以，我们把Student类改一改：

```python
class Student(object):
    def __init___(self,name,score):
        self.__name = name
        self.__score = score
    def print_score(self):
        print('%s:%s' % (self.__name,self.__score))
```

> 变量名类似\_\_xxx\_\_的，也就是以双下划线开头，并且以双下划线结尾的，是特殊变量，特殊变量是可以直接访问的，不是private变量

双下划线不代表private

```txt
有些时候，你会看到以一个下划线开头的实例变量名，比如_name，这样的实例变量外部是可以访问的，但是，按照约定俗成的规定，当你看到这样的变量时，意思就是，“虽然我可以被访问，但是，请把我视为私有变量，不要随意访问”。

双下划线开头的实例变量是不是一定不能从外部访问呢？其实也不是。不能直接访问__name是因为Python解释器对外把__name变量改成了_Student__name，所以，仍然可以通过_Student__name来访问__name变量
```

---

练习:写一个student类

```python
class Student(Object):
    def __init__(self,name,general):
        self.__name = name
        self.__general = general

    def set_general(general):
        self.__general = general

    def get_general(general):
        return self.__general
```

### 继承和多态 ###

```python
class Animal(Object):
    def fun(self):
       print("I am running")

class Dog(Animal):
    pass
#此时Dog类有父类Animal的方法,可以实例化并调用父类的方法
```

>对于静态语言（例如Java）来说，如果需要传入Animal类型，则传入的对象必须是Animal类型或者它的子类，否则，将无法调用run()方法。

对于Python这样的动态语言来说，则不一定需要传入Animal类型。我们只需要保证传入的对象有一个run()方法就可以了.

>这就是动态语言的“鸭子类型”，它并不要求严格的继承体系，一个对象只要“看起来像鸭子，走起路来像鸭子”，那它就可以被看做是鸭子。

### 获取对象信息 ###

#### 使用type() ####

```python
>>>type(123)
<class 'int'>
```

#### 使用isinstance() ####

```python
>>>a = Animal()
>>>dog = Dog()
>>>isinstance(a,Animal)
True
>>>isinstance(dog,Animal)
True
```

#### 使用dir() ####

如果要获得一个对象的所有属性和方法，可以使用dir()函数，它返回一个包含字符串的list

仅仅把属性和方法列出来是不够的，配合getattr()、setattr()以及hasattr()，我们可以直接操作一个对象的状态：

```python
>>> class MyObject(object):
...     def __init__(self):
...         self.x = 9
...     def power(self):
...         return self.x * self.x
...
>>> obj = MyObject()

>>> hasattr(obj, 'x') # 有属性'x'吗？
True
>>> obj.x
9
>>> hasattr(obj, 'y') # 有属性'y'吗？
False
>>> setattr(obj, 'y', 19) # 设置一个属性'y'
>>> hasattr(obj, 'y') # 有属性'y'吗？
True
>>> getattr(obj, 'y') # 获取属性'y'
19
>>> obj.y # 获取属性'y'
19
```

---

练习 : 为了统计学生人数，可以给Student类增加一个类属性，每创建一个实例，该属性自动增加;

```python
class Count(object):
    count = 0

class Student(Count):
    def __init__(self,name):
        self.name = name
        Count.count += 1
    def get_Count():
        print(Count.count)
        return Count.count
```

## 面向对象高级编程 ##

python允许动态为实例添加属性和方法...

### 使用 \_\_slots\_\_ ###

动态添加属性和方法:

```python
class Student(object):
    pass
# 给实例添加属性
s = Student()
s.name = 'Micheal'
print(s.name)

# 绑定方法
def set_age(self,age):
    self.age = age
from types import MethodType
s.set_age = MethodType(set_age,s)
s.set_age(25)
print(s.age)
```

>给一个实例绑定的方法，对另一个实例是不起作用的

要给所有实例都绑定方法,可以用class绑定方法:

```python
def set_score(self,score):
    self.score = score
Student.set_score = set_score
```

既然可以动态添加实例的属性,就可以限制添加属性

```python
class Student(object):
    __slots__ = ('name','age')

# 现在Student类只允许设置name和age
```

### 使用@property ###

```python
class Screen(object):
    @property
    def width(self):
        return self.width
    @width.setter
    def width(self,vale):
        self.width = value
    @property
    def height(self):
        return self.heigth
    @height.setter
    def height(self,value):
        self.height = value

```

> property要比setter先设置,否则会出现无法识别相关属性
> NameError: name 'xxx' is not defined

### 多继承 ###

```python
class Farther(object):
    pass
class Monther(object):
    pass

class Son(Farther,Monther):
    pass
```