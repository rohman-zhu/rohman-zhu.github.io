---
title: Docker-Hexo_Blog实例
tags:
  - default
categories:
  - Docker
date: 2024-12-08 22:23:15
---
# 需求说明

之前是使用一台CentOS 部署 node.js 与 hexo ， 这种形态还是有点重，想改成Docker形态看看。

# 开始操作

思路是先 拉取一个 node 镜像，然后再基于 node 镜像 封装一个 hexo 镜像；

参照：https://chunchengwei.github.io/ruan-jian/ji-yu-docker-de-hexo-bo-ke-da-jian/

## 拉取 node 镜像

```sh
# 获取最新的 node.js 镜像
docker pull node:latest
```

## 封装镜像

```sh
# 创建 hexo 工作目录
mkdir -p ~/Hexo && cd ~/Hexo
mkdir hexo_docker && cd hexo_docker
# 创建 Docker 封装的编译文件
touch Dockerfile
```

```dockerfile
# 基础镜像
FROM node:latest

# 维护者信息
MAINTAINER your_name <your_mail>

# 工作目录
WORKDIR /hexo

# 安装Hexo
RUN npm install hexo-cli -g
RUN hexo init .
RUN npm install

# 设置git
RUN git config --global user.name "your_name"
RUN git config --global user.email "your_mail"

# 映射端口
EXPOSE 4000

# 运行命令
CMD ["/bin/bash"]
```

执行编译

```sh
docker build -t "hexo:latest"
```

封装结束后，可以看到有这个镜像：

```sh
docker images
```

## 测试镜像是否可用

```sh
# 创建 6000 映射 4000 的容器
docker run -it --name="temp" -p 6000:4000 hexo:latest /bin/bash

# 进入docker后
# 执行指令 hexo s，开启hexo服务
hexo s


```

> 确认可以访问 ： 在外部访问 http://docker 宿主机IP:6000

## 二次封装镜像

确认完上述方案是可以成功运行后，我们需要进一步去封装docker镜像，使镜像可以直接使用。

我期望有一些初始化动作就直接封装完毕，比如一些安装插件的动作即可在镜像中就完成。

```hexo_dockerfile_yaml
# 基础镜像
FROM hexo:latest

# 维护者
MAINTAINER [维护者信息]

# 工作目录
WORKDIR /hexo

# 修改npm 源，增加npm安装速率
RUN npm config set registry https://registry.npmmirror.com
RUN npm get registry

# 安装 hexo 插件
RUN npm i hexo-prism-plugin --save
# 搜索插件
RUN npm i hexo-generator-searchdb --save
# 汉字转拼音插件
RUN npm i hexo-permalink-pinyin --save

# node 14 报错问题
RUN yarn add hexo-renderer-stylus


# 对外映射端口
EXPOSE 4000

# 运行命令
# CMD ["/bin/bash"]
CMD ["/usr/bin/env", "hexo", "server"]
```

构建镜像

```sh
docker build -t "nextblog:24" -f dockerfile ./
```

## 创建docker compose文件

```yml
version: '3'
services:
  blog:
    restart: always
    build:
        context: hexo_docker
        dockerfile: dockerfile
    image: nextblog:24
    container_name: temp_simple_test
    ports:
      - "4000:4000"
    volumes:
     - $PWD:/hexo
```

执行指令：

```sh
# 启动整个应用
docker-compose up -d

# 停止整个应用
docker-compose down
```

## 其他一些补充

```sh
# 查看 npm 当前安装了哪一些部件以及版本号
npm ls --depth 0

# 安装指定版本
npm i hexo@4.2.0 -g

# 看compose过程中的一些报错
docker-compose logs -f --tail=50
```


## 实例记录

基础镜像 node.js

```
# 获取最新node 
docker pull node:latest
```

创建 dockerfile 文件，用于编译专用镜像:

- docker相关：
  - docker-compose.yml 服务配置文件
  - hexo_docker/ 用于存放Dockerfile文件
- hexo相关：
  - scaffolds/ 存放模版文件
  - source/ 存放用户资源文件，post，draft
  - themes/ 存放主题
- git相关：
  - .deploy_git/ hexo-deployer-git插件用于存放commit历史记录。


```sh
# dockerfile如下
FROM node:latest

MAINTAINER rohman.zhu

WORKDIR /hexo

# 使用国内源
RUN npm config set registry https://registry.npmmirror.com
RUN npm install hexo-cli -g --save
RUN hexo init .
RUN npm install

# 初始化主题
# [TODO] 主题可能会变
# Git 可能获取会超时，需要调整
# RUN git config --global http.version HTTP/1.1
# RUN git clone https://github.com/iissnan/hexo-theme-next themes/next

# 新版本的next需要安装这个插件
RUN npm i hexo-renderer-swig --no-fund --save
RUN npm i hexo-prism-plugin --save
RUN npm i hexo-permalink-pinyin --save

# HEXO 相关的
# 生成 categories 页面
RUN hexo new page "categories"
# 生成 about 页面
RUN hexo new page "about"
# 生成 tag 页面
RUN hexo new page "tags"
# 生成页面
RUN hexo g

# 创建挂载点
VOLUME ["/hexo/.deploy_git", "/hexo/scaffolds", "/hexo/source", "/hexo/themes", "/root/.ssh"]


# 对外暴露 4000 端口
EXPOSE 4000

# 运行命令
# CMD ["/bin/bash"]
# 容器启动后，会默认执行的指令；
CMD ["/usr/bin/env", "hexo", "server"]
```

可以临时编译测试看看；

```sh
# 基于 node:latest 创建一个hexo镜像
docker build -t "hexo:1" .

# 不使用缓存,重新编译
docker build -t "hexo:1" . --no-cache
```

```
# 对创建出来的镜像试运行
docker run -it --name="hexo-temptest" -p 60101:4000  -v $PWD:/hexo/org hexo:1 /bin/bash
```

编写docker compose文件，用于自动生成；

```yml
version: '3'
services:
  blog:
    restart: always
    build:
        context: ./
        dockerfile: dockerfile
    image: hexo:1
    container_name: temp_simple_test
    ports:
      - "60101:4000"
    volumes:
     - $HOME/.ssh:/root/.ssh
     - $PWD/.deploy_git:/hexo/.deploy_git
     - $PWD/scaffolds:/hexo/scaffolds
     - $PWD/source:/hexo/source
     - $PWD/themes:/hexo/themes
     - $PWD/_config.yml:/hexo/_config.yml
```

服务创建完成后，常用指令为：

```sh
# 启动服务
# 进入compose文件所在的目录
docker-compose up -d

# 创建新文章
docker exec [blog_docker 名称] hexo new "文章名"

# 生成文章静态页面
docker exec [blog_docker 名称] hexo g 

# 发布文章至github
docker exec [blog_docker 名称] hexo d

# 关闭服务
docker-compose down

# 创建指令别名
alias hexo="docker exec [blog_docker 名称] hexo"
```