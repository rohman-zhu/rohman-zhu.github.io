---
title: Linux磁盘IO性能观测
tags:
  - 监控
categories:
  - Linux
date: 2022-09-05 23:48:55
---

# 说明

用于检查磁盘性能IO情况、读写情况。

# iostat

常用指令

```sh
# 间隔1s输出结果
iostat -x 1
```

# sar

```sh
sar -d 1 10
```

# atop

```sh
atop -dl
```

# iotop

# dstat
