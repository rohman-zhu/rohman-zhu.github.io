---
title: Ubuntu下安装VmwareWorkstation无法启动
date: 2018-10-11 23:19:47
tags: 
- Ubuntu
- 软件安装
catergories:
- Linux
---



# 系统信息

- Ubuntu 14.04.3 Kylin
- 3.3.56-genric 的内核
- gcc版本
- Vmware Workstation 11\14\15 (都试过安装)



# Vmware 安装步骤

```shell
# 下载VM安装文件到当前目录，vmware...bundle
# 添加可执行权限
# chmod +x ./vmware...bundle
# sudo ./vmware...bundle
# 接着图形界面安装即可
```

# 报错信息

## version11

- 控制台会提示 无法加载主题引擎 ‘murrine‘ ， 并且会有字体配置文件错误的提示。

- 打开软件会提示两个内核模块没有加载成功 ： vmmon 、 vmnet



## version12

- 控制台会提示 无法加载主题引擎 ‘murrine‘ ， 并且会有字体配置文件错误的提示。

- 打开虚拟机会提示，无法找到 '/dev/vmmon'目录或者文件夹。

## version14

- 控制台会提示 无法加载主题引擎 ‘murrine‘ ， 并且会有字体配置文件错误的提示。

- 打开虚拟机会提示，无法找到 '/dev/vmmon'目录或者文件夹。

## version15

- 控制台无错误信息。

- 打开虚拟机会提示，无法找到 '/dev/vmmon'目录或者文件夹。



# 网络上的解决方案



## 手动复制 vmmon.ko

## 安装必须的gtk内核

## 修改vmware补丁的配置文件（未尝试）

## 执行vmware提供的命令生产vmmon
