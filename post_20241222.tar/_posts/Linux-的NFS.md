---
title: Linux 的NFS
date: 2017-10-14 10:08:01
tags: Linux
---
# Network File System #

## 1.什么是NFS？ ##

Network File System，即是网络文件系统。它允许网络中的计算机之间通过TCP/IP网络共享资源。在NFS的应用中，本地NFS的客户端应用可以透明地读写位于远端NFS服务器上的文件，就像访问本地文件一样。

## 2.NFS的组成 ##

NFS体系至少有两个主要部分：

* 一台NFS服务器
* 若干台客户机

## 3.组成NFS需要的条件 ##

* IP地址 与 端口号
* RPC 服务

### 3.1什么是RPC 服务 ###

RPC（Remote Procedure Call Protocol）——远程过程调用协议，它是一种通过网络从远程计算机程序上请求服务，而不需要了解底层网络技术的协议。RPC协议假定某些传输协议的存在，如TCP或UDP，为通信程序之间携带信息数据。在OSI网络通信模型中，RPC跨越了传输层和应用层。RPC使得开发包括网络分布式多程序在内的应用程序更加容易。

> 至于为什么用到RPC服务？ 简单的理解就是，客户机要访问NFS服务器，需要一个中介（RPC）来处理这些请求，减少NFS服务器的工作量。

## 4.安装步骤 ##

分为两部分:客户端和服务端

### 4.1 服务端 ###

需要安装两个软件rpcbind与nfs-utils

* rpcbind--centos 下面RPC主程序
* nfs-utils--NFS服务主程序，包括NFS的基本命令和监控程序

```{.Linux}
# 安装必要软件
# yum install rpcbind nfs-utils

# 开启RCP服务
# /etc/init.d/rpcbind start

# 检查服务端口号码
# netstat -lntup | grep rpcbind

# 检查rpc服务是否有端口注册
# rpcinfo -p localhost

# 创建存放数据的文件夹
# mkdir /data
# 更改该文件夹的权限
# chown -R nfsnobody.nfsnobody /data

# 修改配置文件
# vi /etc/exports
#-----------------
/data 172.16.1.0/24(rw,sync)
#-----------------

# 开启NFS服务
# /etc/ini.d/nfs start

```

### 4.2 客户端 ###

```{.Linux}
# 开启rpcbind服务程序
# /etc/init.d/rpcbind status

# 挂载共享目录
# mount -t nfs 172.16.1.31:/data /mnt

```

## 4.配置NFS共享的文件 ##

配置文件是/etc/exports。

```{.normal}
格式如下：
共享的目录   客户端访问的地址（可配参数）
/data   10.0.0.7(rw,sync)
```

### 可配参数讲解 ###

参数列表如下：
|   参数  |      意义   |
|:------:|:---------:|
|   rw  |   表示可读写权限 |
|   ro  |   表示只读权限  |
|   sync    |   请求或写入数据时，数据同步到写入到NFS Server的硬盘中（数据安全，不容易丢失，缺点就是会导致性能比不启动该参数时要差  |
|   async   |  异步写入，即是将数据写入内容，但是机器断电后，数据会丢失 |
|   no\_root_squash  |  用户是root登录，则将该目录赋予 root权限 |
|   all_squash  |   客户端用户访问，则会被压缩成匿名用户--nfsnobody   |
|   anounuid    | anon*开头，指的时anonymous匿名用户，设置匿名用户id    |
|   anongid |   设置匿名用户组的id  |

## 5.NFS故障排错 ##

在运行NFS服务或者挂载NFS服务器下的文件目录时，可能会遇到以下错误。

### No route to host ###

这种情况要检测以下防火墙，甚至是把_iptables_服务关闭。

### RPC:Programm not registered ###

这个可能是启动顺序出了问题，NFS服务在RPC服务前启动，造成RPC的程序不能正常注册。

```{.normal}
正常启动顺序
# /etc/init.d/rpcbind start
# rpcinfo -p localhost
# /etc/init.d/nfs start
# rpcinfo -p localhost
```

### 客户端挂载nfs文件的时候出现"No file or directory" ###

这种情况一般是NFS服务器里面不存在这个文件夹或目录，只要创建了即可。

## 客户端挂载NFS服务器的文件夹 ##

格式如下：

> mount NFS服务器的地址 挂载点

</br>

如 mount 10.0.0.7:/data /mnt

</br>

如果追求极致，也可以这么做：

> mount -t nfs bg,hard,intr,rsize=131072,wsize=131072 10.0.0.7:/data /mnt

### 关于mount的参数 ###

* -a：把/etc/fstab中列出的路径全部挂载。
* -t：需要mount的类型，如nfs等。
* -r：将mount的路径定为read only。
* -v mount：过程的每一个操作都有message传回到屏幕上。
* rsize=n：在NFS服务器读取文件时NFS使用的字节数，默认值是1 024个字节。
* wsize=n：向NFS服务器写文件时NFS使用的字节数，默认值是1 024个字节。
* timeo=n：从超时后到第1次重新传送占用的1/7秒的数目，默认值是7/7秒。
* retry=n：在放弃后台mount操作之前可以尝试的次数，默认值是7 000次。
* soft：使用软挂载的方式挂载系统，若Client的请求得不到回应，则重新请求并传回错误信息。
* hard：使用硬挂载的方式挂载系统，该值是默认值，重复请求直到NFS服务器回应。
* intr：允许NFS中断文件操作和向调用它的程序返回值，默认不允许文件操作被中断。
* fg：一直在提示符下执行重复挂载。
* bg：如果第1次挂载文件系统失败，继续在后台尝试执行挂载，默认值是失败后不在后台处理。
* tcp：对文件系统的挂载使用TCP，而不是默认的UDP。

一般hard参数与intr参数一同使用，防止NFS锁死。

来自网友的总结：

> 采用hard mount，NFS客户机会不断地尝试与NFS服务器连接（在后台一般不会给出任何提示信息），直到挂载上为止。
> 采用soft mount，会在前台尝试与NFS服务器连接，当收到错误信息后终止mount尝试，并给出相关信息。

## NFS挂载优化 ##

### 实例一：一个NFS服务器共享的只是普通静态数据，不需要执行suid、exec等权限，挂载的这个文件系统只能作为数据存取之用，无法执行程序，对于客户端来讲增加了安全性。 ###

安全挂载参数：
> mount -t nfs -o nosuid,noexec,nodev,rw 10.0.0.7:/data /mnt

通过 mount -o 指定挂载参数和在/etc/fstab 里指定挂载参数效果时一样的。

</br>

禁止更新目录以及文件时间戳挂载：
> mount -t nfs -o noatime,nodiratime 10.0.0.7:/data /mnt

</br>

安全加优化的挂载方式：
> mount -t nfs -o nosuid,noexec,nodev,noatime,nodiratime,nodiratime,intr,rsize=65536,wsize=65536 10.0.0.7:/data /mnt

## NFS 优缺点 ##

### 优点 ###

1. 简单
1. 所有数据都是在文件系统上，即都可以看得见。
1. 方便，因为可以快速部署，维护简单。
1. 可靠；从软件层面来讲要可靠一些。
1. 稳定。

### 缺点 ###

1. 存在单点故障，如果NFS服务器端宕机，所有C端的机器都不能连接NFS服务器。
1. 大数据高并发的场合，NFS效率与性能有限。
1. 客户端认证基于ip和主机名，权限是根据ID识别的，安全性一般。
1. NFS数据都是明文。
1. 耦合度高，不易于维护.