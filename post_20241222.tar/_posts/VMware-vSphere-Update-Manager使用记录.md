---
title: VMware vSphere Update Manager使用记录
tags:
  - default
categories:
  - VMware
date: 2023-04-02 17:01:14
---
# 背景

ESXi 经常需要更新补丁，常规做法是将补丁包上传到目标存储存储卷里面，然后在目标ESXi内执行升级指令，并重启ESXi；

常用指令：

```sh
esxcli software vib update -d /vmfs/xxxxxxxx.zip
```
# 什么是Lifecycle Manager

生命周期管理是指安装软件、通过更新和升级维护软件，以及取消配置软件的过程。
在维护 vSphere 环境（特别是维护集群和主机）的情况下，生命周期管理是指在新主机上安装 ESXi 和固件以及在需要时更新或升级 ESXi 版本和固件等任务。

vSphere Lifecycle Manager 是一项在 vCenter Server 中运行并使用嵌入式 vCenter Server PostgreSQL 数据库的服务。不需要进行额外的安装即可开始使用该功能。部署 vCenter Server Appliance 后，vSphere Lifecycle Manager 用户界面将在基于 HTML5 的 vSphere Client 中自动启用。

vSphere Lifecycle Manager 包含以前 vSphere 版本中 Update Manager 提供的功能，并进行了增强，增加了在集群级别进行 ESXi 生命周期管理的新功能和选项。

在低于 7.0 的 vSphere 版本中，您可以通过 Update Manager 使用基准和基准组执行主机修补和主机升级操作。从 vSphere 7.0 开始，vSphere Lifecycle Manager 引入了一种替代方法，可使用 vSphere Lifecycle Manager 映像管理环境中主机和集群的生命周期。此外，还可以使用 vSphere Lifecycle Manager 升级环境中虚拟机的虚拟机硬件和 VMware Tools 版本。

vSphere Lifecycle Manager 可以在能够访问 Internet（直接访问或通过代理服务器访问均可）的环境中运作。也可以在无法访问 Internet 的安全网络中运作。在这种情况下，可以使用 Update Manager Download Service (UMDS) 将更新下载到 vSphere Lifecycle Manager 库，也可以手动导入更新。

# 使用说明

这里可以用 vCenter 的 Lifecycle Manager 功能 ，来统一下发指令安装补丁；

| 操作	| 描述 |
|:----:|:-----:|
| 合规性检查 |	扫描 ESXi 主机的操作，用于确定这些主机对附加到集群的基准或集群所用映像的合规性级别。合规性检查不会改变对象。|
| 修复预检查 |	在修复之前执行的操作，用于确保集群的运行状况良好并且在修复过程中不会出现任何问题。|
| 修复	| 将软件更新应用到集群中 ESXi 主机的操作。在修复过程中，会在主机上安装软件。修复会使不合规的主机符合附加到集群的基准或集群的映像。|
| 正在转储	| 仅适用于使用基准或基准组管理的集群的操作。将修补程序或扩展转储到 ESXi 主机时，可以将修补程序和扩展 VIB 下载到主机，而不立即应用。转储使修补程序和扩展可在主机本地使用。|

## 相关术语

|术语|	定义|
|:----:|:---:|
|VIB| 元数据	描述 VIB 内容的 XML 文件 (descriptor.xml)。它还包含依赖项信息、文本描述、系统要求和有关公|告的信息。
|独立 VIB| 	未包含在公告或组件中的 VIB。| 

vSphere Lifecycle Manager 不使用各个 VIB。VIB 必须进一步打包为更高级别的构造。

## 基础映像（镜像）

基础映像是 VMware 在每个 ESXi 版本中提供的 ESXi 映像。基础映像是完整且可引导服务器的组件集合。基础映像具有用户可读的名称和唯一版本（随 ESXi 的每个主要版本或次要版本更新）。

基础映像的版本与 ESXi 版本相对应，并使用以下命名格式：
- 正式发布版本：7.0
- 更新版本：7.0 U1、7.0 U2
- 修补程序版本：7.0 a、7.0 b
- 安全修补程序版本：7.0 sa、7.0 sb
- 更新后的修补程序版本：7.0 U1 a、7.0 U1 sa、7.0 b、7.0 sb

基础映像托管在 VMware 联机库中并可供使用。此外，还可以从 my.vmware.com 下载包含 ESXi 版本的 ESXi 安装程序 ISO 文件和脱机包（ZIP 文件）。

### 映像一般有什么？

vSphere Lifecycle Manager 映像可以包含以下四个元素：

ESXi 基础映像： 

- 基础映像包含 VMware ESXi Server 的映像，以及引导服务器所需的驱动程序和适配器等附加组件。基础映像是 vSphere Lifecycle Manager 映像中的唯一必需元素。所有其他元素是可选元素。

供应商加载项：
- 供应商加载项是 OEM 创建和分发的软件组件集合。供应商加载项可以包含驱动程序、修补程序和解决方案。

固件和驱动程序加载项：
- 固件和驱动程序加载项是一种特殊类型的供应商加载项，旨在帮助执行固件更新过程。固件和驱动程序加载项包含特定服务器类型的固件和相应驱动程序。要将固件和驱动程序加载项添加到映像中，您必须安装相应集群中的主机所对应的硬件供应商提供的硬件支持管理器插件。

独立组件：
- 组件是映像中的最小离散单元。添加到映像中的独立组件包含第三方软件，例如，驱动程序或适配器。

## 网络需求

```sh
SRC: ESXi
DST: vCenter 
TCP: 9084
```

如果vCenter使用的是FQDN，则ESXi需要配置 DNS ；

# 参考资料

- 关于 vSphere Lifecycle Manager ：  https://docs.vmware.com/cn/VMware-vSphere/7.0/com.vmware.vsphere-lifecycle-manager.doc/GUID-74295A37-E8BB-4EB9-BFBA-47B78F0C570D.html
- 安装包： https://my.vmware.com
