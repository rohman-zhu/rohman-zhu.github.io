---
title: 基于坚果云的WedDav功能创建keepass云同步服务
tags:
  - 坚果云
  - keepass
categories:
  - default
date: 2024-10-06 11:51:20
---

# 需求说明

keepass是一款免费开源的密码管理软件，使用起来稍微麻烦一些（免费，所以比1password强）。但keepass有一个缺点就是没有数据同步，对于多个客户端使用会造成不便，所以强如 keepass 也会有云同步的困扰；
今天看到坚果云支持Webdav ，免费容量1GB，上传流量1GB，下载流量3GB，每30天重置一次；（https://www.jianguoyun.com/#/setting/）对于传输密码文件已经足够了。但如果密码文件仅存放在云上，心里还是有担忧，万一云无法访问或者数据销毁了怎么办？
所以本地仍然需要保留一份数据副本，刚好可以利用DSM的Cloud Sync功能，设置定期单向同步，将云上的数据拉取下来。


所以本文会分为三部分：

1. 坚果云设置WebDav；
2. DSM设置Cloud Sync；
3. keepass客户端读取云上kdbx；

> 把密码安全的命交给 坚果云厂商 与 keepass 开源软件，多少有点搞笑 ...

## 坚果云设置

1. 注册账户，本步骤忽略；但是创建完账户后一定要开启二次验证，无论是谷歌二次验证还是微信二次验证，我建议是微信二次验证，跟微信绑定；
2. 到账户中心的安全选项（https://www.jianguoyun.com/#/safety），点击添加应用，会自动生成应用密码；
3. 记录 服务器地址，格式为 https://dav.jianguoyun.com/dav/[文件目录] ， 账户名 ， 应用密码；

## DSM中的Cloud Sync设置

1. 打开DSM中的Cloud Sync；
2. 点击添加按钮，选择 WebDav；
3. 输入服务器地址，用户账户，密码（这个密码是坚果云的应用密码，不是坚果云的登录密码）；
4. 设置同步文件的方向，需要将目标文件同步至本地，需要将文件拉取到本地文件夹，即设置为单向传输；
5. 设置任务同步时间，计划是每天的0点执行；避免太消耗流量；

## keepass客户端读取云上的kdbx文件

打开keepass客户端，点击 Open from URL，输入对应信息；

对于IOS客户端，目前还没有想到好的方法，我是使用坚果云客户端，将tdbx文件下载到本地；然后用keepassium客户端去读取本地文件；

### 客户端开启 安全桌面功能，避免键位记录软件

Options>Advanced>Enter master key on scure desktop



# 参考地址

坚果云：https://www.jianguoyun.com/
KeePass如何搭配坚果云实现多设备同步？：https://help.jianguoyun.com/?p=3348
Keepassxc+Keepass2Android+坚果云密码管理方案： https://segmentfault.com/a/1190000041381245
https://zhuanlan.zhihu.com/p/134513911
https://help.jianguoyun.com/?p=3348