---
title: LNMP-Zabbix管理员账户密码重置
tags:
  - default
categories:
  - default
date: 2022-11-24 00:06:38
---
# 背景

Zabbix业务系统默认的密码忘记了，现在持有服务器的登录权限以及数据库权限，需要登录进数据库重置密码。

# 解决方法

## Zabbix 5.0 以前的版本

```sh
# 密码转md5
echo -n 'NEW PASSWORD' | openssl md5

# 登录进数据库
mysql -u root -p
# 输入数据库密码
```

```sql
/*切换数据库*/
use zabbix;
/*查询数据库内的表*/
show tables;
/*查询用户列表*/
select * from users;
/*更新密码*/
update users set passwd='NEW PASSWORD[MD5]' where userid ='1';
/*刷新权限*/
flush privileges;
```

## Zabbix 5.0 以后的版本

5.0后需要使用Bcrypt密码加密，而不能使用MD5加密的密文；

> bcrypt，是一个跨平台的文件加密工具。由它加密的文件可在所有支持的操作系统和处理器上进行转移。它的口令必须是8至56个字符，并将在内部被转化为448位的密钥。bcrypt 使用的是布鲁斯·施内尔在1993年发布的 Blowfish 加密算法。具体来说，bcrypt 使用保罗·柯切尔的算法实现。随 bcrypt 一起发布的源代码对原始版本作了略微改动。

在线工具：https://www.bejson.com/encrypt/bcrpyt_encode/

```sql
/*切换数据库*/
use zabbix;
/*查询数据库内的表*/
show tables;
/*查询用户列表*/
select * from users;
/*更新密码*/
update users set passwd='NEW PASSWORD[Bcrypt]' where userid ='1';
/*刷新权限*/
flush privileges;
```

# 参考资料

- 自 5.0 Zabbix 从md5哈希算法切换到bcrypt：
https://www.zabbix.com/forum/zabbix-troubleshooting-and-problems/410430-reset-admin-password-for-zabbix-lts-5-0
- zabbix密码重置：
https://blog.51cto.com/u_13045706/3835020
- 在线生成Bcrypt密码
https://www.bejson.com/encrypt/bcrpyt_encode/