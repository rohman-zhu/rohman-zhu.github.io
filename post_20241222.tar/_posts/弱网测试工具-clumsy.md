---
title: 弱网测试工具--clumsy
tags:
  - 网络
categories:
  - Windows Server
date: 2024-10-20 19:20:08
---

# 需求描述

需要模拟时延、丢包等网络条件问题对业务的影响，最近看到有一款软件可以满足这个需求 clumsy。故做一下使用记录。

## 开始模拟

使用的版本一定要为 0.4 版本，测试过程会较老版本稳定

### 时延 LAG

1. presets = outbound ;
2. Lag 勾选
3. Delay(ms): 输入需要的时延；

参考参数：
- 0ms ， 用于记录软件自身的时延，以及波动偏差；
- +10ms、+15ms为梯度去测试；（根据实际业务环境去实测）


# 参考资料

https://gulut.github.io/gulut-blog/post1/2020/09/20/2020-09-20-clumsy-a-bad-net-test-tool/
http://jagt.github.io/clumsy/manual.html
