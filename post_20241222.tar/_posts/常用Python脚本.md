---
title: 常用Python脚本
tags:
  - 常用指令
  - 脚本
categories:
  - 基础知识
  - 编程
  - Python
date: 2023-11-09 00:07:43
---

# 条件判断

```py
if (判断语句):
    执行条件
```

> 没有{}，没有; ，注意缩进格式，注意: 。

| 含义 | 符号 |
|:---:|:---:|
| 大于 | > |
| 小于 | < |
| 大于等于 | >= |
| 小于等于 | <= |
| 赋值 | = |
| 相等 | == |
| 不等 | != |
| 相等(对象)| is |
| 不等(对象) | is not |
| 逻辑非 | not |
| 逻辑与 | and |
| 逻辑或 | or |
| 位运算 或 | \| |
| 位运算 异或 | ^ |
| 位运算 与 | & | 

# 函数体

```py
# 定义函数
def 函数名(形参):
    函数体

# 调用函数
函数名(实参)
```

# 逐行读取文本

> 节省内存,但会比较慢

```py
FILE = Open('文件绝对路径‘)
LINE = FILE.readline()
while LINE:
    print(LINE)
    LINE = FILE.readline()
FILE.close()
```

参考 ： https://www.cnblogs.com/Kingfan1993/p/9570079.html

# 字符串分割

```py
string="world;world2;word"
stringSet=string.split(";")
stringSet[0]
stringSet[1]
stringSet[2]
```

# 字符型与整型转化

```py
num_str="123"
num_int=int(num_str)

num_str=str(num_int)
```

# 时延函数

```py
time.sleep(秒)
```

# 其他规则

1. Python严格区分大小写