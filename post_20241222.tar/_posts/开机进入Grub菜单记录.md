---
title: 开机进入Grub菜单记录
tags:
  - Linux
  - Grub
categories:
  - 物理服务器
date: 2022-01-21 23:11:01
---

# 背景

有一台Linux服务器忘记密码了，需要进入单用户模式下修改密码。


# 操作方式

在BIOS转操作系统的时候：

方法1：按shift键
方法2：按ESC键（一次）
方法3：在Loading 系统的时候，发送Ctrl + Alt + del触发重启。