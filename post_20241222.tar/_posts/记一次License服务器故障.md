---
title: 记一次License服务器故障
tags:
  - 故障
categories:
  - Windows Server
date: 2021-11-07 23:16:22
---

# 背景

一个授权服务器需要加载dat文件来开启服务，然而dat文件算出的机器码值不一致。

# 原因

跟虚拟机的CPU、网卡Mac地址有关。

判断MAC地址是否有变化，可以通过检查虚拟机日志查看。
