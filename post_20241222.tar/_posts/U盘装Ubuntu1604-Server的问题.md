---
title: U盘装Ubuntu1604-Server的问题
date: 2018-12-04 21:41:11
tags: Linux
---

# 前言

用软碟通制作 Ubuntu1604-Server 的启动盘，安装到自检的时候，会发现镜像没有挂载上去，安装完系统后发现系统没有GCC、MAKE，以及其他未知的系统问题。

目前遇到的是：

* 安装过程中会中断，提示“Failed to copy file from CD-ROM” 。
* 安装完后系统没有 gcc 和 make。

# 实际操作

## 问题一 ：安装中断的问题，提示无法从CD-ROM中复制文件

使用软碟通 Ultraiso 制作的启动盘都会有这个问题。

解决方法是强行挂载 iso 镜像到 cdrom 下。

```shell
# 当出现错误提示的时候 ， “Failed to copy file from cd-rom , retry?"
# 按 ctrl + alt + F2
# 按 Enter 键
# 卸载 usb 设备，重新挂载
umount /dev/sdx4
# 挂载 usb 设备
mount /dev/sdx4 /mnt
# 把 usb 设备中的 iso 镜像挂载到 cdrom 上面。
# U 盘中需要放置 ubuntu 的系统镜像文件。
mount -o loop /mnt/ubuntu-16.04.5-server.iso /cdrom
# 按 ctrl + alt + F1 回到安装界面
```

## 问题二 ：安装完后没有 gcc 和 make

目前还不知道原因，默认安装完后，系统没有带 gcc 和 make ，同时又没有外网环境，只能挂载光盘源来安装。

```shell
# 挂载系统的 iso 镜像到 /cdrom 下 
mount -o loop /opt/ubuntu-16.04.5-server.iso /cdrom
# 更改 apt 源文件
vim /etc/apt/sources.list
#--- sources.list ---#
deb file:///media/cdrom xenial main
#--- sources.list ---#
# 更新源后安装即可。
apt-get update
apt-get install gcc make
```
![Linux版本](https://img-blog.csdn.net/20171110214349379?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvaHpkMTIzNjg=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/Center)

# Linux知识补充

## loop 设备

在类 UNIX 系统里，loop 设备是一种伪设备(pseudo-device)，或者也可以说是仿真设备。它能使我们像块设备一样访问一个文件。

# 参考资料

* 光盘中安装 gcc、make ： https://blog.csdn.net/hzd12368/article/details/78503315
* Linux中的loop设备 ： https://blog.csdn.net/ustc_dylan/article/details/6878252