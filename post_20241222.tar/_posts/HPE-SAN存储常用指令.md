---
title: HPE SAN存储常用指令
tags:
  - default
categories:
  - 服务器与存储
  - 存储
  - SAN存储
date: 2024-05-03 17:54:31
---

# 常用指令集

## 查询类

### 查询后端存储端口流量

```sh
statport -disk -ni
``` 

### 查询盘笼状态

```sh
showcage
```

### 查询 PD 状态，即硬盘状态

会显示该硬盘的总容量、使用量、可用容量、热备空间；

```sh
showpd -c
```

### 查询系统信息

序列号、总容量、已分配容量、空闲容量；

> 注意精简置备带来的影响！

```sh
showsys -d
```

### 查询CPG策略

```sh
showcpg
```

### 查询CPG对应的容量分配

```sh
showspace -cpg [CPG_NAME]
```

### 查询任务

```sh
showtask

# 查询具体任务信息
showtask -d [PID]
```
