---
title: Windows性能计数器-磁盘性能分析【待补充】
tags:
  - 监控
categories:
  - Windows Server
date: 2022-12-20 00:07:29
---
# 背景

监控方案中，需要监控磁盘相关性能指标，因此需要选用相关参数用于监控。

选用的指标：

- 磁盘总IO
- 磁盘读IO
- 磁盘写IO
- 进程读IO
- 进程写IO
- 磁盘队列【重要】
- 磁盘带宽

# 参考资料

《Windows性能计数器--磁盘性能分析Disk》： https://www.cnblogs.com/dreamer-fish/p/3769816.html
《关于Windows主机的性能监控》：https://www.cnblogs.com/mingmingrose/p/3657557.html
《Microsoft Windows相关指标》https://doc.octoperf.com/monitoring/create-connection/microsoft-windows/