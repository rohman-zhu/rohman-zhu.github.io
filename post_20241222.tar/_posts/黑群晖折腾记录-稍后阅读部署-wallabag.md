---
title: 黑群晖折腾记录_稍后阅读部署_wallabag
tags:
  - docker
categories:
  - 服务器与存储
  - 存储
  - NAS存储
date: 2024-10-19 20:23:33
---
# 前言

最近在什么值得买里面看到稍后阅读的服务 wallabag ，于是想利用这个组建搭建一个私有化的服务器用于保留日常记录的网页信息。

# 开始部署

本地化部署是需要 数据库 + 应用的

## 安装数据库

```sh
docker pull mariadb

# 启动数据库容器
# 配置的关键参数是MARIDB_ROOT_PASSWORD \ TZ
```

## 安装 wallabag

### 拉取镜像

```sh
docker pull wallabag/wallabag

# 国内有保护，需要使用代理
docker pull dockerproxy.cn/wallabag/wallabag
```

### 启动 wallabag 容器

```sh
# 1. 设置网页缓存路径
# docker 内关键路径：/var/www/wallabag/web/assets/images

# 2. 设置端口映射，默认是使用80端口

# 3. 设置数据库路径
关键参数：
MARIDB_ROOT_PASSWORD	
SYMFONY__ENV__DATABASE_DRIVER	
SYMFONY__ENV__DATABASE_PORT
SYMFONY__ENV__DATABASE_NAME
SYMFONY__ENV__DATABASE_USER
SYMFONY__ENV__DATABASE_PASSWORD
SYMFONY__ENV__DATABASE_CHARSET

# 4. 设置对外映射环境
SYMFONY__ENV__DOMAIN_NAME
SYMFONY__ENV__SERVER_NAME
SYMFONY__ENV__FOSUSER_CONFIRMATION
SYMFONY__ENV__TWOFACTOR_AUTH	
```

### 初始化

默认密码 wallabag/wallabag

# 思考或待办

1. 在部署maridb 、 wallabag 的容器时，均会涉及到目录文件权限的问题，docker的日志中会提示权限不足，无法写入；对应的解决方法是将目录权限改为 Everyone，这个风险很大，需要解决；
2. 导出会有乱码问题，应该是字符集没有设置好导致的；
3. 部署至公有云，则可以通过移动端采集，服务器端自动记录；

# 参考资料

1. 保存网页、稍后阅读，自建 Wallabag 服务也是一种选择 ：https://sspai.com/post/52979
2. 官方文档：https://doc.wallabag.org/en/admin/installation/installation.html#installation
3. 部署说明：https://www.christian-knedel.de/zh/post/2021/april/20210418-docker-wallabag/