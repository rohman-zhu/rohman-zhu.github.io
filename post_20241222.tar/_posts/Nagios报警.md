---
title: Nagios报警
date: 2017-12-09 14:57:14
tags: Linux
---

# Nagios监控报警 #

报警的常用方式有这几种,邮件, _http短信网关_ ,短信猫,电话语音报警,MSN,QQ,微信等.

## 短信报警实战配置 ##

```sh

# 第一步添加联系人
vi contact.cfg

define contact{
    use generic
    contact_name Rohman
    email xx@126.com
}

#==

define contactgroup{
    contact_groupname admins
    alias centos_admins
    members Rohman,Jack,John...
}

# 第二步在command添加命令

vi commands.cfg

define command{
    command_name notify-host-by-email
    command_line xxxxx
}

# 第三步在联系人里面添加pager即电话
define contact{
    use generic
    contact_name Rohman
    email xx@126.com
    pager 18267232322
}

# 第四步在调整联系人模板,联系人里面添加 host_notification_commands 命令
define contact{
    ...
    host_notification_commands notify-host-by-email
}

# 第五步在hosts.cfg,service.cfg添加联系人组或者联系人
define host{
    contact_groups xx
    user xxx
}

# 第六步开发报警脚本

略

# 第七步把脚本添加到command

```

> 短信网关要钱的 -.-