---
title: 'Ubuntu内核升级or降级实例'
date: 2018-11-05 23:09:37
tags:
  - 内核
categories:
  - Linux
---

# 前言

记一次对ubuntu内核升降级的操作。

# 升级

## 环境

* OS ： Ubuntu 16.04.5-LTS
* Kernel ： 4.4.0-131-generic

## 升级操作

总共就两步： 

1. 安装新版内核
2. 更新 grub 

```shell
# 主要安装 linux-image-xxxxxx
# 主要安装 linux-headers-xxxxxx
# linux-image-版本号：内核映像文件
# linux-headers-版本号：内核头文件
# linux-image-extra-版本号：内核扩展文件记住，不能删除当前使用的内核版本。一般有些服务器的驱动需要额外安装，此包最好也安装一下

# 安装 4.4.0-137-generic 内核
apt install linux-image-4.4.0-137-generic  linux-headers-4.4.0-137 linux-headers-4.15.0-29-generic linux-image-extra-4.4.0-137 -y
# 更新 grub
update-grub
# 重启即可
init 6
```

# 降级

## 环境

* OS ： Ubuntu 16.04.5-LTS
* Kernel : 4.4.0-138-generic

## 降级操作

总共就三步： 

1. 安装新版内核
2. 修改grub启动文件
3. 更新 grub 

```shell
# 安装 4.4.0-137-generic 内核
# 主要安装 linux-image-xxxxxx
# 主要安装 linux-headers-xxxxxx
# linux-image-版本号：内核映像文件
# linux-headers-版本号：内核头文件
# linux-image-extra-版本号：内核扩展文件记住，不能删除当前使用的内核版本。

# 安装 4.4.0-137-generic 内核
apt install linux-image-4.4.0-137-generic  linux-headers-4.4.0-137 linux-headers-4.15.0-29-generic -y
# 修改 grub文件
vim /etc/default/grub

#---/etc/default/grub
GRUB_DEFAULT="Ubuntu, Linux 4.4.0-137-generic"
# 内核启动顺序参照Linux内核启动顺序修改.md，避免无法正确使用。
#---/etc/default/grub

# 更新 grub
update-grub
# 重启即可
init 6
```

# 后记

暂不知内核变更是否会对运行的服务有什么影响。