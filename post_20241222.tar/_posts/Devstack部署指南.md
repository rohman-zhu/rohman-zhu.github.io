---
title: Devstack部署指南
date: 2018-06-23 16:23:14
tags: Virtualization
---

# OpenStack 云系统

## 下载

```sh
#Ubuntu
sudo apt-get install git
git clone https://github.com/openstack-dev/devstack.git
```

> Git一般通过两种协议实现传输 ： http（https） 和 ssh

## 源码结构

主目录
---

* 自动化部署的入口 stack.sh
* 卸载脚本 unstack.sh
* 配置文件，用于传入stack.sh的参数 localrc （nova部署在拿一个节点 、设置用户名和密码等)
* 环境变量的脚本 openrc
* 每个服务的自动化安装脚本 lib\ (nova、swift等自动化安装脚本 ； 手动安装时执行的所有命令 ； 每一个openstack服务对应一个文件 )

lib目录
---

* database 对应的是数据库 ， 默认为 MySQL 数据库
* nova 实现虚拟化技术的脚本 （可支持 vsphere 、 xen 等）
* neutron 对应网络通用自动化安装脚本 (支持 nuage 、 linuxbridge 、 vmware_nsx 、 ml2 、 openvswitch 、 ryu等)
* cinder 对应存储方面的自动化安装脚本 （支持 nfs 、 vsphere 等）
* heat 应用的自动化部署 （类似 AWS cloudformation）
* ceilometer 实现监控和计费
* sahara 结合大数据方面的hadoop项目
* ironic 实现 PXE +IPMI ， 物理节点的自动化部署 ， 可管理虚拟机和物理机
* trove 将数据库部署到openstack的虚拟机上
* tempest 单元测试框架
* opendaylight 开源的SDN控制器
* ladp 轻量型目录访问协议 ， 与keystone整合 ， 实现多级用户的鉴权

## devstack 两种执行方式

### 执行原理

stack.sh 判断是否存在localrc文件是否存在

* 如果不存在，则进入交互模式
* 存在则进入

### localrc

```config
#默认采用mysql数据库
DATABASE_TYPE=postgresql
# 消息队列 （Message Queue）
Rabbit ， qpid ，zeromq


# 启动服务
ENABLED_SERVICES=rabbit
ENABLED_SERVICES+=-rabbit
#上面的+=类似于C语言中的二元运算符
# 禁用服务
DISABLED_SERVICE=rabbit

```

## 安装过程中的报错日志 ##

```
E: Unable to locate package libsystemd-dev
```

从官网上面（https://docs.openstack.org/devstack/latest/） 支持最好的是 ubuntu 1604 。

更换为 1604 去安装devstack 

```
# E: stack is not in the sudoer file .
# A: 把stack用户添加进sudoers列表中
#    切换到root用户，给 /etc/sudoers 添加写入权限
#    添加 stack ALL =（ALL:ALL) ALL

su - root
chmod u+r /etc/sudoers
echo "stack ALL=(ALL:ALL) ALL" >> /etc/sudoers


# E:权限不足问题,比如无法创建or打开：/usr/local/lib/python2.7/dist-packages/parsley.pyc 
# A:添加权限

sudo chown -R stack:stack /usr/local/lib/python2.7/dist-packages/

# error processing package mysql-server (--configure):

```Gt