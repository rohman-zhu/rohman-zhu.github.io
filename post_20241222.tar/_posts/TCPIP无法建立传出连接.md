---
title: TCPIP无法建立传出连接
tags:
  - 故障
catergories:
  - Windows Server
date: 2020-02-03 22:23:16
---
# 前言

事件4227

## 查看端口

```bat
rem 查看动态端口范围
netsh int ipv4 show dynamicport tcp
netsh int ipv4 show dynamicport udp
netsh int ipv6 show dynamicport tcp
netsh int ipv6 show dynamicport udp

```

```ps1
get-NetTcpConnection | group-object -Property state,owningprocess
```

## 注册表调整TcpTimedWaitDelay值

默认情况下，这个值为4分钟；

REG_DWORD

## 调整扩展动态端口范围

```cmd
netsh int ipv4 set dynamicport tcp start = 10000 num = 20000
```

# 参考资料

https://blog.csdn.net/u010133338/article/details/80961256