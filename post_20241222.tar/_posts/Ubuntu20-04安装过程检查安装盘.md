---
title: Ubuntu20.04安装过程检查安装盘
tags:
  - Ubuntu
categories:
  - Linux
date: 2020-12-22 23:36:34
---

# 故障现象

服务器KVM安装Ubuntu 20.04 的时候，会自动进入安装盘检查。

# 解决方法

按 E 编辑 安装选项的第一项 “Install Ubuntu Server"

在linux 那行添加 fsck.mode=skip 后，按 ctrl + x 启动。
