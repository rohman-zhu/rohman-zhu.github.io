---
title: Photon Linux的网卡设置
tags:
  - 网络
categories:
  - VMware
  - Photon Linux
date: 2023-01-08 21:47:24
---
# 需求

1. 设置网卡的IP；
2. 设置多网卡的IP；

# 解决方法

```sh
# 网络配置文件路径
# /etc/systemd/network

# 修改eth0 的网卡配置
vim /etc/systemd/network/10-eth0.network
#---
[Match]
Name=eth0

[Network]
Address=x.x.x./24
Gateway=x.x.x.x
DNS=x.x.x.x
#---

# 设置完毕后，重启网络服务
systemctl restart systemd-networkd.services

```

设置第二张网卡 eth1 的IP

```sh
vim /etc/systemd/network/10-eth1.network
#---
[Match]
Name=eth1

[Network]
Address=x.x.x.x
DNS=x.x.x.x
#---
```


# 参考资料

https://blog.csdn.net/m0_58983558/article/details/124375474