---
title: Windows删除用户配置脚本
tags:
  - 脚本
  - ps1
catergories:
  - Windows Server
date: 2020-02-19 22:50:56
---

# 前言

用于删除Windows上的用户配置文件夹。

# beta版

仅删除指定用户的配置文件夹。

```ps1
$domainName = "domain.com"
$targetUser = "Rohman.Zhu"
$sid = (New-Object Security.Principal.NTAccount($domainName, $targetUser)).Translate([Security.Principal.SecurityIdentifier]).Value

Get-WmiObject -ClassName Win32_UserProfile -Filter "SID='$sid'" |
  ForEach-Object {
    $_.Delete()
  }
```

# v1

检索C:\Users目录下的所有用户配置文件夹，将超过120天都未修改的文件夹删除。

```ps1
$limitTime = 120
$domainName = "domain.com"

$userProfilesPath = "C:\Users"
$userCollect = get-childitem -Path $userProfilesPath

$currentTime = Get-Date

foreach($item in $userCollect)
{
    $lastAccessTime = $item.LastAccessTime
    $timeSpan = New-TimeSpan $lastAccessTime $currentTime
    $timeSpanDays = $timeSpan.Days
    $userName = $item.Name

    if($timeSpanDays -gt $limitTime)
    {
      $sid = (New-Object Security.Principal.NTAccount($domainName, $targetUser)).Translate([Security.Principal.SecurityIdentifier]).Value
      Get-WmiObject -ClassName Win32_UserProfile -Filter "SID='$sid'" |
      ForEach-Object {
        $_.Delete()
      }
    }
}
```

# v2

读取用户名单，并根据名单删除用户配置。

```ps1
$domainName="domain.com"
$PATH = ".\userlist.txt"
$i = 0
foreach($line in $PATH)
{
  $targetUser = $line
  $sid = (New-Object Security.Principal.NTAccount($domainName, $targetUser)).Translate([Security.Principal.SecurityIdentifier]).Value
  write-host $i"--"$username"--"$sid
  Get-WmiObject -ClassName Win32_UserProfile -Filter "SID='$sid'" |
      ForEach-Object {
        $_.Delete()
      }
  $i += 1
}
```

# 参考资料

https://www.cnblogs.com/linuxsec/articles/7517851.html
http://blog.vichamp.com/2017/12/27/deleting-user-profiles/