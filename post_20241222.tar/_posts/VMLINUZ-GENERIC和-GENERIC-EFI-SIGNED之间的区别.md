---
title: 转载-VMLINUZ*-GENERIC和*-GENERIC.EFI.SIGNED之间的区别
tags:
  - default
categories:
  - Linux
date: 2022-11-14 00:27:58
---
# 说明

在/boot ，有两个vmlinuz内核文件：

```sh
vmlinuz-4.8.0-37-generic vmlinuz-4.8.0-37-generic.efi.signed 
```

# 这两个内核文件有什么区别？ 

谁签了第二个（如果确实签名，顾名思义），我的UEFI / BIOS如何知道信任并使用*-generic.efi.signed而不是*-generic ？

文件名以.efi.signed结尾的内核由Canonical签名，用于安全启动。 
但是，大多数计算机的固件都不信任Canonical的签名; 只有借助Shim程序（ ESP上的shimx64.efi二进制文件），签名内核才会受到信任。

为了详细说明，启用了安全启动的Ubuntu签名组件的加载路径如下所示：

```sh
EFI -> Shim -> GRUB 2 -> Kernel -> Kernel modules 
```

- EFI信任Shim，因为它已经由Microsoft签署，其密钥嵌入在固件中。
- Shim修补了EFI的安全启动子系统，并包含Canonical的公钥。 Shim信任GRUB 2，因为它已经使用Canonical的私钥签名。
- GRUB 2调用EFI的安全启动系统（现在由Shim修补）来validation内核，该内核也使用Canonical的私钥进行签名。
- 内核validation内核模块是否由Canonical的私钥或安全启动链中的其他密钥签名。

在IIRC，Ubuntu 15.10之前，Ubuntu的GRUB 2没有在内核上强制执行安全启动策略，内核也没有在内核模块上强制实施安全启动策略。 不过最近收紧了。 AFAIK，没有计划要求签署普通的系统二进制文件。

我不知道为什么在Ubuntu中有一个未签名的内核文件。 即使在不支持安全启动的系统（包括纯BIOS计算机）上，签名文件也能正常工作。 因此，未签名的文件是多余的，AFAIK。

请注意，Shim以后的每个组件都可以以未签名的forms获得，或者它们的签名被剥离。 如果你自己构建Shim，你可以用自己的或者你想要的任何其他公钥替换Canonical的公钥。 （大多数主要发行版都有自己的Shim二进制文件，其中嵌入了自己的密钥。）从源代码构建Shim是没有意义的，除非你让微软签署它，这需要花费100美元并且需要付出很多努力。 如果您需要自己签名，将密钥添加为机器所有者密钥（MOK）比重建Shim并让Microsoft签名更容易。 您还可以调整EFI直接支持的密钥集，这样可以避免使用Shim。 因此，你可以改变很多关于所有这些部分如何组合在一起的东西。 有关如何管理安全启动的更多详细信息，请参阅我的安全启动 主页和完全控制安全启动的页面 。

签名版本用于UEFI安全启动。 它已使用非对称加密签名。 意味着解密它的密钥与用于加密密钥的密钥不同。 BIOS只有一个公钥，可以validation签名是否正确（未被篡改）。 创建此类签名的私钥是秘密的，因此您无法自己创建它。 这就是为什么BIOS信任它并允许它开始。



# 参考资料

https://ubuntu.dovov.com/23100/vmlinuz-generic%e5%92%8c-generic-efi-signed%e4%b9%8b%e9%97%b4%e7%9a%84%e5%8c%ba%e5%88%ab.html

有关详细信息： https ： //wiki.ubuntu.com/SecurityTeam/SecureBoot