---
title: Linux基于PXE-Preseed自动化安装操作系统[TODO]
tags:
  - PXE
  - 自动化
categories:
  - Linux
date: 2022-09-20 00:20:40
---

# 背景

有很多物理服务器上架完成后，需要安装操作系统初始化。本文需要记录PXE的方式来自动安装操作系统，并完成初始化方式；

方法1：PXE+Preseed
方法2：PXE+Cloud-Init
