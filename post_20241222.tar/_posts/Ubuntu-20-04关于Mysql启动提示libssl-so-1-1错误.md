---
title: Ubuntu 20.04关于Mysql启动提示libssl.so.1.1错误
tags:
  - Ubuntu20.40
  - 故障
categories:
  - Linux
date: 2020-12-26 00:57:26
---
# 故障描述

启动MySQL时，提示：

“mysqld:error while loading shared libraries:libssl.so.1.1 : cannont open shared object file:Permission denied"

用ldd /usr/sbin/mysqld 时，发现该命令会有指向的库。

```sh
libssl.so.1.1 --> /usr/lib/libssl.so.1.1
libcrypto.so.1.1 --> /usr/lib/libcrypto.so.1.1

#上述两个库均为软连接，其文件放在

/usr/lib/libssl.so.1.1  => /usr/local/openssl/lib/libssl.so.1.1
/usr/lib/libcrypto.so.1.1  => /usr/local/openssl/lib/libcrypto.so.1.1
```

# 原因分析

未知

# 解决方法

找到这两个文件，直接将文件放在 /usr/lib下。