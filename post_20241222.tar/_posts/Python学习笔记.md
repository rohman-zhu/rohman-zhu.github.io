---
title: Python学习笔记
date: 2017-11-17 22:59:55
tags: Python
---
# Python学习 -- 基础学习 #

官方介绍略,这里只说python的缺点:

1. 运行速度慢，和C程序相比非常慢，因为Python是解释型语言，你的代码在执行时会一行一行地翻译成CPU能理解的机器码，这个翻译过程非常耗时，所以很慢。而C程序是运行前直接编译成CPU能执行的机器码，所以非常快。
1. 代码不能加密。如果要发布你的Python程序，实际上就是发布源代码，这一点跟C语言不同，C语言不用发布源代码，只需要把编译后的机器码（也就是你在Windows上常见的xxx.exe文件）发布出去。要从机器码反推出C代码是不可能的，所以，凡是编译型的语言，都没有这个问题，而解释型的语言，则必须把源码发布出去。

## 安装Python ##

这里有三种平台的安装文件:

1. Mac : `https://www.python.org/ftp/python/3.6.3/python-3.6.3-macosx10.6.pkg`
1. Linux 略
1. Windows 下载对应的exe安装文件即可

检测是否安装成功:

* 在Windows上运行Python时，请先启动命令行，然后运行python。
* 在Mac和Linux上运行Python时，请打开终端，然后运行python3。

## Python解释器 ##

当我们编写Python代码时，我们得到的是一个包含Python代码的以.py为扩展名的文本文件。要运行代码，就需要Python解释器去执行.py文件。
由于整个Python语言从规范到解释器都是开源的，所以理论上，只要水平够高，任何人都可以编写Python解释器来执行Python代码（当然难度很大）。事实上，确实存在多种Python解释器。

1. CPython -- 官方版本的解释器：CPython。这个解释器是用C语言开发的，所以叫CPython。在命令行下运行python就是启动CPython解释器。
1. IPython -- 基于CPython之上的一个交互式解释器，也就是说，IPython只是在交互方式上有所增强，但是执行Python代码的功能和CPython是完全一样的。
1. PyPy -- 另一个Python解释器，它的目标是执行速度。PyPy采用JIT技术，对Python代码进行动态编译（注意不是解释），所以可以显著提高Python代码的执行速度。
1. Jython -- Jython是运行在Java平台上的Python解释器，可以直接把Python代码编译成Java字节码执行。
1. IronPython -- IronPython和Jython类似，只不过IronPython是运行在微软.Net平台上的Python解释器，可以直接把Python代码编译成.Net的字节码。

## 开始编写python程序 ##

### 1.进入编辑界面 -- 第一个程序 ###

打开命令行

```Command
# python

Python 2.7.10 (default, Feb  7 2017, 00:08:15)
[GCC 4.2.1 Compatible Apple LLVM 8.0.0 (clang-800.0.34)] on darwin
Type "help", "copyright", "credits" or "license" for more information.

>>>
>>>exit()
```

在Python交互模式下输入exit()并回车，就退出了Python交互模式，并回到命令行模式;

如果要让Python打印出指定的文字，可以用print()函数，然后把希望打印的文字用单引号或者双引号括起来，但不能混用单引号和双引号：

```python
>>>print('hello world')
>>>print("hello world")
```

执行一个.py文件只能在命令行模式执行。

小结:

* 在Python交互式模式下，可以直接输入代码，然后执行，并立刻得到结果。
* 在命令行模式下，可以直接运行.py文件。

#### 1.1 输入 ####

```python
>>>name = input()
```

### 2.Python基础部分 ###

Python是一种计算机编程语言。计算机编程语言和我们日常使用的自然语言有所不同，最大的区别就是，自然语言在不同的语境下有不同的理解，而计算机要根据编程语言执行任务，就必须保证编程语言写出的程序决 _不能有歧义_ ，所以，任何一种编程语言都有自己的一套语法，编译器或者解释器就是负责把符合语法的程序代码转换成CPU能够执行的机器码，然后执行。Python也不例外。

以#开头的语句是注释，注释是给人看的，可以是任意内容，解释器会忽略掉注释。其他每一行都是一个语句，当语句以冒号:结尾时，缩进的语句视为代码块。

> 缩进有利有弊。好处是强迫你写出格式化的代码，但没有规定缩进是几个空格还是Tab。按照约定俗成的管理，应该始终坚持使用 _4个空格_ 的缩进。

#### 2.1 数据类型和变量 ####

##### 整数 #####

* Python可以处理任意大小的整数，当然包括负整数，在程序中的表示方法和数学上的写法一模一样，例如：1，100，-8080，0，等等。
* 计算机由于使用二进制，所以，有时候用十六进制表示整数比较方便，十六进制用0x前缀和0-9，a-f表示，例如：0xff00，0xa5b4c3d2，等等。

##### 浮点数 #####

浮点数也就是小数，之所以称为浮点数，是因为按照科学记数法表示时，一个浮点数的小数点位置是可变的，比如，1.23x109和12.3x108是完全相等的。浮点数可以用数学写法，如1.23，3.14，-9.01，等等。但是对于很大或很小的浮点数，就必须用科学计数法表示，把10用e替代，1.23x109就是1.23e9，或者12.3e8，0.000012可以写成1.2e-5，等等。

整数和浮点数在计算机内部存储的方式是不同的，整数运算永远是精确的（除法难道也是精确的？是的！），而浮点数运算则可能会有四舍五入的误差。

##### 字符串 #####

字符串是以单引号'或双引号"括起来的任意文本，比如'abc'，"xyz"等等。请注意，''或""本身只是一种表示方式，不是字符串的一部分，因此，字符串'abc'只有a，b，c这3个字符。如果'本身也是一个字符，那就可以用""括起来，比如"I'm OK"包含的字符是I，'，m，空格，O，K这6个字符。

* 转义字符\可以转义很多字符，比如\n表示换行，\t表示制表符，字符\本身也要转义，所以\\表示的字符就是\，可以在Python的交互式命令行用print()打印字符串看看：

* 如果字符串里面有很多字符都需要转义，就需要加很多\，为了简化，Python还允许用r''表示''内部的字符串默认不转义，可以自己试试：

##### 布尔值 #####

布尔值和布尔代数的表示完全一致，一个布尔值只有True、False两种值，要么是True，要么是False，在Python中，可以直接用True、False表示布尔值（请注意大小写）.

布尔值可以用and、or和not运算。

* and运算是与运算，只有所有都为True，and运算结果才是True：
* or运算是或运算，只要其中有一个为True，or运算结果就是True：
* not运算是非运算，它是一个单目运算符，把True变成False，False变成True：

##### 空值 #####

空值是Python里一个特殊的值，用None表示。None不能理解为0，因为0是有意义的，而None是一个特殊的空值。

##### 变量 #####

变量的概念基本上和初中代数的方程变量是一致的，只是在计算机程序中，变量不仅可以是数字，还可以是任意数据类型。

> 变量在程序中就是用一个变量名表示了，变量名必须是大小写英文、数字和_的组合，且不能用数字开头

python可以不指定变量类型

>这种变量本身类型不固定的语言称之为动态语言，与之对应的是静态语言。静态语言在定义变量时必须指定变量类型，如果赋值的时候类型不匹配，就会报错。例如Java是静态语言.

```python
>>>a='zrj' #解释器创建了字符串'zrj'和变量a，并把a指向'zrj'：
>>>b=a #解释器创建了变量b，并把b指向a指向的字符串'zrj'：
>>>a='genius' #解释器创建了字符串'genius'，并把a的指向改为'genius'，但b并没有更改
>>>print(b)
zrj
```

##### 常量 #####

在Python中，通常用全部大写的变量名表示常量: PI=3.1414926

##### 字符编码 #####

字符串也是一种数据类型,但字符串比较特殊的是还有一个编码问题.

用记事本编辑的时候，从文件读取的UTF-8字符被转换为Unicode字符到内存里，编辑完成后，保存的时候再把Unicode转换为UTF-8保存到文件：

![Unicode编码](https://cdn.webxueyuan.com/cdn/files/attachments/001387245992536e2ba28125cf04f5c8985dbc94a02245e000/0)

![浏览网页的时候，服务器会把动态生成的Unicode内容转换为UTF-8再传输到浏览器](https://cdn.webxueyuan.com/cdn/files/attachments/001387245979827634fd6204f9346a1ae6358d9ed051666000/0)

看到很多网页的源码上会有类似 \<meta charset="UTF-8" /\> 的信息，表示该网页正是用的UTF-8编码。

在最新的Python 3版本中，字符串是以Unicode编码的，也就是说，Python的字符串支持多语言，例如：

```python
>>>print('包含中文的str')
包含中文的str
>>>ord('A') # ord 函数获取字符的整数表示
65
>>>char(65) # chr函数把编码转换为对应的字符
'A'
>>>
```

由于Python的字符串类型是str，在内存中以Unicode表示，一个字符对应若干个字节。如果要在网络上传输，或者保存到磁盘上，就需要把str变为以字节为单位的bytes。

Python对bytes类型的数据用带b前缀的单引号或双引号表示：

```python
>>>x =b'ABC'
>>>'ABC'.encode('ascii') #以Unicode表示的str通过encode()方法可以编码为指定的bytes
b'ABC'
>>>b'ABC'.decode('ascii') #从网络或磁盘上读取了字节流，那么读到的数据就是bytes。要把bytes变为str，就需要用decode()方法;
>>>b'ABC'.decode('utf-8',errors='ignore') # 如果bytes中只有一小部分无效的字节，可以传入errors='ignore'忽略错误的字节
```

> 纯英文的str可以用ASCII编码为bytes，内容是一样的，含有中文的str可以用UTF-8编码为bytes。含有中文的str无法用ASCII编码，因为中文编码的范围超过了ASCII编码的范围，Python会报

计算string包含多少字符,可以用len()函数(类似java的String.length()函数)

len()函数计算的是 _str的字符数_ ，如果换成bytes，len()函数就计算字节数;

> 如果Python源码中包含中文字符,那么在保存源码文件的时候,用UTF-8编码保存.

格式化:

```python
>>>'Hi, %s, you have $%d.' % ('Michael', 1000000)
```

这个类似C语言中的print语句,例如 : n=100 ,print("I have %d $",n);

> %运算符就是用来格式化字符串的。在字符串内部，%s表示用字符串替换，%d表示用整数替换，有几个%?占位符，后面就跟几个变量或者值，顺序要对应好。如果只有一个%?，括号可以省略。

常见的占位符:

| 占位符 | 替换内容 |
|:------:|:------:|
|%d|整数|
|%f|浮点数|
|%s|字符串|
|%x|十六进制整数|

> 有些时候，字符串里面的%是一个普通字符怎么办？这个时候就需要转义，用%%来表示一个%

```python
>>>'This is %d %%" % 60
This is 60 %
```

#### list 和 tuple ####

Java中有list集合,python也有,python不需要new一个list集合,直接定义即可.

```python
>>>classmates = ["Zrj","Roman","Cheryl"]
>>>classmates
["Zrj","Roman","Cheryl"]
>>>len(classmates) # 显示list集合元素个数
3
>>>classmates[0] #根据索引来获取元素,
```

遍历list集合也不需要写个for循环,直接显示

显示list的元素个数,用len()函数 ,

一个list的元素可以是另一个list

```python
>>>p=['asp','php']
>>>a=['python',p,'scheme']
>>>len(a)
3
>>>a
['python',['asp','php'],'scheme']
```

---

另一种有序列表叫元组,tuple . tuple和list非常类似，但是tuple一旦初始化就不能修改，比如同样是列出同学的名字

定义tuple:

```python
>>>classmates=('Zrj','Romen')
>>> #classmates这个tuple不能变了，它也没有append()，insert()这样的方法。其他获取元素的方法和list是一样的，你可以正常地使用classmates[0]，classmates[-1]，但不能赋值成另外的元素。
```

>因为tuple不可变，所以代码更安全。如果可能，能用tuple代替list就尽量用tuple。

Python在显示只有1个元素的tuple时，也会加一个逗号,，以免你误解成数学计算意义上的括号.

```python
>>>t = (1)
>>>t
1
>>> #定义的不是tuple，是1这个数！这是因为括号()既可以表示tuple，又可以表示数学公式中的小括号，这就产生了歧义，因此，Python规定，这种情况下，按小括号进行计算，计算结果自然是1。

>>>t=(1,)
>>>t
(1,)
```

##### 可变的tuple #####

```python
>>>t=(1,2,['A','B'])
>>>t
(1,2,['A','B'])
```

![;定义的三个变量](https://cdn.webxueyuan.com/cdn/files/attachments/001387269705541ad608276b6f7426ca59b8c2b19947243000/0)

表面上看，tuple的元素确实变了，但其实变的不是tuple的元素，而是list的元素。

> tuple一开始指向的list并没有改成别的list，所以，tuple所谓的“不变”是说，tuple的每个元素，指向永远不变。即指向'a'，就不能改成指向'b'，指向一个list，就不能改成指向其他对象，但指向的这个list本身是可变的！

#### 条件判断 ####

```python
age = 20
if age >= 20:
    print('Your age is',age)
    print('adult')
else:
    print('Your age is',age)
```

如果if语句判断是True，就把缩进的两行print语句执行了,也可以给if添加一个else语句，意思是，如果if判断是False，不要执行if的内容，去把else执行了

> 注意冒号':'不要遗漏,同时每一个语句后面都不用加分号';'

多分支用elif

```python
age = 20
if age >= 20:
    print('Your age is',age)
    print('adult')
elif age >= 80:
    print('You are a old man')
else:
    print('Your age is',age)
```

>if语句执行有个特点，它是从上往下判断，如果在某个判断上是True，把该判断对应的语句执行后，就忽略掉剩下的elif和else.

if语句可以简写:

```python
#只要x是非零数值、非空字符串、非空list等，就判断为True，否则为False。
if x:
    print('True')
```

输入函数input返回的是string类型,如果需要对string类型进行转义则需要int()函数

```python
i = input('your age is')
age = int(i)
if age < 18:
    print('young man!')
```

>int()函数发现一个字符串并不是合法的数字时就会报错，程序就退出了. 跟java的valueof()一样有检查检查功能.

#### 循环 ####

##### for 循环 #####

这的语法跟shell的语法类似

```python
names=['Zrj','Roman']
for name in names:
    print(name)
```

做一个累加的程序:

```python
sum = 0
for x in [1,2,3,4,5,6]:
    sum = sum + x
print(sum)

# 如果是1到100累加,在shell中是{1..100},在python中可以用range(n)函数,这个是从0到n的整数

for x in range(101):
    sum += x
print(sum)
```

> 一样的,不要忘记冒号':'

##### while 循环 #####

```python
sum = 0
n = 99
while n > 0:
    sum = sum + n
    n = n - 2
print(sum)
```

##### break , Continue #####

* 在循环中，break语句可以提前退出循环
* 在循环过程中，也可以通过continue语句，跳过当前的这次循环，直接开始下一次循环

#### dict & set ####

##### dict #####

Python内置了字典：dict的支持，dict全称dictionary，在其他语言中也称为map，使用键-值（key-value）存储，具有极快的查找速度。

> 这类似java中的map

```python
>>>d = {'Zrj':92,'Roman':99}
>>>d['Zrj']
92
>>>d['Zrj']=95 #修改,由于一个key只能对应一个value，所以，多次对一个key放入value，后面的值会把前面的值冲掉：
>>>d['Zrj']
95
```

判断dict是否有这个key,有两种方法:

```python
>>>'Zrx' in d
False
>>>d.get('Zrx')
>>>d.get('Zrx','False')
'False'
```

删除一个key-value,可以用pop(key)的方法:

```python
>>>d.pop('Roman')
99
```

dict与list的特点对比:

| dict | list |
|:-----:|:-----:|
|查找和插入速度极快,不会随着key的增减而变慢|查找和插入的空间随着元素的增加而增加|
|需要占用大量的内存,内存浪费|占用空间小,浪费的内存很少|

>dict是用空间来换取时间的一种方法。

##### set #####

set和dict类似，也是一组key的集合，但不存储value。由于key不能重复，所以，在set中，没有重复的key。

```python
>>>#创建一个set , 需要提供一个list作为输入集合
>>>s =set([1,2,3])
>>>s
{1,2,3}
>>>#重复元素将被自动过滤掉
>>>s=set([1,2,3,4,3,3])
>>>s
{1,2,3,4}
>>>通过add()方法将元素添加到set中
>>>s.add(5)
>>>s
{1,2,3,4,5}
>>>通过remove(key)方法可以删除元素
>>>s.remove(4)
>>>s
{1,2,3,5}
>>>#set可以看成数学意义上的无序和无重复元素的集合，因此，两个set可以做数学意义上的交集、并集等操作
>>>s1= set([1,2,3])
>>>s2= set([2,3,4])
>>>s1 & s2
{2,3}
>>>s1 | s2
>>>{1,2,3,4}
```

### 函数 ###

* 求绝对值 abs()
* 最大值 max()
* 类型转换 int() , float() , str() , bool()

函数名其实就是指向一个函数对象的引用，完全可以把函数名赋给一个变量，相当于给这个函数起了一个“别名”:

```python
>>>a=abs
>>>a(-1)
1
```

请使用迭代查找一个list中最小和最大值，并返回一个tuple：

```python
#Find the max and min number and return a tuple

def fun():
    #Max
    a = 0
    #Min
    b = 99
    for i ,value in enumerate([2,3,4,5,1,3,1,2,3,4,5]):
        if a < value :
            a = value
        if b > value :
            b = value
    print(a,b)ww
    return d = (a,b)
```

---

定义一个函数要使用def语句,一次写出 函数名 , 括号 , 括号中的参数 , 冒号 ; 然后，在缩进块中编写函数体，函数的返回值用return语句返回。

```python
def my_abs(x):
    if x >= 0:
        return x
    else
        return -x

#对参数类型做检查，只允许整数和浮点数类型的参数。数据类型检查可以用内置函数isinstance()

def my_abs(x):
   if not isinstance(x,(int,float)):
       raise TypeError('Bad operand type')
    if x >= 0:
        return x
    else
        return -x
```

> 把my\_abs()的函数定义保存为abstest.py文件了，那么，可以在该文件的当前目录下启动Python解释器，用from abstest import my\_abs来导入my\_abs()函数，注意abstest是文件名（不含.py扩展名）：

```python
>>>from abstest import my_abs
>>> my_abs(-8)
8
```

---

如果想定义一个什么事也不做的空函数，可以用pass语句;

```python
def nop():
    pass

#pass语句什么都不做，那有什么用？实际上pass可以用来作为占位符，比如现在还没想好怎么写函数的代码，就可以先放一个pass，让代码能运行起来。
```

---

测试:写一个一元二次方程的求解程序

```python
import math
def fun(a,b,c):
    if b*b - 4*a*c < 0:
        print("Illegal args")
        return False
    print("x1=" , (-b + math.sqrt(b*b - 4*a*c))/(2*a))
    print("x2=" , (-b - math.sqrt(b*b - 4*a*c))/(2*a))
    return True
```

---

Python的函数定义非常简单，但灵活度却非常大。除了正常定义的必选参数外，还可以使用默认参数、可变参数和关键字参数，使得函数定义出来的接口，不但能处理复杂的参数，还可以简化调用者的代码。

> 函数的参数跟C语言差不多,都有形参与实参的说法

```python
#给参数一个默认值
def fun(x,y=2)
```

需要注意:

1. 是必选参数在前，默认参数在后，否则Python的解释器会报错.(会产生歧义,fun(x,y=2,z),用户调用fun(1,3)则会报错)
1. 当函数有多个参数时，把变化大的参数放前面，变化小的参数放后面。变化小的参数就可以作为默认参数。

> 如果默认参数是一个list,记得要给list加上一个END,list.append('END')

---

可变参数:

当函数有多个参数时，把变化大的参数放前面，变化小的参数放后面。变化小的参数就可以作为默认参数。

```python
# a*a + b*b + c*c +...
def calc(*numbers):
    sum = 0
    for n in numbers:
        sum = sum + n*n
    return sum

# 如果没有* 每次调用则需要传入一个list或者tuple
```

## 小结 ##

了解python的基础变量 , 集合 , 数组 , 函数的定义 , 在python中用缩进的规则来区分代码块,并且不要遗忘冒号 :