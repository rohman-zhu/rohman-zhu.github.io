---
title: Linux-IB交换机测试相关记录
tags:
  - default
categories:
  - Linux
date: 2021-06-20 23:21:21
---

## 查看命令

```sh
mlnx_tune -p HIGH_THROUGHPUT
```

## 异常现象

IB理论速度是100Gb/Sec ,测试结果只有53 Gb/Sec


测试指令 

```sh
# 检测指令
ib_read_bw -a --report_gbits

# IB状态指令查看
ibstatus
```

> 使用 mlnx_tune -p HIGH_THROUGHPUT 命令查看有提示：PCI capabilities might not be fully utilized with broadwell CPU. Make sure I/O non-posted prefetch is disabled in BIOS.

> Warning：PCI speed 8GT/s >>> PCI width status is below PCI capabilities.Check PCI configuration in BIOS

因此需要调整BIOS参数。

##  参考资料

IO Non Posted Prefectching - This parameter is relevant to haswell/broadwell and onwards , and should be disabled on those systems.Note,it is not exposed on all BIOS versions.