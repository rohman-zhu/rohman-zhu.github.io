---
title: Linux 挂载与卸载文件系统
date: 2017-10-05 13:24:51
tags: Linux
---
# Linux挂载与卸载文件系统 #

## 练习 ： 将一个NTFS分区格式的硬盘挂载到 Linux 系统上 ##

1. 查询这个硬盘的信息。

```{.normal}
$ blkid


/dev/sda1: UUID="2A98DE1F98DDE979" TYPE="ntfs" 
/dev/sda2: UUID="000A8A2B00090684" TYPE="ntfs" 
/dev/sda3: UUID="a19323f9-0867-4328-9ec5-6075bf75fe5e" TYPE="xfs" 
/dev/sda5: UUID="zDW5vb-IDea-s8rS-Wo5k-mWMf-eou2-MWtxXc" TYPE="LVM2_member" 
/dev/mapper/cl-root: UUID="a9d6aab6-0568-4b3b-b11e-278ec4f9795d" TYPE="xfs" 
/dev/mapper/cl-swap: UUID="344d22fa-7e77-4168-a1a7-0abb8614f637" TYPE="swap" 
/dev/mapper/cl-home: UUID="db643711-334f-47ab-b5e7-4729f5edb435" TYPE="xfs" 


```

2. 在Linux上创建一个文件夹，作为挂载点
```
$ mkdir testDev
```

3. 根据 UUID 将文件系统挂载到 Linux 的 testDev 下
```
$ mount UUID="000A8A2B00090684" testDev/
```

4. 卸载在 Linux 上面的文件系统
```
$ umount testDev/
```