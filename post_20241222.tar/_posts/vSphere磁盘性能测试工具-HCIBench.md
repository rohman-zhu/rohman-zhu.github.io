---
title: vSphere磁盘性能测试工具-HCIBench
tags:
  - 性能
categories:
  - VMware
date: 2023-01-15 15:20:34
---

# HCIBench 说明

```官方资料
HCIBench stands for "Hyper-converged Infrastructure Benchmark".  It's essentially an automation wrapper around the popular and proven open source benchmark tools: Vdbench and Fio that make it easier to automate testing across a HCI cluster.  HCIBench aims to simplify and accelerate customer POC performance testing in a consistent and controlled way.  The tool fully automates the end-to-end process of deploying test VMs, coordinating workload runs, aggregating test results, performance analysis and collecting necessary data for troubleshooting purposes.

HCIBench is not only a benchmark tool designed for vSAN, but also could be used to evaluate the performance of all kinds of Hyper-Converged Infrastructure Storage in vSphere environment.

---来自 https://flings.vmware.com/hcibench
```

![HCI 架构](https://flings.vmware.com/files/uploads/0/0/0/0/2/8/8/hcibench_architecture_2.3u1.png)

```简单翻译
HCIBench代表“超融合基础设施基准测试”。它本质上是一个围绕流行的、经过验证的开源基准测试工具的自动化包装: Vdbench和Fio，它们使跨HCI集群的自动化测试变得更容易。

HCIBench旨在以一致和可控的方式简化和加速客户POC性能测试。
该工具完全自动化了部署测试虚拟机、协调工作负载运行、聚合测试结果、性能分析以及为故障排除收集必要数据的端到端流程。

HCIBench不仅是为vSAN设计的基准测试工具，还可以用于评估vSphere环境下各种超融合基础设施存储的性能。
```

## 软件要求

```
1. Web Browser:IE8+, Firefox or Chrome
2. vSphere 5.5 and later environments for both HCIBench and its client VMs deployment
```



# 防火墙需求

| SRC | DST | TCP | UDP | 说明 |
|:---|:---|:---:|:---:|:---|
| HCIBench Mgmt | vCenter IP | 443 | | HCIBench 需要集成 vCenter ，需要向vCenter发起部署测试虚拟机的任务 ；|
| HCIBench Mgmt | ESXi IP | 22 | | HCIBench 批量部署完虚拟机后，需要通过22端口控制目标虚拟机的宿主机； |
| 跳板机 | HCIBench Mgmt IP | 8443 | | HCIBench 的WEB配置页面 |
| 跳板机 | HCIBench Mgmt IP | 3000 | | HCIBench 的Grafana监控页面 |
| 跳板机 | HCIBench Mgmt IP | 80 | | HCIBench 的测试结果归档 |

# 部署实例

# 测试实例

```配置文件
Best Practice:

We recommend having the number of VMs, number and size of Data Disks as well as the Number of thread per Disk reasonably configured. The total threads configured = Number of VMs * Number of Data Disks per VM * Number of Threads per Disk.

If your goal is to achieve best possible IOPS or Throughput, you can start with 4 VMs per ESXi host, 8 Data Disks per VM and 4 Threads per Disk, run the testing, increase any of those variable for another run if the first run doesn’t satisfy you.

if your goal is to achieve best possible latency, you can start with 2 VMs per ESXi host, 4 Data Disks per VM and 1 Threads per Disk, run the testing, reduce any of those variable for another run if the first run doesn’t satisfy you.

```

## IO模型测试表格

|序号|块大小(k)|读比例(%)|随机比例(%)|说明|
|:---:|:---:|:---:|:----:|:----|
|01|4|100|100|4k 100%随机读|
|02|64|100|100|64k 100%随机读|
|03|1024|100|100|1024k 100%随机读|
|04|4|0|100|4k 100%随机写|
|05|64|0|100|64k 100%随机写|
|06|1024|0|100|1024k 100%随机写|
|07|4|70|100|4k 70%随机读，30%随机写|
|08|64|70|100|64k 70%随机读，30%随机写|
|09|1024|70|100|1024k 70%随机读，30%随机写|
|10|4|100|0|4k 100%顺序读|
|11|64|100|0|64k 100%顺序读|
|12|1024|100|0|1024k 100%顺序读|
|13|4|0|0|4k 100%顺序写|
|14|64|0|0|64k 100%顺序写|
|15|1024|0|0|1024k 100%顺序写|
|16|4|70|0|4k 70%顺序读，30%顺序写|
|17|64|70|0|64k 70%顺序读，30%顺序写|
|18|1024|70|0|1024k 70%顺序读，30%顺序写|




# 参考资料

- HCIBench 官方资料介绍：  https://flings.vmware.com/hcibench
- HCIBench ova下载地址： https://flings.vmware.com/hcibench?download_url=https%3A%2F%2Fdownload3.vmware.com%2Fsoftware%2Fvmw-tools%2Fhcibench%2FHCIBench-2.8.0.ova
- 说明文档： https://download3.vmware.com/software/vmw-tools/hcibench/hcibench_user_guide_2.5.pdf