---
title: LNMP-zabbix-3.4.5-实战
tags:
  - Zabbix
  - LNMP
date: 2018-01-07 09:34:36
categories: Linux
---

# 前言 #

本次使用的电脑是上初中时,在淘宝买的二手电脑(NEC VY20M/W-5),当时只是买来打打dota,配置如下表:

| 组件 | 型号 | 价格 |
|:----:|:-----:|:-----:|
| CPU | | |
| 内存 | | |
| 显卡 | | |
| 主板 | | |
| 硬盘 | | |

如今这台电脑的性能已经过于老旧了,因此想把它做成Linux服务器,平时做做文件存储之类的工作,或者家庭点播平台之类的活(这些后续再说...).

目前这条电脑没有发现损坏的地方(扬声器和显示屏完好无损).

下面是这台电脑的应用程序清单:

| 软件类型 | 名称 | 版本号 |
|:--------:|:------:|:------:|
| 操作系统 | Linux_Centos | centos7 |
| 数据库 | MySQL | mysql-5.5.58 |
| Web应用 | Nginx | nginx-1. |
| 监控服务端 | Zabbix | zabbix-3.4.5 |
| PHP | PHP | php-5.5.38 |  

软件下载地址:

* Nginx : http://nginx.org/en/download.html
* Mysql : https://downloads.mysql.com/archives/community/
* Zabbix : https://www.zabbix.com/download
* PHP : http://php.net/releases/

## 开始安装 ##

### 安装系统.(略) ###

### 配置系统 ###

```sh
# 网络 #
# 添加IP到局域网内 #
# ifconfig enp2s0 192.168.1.89 netmask 255.255.255.0 gateway
# 添加默认网关 #
# echo "GATEWAY=192.168.1.1" >> /etc/sysconfig/network

# 关闭Selinux #
# sed -i "s#enforcing#disabled#g" /etc/selinux/config

# 关闭防火墙 #
# systemctl stop firewalld.server
# systemctl disable firewalld.server

# 合上笔记本后不休眠 #
# 方法一 : 追加
# echo 'HandleLidSwitch=ignore' >> /etc/systemd/logind.conf
# 方法二 : 替换
# sed -i 's##\HandleLidSwitch=hibernate#HandleLidSwitch=ignore#g' /etc/systemd/logind.conf
# 生效
# systemctl restart systemd-logind

# 配置国内源 #
# cd /etc/yum.repos.d/
# wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
```

> 添加网卡的时候出现'不允许的操作',需要提升权限操作.
 
#### /etc/systemd/logind.conf ####

* HandlePowerKey：按下电源键后的动作
* HandleSleepKey：按下挂起键后的动作
* HandleHibernateKey: 按下休眠键后的动作
* HandleLidSwitch：合上笔记本盖后待机

值:

* ignore（什么都不做）
* poweroff（关机）
* reboot（重新启动）
* halt（关机，和poweroff有什么区别，需要手动断开电源？）
* suspend（待机挂起）
* hibernate（休眠）

### 安装Nginx-1.6 ###


```sh
# 安装nginx #
# 解压 && 安装 (略)

# 提示没有PCRE库 #
# yum install pcre pcre-devel -y

```

这里也有一个坑要注意一下:

本部电脑连接了两个网卡,一个连接局域网的网卡enp2s0,另一个是通过手机分享出来的网卡.

* 局域网 IP:192.168.1.89 Gateway:192.168.1.1
* 广域网 IP:192.168.42.xx Gateway:192.168.42.129

解决方法是通过路由表设置

```sh
# route add default gw 192.168.42.129
# route add -net 192.168.1.0/24 gw 192.168.1.1 enp2s0
```

### 安装Mysql数据库 ###

```sh
# 解压源码复制到/usr/local/ #
# 运行安装脚本 ./support_files/mysql_install --user=mysql --datadir=/usr/local/mysql/data/mysql
# 添加命令到profile #
# 复制启动脚本到/etc/init.d #
```

遇坑:

```error
Starting MySQL.180107 15:11:06 mysqld_safe error: log-error set to '/var/log/mariadb/mariadb.log', however file don't exists. Create writable for user 'mysql'.
 ERROR! The server quit without updating PID file (/var/lib/mysql/sunday.nec.com.pid).
 ```

 手动创建日志文件,并更改所有组.

 ```error
 Starting MySQL.180107 15:11:06 mysqld_safe error: log-error set to '/var/log/mariadb/mariadb.log', however file don't exists. Create writable for user 'mysql'.
 ERROR! The server quit without updating PID file (/var/lib/mysql/sunday.nec.com.pid).
 ```

 可能存在僵尸线程,关闭掉即可.

 ### 安装PHP-5.5.58 ###

```sh
# ./configure --prefix=/usr/local/php-5.5.38 --with-config-file-path=/usr/local/php-5.5.38/etc --with-bz2 --with-curl --enable-ftp --enable-sockets --disable-ipv6 --with-gd --with-jpeg-dir=/usr/local --with-png-dir=/usr/local --with-freetype-dir=/usr/local --enable-gd-native-ttf --with-iconv-dir=/usr/local --enable-mbstring --enable-calendar --with-gettext --with-libxml-dir=/usr/local --with-zlib --with-pdo-mysql=mysqlnd --with-mysqli=mysqlnd --with-mysql=mysqlnd --enable-dom --enable-xml --enable-fpm --with-libdir=lib64 --enable-bcmath --enable-mbstring --with-gd  --with-libxml-dir=/usr/local

# make && make install
# 在php主目录下
# cp php.ini-production   /application/php/lib/php.ini
#在软件目录下的etc文件夹内
# cp php-fpm.conf.default  ./php-fpm.conf
```
* 遇坑:80端口拒绝访问,这个是防火墙问题,在centos7,防火墙是firewall

* gd 负责画图的库

### 安装ZABBIX-3.4.5 ###

```sh
# 解压安装 #
# ./configure --prefix=/usr/local/zabbix-3.4.5/ --enable-server --enable-agent --with-mysql --with-net-snmp --with-libcurl --with-lixbml2
# make && make install

# 添加用户 #
# useradd zabbix

```

初始化数据库

```sh
# mysql -uroot -p
mysql>create database zabbix default charset utf8;
mysql>create user zabbix@'localhost' identified by '503428761';
mysql>grant all on zabbix.* to zabbix@'localhost';
mysql>flush privileges;
mysql>quit;
#mysql -uroot zabbix < ./database/mysql/schema.sql
#mysql -uroot zabbix < ./database/mysql/images.sql
#mysql -uroot zabbix < ./database/myslq/data.sql
```

配置Zabbix_server

```sh
# 生成配置文件 #
# mkdir /etc/zabbix
# cp ./config/zabbix_server.conf /etc/zabbix
# vim /etc/zabbix/zabbix_server.conf
DBName=zabbix
DBUser=zabbix
DBPassword=503428761
DBPort=3306
```

在Nignx中添加前段文件
```sh
# mkdir /usr/local/nginx/html/monitor.r0hman.com/zabbix -p
# cp -rp ./frontends/php/* /usr/local/nginx/html/monitor.r0hman.com/zabbix
# chown -R nginx:nginx /usr/local/nginx/html/monitor.r0hman.com/
```

在Nignx文件中添加节点

```sh
server
{
    listen 80;
    server_name monitor.r0hman.com;
    access_log logs/monitor.r0hman.com;
    index index.html index.php;
    root html/monitor.r0hman.com;

    location \
    {
       try_files $uri /index.php?$args;
    }

    location ~*.\.(php|php5)$
    {
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_index index.php;
        include fastcgi.conf;
    }
}
```

修改PHP的配置文件

在浏览器中打开 monitor.r0hman.com,按照流程逐渐输入即可.如果遇到什么问题,则去查看日志,任何问题的解决方案都是在日志上面的.


遇坑:

1. 到最后一步,可能会遇到无法生存配置文件,这个是因为php没有写入权限.原因是因为php-fpm的写入用户是nobody,而/monitor.rohman.com/站点下的目录文件下的conf文件夹是有写入权限限制的.
1. 20170109目前出现了一个坑,更改了nginx和php的用户(从nobody变为nginx),zabbix的安装界面就不能继续了...这个是php-fpm的用户组出问题了,默认为nobody没有问题
1. php中提示UTC 与 其他时区冲突,修改php的配置文件即可
1. zabbix中提示"server is not running",这个是网站的php配置出现问题,修改一下servername和地址即可.

### 监视第一台客户端 ###

客户端地址:192.168.1.88

服务端地址:192.168.1.89

网址:monitor.rohman.com/zabbix

客户端需要安装 _zabbix\_agentd_,并且配置 zabbix\_agentd.conf 文件.

> 注意 : zabbix\_agentd.conf文件的路径是这样的 /zabbix-3.4.5/etc/zabbix\_agentd.conf,然而在启动zabbix\_agentd的时候,如果没有制定配置文件,则zabbix会选用 /usr/local/etc/zabbix\_agentd.conf的配置文件.

在 zabbix_agentd.conf 中要修改的几个地方 :

* Hostname , 这个属性跟server端网页配置主机的hostname相对应.(见图一)
* Server , 这个填写的地址即是server端的地址.
* ServerActive , 这个也是填写server端的地址.

![图一](http://www.ttlsa.com/wp-content/uploads/2014/04/zabbix-monitor-server-01.jpg)

```
# Server 与 ServerActive 的区别 #

### Option: Server
#       List of comma delimited IP addresses, optionally in CIDR notation, or hostnames of Zabbix servers.
#       Incoming connections will be accepted only from the hosts listed here.
#       If IPv6 support is enabled then '127.0.0.1', '::127.0.0.1', '::ffff:127.0.0.1' are treated equally and '::/0' will allow any IPv4 or IPv6 address.
#       '0.0.0.0/0' can be used to allow any IPv4 address.
#       Example: Server=127.0.0.1,192.168.1.0/24,::1,2001:db8::/32,zabbix.domain
#
# Mandatory: no
# Default:
# Server=

### Option: ServerActive
#       List of comma delimited IP:port (or hostname:port) pairs of Zabbix servers for active checks.
#       If port is not specified, default port is used.
#       IPv6 addresses must be enclosed in square brackets if port for that host is specified.
#       If port is not specified, square brackets for IPv6 addresses are optional.
#       If this parameter is not specified, active checks are disabled.
#       Example: ServerActive=127.0.0.1:20051,zabbix.domain,[::1]:30051,::1,[12fc::1]
#
# Mandatory: no
# Default:
# ServerActive=

```

通过以上两段话的对比,可以得知,Server设置完,只是被动接受目标server的请求,而 ServerActive 则设置的是主动模式.

>主动：agent请求server获取主动的监控项列表，并主动将监控项内需要检测的数据提交给server/proxy
>被动：server向agent请求获取监控项的数据，agent返回数据。

主动模式的流程:

* 设置ServerActive=ServerIP
* Agent向Server建立一个TCP连接
* Agent请求需要检测的数据列表
* Server响应Agent，发送一个Items列表
* Agent允许响应
* TCP连接完成本次会话关闭
* Agent开始周期性地收集数据