---
title: 有关Fragment的相关问题
date: 2017-06-28 12:26:18
tags: Android
categories: Android
---
# 前言 #
写笔记前先扯一下蛋,明天(2017-06-29 14:00 信息楼103)要参加A+认证考试.而到现在为止,本人还没有看多少题.本人最近都是在根据题库做一个背题的APP,就当作练练手.从上星期六(2017-06-26)立项到现在,历时4天,终于弄出了以下玩意:

![img](sourc/images/20170628_mainpager.png)
![img](sourc/images/20170628_testPager.png)
![img](images/20170628_rememberPager.jpeg)
![img](images/20170628_recordPager.jpeg)

### 用到了一下几个控件: ###
* ViewPager(主要)
    #### viewpager用的适配器: FragmentAdapter ####
* DrawerLayout
* CheckBox
* Button
* ListView

### APP构思 ###

1. 编码题库TXT文件 txt -> xml
2. 解析题库XML文件 xml -> 题目类
3. 编辑题目类,有 题号/题目内容/选项A内容/选项B内容/选项C内容/选项D内容/正确答案,一个类共7个项内容,并且设置相应的操作函数.
4. 加载题库数据到Viewpager...

最终实现流程:
编码XML -> 解析XML -> 封装类到集合 -> 根据集合封装Fragment -> 给Viewpager设置适配器

### 出现大的问题 ###
1. 因为本APP有三种模式,其中错题模式的页面内容是跟另外两个模式不一样的,适配器的数据(Fragment集需要更变)更变后,页面没变化.
2. 在 _测试模式_ 和 _背题模式_ 中,不同的是Fragment中的题目答案是否有显示,而在页面中要让一个TextView显示,Fragment必须是要加载到Activity中,未加载的Fragment是不能设置TextView显示.

### 解决方法 ###
1. 留到下文再写.
2. 在每一个题目的Fragment中设置一个用于表示 _是否显示参数_ (boolean isVisible),如果要显示则,通过fragment集合获取指定的fragment的这个参数(isVisible),设置为 _true_ ;然后在onCreateView()中加入这段逻辑:
```
    TestViewAnswer.setVisibility(isVisible);
```

# 正文 #
话说回来,因为我用到的Viewpager控件采用的是FragmentAdapter这个适配器,因此用的是有关Fragment的相关内容.

## Fragment ##

### 一.什么是Fragment ###
Fragment是一个类似Activity组件,跟Activity一样的也有生命周期.
![Fragment生命周期](http://img.my.csdn.net/uploads/201211/29/1354170699_6619.png)

由图中可以看到,Fragment被加载的时候,会多一个onCreateView方法.而且每一次再加载的时候都是调用onCreateView方法.

### 二.使用Fragment(加载Fragment) ###
#### 方法一: 静态添加 ####
这个方法其实跟自定义控件一样,需要java文件与xml布局文件.
1. 正常设置布局
2. 编写java文件 ,类继承自Fragment,并重写以对应的方法.
```
 @Override  
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  
            Bundle savedInstanceState)  
    {  
        return inflater.inflate(R.layout.fragment_content, container, false);  
        //这里相当于加载了fragment的布局文件
    }  
```
3. 在MainActivity中也需要编写两个文件,只需编写布局文件就好了

    ```
    //这里是MainActivity的布局文件
    <fragment
        android:id="@+id/id_fragment_content"  
        android:name="fragment放置的包名"  
        android:layout_width="fill_parent"  
        android:layout_height="fill_parent" />  
    ```
  
#### 方法二 : 动态添加 ####
这个方法是通过 FragmentManager的一个事务对象来实现的 ( _FragmentTransaction_ ),常用方法有add,remove,replace, 最后都要用commit方法提交.

1. replace()

    * 这里需要设置两个参数(被替换的布局文件id,将要替换的fragment);
    * 设置完后提交,FragmentTransaction.commit();

### 小结 ###
Fragment常用的三个类：
* android.app.Fragment 主要用于定义Fragment
* android.app.FragmentManager 主要用于在Activity中操作Fragment
* android.app.FragmentTransaction 保证一些列Fragment操作的原子性，熟悉事务这个词，一定能明白~

---
* 获取FragmentManager的方法是getFragmentManager(),而在v4中是用getSupportFragmentManager();
* 操作事务的对象是 FragmentManager.beginTransaction();
* transaction.add() ;往Activity中添加一个Fragment
* transaction.remove() ; 从Activity中移除一个Fragment，如果被移除的Fragment没有添加到回退栈（回退栈后面会详细说），这个Fragment实例将会被销毁。
* transaction.replace()
使用另一个Fragment替换当前的，实际上就是remove()然后add()的合体
* transaction.hide()
隐藏当前的Fragment，仅仅是设为不可见，并不会销毁
* transaction.show()
显示之前隐藏的Fragment
* detach()
会将view从UI中移除,和remove()不同,此时fragment的状态依然由FragmentManager维护。
* attach()
重建view视图，附加到UI上并显示。
* transatcion.commit()//提交一个事务

* 注意：常用Fragment的哥们，可能会经常遇到这样Activity状态不一致：State loss这样的错误。主要是因为：commit方法一定要在Activity.onSaveInstance()之前调用。

* a、比如：我在FragmentA中的EditText填了一些数据，当切换到FragmentB时，如果希望会到A还能看到数据，则适合你的就是hide和show；也就是说，希望保留用户操作的面板，你可以使用hide和show，当然了不要使劲在那new实例，进行下非null判断。

* b、再比如：我不希望保留用户操作，你可以使用remove()，然后add()；或者使用replace()这个和remove,add是相同的效果。

* c、remove和detach有一点细微的区别，在不考虑回退栈的情况下，remove会销毁整个Fragment实例，而detach则只是销毁其视图结构，实例并不会被销毁。那么二者怎么取舍使用呢？如果你的当前Activity一直存在，那么在不希望保留用户操作的时候，你可以优先使用detach。
### 关于回退栈 ###
* 如果不添加事务到回退栈，前一个Fragment实例会被销毁。这里很明显，我们调用tx.addToBackStack(null);将当前的事务添加到了回退栈，所以FragmentOne实例不会被销毁，但是视图层次依然会被销毁，即会调用onDestoryView和onCreateView.

## ViewPager
我用的是FragmentAdapter,也就是说,这个Viewpager里面放的是Fragment,这个控件会在当前页中,预先加载position - 1 页 和 position + 1页.

### FragmentAdapter
* 构造函数中必须需要传入一个FragmentManager参数.
* 将显示的页面,需要传入一个Fragment集合
----
方法说明:
* public Fragment getItem()
    
1.  该类中新增的一个虚函数。函数的目的为生成新的 Fragment 对象。重载该函数时需要注意这一点。在需要时，该函数将被 instantiateItem() 所调用。
2. 如果需要向 Fragment 对象传递相对静态的数据时，我们一般通过 Fragment.setArguments() 来进行，这部分代码应当放到 getItem()。它们只会在新生成 Fragment 对象时执行一遍。
3. 如果需要在生成 Fragment 对象后，将数据集里面一些动态的数据传递给该 Fragment，那么，这部分代码不适合放到 getItem() 中。因为当数据集发生变化时，往往对应的 Fragment 已经生成，如果传递数据部分代码放到了 getItem() 中，这部分代码将不会被调用。这也是为什么很多人发现调用 PagerAdapter.notifyDataSetChanged() 后，getItem() 没有被调用的一个原因。

* public Object instantiateItem()

    在每次 ViewPager 需要一个用以显示的 Object 的时候，该函数都会被 ViewPager.addNewItem() 调用。

1. 函数中判断一下要生成的 Fragment 是否已经生成过了，如果生成过了，就使用旧的，旧的将被 Fragment.attach()；如果没有，就调用 getItem() 生成一个新的，新的对象将被 FragmentTransation.add()。
2. FragmentPagerAdapter 会将所有生成的 Fragment 对象通过 FragmentManager 保存起来备用，以后需要该 Fragment 时，都会从 FragmentManager 读取，而不会再次调用 getItem() 方法。
3. 如果需要在生成 Fragment 对象后，将数据集中的一些数据传递给该 Fragment，这部分代码应该放到这个函数的重载里。在我们继承的子类中，重载该函数，并调用 FragmentPagerAdapter.instantiateItem() 取得该函数返回 Fragment 对象，然后，我们该 Fragment 对象中对应的方法，将数据传递过去，然后返回该对象。
4. 否则，如果将这部分传递数据的代码放到 getItem()中，在 PagerAdapter.notifyDataSetChanged() 后，这部分数据设置代码将不会被调用。


* public void notifyDataSetChanged()

    在数据集发生变化的时候，一般 Activity 会调用 PagerAdapter.notifyDataSetChanged()，以通知 PagerAdapter，而 PagerAdapter 则会通知在自己这里注册过的所有 DataSetObserver。其中之一就是在 ViewPager.setAdapter() 中注册过的 PageObserver。PageObserver 则进而调用 ViewPager.dataSetChanged()，从而导致 ViewPager 开始触发更新其内含 View 的操作。

参考资料:<a href=http://m.blog.csdn.net/shaoyezhangliwei/article/details/52488179>CSDN</a>