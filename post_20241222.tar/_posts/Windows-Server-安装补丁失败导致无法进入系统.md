---
title: Windows Server 安装补丁失败导致无法进入系统
tags:
  - 故障
  - 补丁
catergories:
  - Windows Server
date: 2020-01-22 00:13:49
---

# 故障描述

安装完补丁后，重启无法进入操作系统，也无法进入安全模式，只能打开命令提示符。

# 原因分析

安装补丁失败导致的：

1. 补丁直接安装失败；
2. 前置补丁未安装，直接安装最新的补丁，安装结束后未报错；

# 解决方案

解决流程：

1. 找到未安装成功的补丁包；
2. 移除未安装成功的补丁；

详情：

```bat
rem 查询系统盘的分区

diskpart
diskpart>list volume

rem 显示已安装的软件包
DISM /image:c:\ /get-packages /format:table

rem 删除安装包
dism /image:c:\ /remove-package /packagename:[包名]
```

# 参考资料

http://woshub.com/windows-wont-boot-after-updates/