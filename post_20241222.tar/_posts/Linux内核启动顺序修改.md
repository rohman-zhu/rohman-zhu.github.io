---
title: Linux内核启动顺序修改
tags:
  - 内核
categories:
  - Linux
date: 2023-04-05 15:13:07
---
# 背景

OS经常会安装新版本内核，而OS对内核版本有强关联，需要指定特定版本内核启动才可以。

# 操作方式

总的来说有两种方式：

1. 修改grub菜单，指定特定版本内核；
2. 删除非必要内核，关闭内核自动更新；

## 修改Grub菜单

### CentOS 6

```sh
vim /etc/grub.conf

# 在grub.conf文件中决定开机使用哪个内核版本做启动的参数是default，默认值为0，代表从最新的内核启动。
# 代表启动的内核版本从上往下依次是0、1、2等。
```

### CentOS 7

使用grub2作为引导程序；

```sh
# 1、执行如下命令，查看系统内部有多少个内核。
cat /boot/grub2/grub.cfg | grep menuentry

# 2、参考如下命令，配置从默认内核启动。内核名称根据系统内部查到的实际名称来替换。
grub2-set-default 'CentOS Linux (3.10.0-123.9.3.el7.x86_64) 7 (Core)'

# 3、执行如下命令，确认配置成功。
grub2-editenv list
```

### CentOS 8

```sh
# 1、执行下述命令查看默认内核
grubby --default-kernel

# 执行下述命令查看所有内核
grubby --info=ALL

# 2、设置需要设置的启动的默认的内核
rubby --set-default /boot/vmlinuz-4.18.0-80.11.2.el8_0.x86_64
```

### Ubuntu 

```sh
# 1、 查看当前内核的启动顺序
cat /boot/grub/grub.cfg |grep menuentry

# 2、修改grub文件
# 假设要修改为3.13.0-166内核启动, 修改文件/etc/default/grub

vim /etc/default/grub
GRUB_DEFAULT=0 修改为
GRUB_DEFAULT="Advanced options for Ubuntu>Ubuntu, with Linux 3.13.0-166-generic"
#注意GRUB_DEFAULT不要有多余的空格，导致无法正确识别

# 更新修改后的grub后执行下
update-grub
```



# 参考资料

https://blog.51cto.com/u_14757092/2631074