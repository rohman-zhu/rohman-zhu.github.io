---
title: VMWare P2V事宜
tags:
  - P2V
categories:
  - VMware
date: 2021-08-08 23:19:20
---

# P2V

## 应用场景

将物理机转化为虚拟机

## 流程

1. 在物理机源安装P2V的软件，如VMware-convert.exe
2. 检测克隆源与目标ESXi、vCenter之间的防火墙端口是否开通

|源地址|目的地址|TCP-端口|说明|
|:----:|:---:|:-----:|:----:|
|物理机源|目标ESXi|443,902||
|物理机源|目标vCenter|443|如果目标ESXi已托管至vCenter，则需要开通此端口|

## 参考资料

https://kb.vmware.com/s/article/1010056?lang=zh_cn
https://www.istartips.com/zh-CN/vmware-p2v.html