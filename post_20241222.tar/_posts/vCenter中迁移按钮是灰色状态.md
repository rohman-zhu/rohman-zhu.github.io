---
title: vCenter中迁移按钮是灰色状态
tags:
  - VMware
  - vSphere
categories:
  - 故障
  - KB
date: 2023-11-06 23:56:57
---
# 故障描述

虚拟机在vCenter中无法做vMotion，迁移按钮是灰色状态；

# 原因分析

虚拟机因为备份而被锁定，导致无法执行迁移操作；

# 解决方法

需要进入vCenter的PG数据库，将对应条目删除；

```sh
# 执行前，先对vCenter进行快照备份！！！！

# 登录 VCSA 的SSH Shell；

# 关闭vpxd服务
service-control --stop vmware-vpxd

# 登录 PG 数据库
/opt/vmware/vpostgres/current/bin/psql -d VCDB -U postgres

# 查询目标虚拟机的VM-ID
# 语句：select * from VPX_VM WHERE FILE_NAME LIKE '%Virtual_Machine_Name%';
# 比如
select * from VPX_VM WHERE FILE_NAME LIKE '%[rohmanvm]%';

# 获取到虚拟机的ID

# 获取虚拟机执行的条目
select * from VPX_DISABLED_METHODS WHERE ENTITY_MO_ID_VAL = 'vm-[ID编码]';

# 删除编码
delete from VPX_DISABLED_METHODS WHERE ENTITY_MO_ID_VAL = 'vm-[ID编码]';

# 启动vCenter服务
service-control --start vmware-vpxd

```

# 参考资料

https://kb.vmware.com/s/article/1029926?lang=zh_CN

https://kb.vmware.com/s/article/2044369