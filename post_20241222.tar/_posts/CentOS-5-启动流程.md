---
title: CentOS_5_启动流程
date: 2017-10-03 11:21:34
tags: Linux
---

1. 开机自检 （BIOS）
2. MBR 引导
3. GRUB菜单
4. 加载内核（kernel）
5. 运行 _INIT_ 进行
6. 读取 /etc/inittab 配置文件
7. 执行 /etc/rc.d/rc.sysinit 脚本
8. 执行 /etc/rc.d/rc 脚本
    * /etc/rc0.d/*
    * /etc/rc1.d/*
    * /etc/rc2.d/*
    * /etc/rc3.d/*
    * /etc/rc4.d/*
    * /etc/rc5.d/*
    * /etc/rc5.d/*

    > 根据运行级别选择运行的rc脚本


9. 启动 mingetty 进程
    