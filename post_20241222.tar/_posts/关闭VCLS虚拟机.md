---
title: 关闭VCLS虚拟机
tags:
  - default
categories:
  - VMware
  - vSphere
date: 2023-11-15 00:08:09
---
# 需求描述

从 vSphere 7 开始，集群中会部署vCLS虚拟机用于集群管理；但是vCLS虚拟机需要检查ESXi主机的BIOS设置，CPU选项需要开启“MWAIT”选项。
如果没有开启，则vCLS虚拟机会无法启动，而vCenter会一直尝试部署开机；

因此短期需要关闭vCLS部署；长期来看，需要开启底层BIOS设置；

> Monitor 指令：MONITOR EAX, ECX, EDX；设置硬件要监视的线性地址范围，并激活监视器。地址范围应该是写回内存缓存型。

> Mwait指令：MwAIT EAX, ECX；这是一个提示，允许处理器停止指令执行，并进入取决于具体版本的优化状态，直到发生某类事件。

# 操作步骤

1. 登录 vCenter Client；
2. 选中集群，会在URL中看到集群域ID，类似于 domain-c<number>；
3. 进入vCenter配置选项；
4. 进入高级配置选项；点击编辑设置；
5. 添加参数  config.vcls.clusters.domain-c<number>.enabled 且值为 False 的新条目；
6. 保存退出即可；

> 设置完后，vCLS 监控服务将启动 vCLS 虚拟机的清理，用户将开始看到删除虚拟机的任务。 
> 如果此集群启用了 DRS，则它将不起作用，并会在集群摘要中显示额外的警告。在此集群上重新启用 vCLS 之前，DRS 将一直处于禁用状态。 
> 要从集群中移除撤回模式，请在上面的步骤 5 中将值更改为 True。 


# 参考资料

https://kb.vmware.com/s/article/80472?lang=zh_CN
Mwait设置： https://support.huawei.com/enterprise/zh/knowledge/EKB1100006339