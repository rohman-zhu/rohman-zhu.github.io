---
title: Windows Powershell 相关脚本
tags:
  - default
catergories:
  - default
date: 2020-01-30 23:28:05
---

```ps1
#无法运行近脚本
set-executionpolicy RemoteSigned



```

## 使用脚本固定IP


```ps1
# 这是CMD的命令
# netsh interface ipv4 set address name="网卡名" static add="0.0.0.0" mask="255.255.255.0" gateway="0.0.0.1"

$NIC_NAME="以太网"
$TARGET_IP="192.168.1.1"
$MASK="255.255.255.0"
$GATEWAY="192.168.1.254"

netsh interface ipv4 set address name=$NIC_NAME static add=$TARGET_IP mask=$MASK gw=$GATEWAY
```

## 使用脚本更改DNS

```ps1
# 这是CMD的命令
# netsh interface ipv4 set dns name="网卡名" static addr="8.8.8.8" register=PRIMARY
# netsh interface ipv4 add dns name="网卡名" addr="8.8.0.0" index=2
$NIC_NAME="以太网"
$MAIN_DNS="8.8.8.8"
$BAK_DNS="8.8.0.0"

netsh interface ipv4 set dns name=$NIC_NAME static addr=$MAIN_DNS register=PRIMARY
netsh interface ipv4 add dns name=$BAK_DNS index=2
```

```ps1
#Powershell
# 
# 查看ipv4与ipv6的DNS 命令 Get-DnsClientServerAddress 
# 查看ipv4的DNS 命令 Get-DnsClientServerAddress -AddressFamily ipv4


```

## 利用脚本关闭服务

```ps1
# Powershell 脚本
# set-service "服务名" -StartupType Disabled
set-service "vminit service" -StartupType Disabled
```

## 利用脚本加域

```ps1
$CURRENT_HOSTNAME=hostname
$NEW_HOSTNAME="新电脑名"
# 也可以通过脚本参数获取 ，例如第一位参数 $($args[0])
# $NEW_HOSTNAME=$($args[0])
$DOMAIN="domain.com"

add-computer -computername $CURRENT_HOSTNAME -newname $NEW_HOSTNAME -domain $DOMAIN
# 在弹窗中输入账户密码

#检测加域是否成功
$isJoinDomain=Test-ComputerSecureChannel
if($isJoinDomain -cmatch "True" )
{
  Write-Host "加入 $DOMAIN 域成功。"
}
else
{
  Write-Host "加域失败，请重新检查加域操作。"
}
```

## 添加用户

```ps1
# 添加账户到administrators组
# net localgroup administrators /add "domain.com"\"rohman"
$TARGET_USER="Rohman"
$DOMAIN="WORKGROUP"
$TARGET_GROUP="Administators"

net localgroup $TARGET_GROUP /add $DOMAIN\$TARGET_USER

# 检测用户是否添加成功
$CurrentGroupUser= get-localgroupmember -group $TARGET_GROUP | findstr $DOMAIN

if ( $CurrentGroupUser -cmatch $TARGET_USER )
{
  Write-Host "用户 $TARGET_USER 已添加到 $TARGET_GROUP 中。"
}
else
{
  Write-Host "添加用户失败，请重新检查用户名。"
}
```

# 参考资料

https://blog.csdn.net/weixin_34415923/article/details/92337634
Powershell 定义变量 ：  https://www.pstips.net/powershell-define-variable.html
https://www.cnblogs.com/wenzhongxiang/p/10357154.html
https://www.cnblogs.com/wenzhongxiang/p/10357154.html