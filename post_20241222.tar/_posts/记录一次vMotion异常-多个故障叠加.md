---
title: 记录一次vMotion异常-多个故障叠加
tags:
  - 故障
categories:
  - VMware
  - vSphere
date: 2024-07-21 21:59:16
---

# 故障描述

一台虚拟机要做存储迁移，该虚拟机规格是一台高负载、高配置的复杂虚拟机，虚拟机有40多个vmdk，OS内通过LVM做了条带卷。

第一次迁移，选择一次性同时迁移6块盘，该任务耗时 3 个小时左右，最终提示"Operation timed out"；

第二次迁移，选择单次仅迁移1块盘，任务均会提示失败，提示"The operation is not allowed in the cureent state.The operation cannot be performed because VM migration is in progress.";

第三次迁移，选择仅迁移计算资源，任务均会提示失败，提示"The operation is not allowed in the cureent state.The operation cannot be performed because VM migration is in progress.";

第四次迁移，选择仅迁移1块盘，这次任务正常了，任务耗时较久，为54分钟；


# 原因分析

第一次迁移失败，可能是因为该虚拟机负载过高，vMotion过程需要拷贝原始数据，但数据变化量远远超过vMotion所能承受的极限，在第一次vMotion任务至第四次vMotion任务期间，可以观测到虚拟机整体的IOPS在 10K-17K 之间。

第二次迁移失败，因为在此时发现VCSA有异常，LOG目录的空间被写满，导致vpxd服务异常，因此对VCSA做了扩容修复，并重启了VCSA；这个过程导致VCSA的任务管理异常，迁移任务处于未释放的状态；且重启完VCSA后，选择VCSA的时候，会提示还在同步中；

```sh
# 在VCSA中，可以查到有很多 TASK ID
# 参考：https://blogs.vmware.com/vsphere/2019/09/troubleshooting-vmotion.html
grep "relocate" /var/log/vmware/vpxd/vpxd-*.log | grep BEGIN
```

```sh
# 分析ESXi的hostd日志
# 会有提示
Hostlog_ExecuteCleanup:Failed to start disk /vmfs/xxxxxxx.vmdk - not cleaning up.xxxxx
#  磁盘任务失败；

# 任务状态也会异常
Invlid transition requested (VM_STATE_EMIGRATING -> VM_STATE_CREATE_SCREENSHOT):Invalid state;
```

# 解决方法

1. VCSA要确保正常，各项服务需要是正常运行的；
2. ESXi可以尝试重启管理程序，或者在VCSA中试试断开连接后重连；
3. 针对这种类型的虚拟机，迁移时尽可能选择较少的磁盘迁移，每次仅迁移一块磁盘；

> 留一个方案： 假如我调整了ESXi的 Stream Helper是否会有帮助呢？